package classDirectlyOrderTransfer;

public class ClassDirectlyOrderTransferPortProxy implements classDirectlyOrderTransfer.ClassDirectlyOrderTransferPort {
  private String _endpoint = null;
  private classDirectlyOrderTransfer.ClassDirectlyOrderTransferPort classDirectlyOrderTransferPort = null;
  
  public ClassDirectlyOrderTransferPortProxy() {
    _initClassDirectlyOrderTransferPortProxy();
  }
  
  public ClassDirectlyOrderTransferPortProxy(String endpoint) {
    _endpoint = endpoint;
    _initClassDirectlyOrderTransferPortProxy();
  }
  
  private void _initClassDirectlyOrderTransferPortProxy() {
    try {
      classDirectlyOrderTransferPort = (new classDirectlyOrderTransfer.ClassDirectlyOrderTransferServiceLocator()).getclassDirectlyOrderTransferPort();
      if (classDirectlyOrderTransferPort != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)classDirectlyOrderTransferPort)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)classDirectlyOrderTransferPort)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (classDirectlyOrderTransferPort != null)
      ((javax.xml.rpc.Stub)classDirectlyOrderTransferPort)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public classDirectlyOrderTransfer.ClassDirectlyOrderTransferPort getClassDirectlyOrderTransferPort() {
    if (classDirectlyOrderTransferPort == null)
      _initClassDirectlyOrderTransferPortProxy();
    return classDirectlyOrderTransferPort;
  }
  
  public classDirectlyOrderTransfer.GetListTransferingOrdersResult getListTransferingOrders(java.lang.String tradingDate, java.lang.String authenUser, java.lang.String authenPass) throws java.rmi.RemoteException{
    if (classDirectlyOrderTransferPort == null)
      _initClassDirectlyOrderTransferPortProxy();
    return classDirectlyOrderTransferPort.getListTransferingOrders(tradingDate, authenUser, authenPass);
  }
  
  public classDirectlyOrderTransfer.GetListAdOrdersResult getListAdOrders(java.lang.String tradingDate, java.lang.String authenUser, java.lang.String authenPass) throws java.rmi.RemoteException{
    if (classDirectlyOrderTransferPort == null)
      _initClassDirectlyOrderTransferPortProxy();
    return classDirectlyOrderTransferPort.getListAdOrders(tradingDate, authenUser, authenPass);
  }
  
  public classDirectlyOrderTransfer.UpdateReject2GResult updateReject2G(java.lang.String messageType, java.lang.String firm, java.lang.String rejectReasonCode, java.lang.String originalMessageText, java.lang.String authenUser, java.lang.String authenPass) throws java.rmi.RemoteException{
    if (classDirectlyOrderTransferPort == null)
      _initClassDirectlyOrderTransferPortProxy();
    return classDirectlyOrderTransferPort.updateReject2G(messageType, firm, rejectReasonCode, originalMessageText, authenUser, authenPass);
  }
  
  public classDirectlyOrderTransfer.Update1IOrderResult update1IOrder(java.lang.String messageType, java.lang.String firm, java.lang.String orderNumber, java.lang.String orderDate, java.lang.String rejectCode, java.lang.String messageText, java.lang.String authenUser, java.lang.String authenPass) throws java.rmi.RemoteException{
    if (classDirectlyOrderTransferPort == null)
      _initClassDirectlyOrderTransferPortProxy();
    return classDirectlyOrderTransferPort.update1IOrder(messageType, firm, orderNumber, orderDate, rejectCode, messageText, authenUser, authenPass);
  }
  
  public classDirectlyOrderTransfer.UpdateOrder2BResult updateOrder2B(java.lang.String messageType, java.lang.String firm, java.lang.String orderNumber, java.lang.String orderEntryDate, java.lang.String rejectCode, java.lang.String messageText, java.lang.String authenUser, java.lang.String authenPass) throws java.rmi.RemoteException{
    if (classDirectlyOrderTransferPort == null)
      _initClassDirectlyOrderTransferPortProxy();
    return classDirectlyOrderTransferPort.updateOrder2B(messageType, firm, orderNumber, orderEntryDate, rejectCode, messageText, authenUser, authenPass);
  }
  
  public classDirectlyOrderTransfer.UpdateOrder2CResult updateOrder2C(java.lang.String messageType, java.lang.String firm, java.lang.String cancelShares, java.lang.String orderNumber, java.lang.String orderEntryDate, java.lang.String orderCancelStatus, java.lang.String rejectCode, java.lang.String messageText, java.lang.String authenUser, java.lang.String authenPass) throws java.rmi.RemoteException{
    if (classDirectlyOrderTransferPort == null)
      _initClassDirectlyOrderTransferPortProxy();
    return classDirectlyOrderTransferPort.updateOrder2C(messageType, firm, cancelShares, orderNumber, orderEntryDate, orderCancelStatus, rejectCode, messageText, authenUser, authenPass);
  }
  
  public classDirectlyOrderTransfer.UpdateOrder2DResult updateOrder2D(java.lang.String messageType, java.lang.String firm, java.lang.String orderNumber, java.lang.String orderEntryDate, java.lang.String clientID, java.lang.String portClientFlag, java.lang.String publishedVolume, java.lang.String price, java.lang.String filler, java.lang.String rejectCode, java.lang.String messageText, java.lang.String authenUser, java.lang.String authenPass) throws java.rmi.RemoteException{
    if (classDirectlyOrderTransferPort == null)
      _initClassDirectlyOrderTransferPortProxy();
    return classDirectlyOrderTransferPort.updateOrder2D(messageType, firm, orderNumber, orderEntryDate, clientID, portClientFlag, publishedVolume, price, filler, rejectCode, messageText, authenUser, authenPass);
  }
  
  public classDirectlyOrderTransfer.UpdateMatchOrder2EResult updateMatchOrder2E(java.lang.String messageType, java.lang.String firm, java.lang.String side, java.lang.String orderNumber, java.lang.String orderEntryDate, java.lang.String filler, java.lang.String volume, java.lang.String price, java.lang.String confirmNumber, java.lang.String authenUser, java.lang.String authenPass) throws java.rmi.RemoteException{
    if (classDirectlyOrderTransferPort == null)
      _initClassDirectlyOrderTransferPortProxy();
    return classDirectlyOrderTransferPort.updateMatchOrder2E(messageType, firm, side, orderNumber, orderEntryDate, filler, volume, price, confirmNumber, authenUser, authenPass);
  }
  
  public classDirectlyOrderTransfer.UpdateMatchOrder2IResult updateMatchOrder2I(java.lang.String messageType, java.lang.String firm, java.lang.String orderNumberBuy, java.lang.String orderEntryDateBuy, java.lang.String orderNumberSell, java.lang.String orderEntryDateSell, java.lang.String volume, java.lang.String price, java.lang.String confirmNumber, java.lang.String authenUser, java.lang.String authenPass) throws java.rmi.RemoteException{
    if (classDirectlyOrderTransferPort == null)
      _initClassDirectlyOrderTransferPortProxy();
    return classDirectlyOrderTransferPort.updateMatchOrder2I(messageType, firm, orderNumberBuy, orderEntryDateBuy, orderNumberSell, orderEntryDateSell, volume, price, confirmNumber, authenUser, authenPass);
  }
  
  public classDirectlyOrderTransfer.UpdateConfirmDealOrder2LResult updateConfirmDealOrder2L(java.lang.String messageType, java.lang.String firm, java.lang.String side, java.lang.String dealID, java.lang.String contraFirm, java.lang.String volume, java.lang.String price, java.lang.String confirmNumber, java.lang.String authenUser, java.lang.String authenPass) throws java.rmi.RemoteException{
    if (classDirectlyOrderTransferPort == null)
      _initClassDirectlyOrderTransferPortProxy();
    return classDirectlyOrderTransferPort.updateConfirmDealOrder2L(messageType, firm, side, dealID, contraFirm, volume, price, confirmNumber, authenUser, authenPass);
  }
  
  public classDirectlyOrderTransfer.UpdateAdmin3AResult updateAdmin3A(java.lang.String messageType, java.lang.String firm, java.lang.String traderIDSender, java.lang.String traderIDReciever, java.lang.String contraFirm, java.lang.String adminMessageText, java.lang.String authenUser, java.lang.String authenPass) throws java.rmi.RemoteException{
    if (classDirectlyOrderTransferPort == null)
      _initClassDirectlyOrderTransferPortProxy();
    return classDirectlyOrderTransferPort.updateAdmin3A(messageType, firm, traderIDSender, traderIDReciever, contraFirm, adminMessageText, authenUser, authenPass);
  }
  
  public classDirectlyOrderTransfer.UpdateDealOrder2FResult updateDealOrder2F(java.lang.String messageType, java.lang.String firmBuy, java.lang.String traderIDBuy, java.lang.String sideB, java.lang.String contraFirmSell, java.lang.String traderIDContraSideSell, java.lang.String securitySymbol, java.lang.String volume, java.lang.String price, java.lang.String board, java.lang.String confirmNumber, java.lang.String authenUser, java.lang.String authenPass) throws java.rmi.RemoteException{
    if (classDirectlyOrderTransferPort == null)
      _initClassDirectlyOrderTransferPortProxy();
    return classDirectlyOrderTransferPort.updateDealOrder2F(messageType, firmBuy, traderIDBuy, sideB, contraFirmSell, traderIDContraSideSell, securitySymbol, volume, price, board, confirmNumber, authenUser, authenPass);
  }
  
  public classDirectlyOrderTransfer.UpdateResultDealOrder3BResult updateResultDealOrder3B(java.lang.String messageType, java.lang.String firm, java.lang.String confirmNumber, java.lang.String dealID, java.lang.String clientIDBuyer, java.lang.String replyCode, java.lang.String filler, java.lang.String brokerPortfolioVolume, java.lang.String brokerClientVolume, java.lang.String brokerMutualFundVolume, java.lang.String brokerForeignVolume, java.lang.String filler2, java.lang.String authenUser, java.lang.String authenPass) throws java.rmi.RemoteException{
    if (classDirectlyOrderTransferPort == null)
      _initClassDirectlyOrderTransferPortProxy();
    return classDirectlyOrderTransferPort.updateResultDealOrder3B(messageType, firm, confirmNumber, dealID, clientIDBuyer, replyCode, filler, brokerPortfolioVolume, brokerClientVolume, brokerMutualFundVolume, brokerForeignVolume, filler2, authenUser, authenPass);
  }
  
  public classDirectlyOrderTransfer.UpdateCancelDealOrder3CResult updateCancelDealOrder3C(java.lang.String messageType, java.lang.String firm, java.lang.String contraFirm, java.lang.String traderID, java.lang.String confirmNumber, java.lang.String securitySymbol, java.lang.String side, java.lang.String authenUser, java.lang.String authenPass) throws java.rmi.RemoteException{
    if (classDirectlyOrderTransferPort == null)
      _initClassDirectlyOrderTransferPortProxy();
    return classDirectlyOrderTransferPort.updateCancelDealOrder3C(messageType, firm, contraFirm, traderID, confirmNumber, securitySymbol, side, authenUser, authenPass);
  }
  
  public classDirectlyOrderTransfer.UpdateCancelDealOrder3DResult updateCancelDealOrder3D(java.lang.String messageType, java.lang.String firm, java.lang.String confirmNumber, java.lang.String replyCode, java.lang.String authenUser, java.lang.String authenPass) throws java.rmi.RemoteException{
    if (classDirectlyOrderTransferPort == null)
      _initClassDirectlyOrderTransferPortProxy();
    return classDirectlyOrderTransferPort.updateCancelDealOrder3D(messageType, firm, confirmNumber, replyCode, authenUser, authenPass);
  }
  
  public classDirectlyOrderTransfer.InsertAAResult insertAA(java.lang.String messageType, java.lang.String securityNumber, java.lang.String volume, java.lang.String price, java.lang.String firm, java.lang.String trader, java.lang.String side, java.lang.String board, java.lang.String time, java.lang.String addCancelFlag, java.lang.String contact, java.lang.String authenUser, java.lang.String authenPass) throws java.rmi.RemoteException{
    if (classDirectlyOrderTransferPort == null)
      _initClassDirectlyOrderTransferPortProxy();
    return classDirectlyOrderTransferPort.insertAA(messageType, securityNumber, volume, price, firm, trader, side, board, time, addCancelFlag, contact, authenUser, authenPass);
  }
  
  public classDirectlyOrderTransfer.InsertBRResult insertBR(java.lang.String messageType, java.lang.String firm, java.lang.String marketID, java.lang.String volumeSold, java.lang.String valueSold, java.lang.String volumeBought, java.lang.String valueBought, java.lang.String authenUser, java.lang.String authenPass) throws java.rmi.RemoteException{
    if (classDirectlyOrderTransferPort == null)
      _initClassDirectlyOrderTransferPortProxy();
    return classDirectlyOrderTransferPort.insertBR(messageType, firm, marketID, volumeSold, valueSold, volumeBought, valueBought, authenUser, authenPass);
  }
  
  public classDirectlyOrderTransfer.InsertBSResult insertBS(java.lang.String messageType, java.lang.String firm, java.lang.String autoMatchHaltFlag, java.lang.String putthroughHaltFlag, java.lang.String authenUser, java.lang.String authenPass) throws java.rmi.RemoteException{
    if (classDirectlyOrderTransferPort == null)
      _initClassDirectlyOrderTransferPortProxy();
    return classDirectlyOrderTransferPort.insertBS(messageType, firm, autoMatchHaltFlag, putthroughHaltFlag, authenUser, authenPass);
  }
  
  public classDirectlyOrderTransfer.InsertCOResult insertCO(java.lang.String messageType, java.lang.String referenceNumber, java.lang.String authenUser, java.lang.String authenPass) throws java.rmi.RemoteException{
    if (classDirectlyOrderTransferPort == null)
      _initClassDirectlyOrderTransferPortProxy();
    return classDirectlyOrderTransferPort.insertCO(messageType, referenceNumber, authenUser, authenPass);
  }
  
  public classDirectlyOrderTransfer.InsertDCResult insertDC(java.lang.String messageType, java.lang.String confirmNumber, java.lang.String securityNumber, java.lang.String volume, java.lang.String price, java.lang.String board, java.lang.String authenUser, java.lang.String authenPass) throws java.rmi.RemoteException{
    if (classDirectlyOrderTransferPort == null)
      _initClassDirectlyOrderTransferPortProxy();
    return classDirectlyOrderTransferPort.insertDC(messageType, confirmNumber, securityNumber, volume, price, board, authenUser, authenPass);
  }
  
  public classDirectlyOrderTransfer.InsertGAResult insertGA(java.lang.String messageType, java.lang.String adminMessageLengh, java.lang.String adminMessageText, java.lang.String authenUser, java.lang.String authenPass) throws java.rmi.RemoteException{
    if (classDirectlyOrderTransferPort == null)
      _initClassDirectlyOrderTransferPortProxy();
    return classDirectlyOrderTransferPort.insertGA(messageType, adminMessageLengh, adminMessageText, authenUser, authenPass);
  }
  
  public classDirectlyOrderTransfer.InsertIUResult insertIU(java.lang.String messageType, java.lang.String indexHoSE, java.lang.String totalTrades, java.lang.String totalSharesTraded, java.lang.String totalValuesTraded, java.lang.String upVolume, java.lang.String downVolume, java.lang.String noChangeVolume, java.lang.String advances, java.lang.String declines, java.lang.String noChange, java.lang.String filler1, java.lang.String marketID, java.lang.String filler2, java.lang.String indexTime, java.lang.String authenUser, java.lang.String authenPass) throws java.rmi.RemoteException{
    if (classDirectlyOrderTransferPort == null)
      _initClassDirectlyOrderTransferPortProxy();
    return classDirectlyOrderTransferPort.insertIU(messageType, indexHoSE, totalTrades, totalSharesTraded, totalValuesTraded, upVolume, downVolume, noChangeVolume, advances, declines, noChange, filler1, marketID, filler2, indexTime, authenUser, authenPass);
  }
  
  public classDirectlyOrderTransfer.InsertLOResult insertLO(java.lang.String messageType, java.lang.String confirmNumber, java.lang.String securityNumber, java.lang.String oddLotVolume, java.lang.String price, java.lang.String referenceNumber, java.lang.String authenUser, java.lang.String authenPass) throws java.rmi.RemoteException{
    if (classDirectlyOrderTransferPort == null)
      _initClassDirectlyOrderTransferPortProxy();
    return classDirectlyOrderTransferPort.insertLO(messageType, confirmNumber, securityNumber, oddLotVolume, price, referenceNumber, authenUser, authenPass);
  }
  
  public classDirectlyOrderTransfer.InsertLSResult insertLS(java.lang.String messageType, java.lang.String confirmNumber, java.lang.String securityNumber, java.lang.String lotVolume, java.lang.String price, java.lang.String side, java.lang.String authenUser, java.lang.String authenPass) throws java.rmi.RemoteException{
    if (classDirectlyOrderTransferPort == null)
      _initClassDirectlyOrderTransferPortProxy();
    return classDirectlyOrderTransferPort.insertLS(messageType, confirmNumber, securityNumber, lotVolume, price, side, authenUser, authenPass);
  }
  
  public classDirectlyOrderTransfer.InsertNHResult insertNH(java.lang.String messageType, java.lang.String newsNumber, java.lang.String securitySymbol, java.lang.String newsHeadlineLength, java.lang.String totalNewsStoryPages, java.lang.String newsHeadlineText, java.lang.String authenUser, java.lang.String authenPass) throws java.rmi.RemoteException{
    if (classDirectlyOrderTransferPort == null)
      _initClassDirectlyOrderTransferPortProxy();
    return classDirectlyOrderTransferPort.insertNH(messageType, newsNumber, securitySymbol, newsHeadlineLength, totalNewsStoryPages, newsHeadlineText, authenUser, authenPass);
  }
  
  public classDirectlyOrderTransfer.InsertNSResult insertNS(java.lang.String messageType, java.lang.String newsNumber, java.lang.String newsPageNumber, java.lang.String newsTextLength, java.lang.String newsText, java.lang.String authenUser, java.lang.String authenPass) throws java.rmi.RemoteException{
    if (classDirectlyOrderTransferPort == null)
      _initClassDirectlyOrderTransferPortProxy();
    return classDirectlyOrderTransferPort.insertNS(messageType, newsNumber, newsPageNumber, newsTextLength, newsText, authenUser, authenPass);
  }
  
  public classDirectlyOrderTransfer.InsertOLResult insertOL(java.lang.String messageType, java.lang.String securityNumber, java.lang.String oddLotVolume, java.lang.String price, java.lang.String side, java.lang.String referenceNumber, java.lang.String authenUser, java.lang.String authenPass) throws java.rmi.RemoteException{
    if (classDirectlyOrderTransferPort == null)
      _initClassDirectlyOrderTransferPortProxy();
    return classDirectlyOrderTransferPort.insertOL(messageType, securityNumber, oddLotVolume, price, side, referenceNumber, authenUser, authenPass);
  }
  
  public classDirectlyOrderTransfer.InsertOSResult insertOS(java.lang.String messageType, java.lang.String securityNumber, java.lang.String price, java.lang.String authenUser, java.lang.String authenPass) throws java.rmi.RemoteException{
    if (classDirectlyOrderTransferPort == null)
      _initClassDirectlyOrderTransferPortProxy();
    return classDirectlyOrderTransferPort.insertOS(messageType, securityNumber, price, authenUser, authenPass);
  }
  
  public classDirectlyOrderTransfer.InsertPDResult insertPD(java.lang.String messageType, java.lang.String confirmNumber, java.lang.String securityNumber, java.lang.String volume, java.lang.String price, java.lang.String board, java.lang.String authenUser, java.lang.String authenPass) throws java.rmi.RemoteException{
    if (classDirectlyOrderTransferPort == null)
      _initClassDirectlyOrderTransferPortProxy();
    return classDirectlyOrderTransferPort.insertPD(messageType, confirmNumber, securityNumber, volume, price, board, authenUser, authenPass);
  }
  
  public classDirectlyOrderTransfer.InsertPOResult insertPO(java.lang.String messageType, java.lang.String securityNumber, java.lang.String projectedOpenPrice, java.lang.String authenUser, java.lang.String authenPass) throws java.rmi.RemoteException{
    if (classDirectlyOrderTransferPort == null)
      _initClassDirectlyOrderTransferPortProxy();
    return classDirectlyOrderTransferPort.insertPO(messageType, securityNumber, projectedOpenPrice, authenUser, authenPass);
  }
  
  public classDirectlyOrderTransfer.InsertSCResult insertSC(java.lang.String messageType, java.lang.String systemControlCode, java.lang.String timestamp, java.lang.String authenUser, java.lang.String authenPass) throws java.rmi.RemoteException{
    if (classDirectlyOrderTransferPort == null)
      _initClassDirectlyOrderTransferPortProxy();
    return classDirectlyOrderTransferPort.insertSC(messageType, systemControlCode, timestamp, authenUser, authenPass);
  }
  
  public classDirectlyOrderTransfer.InsertSIResult insertSI(java.lang.String messageType, java.lang.String indexSectoral, java.lang.String filler, java.lang.String indexTime, java.lang.String authenUser, java.lang.String authenPass) throws java.rmi.RemoteException{
    if (classDirectlyOrderTransferPort == null)
      _initClassDirectlyOrderTransferPortProxy();
    return classDirectlyOrderTransferPort.insertSI(messageType, indexSectoral, filler, indexTime, authenUser, authenPass);
  }
  
  public classDirectlyOrderTransfer.InsertSRResult insertSR(java.lang.String messageType, java.lang.String mainOrForeignDeal, java.lang.String mainOrForeignAccVolume, java.lang.String mainOrForeignAccValue, java.lang.String dealsInBigLotBoard, java.lang.String bigLotAccVolume, java.lang.String bigLotAccValue, java.lang.String dealsInOddLotBoard, java.lang.String oddLotAccVolume, java.lang.String oddLotAccValue, java.lang.String authenUser, java.lang.String authenPass) throws java.rmi.RemoteException{
    if (classDirectlyOrderTransferPort == null)
      _initClassDirectlyOrderTransferPortProxy();
    return classDirectlyOrderTransferPort.insertSR(messageType, mainOrForeignDeal, mainOrForeignAccVolume, mainOrForeignAccValue, dealsInBigLotBoard, bigLotAccVolume, bigLotAccValue, dealsInOddLotBoard, oddLotAccVolume, oddLotAccValue, authenUser, authenPass);
  }
  
  public classDirectlyOrderTransfer.InsertSSResult insertSS(java.lang.String messageType, java.lang.String securityNumber, java.lang.String filler1, java.lang.String sectorNumber, java.lang.String filler2, java.lang.String haltorResumeFlag, java.lang.String systemControlCode, java.lang.String filler3, java.lang.String suspension, java.lang.String delist, java.lang.String filler4, java.lang.String ceiling, java.lang.String floorPrice, java.lang.String securityType, java.lang.String priorClosePrice, java.lang.String filler5, java.lang.String split, java.lang.String benefit, java.lang.String meeting, java.lang.String notice, java.lang.String boardLot, java.lang.String filler6, java.lang.String authenUser, java.lang.String authenPass) throws java.rmi.RemoteException{
    if (classDirectlyOrderTransferPort == null)
      _initClassDirectlyOrderTransferPortProxy();
    return classDirectlyOrderTransferPort.insertSS(messageType, securityNumber, filler1, sectorNumber, filler2, haltorResumeFlag, systemControlCode, filler3, suspension, delist, filler4, ceiling, floorPrice, securityType, priorClosePrice, filler5, split, benefit, meeting, notice, boardLot, filler6, authenUser, authenPass);
  }
  
  public classDirectlyOrderTransfer.InsertSUResult insertSU(java.lang.String messageType, java.lang.String securityNumberOld, java.lang.String securityNumberNew, java.lang.String filler1, java.lang.String sectorNumber, java.lang.String filler2, java.lang.String securitySymbol, java.lang.String securityType, java.lang.String ceilingPrice, java.lang.String floorPrice, java.lang.String lastSalePrice, java.lang.String marketID, java.lang.String filler3, java.lang.String securityName, java.lang.String filler4, java.lang.String suspension, java.lang.String delist, java.lang.String haltorResumeFlag, java.lang.String split, java.lang.String benefit, java.lang.String meeting, java.lang.String notice, java.lang.String clientIDRequired, java.lang.String parValue, java.lang.String SDCFlag, java.lang.String priorClosePrice, java.lang.String priorCloseDate, java.lang.String openPrice, java.lang.String highestPrice, java.lang.String lowestPrice, java.lang.String totalSharesTraded, java.lang.String totalValuesTraded, java.lang.String boardLot, java.lang.String filler5, java.lang.String authenUser, java.lang.String authenPass) throws java.rmi.RemoteException{
    if (classDirectlyOrderTransferPort == null)
      _initClassDirectlyOrderTransferPortProxy();
    return classDirectlyOrderTransferPort.insertSU(messageType, securityNumberOld, securityNumberNew, filler1, sectorNumber, filler2, securitySymbol, securityType, ceilingPrice, floorPrice, lastSalePrice, marketID, filler3, securityName, filler4, suspension, delist, haltorResumeFlag, split, benefit, meeting, notice, clientIDRequired, parValue, SDCFlag, priorClosePrice, priorCloseDate, openPrice, highestPrice, lowestPrice, totalSharesTraded, totalValuesTraded, boardLot, filler5, authenUser, authenPass);
  }
  
  public classDirectlyOrderTransfer.InsertTCResult insertTC(java.lang.String messageType, java.lang.String firm, java.lang.String traderID, java.lang.String traderStatus, java.lang.String authenUser, java.lang.String authenPass) throws java.rmi.RemoteException{
    if (classDirectlyOrderTransferPort == null)
      _initClassDirectlyOrderTransferPortProxy();
    return classDirectlyOrderTransferPort.insertTC(messageType, firm, traderID, traderStatus, authenUser, authenPass);
  }
  
  public classDirectlyOrderTransfer.InsertTPResult insertTP(java.lang.String messageType, java.lang.String securityNumber, java.lang.String side, java.lang.String price1Best, java.lang.String lotVolume1, java.lang.String price2Best, java.lang.String lotVolume2, java.lang.String price3Best, java.lang.String lotVolume3, java.lang.String authenUser, java.lang.String authenPass) throws java.rmi.RemoteException{
    if (classDirectlyOrderTransferPort == null)
      _initClassDirectlyOrderTransferPortProxy();
    return classDirectlyOrderTransferPort.insertTP(messageType, securityNumber, side, price1Best, lotVolume1, price2Best, lotVolume2, price3Best, lotVolume3, authenUser, authenPass);
  }
  
  public classDirectlyOrderTransfer.InsertTRResult insertTR(java.lang.String messageType, java.lang.String securityNumber, java.lang.String totalRoom, java.lang.String currentRoom, java.lang.String authenUser, java.lang.String authenPass) throws java.rmi.RemoteException{
    if (classDirectlyOrderTransferPort == null)
      _initClassDirectlyOrderTransferPortProxy();
    return classDirectlyOrderTransferPort.insertTR(messageType, securityNumber, totalRoom, currentRoom, authenUser, authenPass);
  }
  
  public classDirectlyOrderTransfer.InsertTSResult insertTS(java.lang.String messageType, java.lang.String timestamp, java.lang.String authenUser, java.lang.String authenPass) throws java.rmi.RemoteException{
    if (classDirectlyOrderTransferPort == null)
      _initClassDirectlyOrderTransferPortProxy();
    return classDirectlyOrderTransferPort.insertTS(messageType, timestamp, authenUser, authenPass);
  }
  
  
}