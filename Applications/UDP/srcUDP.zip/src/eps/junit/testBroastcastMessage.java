package eps.junit;

import junit.framework.TestCase;

import org.junit.Test;

import eps.com.common.ValueObject;
import eps.com.message.broadcast.*;
import eps.com.util.MessageUtil;
import static junit.framework.Assert.*;

import org.junit.Test;
public class testBroastcastMessage{

	public testBroastcastMessage() {
		
		testMessage2tobyteAndbytetoMessage_TR();
	}

	/**
	 * @param args
	 */
//	public static void main(String[] args) {
//		// TODO Auto-generated method stub
//		new testBroastcastMessage();
//		
//	}
	
	@Test 
	public void testMessage2tobyteAndbytetoMessage_TS()
	{
		TimeStamp_TS ts = new TimeStamp_TS();
		ts.setTimestamp(2532);
		byte[] message2Bytes = MessageUtil.message2Bytes(ts);
		System.out.print(new String(message2Bytes));
		
		ValueObject object = (ValueObject) MessageUtil
		.bytes2Message(message2Bytes);
		
		if (object instanceof  TimeStamp_TS )
		{
			TimeStamp_TS ts1 = (TimeStamp_TS)object ;
			assertTrue(ts.compareTo(ts1));
		}
	}
	
	@Test 
	public void testMessage2tobyteAndbytetoMessage_SU()
	{
		SecurityUpdate_SU su = new SecurityUpdate_SU() ;
		su.setS_SecurityNumberOld(9212);
		su.setS_SecurityNumberNew(8000);
		su.setS_Filler1(" ");
		su.setS_SectorNumber(95);
		su.setS_Filler2(" ");
		su.setS_SecuritySymbol("12345678");
		su.setS_SecurityType("S");
		su.setS_CeilingPrice(536232);
		su.setS_FloorPrice(23523);
		su.setS_LastSalePrice(23542);
		su.setS_MarketID("A");
		su.setS_Filler3("   ");
		su.setS_SecurityName("1234567890123456789012345");
		su.setS_Filler4(" ");
		su.setS_Suspension(" ");
		su.setS_Delist(" ");
		su.setS_HaltResumeFlag("H");
		su.setS_Split(" ");
		su.setS_Benefit("B");
		su.setS_Meeting(" ");
		su.setS_Notice(" ");
		su.setS_ClientIDRequired("R");
		su.setS_ParValue(2536541);
		su.setS_SDCFlag("S");
		su.setS_PriorClosePrice(2365322);
		su.setS_PriorClosedate("12345678");
		su.setS_OpenPrice(235232);
		su.setS_HighestPrice(23123);
		su.setS_LowestPrice(23532);
		su.setS_TotalSharesTraded(3456);
		su.setS_TotalValuesTraded(23456);
		su.setS_BoardLot(5365);
		su.setS_Filler5(" ");	
		
		byte[] message2Bytes = MessageUtil.message2Bytes(su);
		System.out.print(new String(message2Bytes));
		
		ValueObject object = (ValueObject) MessageUtil
		.bytes2Message(message2Bytes);
		
		if (object instanceof  SecurityUpdate_SU )
		{
			SecurityUpdate_SU su1 = (SecurityUpdate_SU)object ;
			assertTrue(su.compareTo(su1));
			System.out.println(su1);
			
		}
		System.out.println(su);
		
		
	}
	
 
	@Test 
	public void testMessage2tobyteAndbytetoMessage_TR()
	{
		ForeignRoom_TR tr = new ForeignRoom_TR();
		
		tr.setSecurity_Number(9212);
		tr.setTotal_Room(2532);
		tr.setCurrent_Room(255365);//255365
		byte[] message2Bytes = MessageUtil.message2Bytes(tr);
		System.out.print(new String(message2Bytes));
		
		ValueObject object = (ValueObject) MessageUtil
		.bytes2Message(message2Bytes);
		
		if (object instanceof  ForeignRoom_TR )
		{
			ForeignRoom_TR tr1 = (ForeignRoom_TR)object ;
			assertTrue(tr.compareTo(tr1));
		}	
	}
	
	@Test 
	public void testMessage2tobyteAndbytetoMessage_TP()
	{
		TopPrices_TP tp = new TopPrices_TP () ;
		
		tp.setSecurity_Number(914);
		tp.setSide("S");
		tp.setPrice_1_best(253551);
		tp.setLot_Volume_1(1231);	
		tp.setPrice_2_2nd_best(12536);
		tp.setLot_Volume_2(9212);
		tp.setPrice_3_3rd_best(1235423);
		tp.setLot_Volume_3(23225);
	
		byte[] message2Bytes = MessageUtil.message2Bytes(tp);
		System.out.print(new String(message2Bytes));
		
		ValueObject object = (ValueObject) MessageUtil
		.bytes2Message(message2Bytes);
		
		if (object instanceof  TopPrices_TP )
		{
			TopPrices_TP tp1 = (TopPrices_TP)object ;
			assertTrue(tp.compareTo(tp1));
		}
	}
	@Test 
	public void testMessage2tobyteAndbytetoMessage_TC()
	{
		TraderStatusChange_TC tc = new TraderStatusChange_TC();
		
		tc.setFirm(2352);
		tc.setTrader_ID(253623);
		tc.setTrader_Status("S");
		
		byte[] message2Bytes = MessageUtil.message2Bytes(tc);
		System.out.print(new String(message2Bytes));
		
		ValueObject object = (ValueObject) MessageUtil
		.bytes2Message(message2Bytes);
		
		if (object instanceof  TraderStatusChange_TC )
		{
			TraderStatusChange_TC tc1 = (TraderStatusChange_TC)object ;
			assertTrue(tc.compareTo(tc1));
		}
		
		
		
	}
	
	@Test 
	public void testMessage2tobyteAndbytetoMessage_SS()
	{
		SecurityStatusChange_SS ss = new SecurityStatusChange_SS();
		
		ss.setSecurity_Number(8798) ;
		ss.setSector_Number(95);
		ss.setHaltorResume_Flag("H");
		ss.setSystem_Control_Code("C");
		ss.setSuspension("S");
		ss.setDelist("D");
		ss.setCeiling(2536523);
		ss.setFloor_Price(2512535);
		ss.setSecurity_Type("S");
		ss.setPrior_Close_Price(452362);
		ss.setSplit("P");
		ss.setBenefit("B");
		ss.setMeeting("M");
		ss.setNotice("N");
		ss.setBoard_Lot(8777);
		ss.setFiller1(" ");
		ss.setFiller2(" ");
		ss.setFiller3(" ");
		ss.setFiller4(" ");
		ss.setFiller5(2536545);
		ss.setFiller6(" ");
		byte[] message2Bytes = MessageUtil.message2Bytes(ss);
		System.out.print(new String(message2Bytes));
		
		ValueObject object = (ValueObject) MessageUtil
		.bytes2Message(message2Bytes);
		
		if (object instanceof  SecurityStatusChange_SS )
		{
			SecurityStatusChange_SS ss1 = (SecurityStatusChange_SS)object ;
			assertTrue(ss.compareTo(ss1));
		}	
	}
	
	
	@Test 
	// coi lai 
	public void testMessage2tobyteAndbytetoMessage_SR()
	{
		SecurityReconcile_SR sr = new SecurityReconcile_SR() ;
		
		sr.setSecurity_Number(2532);
		sr.setMain_or_Foreign_Deal(533322);
		sr.setMain_or_Foreign_Acc_Volume(81537); // lon hon kieu so long la ?
		sr.setMain_or_Foreign_Acc_Value(1548222);
		sr.setDeals_in_Big_Lot_Board(2535);
		sr.setBig_Lot_Acc_Volume(253252);
		sr.setBig_Lot_Acc_Value(123453);
		sr.setDeals_in_Big_Lot_Board(9212);
		sr.setOdd_Lot_Acc_Volume(3253);
		sr.setOdd_Lot_Acc_Value(23522);
		byte[] message2Bytes = MessageUtil.message2Bytes(sr);
		System.out.print(new String(message2Bytes));
		
		ValueObject object = (ValueObject) MessageUtil
		.bytes2Message(message2Bytes);
		
		if (object instanceof  SecurityReconcile_SR )
		{
			SecurityReconcile_SR sr1 = (SecurityReconcile_SR)object ;
			assertTrue(sr.compareTo(sr1));
			
		}
			
	}
	@Test 
	public void testMessage2tobyteAndbytetoMessage_SI()
	{
		SectoralIndices_SI si = new SectoralIndices_SI();
		si.setIndex_Sectoral_1(15236544);
		String temp = "" ;
		for (int i = 0; i <120; i++) {
			temp+= " ";
		}
		si.setFiller(temp);
		si.setIndex_Time(12531);
		byte[] message2Bytes = MessageUtil.message2Bytes(si);
		System.out.print(new String(message2Bytes));
		
		ValueObject object = (ValueObject) MessageUtil
		.bytes2Message(message2Bytes);
		
		if (object instanceof  SectoralIndices_SI )
		{
			SectoralIndices_SI si1 = (SectoralIndices_SI)object ;
			assertTrue(si.compareTo(si1));
		}
		
	}
	
	
	@Test 
	public void testMessage2tobyteAndbytetoMessage_SC()
	{
		SystemControl_SC sc = new SystemControl_SC();
		sc.setSystem_Control_Code("C");
		sc.setTimestamp(12535);
		
		byte[] message2Bytes = MessageUtil.message2Bytes(sc);
		System.out.print(new String(message2Bytes));
		
		ValueObject object = (ValueObject) MessageUtil
		.bytes2Message(message2Bytes);
		if (object instanceof  SystemControl_SC )
		{
			SystemControl_SC sc1 = (SystemControl_SC)object ;
			assertTrue(sc.compareTo(sc1));
		}
		
	}
	
	
	@Test 
	public void testMessage2tobyteAndbytetoMessage_PO()
	{
		ProjectedOpen_PO po = new ProjectedOpen_PO();
		
		po.setSecurity_Number(5825);
		po.setProjected_Open_Price(884735);
		
		byte[] message2Bytes = MessageUtil.message2Bytes(po);
		System.out.print(new String(message2Bytes));
		
		ValueObject object = (ValueObject) MessageUtil
		.bytes2Message(message2Bytes);
		if (object instanceof  ProjectedOpen_PO )
		{
			ProjectedOpen_PO po1  = (ProjectedOpen_PO)object ;
			assertTrue(po.compareTo(po1));
		}
	}
	@Test 
	public void testMessage2tobyteAndbytetoMessage_PD()
	{
		PutThroughDealNotice_PD pd = new PutThroughDealNotice_PD();
		
		pd.setConfirm_Number(582652);
		pd.setSecurity_Number(9212);
		pd.setVolume(6325423);
		pd.setPrice(84934655);
		pd.setBoard("B");
		byte[] message2Bytes = MessageUtil.message2Bytes(pd);
		System.out.print(new String(message2Bytes));
		
		ValueObject object = (ValueObject) MessageUtil
		.bytes2Message(message2Bytes);
		if (object instanceof  PutThroughDealNotice_PD )
		{
			PutThroughDealNotice_PD pd1 = (PutThroughDealNotice_PD)object ;
			assertTrue(pd.compareTo(pd1));
		}
	}
	
	@Test 
	public void testMessage2tobyteAndbytetoMessage_OS()
	{
		MarketOpenLastSale_OS os = new MarketOpenLastSale_OS() ;
		
		os.setSecurity_Number(2563);
		os.setPrice(5826522);
		
		byte[] message2Bytes = MessageUtil.message2Bytes(os);
		System.out.print(new String(message2Bytes));
		
		ValueObject object = (ValueObject) MessageUtil
		.bytes2Message(message2Bytes);
		if (object instanceof  MarketOpenLastSale_OS )
		{
			MarketOpenLastSale_OS  os1 = (MarketOpenLastSale_OS)object ;
			assertTrue(os.compareTo(os1));
		}
		
		
	}
	
	@Test 
	public void testMessage2tobyteAndbytetoMessage_OL()
	{
		NewOddLot_OL ol = new NewOddLot_OL();
		ol.setSecurity_Number(8000);
		ol.setOdd_Lot_Volume(9212);	
		ol.setPrice(58256522);
		ol.setSide("S");
		ol.setReference_Number(884735);
		
		byte[] message2Bytes = MessageUtil.message2Bytes(ol);
		System.out.print(new String(message2Bytes));
		
		ValueObject object = (ValueObject) MessageUtil
		.bytes2Message(message2Bytes);
		if (object instanceof  NewOddLot_OL )
		{
			NewOddLot_OL ol1 = (NewOddLot_OL)object ;
			assertTrue(ol.compareTo(ol1));
		}
		
	}
	@Test 
	public void testMessage2tobyteAndbytetoMessage_NS()
	{
		NewsStory_NS ns = new NewsStory_NS();
		ns.setNews_Number(8000);
		ns.setNews_Page_Number(6000);
		ns.setNews_Text_Length(5000);
		
		String text1 = "" ;
		text1 = "aaaa" ;
		for(int i=0;i<215-4;i++)
		{
			text1+=" ";
		}
		
		ns.setNews_Text(text1);
		
		byte[] message2Bytes = MessageUtil.message2Bytes(ns);
		System.out.print(new String(message2Bytes));
		
		ValueObject object = (ValueObject) MessageUtil
		.bytes2Message(message2Bytes);
		if (object instanceof  NewsStory_NS )
		{
			NewsStory_NS ns1 =  (NewsStory_NS)object ; 
			assertTrue(ns.compareTo(ns1));
		}
	}
	@Test 
	public void testMessage2tobyteAndbytetoMessage_NH()
	{
		NewHeadLine_NH nh = new NewHeadLine_NH();
		
		nh.setL_NewSNumber(9212);
		nh.setS_SecuritySymbol("12345678");
		nh.setL_NewsHeadlineLength(92) ;
		nh.setL_TotalNewsStoryPages(9212);
		nh.setS_NewsHeadlineText("1234567890123456789012345678901234567890123456789012345678901234567890");
		byte[] message2Bytes = MessageUtil.message2Bytes(nh);
		System.out.print(new String(message2Bytes));
		
		ValueObject object = (ValueObject) MessageUtil
		.bytes2Message(message2Bytes);
		
		if (object instanceof NewsHeadline_NH)
		{
			NewsHeadline_NH nh1 = (NewsHeadline_NH)object ;
			assertTrue(nh.compareTo(nh1));		
		}
		
		
	}
	
	@Test 
	public void testMessage2tobyteAndbytetoMessage_LS()
	{
		LastSale_LS ls = new LastSale_LS();
		
		ls.setConfirmNumber(67777);
		ls.setSecurityNumber(9212);
		ls.setLotVolume(884735) ;
		ls.setPrice(8493465);
		ls.setSide("S");
			
		byte[] message2Bytes = MessageUtil.message2Bytes(ls);
		System.out.print(new String(message2Bytes));
		
		ValueObject object = (ValueObject) MessageUtil
		.bytes2Message(message2Bytes);
		
		if (object instanceof LastSale_LS)
		{
			LastSale_LS ls1 =  (LastSale_LS)object;
			assertTrue(ls.compareTo(ls1));
		}
		
	}
	
	@Test
	public void testMessage2tobyteAndbytetoMessage_LO()
	{
		LastOddLot_LO lo = new LastOddLot_LO();
		
		lo.setConfirm_Number(884735);
		lo.setSecurity_Number(9215)	;
		lo.setOdd_Lot_Volume(96);
		lo.setPrice(84934655);
		lo.setReference_Number(88473);
		
		byte[] message2Bytes = MessageUtil.message2Bytes(lo);
		System.out.print(new String(message2Bytes));
		
		ValueObject object = (ValueObject) MessageUtil
		.bytes2Message(message2Bytes);
		
		if (object instanceof LastOddLot_LO)
		{
			LastOddLot_LO lo1 =  (LastOddLot_LO)object;
			assertTrue(lo.compareTo(lo1));
		}
		
	}
	@Test
	public void testMessage2tobyteAndbytetoMessage_IU()
	{
		IndexUpdate_IU iu = new IndexUpdate_IU();
		
		iu.setIndexHoSE(94);
		iu.setTotalTrades(856325);
		iu.setTotalSharesTraded(444);
		iu.setTotalValuesTraded(815372);
		iu.setUpVolume(8000);
		iu.setDownVolume(7000);
		iu.setNoChangeVolume(815372697);
		iu.setAdvances(9213);
		iu.setDeclines(9000);
		iu.setNoChange(7000);
		iu.setFiller1("    ");
		iu.setMarketID("A");
		String temp = "" ;
		for (int i = 0; i < 7; i++) {
			temp+=" ";
		}
		iu.setFiller2(temp);
		iu.setIndexTime(5686);
		
		byte[] message2Bytes = MessageUtil.message2Bytes(iu);
		System.out.print(new String(message2Bytes));
		
		ValueObject object = (ValueObject) MessageUtil
		.bytes2Message(message2Bytes);
		
		
		if (object instanceof IndexUpdate_IU)
		{
			IndexUpdate_IU iu1 =  (IndexUpdate_IU) object;
			assertTrue(iu.compareTo(iu1));	
			System.out.println(iu1);
			
		}
		System.out.println(iu);
	}
	@Test
	public void testMessage2tobyteAndbytetoMessage_GA()
	{
		GeneralAdmin_GA ga = new GeneralAdmin_GA();
		ga.setAdminMessageLength(94);
		ga.setAdminMessageText("1034567890103456789010345678901034567890103456789010345678901034567890");
		
		byte[] message2Bytes = MessageUtil.message2Bytes(ga);
		System.out.print(new String(message2Bytes));
		
		ValueObject object = (ValueObject) MessageUtil
		.bytes2Message(message2Bytes);
		
		if (object instanceof GeneralAdmin_GA)
		{
			GeneralAdmin_GA ga1 =  (GeneralAdmin_GA)object ;
			assertTrue(ga.compareTo(ga1));	
		}
		
	}
	@Test
	public void testMessage2tobyteAndbytetoMessage_DC()
	{
		DealCancellationNotice_DC dc = new DealCancellationNotice_DC();
		
		dc.setConfirmNumber(80000);
		dc.setSecurityNumber(2000);
		dc.setVolume(8493465);
		dc.setPrice(849346);
		dc.setBoard("B");
		
		byte[] message2Bytes = MessageUtil.message2Bytes(dc);
		System.out.print(new String(message2Bytes));
		
		ValueObject object = (ValueObject) MessageUtil
		.bytes2Message(message2Bytes);
		if (object instanceof DealCancellationNotice_DC)
		{
			DealCancellationNotice_DC dc1 = (DealCancellationNotice_DC)object;
			assertTrue(dc.compareTo(dc1));
			
		}
	}
	
	@Test
	public void testMessage2tobyteAndbytetoMessage_CO()
	{
		CancelOddLot_CO co = new CancelOddLot_CO();
		co.setReferenceNumber(2000);
		
		byte[] message2Bytes = MessageUtil.message2Bytes(co);
		System.out.print(new String(message2Bytes));
		
		ValueObject object = (ValueObject) MessageUtil
		.bytes2Message(message2Bytes);
		
		if (object instanceof CancelOddLot_CO)
		{
			CancelOddLot_CO co1 = (CancelOddLot_CO)object ;
			assertTrue(co.compareTo(co1));
		}
		
	}
	
	@Test 
	public void testMessage2tobyteAndbytetoMessage_BS()
	{
		BrokerStatusChange_BS msgBS = new BrokerStatusChange_BS();
		
		msgBS.setFirm(123);
		msgBS.setAutoMatchHaltFlag("H");
		msgBS.setPutthroughHaltFlag("R");
		
		byte[] message2Bytes = MessageUtil.message2Bytes(msgBS);
		System.out.print(new String(message2Bytes));
		
		ValueObject object = (ValueObject) MessageUtil
		.bytes2Message(message2Bytes);
		
		if (object instanceof BrokerStatusChange_BS)
		{
			BrokerStatusChange_BS msgBS1 = (BrokerStatusChange_BS) object;
			assertTrue(msgBS.compareTo(msgBS1));
			
		}
	}
	
	@Test
	public void testMessage2tobyteAndbytetoMessage_BR()
	{
		BrokerReconcile_BR msgBR = new BrokerReconcile_BR();
		msgBR.setFirm(123);
		msgBR.setMarketID("A");
		msgBR.setVolumeSold("1234567890");
		msgBR.setValueSold("12345678901234");
		msgBR.setVolumeBought("1234567890");
		msgBR.setValueBought("12345678901234");
		
		byte[] message2Bytes = MessageUtil.message2Bytes(msgBR);
		System.out.print(new String(message2Bytes));

		ValueObject object = (ValueObject) MessageUtil
				.bytes2Message(message2Bytes);
		
		if (object instanceof BrokerReconcile_BR)
		{
			BrokerReconcile_BR msgBR1 = (BrokerReconcile_BR) object;
			assertTrue(msgBR.compareTo(msgBR1));
		}
		
		
	}
	
	
	@Test
	public void testMessage2tobyteAndbytetoMessage_AA() {
		AdvertisementAnnouncement_AA msgAA = new AdvertisementAnnouncement_AA();
	
		msgAA.setSecurityNumber(9);
		msgAA.setVolume(84934655);
		msgAA.setPrice("2000000000000");
		msgAA.setFirm(9215);
		msgAA.setTrader(884735);
		msgAA.setSide("A");
		msgAA.setBoard("A");
		msgAA.setTime(884735);
		msgAA.setAddCancelFlag("A");
		msgAA.setContact("aaaaaaaaaaaaaaaaaaaa");

		byte[] message2Bytes = MessageUtil.message2Bytes(msgAA);
		System.out.print(new String(message2Bytes));

		ValueObject object = (ValueObject) MessageUtil
				.bytes2Message(message2Bytes);

		if (object instanceof AdvertisementAnnouncement_AA) {
			AdvertisementAnnouncement_AA msgAA1 = (AdvertisementAnnouncement_AA) object;
			assertTrue(msgAA1.compareTo(msgAA1));
		}
		// System.out.print(object);

	}
	
	

}
