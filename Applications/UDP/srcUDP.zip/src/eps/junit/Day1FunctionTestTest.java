package eps.junit;

import static junit.framework.Assert.*;

import java.util.List;

import org.junit.Test;

import eps.com.client.proposal.EPSServiceController;
import eps.com.common.ValueObject;
import eps.com.message.sended.Advertisement_1E;
import eps.com.message.sended.NewConditioned_1I;
import eps.com.message.sended.RetransmissionRequest_RQ;
import eps.com.test.Day1FunctionTest;
import eps.com.test.TestCommon;
import eps.com.util.MessageUtil;

public class Day1FunctionTestTest {
	@Test
	public void loadTest() throws Exception {
		List<NewConditioned_1I> loadTest1 = Day1FunctionTest.loadTest1();
		assertEquals(300, loadTest1.size());

		List<NewConditioned_1I> loadTest2 = Day1FunctionTest.loadTest2();
		assertEquals(300, loadTest2.size());

		List<NewConditioned_1I> loadTest3 = Day1FunctionTest.loadTest3();
		assertEquals(300, loadTest3.size());

		List loadTest4 = Day1FunctionTest.loadTest4();
		assertEquals(15, loadTest4.size());

	}
}
