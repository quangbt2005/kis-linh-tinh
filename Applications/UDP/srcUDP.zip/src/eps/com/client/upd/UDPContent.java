package eps.com.client.upd;

import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;

import eps.com.common.ValueObject;
import eps.com.message.broadcast.*;
import eps.com.message.received.RetransmissionReply_RP;
import eps.com.test.MainFrame;
import eps.com.test.TestCommon;
import eps.com.util.MessageUtil;

public class UDPContent {
	
	// Default port
	private static int TR=0;
	private static int SS=1;
	private static int SC=2;
	private static int GA=3;
	private static int TP=4;
	private static int LS=5;
	private static int PO=6;
	private static int OS=7;
	private static int IU=8;
	private static int SI=9;
	private static int AA=10;
	private static int PD=11;
	private static int OTHERS=12;
	
	//Priority 1: TR,SS,SC,GA,TP,LS,PO,OS

	//Priority 2: IU,SI,AA,PD

	//Priority 3: BR,CO,NH,NS,OL,LO,DC,BS,SR,TC

	//Priority 4: SU 

	public static final char SEPERATOR = 31;
	public static final char BELL = 7;

	private long sequenceNumber;
	private long prevSequence = 0;
	private String marketID;
	private long messageCount;
	private byte[] messageContent;
	private static UdpLog log = new UdpLog();
	RandomAccessFile raf;
	private ReceiveUDPMessageQueue receiveQueue[];
	public UDPContent() {
	}
	public UDPContent(ReceiveUDPMessageQueue receiveQueue) {
		this.receiveQueue[0] = receiveQueue;
	}
	public UDPContent(ReceiveUDPMessageQueue receiveQueue[]) {
		this.receiveQueue = receiveQueue;
	}

	public void createNewSequenceFile() throws Exception {
		java.io.File f = new java.io.File(TestCommon.DATA_SAVE_PATH
				+ "/sequence.dat");
		if (f.exists())
			f.delete();
		raf = new RandomAccessFile(TestCommon.DATA_SAVE_PATH + "/sequence.dat",
				"rw");
		// begin index
		raf.writeInt(0);

	}

	public static UdpLog getLog() {
		return log;
	}

	public UDPContent(long sequence, String marketID, long messageCount,
			ValueObject object) {
		this.sequenceNumber = sequence;
		this.marketID = marketID;
		this.messageCount = messageCount;
		this.messageContent = MessageUtil.message2Bytes(object);
	}

	public UDPContent(long sequence, String marketID, long messageCount,
			List<ValueObject> objects) {
		this.sequenceNumber = sequence;
		this.marketID = marketID;
		this.messageCount = messageCount;
		int index = 0;
		StringBuffer buffer = new StringBuffer();
		for (int i = 0; i < messageCount; i++) {
			byte temp[] = MessageUtil.message2Bytes(objects.get(i));
			buffer.append(new String(temp));
			if (i < messageCount - 1)
				buffer.append((char) 31);
		}
		int contLen = buffer.toString().length();
		this.messageContent = new byte[contLen];
		System.arraycopy(buffer.toString().getBytes(), 0, this.messageContent,
				0, contLen);

	}

	public byte[] getUDPMessage() {
		int len = this.messageContent.length + 5;
		byte[] result = new byte[len];
		byte seq[] = Common.EnMod96(sequenceNumber, 3);
		result[0] = seq[0];
		result[1] = seq[1];
		result[2] = seq[2];
		result[3] = marketID.getBytes()[0];
		result[4] = Common.EnMod96(messageCount, 1)[0];
		System.arraycopy(this.messageContent, 0, result, 5, len - 5);
		return result;
	}

	public long getSequenceNumber() {
		return sequenceNumber;
	}

	public void setSequenceNumber(long sequencenumber) {
		this.sequenceNumber = sequencenumber;
	}

	public String getMarketID() {
		return marketID;
	}

	public void setMarketID(String marketid) {
		this.marketID = marketid;
	}

	public long getMessageCount() {
		return messageCount;
	}

	public void setMessageCount(int messagecount) {
		this.messageCount = messagecount;
	}

	public byte[] getMessageContent() {
		return messageContent;
	}

	public void setMessageContent(byte[] messagecontent) {
		this.messageContent = messagecontent;
	}

	public List<byte[]> parseData(byte[] data) {
		String msgReturn;
		List result = new ArrayList<byte[]>();

		byte[] lc_seqNum = new byte[3];
		byte[] lc_marketid = new byte[1];
		byte[] lc_msgcount = new byte[1];
		byte[] lc_msgcontent = new byte[data.length - 5];

		System.arraycopy(data, 0, lc_seqNum, 0, 3);
		System.arraycopy(data, 3, lc_marketid, 0, 1);
		System.arraycopy(data, 4, lc_msgcount, 0, 1);
		System.arraycopy(data, 5, lc_msgcontent, 0, data.length - 5);

		this.marketID = new String(lc_marketid);
		this.messageCount = Common.DecodeMod96(lc_msgcount);
		this.sequenceNumber = Common.DecodeMod96(lc_seqNum);
		try {
			// Server restart UPD module
			if (this.sequenceNumber == 1)
				this.prevSequence = 0;
			if (this.sequenceNumber > this.prevSequence + 1	) {
				raf.writeLong(this.prevSequence + 1);
				raf.writeLong(this.sequenceNumber - 1);
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String message = new String(lc_msgcontent);
		log.printAndSave("Sequence : " + this.sequenceNumber);
		if (message.endsWith("" + SEPERATOR))
			message = message.substring(0, message.length() - 1);
		StringTokenizer tokens = new StringTokenizer(message, "" + SEPERATOR);
		prevSequence = this.sequenceNumber;

//		if (tokens.countTokens() != this.messageCount) {
//			System.out.println("------Error UPD packet");
//			return null;
//		}
		// set lai co cho biet hien hanh dang nhan qua UDP
		while (tokens.hasMoreElements()) {
			result.add(tokens.nextToken().getBytes());
		}
		return result;
	}

	public List<byte[]> parseData(RetransmissionReply_RP retran) {
		byte[] lc_msgcontent = retran.getOriginalBroadcastMessage().getBytes();
		String message = retran.getOriginalBroadcastMessage();
		StringTokenizer tokens = new StringTokenizer(message, "" + BELL);
		System.out.println("------Parse Retransmission Data");
		if (tokens.countTokens() != retran.getMessageCount()) {
			System.out.println("------Error retrans UPD packet");
			return null;
		}
		List result = new ArrayList<byte[]>();
		while (tokens.hasMoreElements()) {
			result.add(tokens.nextToken().getBytes());
		}
		return result;
	}

	public void processRetransmissionMessage(List<byte[]> messages,
			long messageCount) {
		this.processMessage(messages, messageCount);
	}
	//Priority 1: TR,SS,SC,GA,TP,LS,PO,OS

	//Priority 2: IU,SI,AA,PD
	public void processMessage(List<byte[]> messages, long messageCount) {
		byte[] msgdata;
		for (int i = 0; i < messageCount; i++) {
			msgdata = messages.get(i);
		    if        (msgdata[0] == (byte) 'T' && msgdata[1] == (byte) 'R') {
				this.receiveQueue[TR].putMessage(msgdata);
			} else if (msgdata[0] == (byte) 'S' && msgdata[1] == (byte) 'S') {
				this.receiveQueue[SS].putMessage(msgdata);
			}else  if (msgdata[0] == (byte) 'S' && msgdata[1] == (byte) 'C') {
				this.receiveQueue[SC].putMessage(msgdata);
			} else if (msgdata[0] == (byte) 'G' && msgdata[1] == (byte) 'A') {
				this.receiveQueue[GA].putMessage(msgdata);
			}else  if (msgdata[0] == (byte) 'T' && msgdata[1] == (byte) 'P') {
				this.receiveQueue[TP].putMessage(msgdata);
			} else if (msgdata[0] == (byte) 'L' && msgdata[1] == (byte) 'S') {
				this.receiveQueue[LS].putMessage(msgdata);
			}else  if (msgdata[0] == (byte) 'P' && msgdata[1] == (byte) 'O') {
				this.receiveQueue[PO].putMessage(msgdata);
			} else if (msgdata[0] == (byte) 'O' && msgdata[1] == (byte) 'S') {
				this.receiveQueue[OS].putMessage(msgdata);
			}else  if (msgdata[0] == (byte) 'I' && msgdata[1] == (byte) 'U') {
				this.receiveQueue[IU].putMessage(msgdata);
			} else if (msgdata[0] == (byte) 'S' && msgdata[1] == (byte) 'I') {
				this.receiveQueue[SI].putMessage(msgdata);
			}else if (msgdata[0] == (byte) 'A' && msgdata[1] == (byte) 'A') {
				this.receiveQueue[AA].putMessage(msgdata);
			} else if (msgdata[0] == (byte) 'P' && msgdata[1] == (byte) 'D') {
				this.receiveQueue[PD].putMessage(msgdata);
			} else
				this.receiveQueue[OTHERS].putMessage(msgdata);
		}
	}

}

// public void processMessage(List<byte[]> messages, long messageCount) {
// byte[] msgdata;
// for (int i = 0; i < messageCount; i++) {
// msgdata = messages.get(i);
// ValueObject object = (ValueObject) MessageUtil.bytes2Message(msgdata);
// if (object != null) {
// //log.printAndSave(object.toString());
// log.saveLog(object.toString());
// } else {
// log.printConsole("Object receive is null.");
// return;
// }
//	
// if (object instanceof GeneralAdmin_GA) { // 5
// final GeneralAdmin_GA msgGA = (GeneralAdmin_GA) object;
// this.receiveQueue.putMessage(object);
// log.printAndSave("--------------");
// log.printAndSave(msgGA.getAdminMessageText());
// log.printAndSave("--------------");
// Runnable doWorkRunnable = new Runnable() {
// String message = msgGA.getAdminMessageText();
//
// public void run() {
// JOptionPane.showMessageDialog(MainFrame.getFrames()[0],
// message);
// }
// };
// SwingUtilities.invokeLater(doWorkRunnable);
// } else if (object instanceof SystemControl_SC) // 21
// {
// this.receiveQueue.putMessage(object);
// final SystemControl_SC msgSC = (SystemControl_SC) object;
// // bat dau doc lenh
// String controlCode =msgSC.getSystem_Control_Code().trim();
//			
// if (controlCode.equalsIgnoreCase("P")) {
// try {
// log.printAndSave("--------------ReOpen Session");
//
// //EPSServiceController.getInstance().startReadingOrders();
// } catch (Exception e) {
// // TODO Auto-generated catch block
// e.printStackTrace();
// }
// // dong connect voi HOSE
// }if (controlCode.equalsIgnoreCase("O")) {
// try {
// log.printAndSave("--------------Open Session");
// //EPSServiceController.getInstance().startReadingOrders();
// } catch (Exception e) {
// // TODO Auto-generated catch block
// e.printStackTrace();
// }
// // dong connect voi HOSE
// }else if (controlCode.equalsIgnoreCase("A")) {
// try {
// log.printAndSave("--------------ReClose Session");
// //EPSServiceController.getInstance().startReadingOrders();
// } catch (Exception e) {
// // TODO Auto-generated catch block
// e.printStackTrace();
// }
// // dong connect voi HOSE
// }else if(controlCode.equalsIgnoreCase("Z")) {
// try {
// //EPSServiceController.getInstance().disconnectFromClient();
// } catch (Exception e) {
// // TODO Auto-generated catch block
// e.printStackTrace();
// }
// }else if (controlCode.equalsIgnoreCase("C")) {
// try {
// log.printAndSave("--------------Market Close Session");
// //EPSServiceController.getInstance().startReadingOrders();
// } catch (Exception e) {
// // TODO Auto-generated catch block
// e.printStackTrace();
// }
// // dong connect voi HOSE
// }
//			
// Runnable doWorkRunnable = new Runnable() {
// final String message="SC flag:" + msgSC.getSystem_Control_Code() ;
//
// public void run() {
// JOptionPane.showMessageDialog(MainFrame.getFrames()[0],
// message);
// }
// };
// SwingUtilities.invokeLater(doWorkRunnable);
// }
// else if (object instanceof TimeStamp_TS){
// //this.receiveQueue.putMessage(object);
// //System.out.println("Queue size:" + this.receiveQueue.getMessageSize());
// System.out.println("Queue size:" + this.receiveQueue.getMessageSize());
// }else{
// this.receiveQueue.putMessage(object);
// }
// }
// // System.out.println("Done...");
//
// }