package eps.com.client.upd;

import java.io.*;
import java.nio.channels.*;
import java.nio.*;

class Test{  
  public static void main(
                        String[] args){
    //Create and populate an array obj
    byte[] array = {65,66,67,68,69,70};
    
    //Wrap array in a buffer to create
    // a ByteBuffer object.  Then 
    // display the contents of the
    // buffer.
    ByteBuffer buf = 
                ByteBuffer.wrap(array);
    showBufferData(buf,"buf-raw data");
        
    try{
      //Delete the file named junk.txt
      // if it already exists
      new File("junk.txt").delete();
      //Get a channel for writing a
      // random access file in rw
      // mode.
      FileChannel rwCh = (
                  new RandomAccessFile(
                     "junk.txt","rw")).
                          getChannel();
                          
      //Write buffer data to the file
      System.out.println(
                   "Bytes written = " 
                   + rwCh.write(buf));
                   
      //Close the channel so that it
      // can no longer be used to 
      // access the file.
      rwCh.close();
                   
      //Make original ByteBuffer object
      // and original array object
      // eligible for garbage 
      // collection so that their data
      // is no longer accessible.  The
      // data is now available only
      // via the file named junk.txt.
      buf = null;
      array = null;
      
      //Get a new FileChannel object
      // for reading and writing the 
      // existing file
      rwCh = new RandomAccessFile(
                      "junk.txt","rw").
                          getChannel();

      //Map entire file to memory and
      // close the channel
      long fileSize = rwCh.size();
      ByteBuffer mapFile = rwCh.map(
        FileChannel.MapMode.READ_WRITE,
                          0, fileSize);
      rwCh.close();
      //Display contents of memory map
      showBufferData(
                    mapFile,"mapFile");
      //Change contents of the map and
      // hence the file.  Note that
      // the channel is closed.

      mapFile.position(2);
      mapFile.put((byte)1);
      mapFile.put((byte)2);
      
      //Display new contents of memory
      // map
      showBufferData(
                mapFile,"mod-mapFile");

      System.out.println(
         "Read/display modified file");
      //Get new channel for read only
      FileChannel newInCh = 
                  new RandomAccessFile(
                       "junk.txt","r").
                          getChannel();
                          
      //Allocate (don't wrap) a new
      // ByteBuffer
      ByteBuffer newBuf = 
                   ByteBuffer.allocate(
                        (int)fileSize);

      //Read file data into the new
      // buffer, close the channel, and
      // display the data.
      System.out.println(
               "Bytes read = " 
               + newInCh.read(newBuf));
      newInCh.close();
      showBufferData(newBuf,"newBuf");
      
      //Get new read-only partial
      // mapping for file and display
      FileChannel rCh = 
                  new RandomAccessFile(
                       "junk.txt","r").
                          getChannel();
      ByteBuffer roMapFile = rCh.map(
         FileChannel.MapMode.READ_ONLY,
                        1, fileSize-2);
      rCh.close();
      showBufferData(roMapFile,
                          "roMapFile");
      
      //Following put throws java.nio.
      // ReadOnlyBufferException, so
      // it is disabled.
      roMapFile.position(2);
      //roMapFile.put((byte)88);
      
    }catch(Exception e){
      System.out.println(e);}
  }// end main
  //---------------------------------//
  
  static void showBufferData(
          ByteBuffer buf, String name){
    //Displays byte buffer contents
    
    //Save position
    int pos = buf.position();
    //Set position to zero
    buf.position(0);
    System.out.println(
            "Data for " + name);
    while(buf.hasRemaining()){
      System.out.print(
                      buf.get() + " ");
    }//end while loop
    System.out.println();//new line
    //Restore position and return
    buf.position(pos);
  }//end showBufferData
  //---------------------------------//
}//end class Channel04 definition
