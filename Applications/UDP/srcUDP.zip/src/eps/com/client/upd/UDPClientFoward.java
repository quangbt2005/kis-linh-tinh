package eps.com.client.upd;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.sql.Timestamp;
import java.util.List;

import eps.com.common.ValueObject;
import eps.com.message.broadcast.*;
import eps.com.message.sended.NewConditioned_1I;
import eps.com.util.MessageUtil;

//Tuan modify : don't change
public class UDPClientFoward extends Thread {
	// Default port

	private DatagramSocket ds;
	private DatagramSocket ds1;
	private DatagramPacket p;
	DatagramPacket ps1;
	private byte[] b = new byte[1024];
	private boolean stop = false;
	public static final int SERVER_PORT = 30000;
	UDPContent UDP = new UDPContent();
	long messageCount = 0;

	/**
	 * @param args
	 */
	public UDPClientFoward() throws Exception {
		ds = new DatagramSocket(SERVER_PORT);
		ds1 = new DatagramSocket();
		p = new DatagramPacket(b, b.length);
		
	}

	public boolean isStop() {
		return stop;
	}

	public void setStop(boolean stop) {
		this.stop = stop;
	}

	@Override
	public void run() {
		while (!stop) {
			// Waiting for a datagram packet from client
			try {
				ds.receive(p);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			// Accept package
			byte[] arg = new byte[p.getLength()];
			System.arraycopy(p.getData(), 0, arg, 0, p.getLength());
			System.out.println("data :" + p.getData());
			List<byte[]> messages = UDP.parseData(arg);
			try {
				ps1 = new DatagramPacket(arg, arg.length, InetAddress.getByName("vpn02"), 33333);
				ds1.send(ps1);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	public static void main(String arg[]) throws Exception {
		UDPClientFoward udpClient = new UDPClientFoward();
		udpClient.setPriority(Thread.MIN_PRIORITY);
		udpClient.start();
	}

}
