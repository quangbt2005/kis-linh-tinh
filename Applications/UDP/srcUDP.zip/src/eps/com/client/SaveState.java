package eps.com.client;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;

public class SaveState {
	private String _filename;
	Writer logAppendWriter;

	public SaveState(String filename) {
		_filename = filename;
	}

	public boolean saveConfig(long _seq, long _ack_seq, byte mode,
			long _sever_seq, long _server_ack_seq, int udpSeq) {
		try {
			Writer savedStateWriter = new BufferedWriter(new FileWriter(
					_filename));

			String content = String.valueOf(_seq) + "\n";
			content = content + String.valueOf(_ack_seq) + "\n";
			content = content + String.valueOf(mode) + "\n";
			content = content + String.valueOf(_sever_seq) + "\n";
			content = content + String.valueOf(_server_ack_seq) + "\n";
			content = content + String.valueOf(udpSeq) + "\n";

			savedStateWriter.write(content);
			// savedStateWriter.flush();
			savedStateWriter.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return true;
	}

	public int[] readConfig() {
		int[] re = new int[6];
		StringBuilder contents = new StringBuilder();
		try {
			// use buffering, reading one line at a time
			// FileReader always assumes default encoding is OK!
			BufferedReader input = new BufferedReader(new FileReader(_filename));
			try {
				String line = null; // not declared within while loop
				for (int i = 0; i < 6; i++) {
					re[i] = Integer.parseInt(input.readLine());
					System.out.println("read line: " + re[i]);
				}
			} finally {
				input.close();
			}
		} catch (IOException ex) {
			ex.printStackTrace();
		}
		return re;
	}

	public void append(String s) {
		try {
			if (logAppendWriter == null) {
				logAppendWriter = new BufferedWriter(new FileWriter(_filename,
						true));
			}

			logAppendWriter.write(s);
			logAppendWriter.flush();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private static void close(Writer writer) throws Throwable {
		if (writer != null) {
			writer.flush();
			writer.close();
		}
	}

	@Override
	protected void finalize() throws Throwable {
		try {
			close(logAppendWriter);
		} finally {
			super.finalize();
		}
	}

	/** Simple test harness. */
	public static void main(String[] args) throws IOException {
		SaveState a = new SaveState("c:/datasave1/SavedState.txt");
		a.saveConfig(1, 1, (byte) 'A', 2, 2, 0);

		// a = new SaveState("c:/datasave1/SavedState.txt");
		// a.saveConfig(1, 1, (byte) 'A', 2, 2, 0);

		System.out.println("");
	}
}
