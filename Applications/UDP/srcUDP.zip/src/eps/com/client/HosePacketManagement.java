package eps.com.client;

import java.util.List;

import eps.com.client.upd.Common;
import eps.com.common.HosePacket;
import eps.com.common.Opcode;

/**
 * @author nghia.tt
 * 
 */
public class HosePacketManagement {
	public HosePacketManagement() {

	}

	public byte[] createLOLLContent(byte marketId, int msgCount, byte[] data) {
		byte[] ret = new byte[2 + data.length];
		ret[0] = marketId;
		ret[1] = Common.EnMod96(msgCount, 1)[0];
		System.arraycopy(data, 0, ret, 2, data.length);

		return ret;
	}

	public byte[] createHelloContent(byte mode, byte[] pass,
			int numberOfmarket, byte[] marketId, byte[] firmid) {
		int passlen = pass.length;
		byte[] bytes = new byte[7 + passlen];
		byte[] temp = null;
		// CONTENT
		// mode
		bytes[0] = mode;
		// pass
		System.arraycopy(pass, 0, bytes, 1, passlen);
		// eos
		bytes[passlen + 1] = '\0';
		// number of market
		temp = Common.EnMod96(numberOfmarket, 1);
		bytes[passlen + 2] = temp[0];
		// market ID
		bytes[passlen + 3] = 'A';
		// firm ID
		System.arraycopy(firmid, 0, bytes, passlen + 4, 3);
		return bytes;
	}

	/**
	 * 
	 * @param _seq
	 * @param _ack_seq
	 * @param opcode
	 * @param linkID
	 * @param content
	 * @return
	 */
	public byte[] createPacket(long _seq, long _ack_seq, byte[] opcode,
			long linkID, byte[] content) {
		int len = 15 + content.length;
		byte[] bytes = new byte[len];
		byte[] temp = null;
		// len 2 byte
		temp = Common.EnMod96(len - 2, 2);
		bytes[0] = temp[0];
		bytes[1] = temp[1];
		// seq 4 byte
		temp = Common.EnMod96(_seq, 4);
		bytes[2] = temp[0];
		bytes[3] = temp[1];
		bytes[4] = temp[2];
		bytes[5] = temp[3];
		// ackseq 4
		temp = Common.EnMod96(_ack_seq, 4);
		bytes[6] = temp[0];
		bytes[7] = temp[1];
		bytes[8] = temp[2];
		bytes[9] = temp[3];
		// opcode HL
		bytes[10] = opcode[0];
		bytes[11] = opcode[1];
		// LinkID 57
		temp = Common.EnMod96(linkID, 2);
		bytes[12] = temp[0];
		bytes[13] = temp[1];
		// CONTENT
		int n = content.length;
		if (n > 0)
			System.arraycopy(content, 0, bytes, 14, n);
		// etx
		bytes[len - 1] = 3;
		return bytes;
	}

	////////////////////////////////////////////////////////////////////////////
	// /////////////
	// 1I 2E 2I 2C 2D
	public byte[] createDT(String marketId, List list) {
		int len = 0;
		byte[] temp;
		for (int i = 0; i < list.size(); i++) {
			temp = (byte[]) list.get(i);
			len += temp.length;
		}
		byte[] bytes = new byte[len + 2 + list.size() - 1];
		// marketId
		temp = string2byte(marketId);
		bytes[0] = temp[0];
		// messcount
		temp = Common.EnMod96(list.size(), 1);
		bytes[1] = temp[0];
		//
		len = 2;
		for (int i = 0; i < list.size(); i++) {
			temp = (byte[]) list.get(i);
			System.arraycopy(temp, 0, bytes, len, temp.length);
			if (i + 1 < list.size()) {
				len = +temp.length;
				bytes[len] = 31;
				len++;
			}
		}

		return bytes;
	}

	/*
	 * marketid=A
	 * 
	 * Field Size Type 1. Message Type 2 "1I" 2. Firm 3 Numeric String 057 3.
	 * Trader ID 4 Alphanumeric String 2120-2125 4. Order number 8 Numeric
	 * String 5. Client ID 10 Alphanumeric String So tai khoan 6. Security
	 * Symbol 8 Alphanumeric String 7. Side 1 Alpha string b/s 8. Volume 8
	 * Numeric String 9. Published volume 8 Numeric String = volume 10. Price 6
	 * Alphanumeric String 11. Board 1 Alpha string A 12. Filler 5 13.
	 * Port/Client Flag 1 Alpha string 14. Filler 5 Total 70
	 */

	public byte[] create1I(String firm, String traderID, String orderNumber,
			String clientId, String symbol, String side, String volume,
			String publishedVol, String price, String board, String flag) {
		byte[] bytes = new byte[70];
		byte[] temp = null;
		byte[] filler = new byte[] { ' ', ' ', ' ', ' ', ' ' };
		bytes[0] = '1';
		bytes[1] = 'I';
		// firm 3 bytes
		temp = string2byte(firm);
		System.arraycopy(temp, 0, bytes, 2, 3);
		// Trader ID 4 bytes
		temp = string2byte(traderID);
		System.arraycopy(temp, 0, bytes, 5, 4);
		// Order number 8 bytes
		temp = string2byte(orderNumber);
		System.arraycopy(temp, 0, bytes, 9, 8);
		// Client ID 10 bytes
		temp = string2byte(clientId);
		System.arraycopy(temp, 0, bytes, 17, 10);
		// Security symbol 8 bytes
		temp = string2byte(symbol);
		System.arraycopy(temp, 0, bytes, 27, 8);
		// Side 1 byte
		temp = string2byte(side);
		System.arraycopy(temp, 0, bytes, 35, 1);
		// Volume 8 bytes
		temp = string2byte(volume);
		System.arraycopy(temp, 0, bytes, 36, 8);
		// Published volume == volume
		temp = string2byte(publishedVol);
		System.arraycopy(temp, 0, bytes, 44, 8);
		// Price 6 bytes
		temp = string2byte(price);
		System.arraycopy(temp, 0, bytes, 52, 6);
		// Board 1 Alpha string
		temp = string2byte(board);
		System.arraycopy(temp, 0, bytes, 58, 1);
		// Filler 5 byte
		System.arraycopy(filler, 0, bytes, 59, 5);
		// Port/Client Flag 1 byte
		temp = string2byte(flag);
		System.arraycopy(temp, 0, bytes, 64, 1);
		// Filler 5 byte
		System.arraycopy(filler, 0, bytes, 65, 5);

		return bytes;
	}

	/*
	 * Field Size Type Message Type 2 "1C" Firm 3 Numeric String Order Number 8
	 * Numeric String Order Entry Date 4 Numeric String DDMM Total 17
	 */
	public byte[] create1C(String firm, String orderNumber,
			String orderEntryDate) {
		byte[] bytes = new byte[17];
		byte[] temp;
		bytes[0] = '1';
		bytes[1] = 'C';
		// Firm 3 Numeric String
		temp = string2byte(firm);
		System.arraycopy(temp, 0, bytes, 2, 3);
		// Order Number 8 Numeric String
		temp = string2byte(orderNumber);
		System.arraycopy(temp, 0, bytes, 5, 8);
		// Order Entry Date 4 Numeric String
		temp = string2byte(orderEntryDate);
		System.arraycopy(temp, 0, bytes, 13, 4);

		return bytes;
	}

	/**
	 * 
	 * @param firm
	 * @param orderNumber
	 * @param orderEntryDate
	 * @param clientID
	 * @return
	 */
	/*
	 * 1D Field Size Type 1. Message Type 2 "1D" 2. Firm 3 Numeric String 3.
	 * Order Number 8 Numeric String 4. Order Entry Date 4 Numeric String 5.
	 * Client ID 10 Alphanumeric String 6. Filler 17 Total 44
	 */
	public byte[] create1D(String firm, String orderNumber,
			String orderEntryDate, String clientID) {
		byte[] bytes = new byte[44];
		byte[] temp;
		bytes[0] = '1';
		bytes[1] = 'D';
		// Firm 3 Numeric String
		temp = string2byte(firm);
		System.arraycopy(temp, 0, bytes, 2, 3);
		// Order Number 8 Numeric String
		temp = string2byte(orderNumber);
		System.arraycopy(temp, 0, bytes, 5, 8);
		// Order Entry Date 4 Numeric String
		temp = string2byte(orderEntryDate);
		System.arraycopy(temp, 0, bytes, 13, 4);
		// Client ID 10 Alphanumeric String
		temp = string2byte(clientID);
		System.arraycopy(temp, 0, bytes, 17, 10);
		//
		temp = new byte[17];
		for (int i = 0; i < 17; i++) {
			temp[i] = (byte) ' ';
		}
		System.arraycopy(temp, 0, bytes, 27, 17);
		return bytes;
	}

	/***
	 * 1E message
	 * 
	 * @param firm
	 * @param traderID
	 * @param symbol
	 * @param side
	 * @param volume
	 * @param price
	 * @param board
	 * @param time
	 * @param flag
	 * @param contact
	 * @return
	 */
	/*
	 * //1E///////////////////////////////////////////////////////////////////////////////////////
	 * Field Size Type 1. Message Type 2 "1E" 2. Firm 3 Numeric String 3. Trader
	 * ID 4 Alphanumeric String 4. Security Symbol 8 Alphanumeric String 5. Side
	 * 1 Alpha String 6. Volume 8 Numeric String 7. Price 12 Numeric String 8.
	 * Board 1 Alpha String 9. Time 6 Numeric String 10. Add/Cancel Flag
	 * Add/Cancel Flag 1 Alpha String 11. Contact 20 Alphanumeric String Total
	 * 66
	 */
	public byte[] create1E(String firm, String traderID, String symbol,
			String side, String volume, String price, String board,
			String time, String flag, String contact) {
		byte[] bytes = new byte[66];
		byte[] temp = null;
		bytes[0] = '1';
		bytes[1] = 'E';
		// firm 3 bytes
		temp = string2byte(firm);
		System.arraycopy(temp, 0, bytes, 2, 3);
		// Trader ID 4 bytes
		temp = string2byte(traderID);
		System.arraycopy(temp, 0, bytes, 5, 4);
		// Security symbol 8 bytes
		temp = string2byte(symbol);
		System.arraycopy(temp, 0, bytes, 9, 8);
		// Side 1 byte
		temp = string2byte(side);
		System.arraycopy(temp, 0, bytes, 17, 1);
		// Volume 8 bytes
		temp = string2byte(volume);
		System.arraycopy(temp, 0, bytes, 18, 8);
		// Price 12 bytes
		temp = string2byte(price);
		System.arraycopy(temp, 0, bytes, 26, 12);
		// Board 1 Alpha string
		temp = string2byte(board);
		System.arraycopy(temp, 0, bytes, 38, 1);
		// Time 6 Numeric String
		temp = string2byte(time);
		System.arraycopy(temp, 0, bytes, 39, 6);
		// Port/Client Flag 1 byte
		temp = string2byte(flag);
		System.arraycopy(temp, 0, bytes, 45, 1);
		// Contact 20 Alphanumeric String
		temp = string2byte(contact);
		System.arraycopy(temp, 0, bytes, 46, 20);

		return bytes;
	}

	/*
	 * 1F Field Size Type 1. Message Type 2 "1F" 2. Firm 3 Numeric String 3.
	 * Trader ID 4 Alphanumeric String 4. Client ID (Buyer) 10 Alphanumeric
	 * string 5. Client ID (Seller) 10 Alphanumeric String 6. Security Symbol 8
	 * Alphanumeric string 7. Price 12 Numeric String 8. Board 1 Alpha String 9.
	 * Deal ID 5 Alphanumeric String 10. Filler 8 11. Broker Portfolio Volume
	 * (Buyer) 8 Numeric String 12. Broker Client Volume (Buyer) 8 Numeric
	 * String 13. Mutual Fund Volume (Buyer) 8 Numeric String 14. Broker Foreign
	 * Volume (Buyer) 8 Numeric String 15. Filler 32 16. Broker Portfolio Volume
	 * (Seller) 8 Numeric String 17. Broker Client Volume (Seller) 8 Numeric
	 * String 18. Mutual Fund Volume (Seller) 8 Numeric String 19. Broker
	 * Foreign Volume (Seller) 8 Numeric String 20. Filler 32 Total 191
	 */

	public byte[] create1F(String firm, String traderID, String clientBuyID,
			String clientSellId, String symbol, String price, String board,
			String dealID, String brokerPortfolioVolumeBuyer,
			String brokerClientVolumeBuyer, String mutualFundVolumeBuyer,
			String brokerForeignVolumeBuyer,
			String brokerPortfolioVolumeSeller,
			String brokerClientVolumeSeller, String mutualFundVolumeSeller,
			String brokerForeignVolumeSeller) {
		byte[] bytes = new byte[191];
		byte[] temp = null;
		//
		byte[] filler32 = new byte[32];
		for (int i = 0; i < 32; i++)
			filler32[i] = (byte) ' ';
		byte[] filler8 = new byte[8];
		for (int i = 0; i < 8; i++)
			filler8[i] = (byte) ' ';
		//
		bytes[0] = '1';
		bytes[1] = 'F';
		// firm 3 bytes
		temp = string2byte(firm);
		System.arraycopy(temp, 0, bytes, 2, 3);
		// Trader ID 4 bytes
		temp = string2byte(traderID);
		System.arraycopy(temp, 0, bytes, 5, 4);
		// 4. Client ID (Buyer) 10 Alphanumeric string
		temp = string2byte(clientBuyID);
		System.arraycopy(temp, 0, bytes, 9, 10);
		// 5. Client ID (Seller) 10 Alphanumeric String
		temp = string2byte(clientSellId);
		System.arraycopy(temp, 0, bytes, 19, 10);
		// 6. Security Symbol 8 Alphanumeric string
		temp = string2byte(symbol);
		System.arraycopy(temp, 0, bytes, 29, 8);
		// 7. Price 12 Numeric String
		temp = string2byte(price);
		System.arraycopy(temp, 0, bytes, 37, 12);
		// 8. Board 1 Alpha String
		temp = string2byte(board);
		System.arraycopy(temp, 0, bytes, 49, 1);
		// 9. Deal ID 5 Alphanumeric String
		temp = string2byte(dealID);
		System.arraycopy(temp, 0, bytes, 50, 5);
		// 10. Filler 8
		System.arraycopy(filler8, 0, bytes, 55, 8);
		// 11. Broker Portfolio Volume (Buyer) 8 Numeric String
		System.arraycopy(string2byte(brokerPortfolioVolumeBuyer), 0, bytes, 63,
				8);
		// 12. Broker Client Volume (Buyer) 8 Numeric String
		System.arraycopy(string2byte(brokerClientVolumeBuyer), 0, bytes, 71, 8);
		// 13. Mutual Fund Volume (Buyer) 8 Numeric Stri
		System.arraycopy(string2byte(mutualFundVolumeBuyer), 0, bytes, 79, 8);
		// 14. Broker Foreign Volume (Buyer) 8 Numeric String
		System
				.arraycopy(string2byte(brokerForeignVolumeBuyer), 0, bytes, 87,
						8);
		// 15. Filler 32
		System.arraycopy(filler32, 0, bytes, 95, 32);
		// 16. Broker Portfolio Volume (Seller) 8 Numeric String
		System.arraycopy(string2byte(brokerPortfolioVolumeSeller), 0, bytes,
				127, 8);
		// 17. Broker Client Volume (Seller) 8 Numeric String
		System.arraycopy(string2byte(brokerClientVolumeSeller), 0, bytes, 135,
				8);
		// 18. Mutual Fund Volume (Seller) 8 Numeric String
		System.arraycopy(string2byte(mutualFundVolumeSeller), 0, bytes, 143, 8);
		// 19. Broker Foreign Volume (Seller) 8 Numeric String
		System.arraycopy(string2byte(brokerForeignVolumeSeller), 0, bytes, 151,
				8);
		// 20. Filler 32
		System.arraycopy(filler32, 0, bytes, 159, 32);

		return bytes;
	}

	/**
	 * 
	 * @return
	 */
	/*
	 * 
	 * Field Size Type 1. Message Type 2 "2E" 2. Firm 3 Numeric String 3. Side 1
	 * Alpha string 4. Order Number 8 Numeric String 5. Order Entry Date 4
	 * Numeric String 6. Filler 2 7. Volume 8 Numeric String 8. Price 6 Numeric
	 * String 9. Confirm Number 6 Numeric String Total 40
	 */

	public byte[] create2E() {
		byte[] bytes = new byte[40];
		return bytes;
	}

	// /CONVERT
	// MODE/////////////////////////////////////////////////////////////
	// /////////////
	private byte[] string2byte(String s) {
		char[] tem = s.toCharArray();
		byte[] bytes = new byte[tem.length];
		for (int i = 0; i < tem.length; i++)
			bytes[i] = (byte) tem[i];
		return bytes;
	}
	////////////////////////////////////////////////////////////////////////////
	// /
}
