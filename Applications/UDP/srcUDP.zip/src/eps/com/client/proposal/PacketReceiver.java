package eps.com.client.proposal;

import java.io.InterruptedIOException;
import java.util.List;

import eps.com.client.HosePacketManagement;
import eps.com.client.upd.Common;
import eps.com.common.HosePacket;
import eps.com.common.HoseSystemPacket;
import eps.com.common.Opcode;
import eps.com.common.RecoveryObject;
import eps.com.common.ValueObject;
import eps.com.test.MainFrame;

public class PacketReceiver extends Thread {

	private byte[] currentStatus;
	private WindowBuffer buffer;
	private int receivedNumber = 0;
	private int packetNumber = 0;
	private boolean isStop;
	private ReceiveMessageQueue receiveQueue;
	public PacketReceiver(WindowBuffer buffer) {
		this.buffer = buffer;
	}
	
	
	public PacketReceiver(WindowBuffer buffer, ReceiveMessageQueue receiveQueue) {
		this.buffer = buffer;
		this.receiveQueue=receiveQueue;
	}
	
	public void setStop(boolean bool) {
		isStop = bool;
	}
	public boolean getStop() {
		return isStop;
	}

	/**
	 * simple automad
	 */
	@Override
	public void run() {
		long serv_ack = 0;
		EPSServiceController svcInstance= null;
		while (!isStop) {
			try {
				svcInstance = EPSServiceController.getInstance();
				List<HosePacket> packets = svcInstance.receivePackets();
				int	size =0;
				// timeout = 40s ; 40s
				if(packets == null)
					packetNumber++;
				else{
					packetNumber=0;
					size = packets.size();
				}
				
				if(packetNumber > 2000)
					throw new Exception("Timeout- Can't receive packet for 40s.");
				for (int i = 0; i < size; i++) {
					// EPSServiceController.isReceiving = false;
					HosePacket packet = (HosePacket) packets.get(i);
					if (packet != null) this.receiveQueue.putMessage(packet);
				}
				Thread.sleep(20);
			} catch (Exception e) {
				setStop(true);
				svcInstance.log("Error: Timeout-Can't recieve packet. Beginning of auto reconnect process");
				return;
				//e.printStackTrace();
			}
		}
	}
}
