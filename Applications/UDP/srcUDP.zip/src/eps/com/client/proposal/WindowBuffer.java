package eps.com.client.proposal;

import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

public class WindowBuffer {
	public static final int WINDOW_SIZE = 7;
	Vector<Long> clientSeqs = new Vector<Long>();
	int currentSize = 0;

	public synchronized void increaseWindowBuffer(long seq) {
		while (currentSize == WINDOW_SIZE) {
			try {
				wait();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		clientSeqs.add(new Long(seq));
		currentSize++;
	}

	// check da nhan duoc cac sequence < serv_ack va remove ra khoi danh sach
	public synchronized void decreaseWindowBuffer(long serv_ack) {
		long seq = 0;
		int size = clientSeqs.size();
		for (int i = size - 1; i >= 0; i--) {
			seq = clientSeqs.get(i).longValue();
			if (seq < serv_ack) {
				clientSeqs.remove(i);
				currentSize--;
			}
		}
		if (currentSize < WINDOW_SIZE)
			notify();
	}

	public synchronized int getWindowBufferSize() {
		return currentSize;
	}
	
	public synchronized void doNotify() {
		notify();
	}
	public void removeAll(){
		this.clientSeqs.clear();
	}

}
