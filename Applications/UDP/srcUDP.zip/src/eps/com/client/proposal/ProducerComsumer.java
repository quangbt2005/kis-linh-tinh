package eps.com.client.proposal;

public class ProducerComsumer {
	private Object message;

	public ProducerComsumer() {
	    message = null; // null indicates empty
	}

	public synchronized void putIn(Object obj) 
	            throws InterruptedException {

	    while ( message != null ) {
	      wait(); 
	    }

	    message = obj;  // put object into slot
	    notify(); // signal that slot has been filled
	  }

	  public synchronized Object takeOut() 
	            throws InterruptedException {

	    while ( message == null ) {
	      wait(); // wait while slot is empty
	    }

	    Object obj = message;
	    message = null; // mark slot as empty
	    notify(); // signal that slot is empty
	    return obj;
	  }
	  public static void main(String[] args) {
	    final ProducerComsumer ch = new ProducerComsumer();

	    Runnable runA = new Runnable() {
	        public void run() {
	          try {
	            String str;
	            Thread.sleep(500);

	            str = "multithreaded";
	            ch.putIn(str);
	            str = "programming";
	            ch.putIn(str);

	            str = "with Java";
	            ch.putIn(str);
	          } catch ( InterruptedException x ) {
	            x.printStackTrace();
	          }
	        }
	      };

	    Runnable runB = new Runnable() {
	        public void run() {
	          try {
	            Object obj;

	            obj = ch.takeOut();
	            System.out.println("in run() - just took out: '" + 
	                obj + "'");

	            Thread.sleep(500);

	            obj = ch.takeOut();
	            System.out.println("in run() - just took out: '" + 
	                obj + "'");

	            obj = ch.takeOut();
	            System.out.println("in run() - just took out: '" + 
	                obj + "'");
	          } catch ( InterruptedException x ) {
	            x.printStackTrace();
	          }
	        }
	      };

	    Thread threadA = new Thread(runA, "threadA");
	    threadA.start();

	    Thread threadB = new Thread(runB, "threadB");
	    threadB.start();
	  }
}
