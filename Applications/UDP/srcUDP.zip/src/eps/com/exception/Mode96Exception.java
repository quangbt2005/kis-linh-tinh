package eps.com.exception;
/**
 * Ngoại lệ này sẽ được đưa ra khi số cần chuyển v�? dạng ASCII(Mod96+32) vượt quá qui định trong bản đặc tả.
 * 
 * @author lequocthai
 *
 */
public class Mode96Exception extends TradingOnlineException{

	private static final long serialVersionUID = 1L;

	public Mode96Exception(int code) {
		super(code + 10);
		this.type = ExceptionType.OUT_OF_RANGE;
	}
	
	public Mode96Exception(int code, String mess){
		super(code + 10);
		this.type = ExceptionType.OUT_OF_RANGE;
		this.message = mess;
	}
	
	public Mode96Exception(String mess){
		super(10);
		this.message = mess;
	}
	
	@Override
	protected void setMessage() {
		switch(code){
		case 11:
			this.message = "Giá trị của số cần chuyển đổi vượt quá qui định cho phép.";
			break;
		case 12:
			this.message = "Mảng byte cần giải mã không hợp lệ.";
			break;
		}
	}

}
