package eps.com.test;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

import java.io.EOFException;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;
import eps.com.common.ValueObject;

import eps.com.message.broadcast.ForeignRoom_TR;

public class testSaveandLoadObject {

	public testSaveandLoadObject(String fileName) throws Exception {
		ForeignRoom_TR tr = new ForeignRoom_TR();
		tr.setSecurity_Number(9212);
		tr.setTotal_Room(2532);
		tr.setCurrent_Room(255365);// 255365

		testWriteObject(tr, fileName);

		Object obj = null;
		obj = testLoadObject(fileName);

		if (obj instanceof ForeignRoom_TR) {
			System.out.println(((ForeignRoom_TR) obj).toString());

			ForeignRoom_TR tr1 = (ForeignRoom_TR) obj;

			System.out.println("Message_Type:" + tr1.getMessage_Type());
			System.out.println("Security_Number:" + tr1.getSecurity_Number());
			System.out.println("Current_Room:" + tr1.getCurrent_Room());
			System.out.println("Total_Room:" + tr1.getTotal_Room());

		}
	}

	public Object testLoadObject(String fileName) throws Exception {

		ObjectInputStream inputStream = null;
		Object obj = null;
		try {

			// Construct the ObjectInputStream object
			inputStream = new ObjectInputStream(new FileInputStream(fileName));

			while ((obj = inputStream.readObject()) != null) {
				// if (obj instanceof ForeignRoom_TR ) {

				// System.out.println(((ForeignRoom_TR)obj).toString());
				// System.out.println((obj).toString());

				// }

			}// while

		} catch (EOFException ex) { // This exception will be caught when EOF is
			// reached
			System.out.println("End of file reached.");
		} catch (ClassNotFoundException ex) {
			ex.printStackTrace();
		} catch (FileNotFoundException ex) {
			ex.printStackTrace();
		} catch (IOException ex) {
			ex.printStackTrace();
		} finally {
			// Close the ObjectInputStream
			try {
				if (inputStream != null) {
					inputStream.close();
					// return obj;
				}
			} catch (IOException ex) {
				ex.printStackTrace();
			}
		}
		return (Object) obj;
	}

	public void testWriteObject(Object tr, String fileName) throws Exception {
		// TODO Auto-generated method stub
		ObjectOutputStream outputStream = null;
		try {

			// Construct the LineNumberReader object
			outputStream = new ObjectOutputStream(new FileOutputStream(
					new File(fileName)));
			outputStream.writeObject(tr);

		} catch (FileNotFoundException ex) {
			ex.printStackTrace();
		} catch (IOException ex) {
			ex.printStackTrace();
		} finally {
			// Close the ObjectOutputStream
			try {
				if (outputStream != null) {
					outputStream.flush();
					outputStream.close();
				}
			} catch (IOException ex) {
				ex.printStackTrace();
			}
		}

	}

	/**
	 * @param args
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		new testSaveandLoadObject(TestCommon.DATA_SAVE_PATH
				+ "/ForeignRoom_TR.txt");
	}

}
