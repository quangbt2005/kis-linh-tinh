package eps.com.test;

import java.util.ArrayList;
import java.util.List;

import eps.com.message.sended.NewConditioned_1I;

public class DataTest {
	public List<NewConditioned_1I> testPreOpen() throws Exception {
		// 1I
		List<NewConditioned_1I> listtest = new ArrayList();
		// 200 B
		for (int i = 0; i < 200; i++) {
			String order = TestCommon.createRandomOrderNumber();
			String acount = TestCommon.createRandomAcountBuy();
			String sb = TestCommon.createRandomSymbol();
			NewConditioned_1I newOrder = create1I("057", "2120", order, acount,
					sb, "B", "1000    ", "1000    ", "ATO     ", "M", "C");
			listtest.add(newOrder); // add to test
		}
		return listtest;
	}

	// public byte[] create1I(String firm,String traderID, String orderNumber,
	// String clientId,String symbol, String side,
	// String volume,String publishedVol, String price,String board, String
	// flag){
	// byte[] bytes=new byte[70];
	// byte[] temp=null;
	// byte[] filler=new byte[]{' ',' ',' ',' ',' '};
	// bytes[0]='1';
	// bytes[1]='I';
	// //firm 3 bytes
	// temp=string2byte(firm);
	// System.arraycopy(temp, 0, bytes, 2, 3);
	// //Trader ID 4 bytes
	// temp=string2byte(traderID);
	// System.arraycopy(temp, 0, bytes, 5, 4);
	// //Order number 8 bytes
	// temp=string2byte(orderNumber);
	// System.arraycopy(temp, 0, bytes, 9, 8);
	// //Client ID 10 bytes
	// temp=string2byte(clientId);
	// System.arraycopy(temp, 0, bytes, 17, 10);
	// //Security symbol 8 bytes
	// temp=string2byte(symbol);
	// System.arraycopy(temp, 0, bytes, 27, 8);
	// //Side 1 byte
	// temp=string2byte(side);
	// System.arraycopy(temp, 0, bytes, 35, 1);
	// //Volume 8 bytes
	// temp=string2byte(volume);
	// System.arraycopy(temp, 0, bytes, 36, 8);
	// //Published volume == volume
	// temp=string2byte(publishedVol);
	// System.arraycopy(temp, 0, bytes, 44, 8);
	// //Price 6 bytes
	// temp=string2byte(price);
	// System.arraycopy(temp, 0, bytes, 52, 6);
	// //Board 1 Alpha string
	// temp=string2byte(board);
	// System.arraycopy(temp, 0, bytes, 58, 1);
	// //Filler 5 byte
	// System.arraycopy(filler, 0, bytes, 59, 5);
	// // Port/Client Flag 1 byte
	// temp=string2byte(flag);
	// System.arraycopy(temp, 0, bytes, 64, 1);
	// //Filler 5 byte
	// System.arraycopy(filler, 0, bytes, 65, 5);
	//		
	// return bytes;
	// }
	public NewConditioned_1I create1I(String firm, String traderID,
			String orderNumber, String clientId, String symbol, String side,
			String volume, String publishedVol, String price, String board,
			String flag) {
		NewConditioned_1I newOrder = new NewConditioned_1I();
		newOrder.setFirm(firm);
		newOrder.setTraderID(traderID);
		newOrder.setOrderNumber(orderNumber);
		newOrder.setClientID(clientId);
		newOrder.setSecuritySymbol(symbol);
		newOrder.setSide(side);
		newOrder.setVolume(volume);
		newOrder.setPublishedVolume(publishedVol);
		newOrder.setPrice(price);
		newOrder.setBoard(board);
		newOrder.setPortClientFlag(flag);
		return newOrder;
	}

}
