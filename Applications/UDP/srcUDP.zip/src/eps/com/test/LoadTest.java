package eps.com.test;

import java.util.ArrayList;
import java.util.List;

import eps.com.client.HosePacketManagement;
import eps.com.message.sended.NewConditioned_1I;
// ORDER TYPE = LO, 
public class LoadTest {
	
	//dung trong phien pre-open (mo cua)
	// chi duoc phep LO hay ATO
	public static List<NewConditioned_1I> loadTest1() throws Exception {
		List<NewConditioned_1I> ret = new ArrayList<NewConditioned_1I>();

		// 200 LO B
		List<NewConditioned_1I> listOrders = NormalTest.get1IMessages(200, "1",
				"B");
		ret.addAll(listOrders);

		// 200 LO S
		listOrders = NormalTest.get1IMessages(200, "2", "S");
		ret.addAll(listOrders);

		// 100 ATO S
		listOrders = NormalTest.get1IMessages(100, "3", "S", "ATO");
		ret.addAll(listOrders);

		return ret;
	}
	//dung trong phien pre-open (mo cua)
	// chi duoc phep LO hay ATO
	public static List<NewConditioned_1I> loadTest2() throws Exception {
		List<NewConditioned_1I> ret = new ArrayList<NewConditioned_1I>();

		// 200 LO B
		List<NewConditioned_1I> listOrders = NormalTest.get1IMessages(300, "4",
				"B");
		ret.addAll(listOrders);

		// 200 LO Sell
		listOrders = NormalTest.get1IMessages(200, "5", "S");
		ret.addAll(listOrders);

		// 100 ATO
		listOrders = NormalTest.get1IMessages(100, "6", "S", "ATO");
		ret.addAll(listOrders);

		return ret;
	}
	//giao dich lien tuc
	public static List<NewConditioned_1I> loadTest3() throws Exception {
		List<NewConditioned_1I> ret = new ArrayList<NewConditioned_1I>();

		// 200 S LO
		List<NewConditioned_1I> listOrders = NormalTest.get1IMessages(200, "8",	"S");
		ret.addAll(listOrders);

		// 300 B
		listOrders = NormalTest.get1IMessages(300, "9", "B");
		ret.addAll(listOrders);

		return ret;
	}
	// LO only
	public static List<NewConditioned_1I> testClose() throws Exception {
		List<NewConditioned_1I> ret = new ArrayList<NewConditioned_1I>();

		// 200 S LO
		List<NewConditioned_1I> listOrders = NormalTest.get1IMessages(200,"10", "S");
		ret.addAll(listOrders);

		// 300 S
		listOrders = NormalTest.get1IMessages(300, "11", "S");
		ret.addAll(listOrders);
		return ret;
	}
}
