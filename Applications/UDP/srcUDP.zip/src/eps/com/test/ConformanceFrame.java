package eps.com.test;

import javax.swing.border.EtchedBorder;
import javax.swing.border.Border;
import javax.swing.JPanel;
import javax.swing.JFrame;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Rectangle;
import java.awt.SystemColor;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JComboBox;
import javax.swing.JRadioButton;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;
import javax.swing.SwingUtilities;

import java.awt.event.KeyEvent;
import eps.com.client.proposal.EPSServiceController;
import eps.com.client.upd.UDPClient;
import eps.com.client.upd.UDPContent;
import eps.com.common.HosePacket;
import eps.com.common.HoseSystemPacket;
import eps.com.common.Opcode;
import eps.com.common.ValueObject;
import eps.com.message.sended.Advertisement_1E;
import eps.com.message.sended.DealCancelReply_3D;
import eps.com.message.sended.DealPutThroughCancelRequest_3C;
import eps.com.message.sended.NewConditioned_1I;
import eps.com.message.sended.OrderCancellation_1C;
import eps.com.message.sended.OrderChange_1D;
import eps.com.message.sended.OneFirmPutThroughDeal_1F;
import eps.com.message.sended.PutThroughDealReply_3B;
import eps.com.message.sended.RetransmissionRequest_RQ;
import eps.com.message.sended.TwoFirmPutThroughDeal_1G;
import eps.com.util.MessageUtil;
import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;

import eps.com.message.received.CrossingDealConfirmation_2I;
import eps.com.message.received.PutThroughAcknowledgment_2F;
import eps.com.message.received.PutThroughDealConfirmation_2L;
import eps.com.message.received.RetransmissionReply_RP;
import java.awt.Font;
import java.awt.Insets;
import java.util.Iterator;
import java.util.List;

public class ConformanceFrame extends JDialog {

	private JTextField endSequence;
	private JTextField startSequence;
	private JButton btSendRR11;
	private JTextField textField_11;
	private JTextField textField_1;
	private JTextField sTextField_1;
	private JTextField textField_10;
	private JTextField textField_7;
	private JTextField sTextField;
	private JTextField textField_9;
	private JTextField textField_8;
	private JTextField ttcTextField_1;
	private JTextField aTextField_1;
	private JTextField textField_2;
	private JTextField textField_6;
	private JTextField textField_5;
	private JTextField textField_4;
	private JTextField textField_3;
	private JTextField aTextField;
	private JTextField textField;
	private JButton btnSend3C;
	private JTextField stbTextField;
	private JTextField ttTextField;
	private JTextField ttcTextField;
	private JTextField changeOrder34;
	private JTextField cancelRejectedOrder33;
	private JTextField cancelValidOrder32;
	private JTextField changeMatchedOrder18;
	private JTextField changeUnmatchedOrder17;
	private JTextField cancelMatchedOrder16;
	private JTextField cancelUnmatchedOrder15;
	private JTextField cancelMatchedOrder7;
	private static final long serialVersionUID = 1L;
	private static EPSServiceController controller;
	private UDPClient udpClient;
	private JPanel jContentPane = null;

	static {
		try {
			controller = EPSServiceController.getInstance();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	Border border1 = BorderFactory.createEtchedBorder(EtchedBorder.RAISED,
			Color.white, new Color(165, 163, 151)); // @jve:decl-index=0:

	/**
	 * This is the default constructor
	 */
	public void update3BInfo(PutThroughAcknowledgment_2F message2F) {
		this.textField.setText(message2F.getConfirmNumber());
		// this.aTextField
		this.textField_3.setText(message2F.getVolume());
		this.textField_4.setText(message2F.getVolume());
		this.textField_5.setText(message2F.getVolume());
		this.textField_6.setText(message2F.getVolume());
	}

	public void update3CInfo(PutThroughDealConfirmation_2L message2L) {
		textField_2.setText(message2L.getFirm());
		aTextField_1.setText(message2L.getContraFirm());
		// textField_8.setText(message2L.get Firm());
		textField_9.setText(message2L.getConfirmNumber());
		// ttcTextField_1.setText(message2L.get.getFirm());
		// sTextField.setText(message2L.getSide());

	}

	public void update3DInfo(DealPutThroughCancelRequest_3C message3C) {
		textField_10.setText(message3C.getConfirmNumber());
	}

	public ConformanceFrame() {
		super();
		getContentPane().setName("contentPane");
		initialize();

		final JTabbedPane tabbedPane = new JTabbedPane();
		tabbedPane.setBounds(0, 0, 716, 520);
		getContentPane().add(tabbedPane);

		final JPanel panel = new JPanel();
		panel.setLayout(null);
		tabbedPane.addTab("PreOpen", null, panel, null);

		final JButton button = new JButton();
		button.addActionListener(new ActionListener() {
			// 2...
			public void actionPerformed(final ActionEvent e) {
				NewConditioned_1I order = C1ConformanceTest.getOrder("ATO");
				controller.log("Chuong trinh chan khong goi : "
						+ order.toString());
				// sendOrders(1);
			}
		});
		button.setBounds(10, 13, 214, 26);
		button.setText("2. Send order to Hose Ko goi");
		panel.add(button);

		final JButton button_2 = new JButton();
		button_2.addActionListener(new ActionListener() {
			// 6...
			public void actionPerformed(final ActionEvent arg0) {
				NewConditioned_1I order = C1ConformanceTest.getOrder("ATO");
				sendOrder(order);
			}
		});
		button_2.setText("6. Send order c.1 ATO");
		button_2.setBounds(10, 75, 173, 26);
		panel.add(button_2);

		final JButton button_2_1 = new JButton();
		button_2_1.addActionListener(new ActionListener() {
			// 6...
			public void actionPerformed(final ActionEvent e) {
				NewConditioned_1I order = C1ConformanceTest.getOrder("ATC");
				controller.log("Chuong trinh chan khong goi : "
						+ order.toString());
			}
		});
		button_2_1.setText("6. Send order c.1 ATC");
		button_2_1.setBounds(10, 118, 173, 26);
		panel.add(button_2_1);

		final JButton button_2_1_1 = new JButton();
		button_2_1_1.addActionListener(new ActionListener() {
			// 6...
			public void actionPerformed(final ActionEvent e) {
				NewConditioned_1I order = C1ConformanceTest.getOrder("MP");
				controller.log("Chuong trinh chan khong goi : "
						+ order.toString());
			}
		});
		button_2_1_1.setText("6. Send order c.1 MP");
		button_2_1_1.setBounds(10, 162, 173, 26);
		panel.add(button_2_1_1);

		final JButton button_2_1_1_1 = new JButton();
		button_2_1_1_1.addActionListener(new ActionListener() {
			// 6...
			public void actionPerformed(final ActionEvent arg0) {
				sendOrders(1);
			}
		});
		button_2_1_1_1.setText("6. Send order c.1 LO");
		button_2_1_1_1.setBounds(10, 206, 173, 26);
		panel.add(button_2_1_1_1);

		cancelMatchedOrder7 = new JTextField();
		cancelMatchedOrder7.setBounds(10, 270, 173, 20);
		panel.add(cancelMatchedOrder7);

		final JButton button_2_1_1_1_1 = new JButton();
		button_2_1_1_1_1.addActionListener(new ActionListener() {
			// 7...
			public void actionPerformed(final ActionEvent e) {
				String text = cancelMatchedOrder7.getText();
				System.out.println(text);
				if (text.equalsIgnoreCase("")) {
					controller
							.log("Chuong trinh chan. Can't send cancel request for matched order");
				} else {
					OrderCancellation_1C get1CMessage = Day1FunctionTest
							.get1CMessage(text);
					controller
							.log("Chuong trinh chan. Can't send cancel request for matched order: "
									+ get1CMessage.toString());
				}
			}
		});
		button_2_1_1_1_1.setText("7. Cancel matched order");
		button_2_1_1_1_1.setBounds(10, 296, 173, 26);
		panel.add(button_2_1_1_1_1);

		final JButton button_2_1_1_1_1_1 = new JButton();
		button_2_1_1_1_1_1.addActionListener(new ActionListener() {
			// 11...
			public void actionPerformed(final ActionEvent e) {
				//controller.setParseMessage(false);
				List<NewConditioned_1I> loadTest1 = C1ConformanceTest
						.loadTest1();
				sendOrders(loadTest1, "PreOpen");
			}
		});
		button_2_1_1_1_1_1.setText("11. Load order #1 ");
		button_2_1_1_1_1_1.setBounds(262, 13, 173, 26);
		panel.add(button_2_1_1_1_1_1);

		final JButton button_2_1_1_1_1_1_1 = new JButton();
		button_2_1_1_1_1_1_1.addActionListener(new ActionListener() {
			// 12...
			public void actionPerformed(final ActionEvent e) {
				//controller.setParseMessage(true);
				List<NewConditioned_1I> listOrders = NormalTest
						.get1IMessages(52);
				sendOrders(listOrders);
			}
		});
		button_2_1_1_1_1_1_1.setText("12. Send > 50 orders");
		button_2_1_1_1_1_1_1.setBounds(265, 67, 173, 26);
		panel.add(button_2_1_1_1_1_1_1);

		final JLabel maCkLabel = new JLabel();
		maCkLabel.setText("Security Symbol");
		maCkLabel.setBounds(15, 332, 108, 16);
		panel.add(maCkLabel);

		ttcTextField = new JTextField();
		ttcTextField.setText("DPM");
		ttcTextField.setBounds(115, 330, 87, 20);
		panel.add(ttcTextField);

		final JButton button_3 = new JButton();
		// 8...
		button_3.addActionListener(new ActionListener() {
			public void actionPerformed(final ActionEvent e) {
				String sb = ttcTextField.getText().trim();
				NewConditioned_1I send = NormalTest.get1IForeignerMessage(sb);
				sendOrder(send);
			}
		});
		button_3.setText("8 Send Buying order of Foreigner");
		button_3.setBounds(9, 355, 232, 26);
		panel.add(button_3);

		final JButton insertPreopenSeparatorButton = new JButton();
		insertPreopenSeparatorButton.addActionListener(new ActionListener() {
			public void actionPerformed(final ActionEvent arg0) {
				controller
						.log("-------------- Bat dau PreOpen ----------------");
			}
		});
		insertPreopenSeparatorButton.setText("Insert PreOpen Separator");
		insertPreopenSeparatorButton.setBounds(284, 438, 277, 26);
		panel.add(insertPreopenSeparatorButton);

		textField_11 = new JTextField();
		textField_11.setBounds(534, 16, 87, 20);
		panel.add(textField_11);

		final JButton setBooleanToButton = new JButton();
		setBooleanToButton.addActionListener(new ActionListener() {
			public void actionPerformed(final ActionEvent arg0) {
				if (textField_11.getText().equals("")) {
					//controller.setParseMessage(true);
				} else {
					//controller.setParseMessage(false);
				}

			}
		});
		setBooleanToButton.setText("Parse Message or not");
		setBooleanToButton.setBounds(517, 42, 167, 26);
		panel.add(setBooleanToButton);

		btSendRR11 = new JButton();
		btSendRR11.addActionListener(new ActionListener() {
			public void actionPerformed(final ActionEvent arg0) {
				int start = Integer.parseInt(startSequence.getText());
				int end = Integer.parseInt(endSequence.getText());
				;
				String marketID ="A";
				long Firm = 57;
				RetransmissionRequest_RQ request = new RetransmissionRequest_RQ();
				request.setFirm(Firm);
				request.setMarketID(marketID);
				request.setRetransmissionStartSequence(start);
				request.setRetransmissionEndSequence(end);
				try {
					controller.sendMessageToQueue(request);
				} catch (Exception e1) {
					e1.printStackTrace();
				}				
			}
		});
		btSendRR11.setFont(new Font("Dialog", Font.BOLD, 10));
		btSendRR11.setText("Send RR 11");
		btSendRR11.setBounds(270, 117, 94, 27);
		panel.add(btSendRR11);

		final JLabel startSequenceLabel = new JLabel();
		startSequenceLabel.setText("Start Sequence");
		startSequenceLabel.setBounds(270, 151, 104, 23);
		panel.add(startSequenceLabel);

		startSequence = new JTextField();
		startSequence.setBounds(371, 152, 87, 20);
		panel.add(startSequence);

		final JLabel endSequenceLabel = new JLabel();
		endSequenceLabel.setText("End Sequence");
		endSequenceLabel.setBounds(278, 187, 86, 16);
		panel.add(endSequenceLabel);

		endSequence = new JTextField();
		endSequence.setBounds(371, 185, 87, 20);
		panel.add(endSequence);

		final JPanel panel_1 = new JPanel();
		panel_1.setLayout(null);
		tabbedPane.addTab("Open", null, panel_1, null);

		final JButton button_1 = new JButton();
		button_1.addActionListener(new ActionListener() {
			// 14...
			public void actionPerformed(final ActionEvent e) {
				sendOrders(1);
			}
		});
		button_1.setBounds(10, 10, 194, 26);
		button_1.setText("14. Send order c.2 ");
		panel_1.add(button_1);

		cancelUnmatchedOrder15 = new JTextField();
		cancelUnmatchedOrder15.setBounds(10, 65, 194, 20);
		panel_1.add(cancelUnmatchedOrder15);

		final JButton button_1_1 = new JButton();
		button_1_1.addActionListener(new ActionListener() {
			// 15...
			public void actionPerformed(final ActionEvent e) {
				System.out.println(cancelUnmatchedOrder15.getText());
				OrderCancellation_1C get1CMessage = Day1FunctionTest
						.get1CMessage(cancelUnmatchedOrder15.getText());
				sendOrder(get1CMessage);
			}
		});
		button_1_1.setText("15. Cancel unmatched order");
		button_1_1.setBounds(10, 91, 194, 26);
		panel_1.add(button_1_1);

		cancelMatchedOrder16 = new JTextField();
		cancelMatchedOrder16.setBounds(11, 158, 194, 20);
		panel_1.add(cancelMatchedOrder16);

		final JButton button_1_1_1 = new JButton();
		button_1_1_1.addActionListener(new ActionListener() {
			// 16...
			public void actionPerformed(final ActionEvent e) {
				String text = cancelMatchedOrder16.getText();
				System.out.println(text);
				if (text.equalsIgnoreCase("")) {
					controller
							.log("Chuong trinh chan. Can't send cancel request for matched order");
				} else {
					OrderCancellation_1C get1CMessage = Day1FunctionTest
							.get1CMessage(text);
					controller
							.log("Chuong trinh chan. Can't send cancel request for matched order: "
									+ get1CMessage.toString());
				}
			}
		});
		button_1_1_1.setText("16. Cancel matched order ");
		button_1_1_1.setBounds(12, 187, 194, 26);
		panel_1.add(button_1_1_1);

		changeUnmatchedOrder17 = new JTextField();
		changeUnmatchedOrder17.setBounds(13, 252, 194, 20);
		panel_1.add(changeUnmatchedOrder17);

		final JButton button_1_1_1_1 = new JButton();
		button_1_1_1_1.addActionListener(new ActionListener() {
			// 17...
			public void actionPerformed(final ActionEvent e) {
				System.out.println(changeUnmatchedOrder17.getText());
				OrderChange_1D get1DMessage = Day1FunctionTest
						.get1DMessage(changeUnmatchedOrder17.getText());
				sendOrder(get1DMessage);
			}
		});
		button_1_1_1_1.setText("17. Change unmatched order");
		button_1_1_1_1.setBounds(12, 282, 202, 26);
		panel_1.add(button_1_1_1_1);

		changeMatchedOrder18 = new JTextField();
		changeMatchedOrder18.setBounds(12, 336, 194, 20);
		panel_1.add(changeMatchedOrder18);

		final JButton button_1_1_1_1_1 = new JButton();
		button_1_1_1_1_1.addActionListener(new ActionListener() {
			// 18...
			public void actionPerformed(final ActionEvent e) {
				String text = changeMatchedOrder18.getText();
				System.out.println(text);
				if (text.equalsIgnoreCase("")) {
					controller
							.log("Chuong trinh chan. Can't send change order request for matched order");
				} else {
					OrderChange_1D get1DMessage = Day1FunctionTest
							.get1DMessage(text);
					controller
							.log("Chuong trinh chan. Can't send change order request for matched order: "
									+ get1DMessage.toString());
				}
			}
		});
		button_1_1_1_1_1.setText("18. Change matched order ");
		button_1_1_1_1_1.setBounds(13, 365, 202, 26);
		panel_1.add(button_1_1_1_1_1);

		final JButton button_1_2 = new JButton();
		button_1_2.addActionListener(new ActionListener() {
			// 26...
			public void actionPerformed(final ActionEvent e) {
				//controller.setParseMessage(false);
				List<NewConditioned_1I> loadTest2 = C1ConformanceTest
						.loadTest2();
				sendOrders(loadTest2, "Open");
			}
		});
		button_1_2.setText("26. Load order #2 ");
		button_1_2.setBounds(288, 333, 194, 26);
		panel_1.add(button_1_2);

		final JButton button_2_2_1 = new JButton();
		// 21...
		button_2_2_1.addActionListener(new ActionListener() {
			public void actionPerformed(final ActionEvent e) {
				Advertisement_1E send = NormalTest.get1EMessage();
				controller.log("Chuong trinh chan:" + send.toString());
			}
		});
		button_2_2_1.setText("21. Send PT Advertisement c.1");
		button_2_2_1.setBounds(288, 112, 223, 26);
		panel_1.add(button_2_2_1);

		final JButton button_2_2_1_1 = new JButton();
		// 22...
		button_2_2_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(final ActionEvent e) {
				Advertisement_1E send = NormalTest.get1EBondMessage();
				sendOrder(send);
			}
		});
		button_2_2_1_1.setText("22. Send PT Advertisement c.2 (Bond 1E)");
		button_2_2_1_1.setBounds(288, 152, 277, 26);
		panel_1.add(button_2_2_1_1);

		final JLabel maCkLabel_2 = new JLabel();
		maCkLabel_2.setText("Security Symbol");
		maCkLabel_2.setBounds(299, 189, 108, 16);
		panel_1.add(maCkLabel_2);

		ttTextField = new JTextField();
		ttTextField.setText("DPM");
		ttTextField.setBounds(413, 187, 87, 20);
		panel_1.add(ttTextField);

		final JButton button_3_2 = new JButton();
		// 23...
		button_3_2.addActionListener(new ActionListener() {
			public void actionPerformed(final ActionEvent e) {
				String sb = ttTextField.getText().trim();
				NewConditioned_1I send = NormalTest.get1IForeignerMessage(sb);
				sendOrder(send);
			}
		});
		button_3_2.setText("23. Send Buying order of Foreigner");
		button_3_2.setBounds(288, 216, 232, 26);
		panel_1.add(button_3_2);

		final JLabel maCkLabel_1_1 = new JLabel();
		maCkLabel_1_1.setText("Security Symbol");
		maCkLabel_1_1.setBounds(288, 253, 108, 16);
		panel_1.add(maCkLabel_1_1);

		stbTextField = new JTextField();
		stbTextField.setText("STB");
		stbTextField.setBounds(409, 251, 87, 20);
		panel_1.add(stbTextField);

		final JButton button_3_1_1 = new JButton();
		// 24...
		button_3_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(final ActionEvent e) {
				String sb = stbTextField.getText().trim();
				NewConditioned_1I send = NormalTest.get1IForeignerMessage(sb);
				String message = "Chuong trinh chan.";
				controller.log(message);
				controller.log(send.toString());
			}
		});
		button_3_1_1.setText("24. Send Buying order of Foreigner (Room <10)");
		button_3_1_1.setBounds(288, 275, 284, 26);
		panel_1.add(button_3_1_1);

		final JButton button_2_2_1_2 = new JButton();
		// 19...
		button_2_2_1_2.addActionListener(new ActionListener() {
			public void actionPerformed(final ActionEvent e) {
				TwoFirmPutThroughDeal_1G send = NormalTest.get1GMessage();
				controller
						.log("Chuong trinh chan. Can't send two firm PT deal for Stock ");
				controller.log(send.toString());
			}
		});
		button_2_2_1_2.setText("19. Send PT Deal c3 (1G)");
		button_2_2_1_2.setBounds(288, 10, 194, 26);
		panel_1.add(button_2_2_1_2);

		final JButton button_2_2_1_1_1 = new JButton();
		// 20...
		button_2_2_1_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(final ActionEvent e) {
				TwoFirmPutThroughDeal_1G send = NormalTest.get1GBondMessage();
				sendOrder(send);
			}
		});
		button_2_2_1_1_1.setMargin(new Insets(0, 0, 0, 0));
		button_2_2_1_1_1.setText("20. Send PT Deal c4 (1G Bond)");
		button_2_2_1_1_1.setBounds(292, 55, 190, 26);
		panel_1.add(button_2_2_1_1_1);

		final JButton button_1_3 = new JButton();
		button_1_3.addActionListener(new ActionListener() {
			public void actionPerformed(final ActionEvent e) {
				controller.log("-------------- Bat dau Open ----------------");
			}
		});
		button_1_3.setText("Insert Open Separator");
		button_1_3.setBounds(302, 437, 194, 26);
		panel_1.add(button_1_3);

		final JPanel panel_2 = new JPanel();
		panel_2.setLayout(null);
		tabbedPane.addTab("PreClose", null, panel_2, null);

		final JButton button_1_2_1 = new JButton();
		button_1_2_1.addActionListener(new ActionListener() {
			// 30...
			public void actionPerformed(final ActionEvent e) {
				sendOrders(1);
			}
		});
		button_1_2_1.setText("30. Send order c.3 ");
		button_1_2_1.setBounds(23, 17, 194, 26);
		panel_2.add(button_1_2_1);

		final JButton button_1_2_1_1 = new JButton();
		button_1_2_1_1.addActionListener(new ActionListener() {
			// 31...
			public void actionPerformed(final ActionEvent e) {
				NewConditioned_1I order = C1ConformanceTest.getOrder("MP");
				controller.log("Chuong trinh chan khong goi : "
						+ order.toString());
				order = C1ConformanceTest.getOrder("ATO");
				controller.log("Chuong trinh chan khong goi : "
						+ order.toString());
			}
		});
		button_1_2_1_1.setText("31. Send order c.4");
		button_1_2_1_1.setBounds(23, 71, 194, 26);
		panel_2.add(button_1_2_1_1);

		cancelValidOrder32 = new JTextField();
		cancelValidOrder32.setBounds(23, 139, 190, 20);
		panel_2.add(cancelValidOrder32);

		final JButton button_1_2_1_1_1 = new JButton();
		button_1_2_1_1_1.addActionListener(new ActionListener() {
			// 32...
			public void actionPerformed(final ActionEvent e) {
				System.out.println(cancelValidOrder32.getText());
				OrderCancellation_1C get1CMessage = Day1FunctionTest
						.get1CMessage(cancelValidOrder32.getText());
				sendOrder(get1CMessage);
			}
		});
		button_1_2_1_1_1
				.setText("32. Cancel valid Order. Chi Cancel cac Order trong 2 phien truoc. ");
		button_1_2_1_1_1.setBounds(23, 170, 489, 26);
		panel_2.add(button_1_2_1_1_1);

		cancelRejectedOrder33 = new JTextField();
		cancelRejectedOrder33.setBounds(23, 231, 190, 20);
		panel_2.add(cancelRejectedOrder33);

		final JButton button_1_2_1_1_1_1 = new JButton();
		button_1_2_1_1_1_1.addActionListener(new ActionListener() {
			// 33...
			public void actionPerformed(final ActionEvent e) {
				String text = cancelRejectedOrder33.getText();
				System.out.println(text);
				if (text.equalsIgnoreCase("")) {
					controller
							.log("Chuong trinh chan. Can't send cancel request for rejected order");
				} else {
					OrderCancellation_1C get1CMessage = Day1FunctionTest
							.get1CMessage(text);
					controller
							.log("Chuong trinh chan. Can't send cancel request for rejected order: "
									+ get1CMessage.toString());
				}
			}
		});
		button_1_2_1_1_1_1.setText("33. Cancel rejected order");
		button_1_2_1_1_1_1.setBounds(23, 263, 194, 26);
		panel_2.add(button_1_2_1_1_1_1);

		changeOrder34 = new JTextField();
		changeOrder34.setBounds(23, 319, 190, 20);
		panel_2.add(changeOrder34);

		final JButton button_1_2_1_1_1_1_1 = new JButton();
		button_1_2_1_1_1_1_1.addActionListener(new ActionListener() {
			// 34...
			public void actionPerformed(final ActionEvent e) {
				System.out.println(changeOrder34.getText());
				OrderChange_1D get1DMessage = Day1FunctionTest
						.get1DMessage(changeOrder34.getText());
				sendOrder(get1DMessage);
			}
		});
		button_1_2_1_1_1_1_1.setText("34. Change order ");
		button_1_2_1_1_1_1_1.setBounds(23, 345, 194, 26);
		panel_2.add(button_1_2_1_1_1_1_1);

		final JButton button_1_2_1_1_1_1_1_1 = new JButton();
		button_1_2_1_1_1_1_1_1.addActionListener(new ActionListener() {
			// 36...
			public void actionPerformed(final ActionEvent e) {
				//controller.setParseMessage(false);
				List<NewConditioned_1I> loadTest3 = C1ConformanceTest
						.loadTest3();
				sendOrders(loadTest3, "PreClose");
			}
		});
		button_1_2_1_1_1_1_1_1.setText("36. Load Order#3 ");
		button_1_2_1_1_1_1_1_1.setBounds(305, 21, 194, 26);
		panel_2.add(button_1_2_1_1_1_1_1_1);

		final JButton insertPrecloseSeparatorButton = new JButton();
		insertPrecloseSeparatorButton.addActionListener(new ActionListener() {
			public void actionPerformed(final ActionEvent e) {
				controller
						.log("-------------- Bat dau PreClose ----------------");
			}
		});
		insertPrecloseSeparatorButton.setText("Insert PreClose Separator");
		insertPrecloseSeparatorButton.setBounds(307, 414, 194, 26);
		panel_2.add(insertPrecloseSeparatorButton);

		final JPanel panel_3 = new JPanel();
		panel_3.setLayout(null);
		tabbedPane.addTab("Close", null, panel_3, null);

		final JButton button_2_3_2_1 = new JButton();
		// 38...
		button_2_3_2_1.addActionListener(new ActionListener() {
			public void actionPerformed(final ActionEvent e) {
			//	controller.setParseMessage(true);
				Advertisement_1E send = NormalTest.get1EMessageRunOff();
				sendOrder(send);
			}
		});
		button_2_3_2_1.setMargin(new Insets(0, 0, 0, 0));
		button_2_3_2_1.setText("38. Send PT Advertisement c.3 (1E)");
		button_2_3_2_1.setBounds(10, 10, 225, 26);
		panel_3.add(button_2_3_2_1);

		final JButton button_2_3_2_1_1 = new JButton();
		// 39...
		button_2_3_2_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(final ActionEvent e) {
				Advertisement_1E send = NormalTest.get1EBondMessageRunoff();
				sendOrder(send);
			}
		});
		button_2_3_2_1_1.setMargin(new Insets(0, 0, 0, 0));
		button_2_3_2_1_1.setText("39. Send PT Advertisement c.4 (1E Bond)");
		button_2_3_2_1_1.setBounds(10, 53, 225, 26);
		panel_3.add(button_2_3_2_1_1);

		final JButton button_2_2_1_2_1 = new JButton();
		// 40...
		button_2_2_1_2_1.addActionListener(new ActionListener() {
			public void actionPerformed(final ActionEvent e) {
				TwoFirmPutThroughDeal_1G send = NormalTest
						.get1GForeignerMessage();
				sendOrder(send);
			}
		});
		button_2_2_1_2_1.setText("40. Send PT Deal c3 (1G)");
		button_2_2_1_2_1.setBounds(10, 97, 194, 26);
		panel_3.add(button_2_2_1_2_1);

		final JButton button_2_2_1_1_1_1 = new JButton();
		// 41...
		button_2_2_1_1_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(final ActionEvent e) {
				TwoFirmPutThroughDeal_1G send = NormalTest
						.get1GForeignerBondMessage();
				sendOrder(send);
			}
		});
		button_2_2_1_1_1_1.setText("41. Send PT Deal c4 (1G Bond)");
		button_2_2_1_1_1_1.setBounds(10, 140, 190, 26);
		panel_3.add(button_2_2_1_1_1_1);

		final JButton button_2_2_1_2_1_1 = new JButton();
		// 42...
		button_2_2_1_2_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(final ActionEvent e) {
				OneFirmPutThroughDeal_1F send = NormalTest
						.get1FForeignerMessage();
				sendOrder(send);
			}
		});
		button_2_2_1_2_1_1.setText("42. Send PT Deal c7 (1F)");
		button_2_2_1_2_1_1.setBounds(260, 10, 201, 26);
		panel_3.add(button_2_2_1_2_1_1);

		final JButton button_2_2_1_1_1_1_1 = new JButton();
		// 43...
		button_2_2_1_1_1_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(final ActionEvent e) {
				OneFirmPutThroughDeal_1F send = NormalTest
						.get1FForeignerBondMessage();
				sendOrder(send);
			}
		});
		button_2_2_1_1_1_1_1.setText("43. Send PT Deal c8 (1F Bond)");
		button_2_2_1_1_1_1_1.setBounds(260, 45, 215, 26);
		panel_3.add(button_2_2_1_1_1_1_1);

		final JButton button_2_2_1_2_1_2 = new JButton();
		button_2_2_1_2_1_2.addActionListener(new ActionListener() {
			public void actionPerformed(final ActionEvent e) {
			}
		});
		button_2_2_1_2_1_2.setText("44. Cancel PT Deal c1 (1F)");
		button_2_2_1_2_1_2.setBounds(260, 83, 194, 26);
		panel_3.add(button_2_2_1_2_1_2);

		final JButton button_2_2_1_1_1_1_2 = new JButton();
		button_2_2_1_1_1_1_2.addActionListener(new ActionListener() {
			public void actionPerformed(final ActionEvent e) {
			}
		});
		button_2_2_1_1_1_1_2.setText("45. Cancel PT Deal c2 (1G)");
		button_2_2_1_1_1_1_2.setBounds(260, 128, 190, 26);
		panel_3.add(button_2_2_1_1_1_1_2);

		final JButton send3bReplyButton = new JButton();
		// 50...
		send3bReplyButton.addActionListener(new ActionListener() {
			public void actionPerformed(final ActionEvent e) {
				String confirmNumber = textField.getText().trim();
				String replyCode = aTextField.getText().trim();
				String pVolumne = textField_3.getText().trim();
				String cVolumne = textField_4.getText().trim();
				String mVolumne = textField_5.getText().trim();
				String fVolumne = textField_6.getText().trim();
				String clientType = textField_1.getText().trim();
				PutThroughDealReply_3B send = C1ConformanceTest.get3BMessage(
						confirmNumber, replyCode, pVolumne, cVolumne, mVolumne,
						fVolumne, clientType);
				sendOrder(send);
			}
		});
		send3bReplyButton.setText("50. Send 3B reply for 1G");
		send3bReplyButton.setBounds(70, 382, 194, 26);
		panel_3.add(send3bReplyButton);

		final JButton button_2_2_1_2_1_2_1_1 = new JButton();
		// 52...
		button_2_2_1_2_1_2_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(final ActionEvent e) {
				String confirmNumber = textField_10.getText().trim();
				DealCancelReply_3D send = C1ConformanceTest
						.get3DMessage(confirmNumber);
				sendOrder(send);

			}
		});
		button_2_2_1_2_1_2_1_1.setText("52. Send 3D reply for 3C");
		button_2_2_1_2_1_2_1_1.setBounds(487, 382, 194, 26);
		panel_3.add(button_2_2_1_2_1_2_1_1);

		btnSend3C = new JButton();
		// 51...
		btnSend3C.addActionListener(new ActionListener() {
			public void actionPerformed(final ActionEvent arg0) {
				String Firm = textField_2.getText().trim();
				String ContraFirm = aTextField_1.getText().trim();
				String TraderID = textField_8.getText().trim();
				String ConfirmNumber = textField_9.getText().trim();
				String SecuritySymbol = ttcTextField_1.getText().trim();
				String Side = sTextField.getText().trim();
				DealPutThroughCancelRequest_3C send = C1ConformanceTest
						.getTwoFirm3CMessage(Firm, ContraFirm, TraderID,
								ConfirmNumber, SecuritySymbol, Side);
				sendOrder(send);
			}
		});
		btnSend3C.setToolTipText("send 2 firm put-through deal (1G)");
		btnSend3C.setFont(new Font("Dialog", Font.BOLD, 10));
		btnSend3C.setText("51. Send 3C");
		btnSend3C.setBounds(356, 383, 94, 27);
		panel_3.add(btnSend3C);

		textField = new JTextField();
		textField.setBounds(149, 218, 87, 20);
		panel_3.add(textField);

		final JLabel confirmNumberLabel = new JLabel();
		confirmNumberLabel.setText("Confirm Number");
		confirmNumberLabel.setBounds(52, 218, 103, 16);
		panel_3.add(confirmNumberLabel);

		final JLabel confirmNumberLabel_1 = new JLabel();
		confirmNumberLabel_1.setText("Reply Code");
		confirmNumberLabel_1.setBounds(79, 238, 63, 16);
		panel_3.add(confirmNumberLabel_1);

		aTextField = new JTextField();
		aTextField.setText("A");
		aTextField.setBounds(149, 242, 87, 20);
		panel_3.add(aTextField);

		final JLabel confirmNumberLabel_2 = new JLabel();
		confirmNumberLabel_2.setText("Portfolio Volume");
		confirmNumberLabel_2.setBounds(44, 263, 103, 16);
		panel_3.add(confirmNumberLabel_2);

		textField_3 = new JTextField();
		textField_3.setBounds(149, 264, 87, 20);
		panel_3.add(textField_3);

		final JLabel confirmNumberLabel_3 = new JLabel();
		confirmNumberLabel_3.setText("Client Volume");
		confirmNumberLabel_3.setBounds(52, 286, 103, 16);
		panel_3.add(confirmNumberLabel_3);

		textField_4 = new JTextField();
		textField_4.setText("30000");
		textField_4.setBounds(149, 286, 87, 20);
		panel_3.add(textField_4);

		final JLabel confirmNumberLabel_1_1 = new JLabel();
		confirmNumberLabel_1_1.setText("Fund Volume");
		confirmNumberLabel_1_1.setBounds(52, 310, 103, 16);
		panel_3.add(confirmNumberLabel_1_1);

		textField_5 = new JTextField();
		textField_5.setBounds(149, 310, 87, 20);
		panel_3.add(textField_5);

		final JLabel confirmNumberLabel_2_1 = new JLabel();
		confirmNumberLabel_2_1.setText("Foreigner Volume");
		confirmNumberLabel_2_1.setBounds(34, 333, 111, 16);
		panel_3.add(confirmNumberLabel_2_1);

		textField_6 = new JTextField();
		textField_6.setBounds(149, 332, 87, 20);
		panel_3.add(textField_6);

		final JLabel confirmNumberLabel_4 = new JLabel();
		confirmNumberLabel_4.setText("Firm");
		confirmNumberLabel_4.setBounds(316, 232, 25, 16);
		panel_3.add(confirmNumberLabel_4);

		textField_2 = new JTextField();
		textField_2.setText("57");
		textField_2.setBounds(356, 230, 87, 20);
		panel_3.add(textField_2);

		final JLabel confirmNumberLabel_1_2 = new JLabel();
		confirmNumberLabel_1_2.setText("Contra Firm");
		confirmNumberLabel_1_2.setBounds(270, 255, 77, 16);
		panel_3.add(confirmNumberLabel_1_2);

		aTextField_1 = new JTextField();
		aTextField_1.setText("57");
		aTextField_1.setBounds(356, 254, 87, 20);
		panel_3.add(aTextField_1);

		final JLabel confirmNumberLabel_2_2 = new JLabel();
		confirmNumberLabel_2_2.setText("Security Symbol");
		confirmNumberLabel_2_2.setBounds(250, 325, 103, 16);
		panel_3.add(confirmNumberLabel_2_2);

		ttcTextField_1 = new JTextField();
		ttcTextField_1.setText("DPM");
		ttcTextField_1.setBounds(360, 320, 87, 20);
		panel_3.add(ttcTextField_1);

		final JLabel confirmNumberLabel_3_1 = new JLabel();
		confirmNumberLabel_3_1.setText("Trader ID");
		confirmNumberLabel_3_1.setBounds(279, 275, 63, 16);
		panel_3.add(confirmNumberLabel_3_1);

		textField_8 = new JTextField();
		textField_8.setText("571");
		textField_8.setBounds(357, 275, 87, 20);
		panel_3.add(textField_8);

		final JLabel confirmNumberLabel_1_1_1 = new JLabel();
		confirmNumberLabel_1_1_1.setText("Confirm Number");
		confirmNumberLabel_1_1_1.setBounds(260, 299, 103, 16);
		panel_3.add(confirmNumberLabel_1_1_1);

		textField_9 = new JTextField();
		textField_9.setBounds(357, 299, 87, 20);
		panel_3.add(textField_9);

		final JLabel confirmNumberLabel_2_1_1 = new JLabel();
		confirmNumberLabel_2_1_1.setText("Side");
		confirmNumberLabel_2_1_1.setBounds(316, 345, 25, 16);
		panel_3.add(confirmNumberLabel_2_1_1);

		sTextField = new JTextField();
		sTextField.setText("S");
		sTextField.setBounds(360, 344, 87, 20);
		panel_3.add(sTextField);

		final JLabel confirmNumberLabel_4_1 = new JLabel();
		confirmNumberLabel_4_1.setText("Firm");
		confirmNumberLabel_4_1.setBounds(527, 294, 25, 16);
		panel_3.add(confirmNumberLabel_4_1);

		textField_7 = new JTextField();
		textField_7.setText("57");
		textField_7.setBounds(567, 292, 87, 20);
		panel_3.add(textField_7);

		final JLabel confirmNumberLabel_1_1_1_1 = new JLabel();
		confirmNumberLabel_1_1_1_1.setText("Confirm Number");
		confirmNumberLabel_1_1_1_1.setBounds(471, 318, 103, 16);
		panel_3.add(confirmNumberLabel_1_1_1_1);

		textField_10 = new JTextField();
		textField_10.setBounds(568, 318, 87, 20);
		panel_3.add(textField_10);

		final JLabel confirmNumberLabel_2_1_1_1 = new JLabel();
		confirmNumberLabel_2_1_1_1.setText("Reply Code");
		confirmNumberLabel_2_1_1_1.setBounds(481, 345, 78, 16);
		panel_3.add(confirmNumberLabel_2_1_1_1);

		sTextField_1 = new JTextField();
		sTextField_1.setText("A");
		sTextField_1.setBounds(568, 342, 87, 20);
		panel_3.add(sTextField_1);

		final JButton insertCloseSeparatorButton = new JButton();
		insertCloseSeparatorButton.addActionListener(new ActionListener() {
			public void actionPerformed(final ActionEvent e) {
				controller.log("-------------- Bat dau Close ----------------");
			}
		});
		insertCloseSeparatorButton.setMargin(new Insets(0, 0, 0, 0));
		insertCloseSeparatorButton.setText("Insert Close Separator");
		insertCloseSeparatorButton.setBounds(295, 442, 225, 26);
		panel_3.add(insertCloseSeparatorButton);

		textField_1 = new JTextField();
		textField_1.setText("F");
		textField_1.setBounds(148, 356, 87, 20);
		panel_3.add(textField_1);

		final JLabel clientTypeLabel = new JLabel();
		clientTypeLabel.setText("Client Type");
		clientTypeLabel.setBounds(44, 360, 85, 16);
		panel_3.add(clientTypeLabel);
	}

	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
		// jContentPane = (JPanel)this.getContentPane();
		this.getContentPane().setLayout(null);
		this.getContentPane().setBackground(SystemColor.control);
		this.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
		this.setResizable(false);
		setSize(new Dimension(800, 600));
		this.setTitle("C1 Conformance Test");
	}

	/**
	 * This method initializes jContentPane
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getJContentPane() {
		if (jContentPane == null) {
			jContentPane = new JPanel();
			jContentPane.setLayout(null);
		}
		return jContentPane;
	}

	// Connect to Server

	/************ Code chung *************************************/
	public void sendOrder(ValueObject object) {
		try {
			controller.sendMessageToQueue(object);
		} catch (Exception e1) {
			e1.printStackTrace();
		}
	}

	public void sendOrders(List listOrders) {
		sendOrders(listOrders, "");
	}

	public void sendOrders(List listOrders, String marketStatus) {
		try {
			Object object;
			NewConditioned_1I new1I;
			for (int i = 0; i < listOrders.size(); i++) {
				controller.log("Load Test : number " + i + " trong "
						+ marketStatus);
				// System.out.println("Load Test : number " + i);
				object = listOrders.get(i);
				if (object instanceof NewConditioned_1I) {
					new1I = (NewConditioned_1I) object;
					if (marketStatus.equalsIgnoreCase("PreOpen")) {
						if (new1I.getPrice().equalsIgnoreCase("ATC")
								|| new1I.getPrice().equalsIgnoreCase("MP")) {
							controller
									.log("Chuong trinh chan. Can't send order: "
											+ new1I.toString());
							continue;
						}
					} else if (marketStatus.equalsIgnoreCase("Open")) {
						if (new1I.getPrice().equalsIgnoreCase("ATC")
								|| new1I.getPrice().equalsIgnoreCase("MP")
								|| new1I.getPrice().equalsIgnoreCase("ATO")) {
							controller
									.log("Chuong trinh chan. Can't send order: "
											+ new1I.toString());
							continue;
						}
					} else if (marketStatus.equalsIgnoreCase("PreClose")) {
						if (new1I.getPrice().equalsIgnoreCase("MP")
								|| new1I.getPrice().equalsIgnoreCase("ATO")) {
							controller
									.log("Chuong trinh chan. Can't send order: "
											+ new1I.toString());
							continue;
						}
					} else if (marketStatus.equalsIgnoreCase("Close")) {
						// Can't send ATO,ATC,MP,LO trong Close
						controller.log("Chuong trinh chan. Can't send order: "
								+ new1I.toString());
						continue;
					}
				}
				controller.sendMessageToQueue(object);
			}
		} catch (Exception e1) {
			e1.printStackTrace();
		}
	}

	public void sendOrders(int numberOfOrders) {
		List<NewConditioned_1I> get1IMessages = NormalTest
				.get1IMessages(numberOfOrders);
		for (NewConditioned_1I new1I : get1IMessages) {
			sendOrder(new1I);
		}
	}
	/************ End Code chung *************************************/

} // @jve:decl-index=0:visual-constraint="2,6"
