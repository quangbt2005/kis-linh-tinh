package eps.com.test;

import java.util.ArrayList;
import java.util.List;

import eps.com.message.sended.Advertisement_1E;
import eps.com.message.sended.DealCancelReply_3D;
import eps.com.message.sended.DealPutThroughCancelRequest_3C;
import eps.com.message.sended.NewConditioned_1I;
import eps.com.message.sended.OneFirmPutThroughDeal_1F;
import eps.com.message.sended.OrderCancellation_1C;
import eps.com.message.sended.OrderChange_1D;
import eps.com.message.sended.PutThroughDealReply_3B;
import eps.com.message.sended.TwoFirmPutThroughDeal_1G;

public class NormalTest {
	 //private static String ContraFirmBuyer = "001";
	 //private static String TraderIDBuyer = "2001";

	 private static String ContraFirmBuyer = "048";
	 private static String TraderIDBuyer = "0481";


	//private static String ContraFirmBuyer = "061";
	//private static String TraderIDBuyer = "611";

	// 61 611

	public static NewConditioned_1I get1IMessage() {
		List<NewConditioned_1I> get1IMessages = get1IMessages(1);
		return get1IMessages.get(0);
	}

	public static List<NewConditioned_1I> get1IMessages(int numberOfMessages) {
		String randomOrderNumber = TestCommon.createRandomOrderNumber();
		return get1IMessages(numberOfMessages, randomOrderNumber, "B");
	}

	public static List<NewConditioned_1I> get1IMessages(int numberOfMessages,
			String orderNumber) {
		return get1IMessages(numberOfMessages, orderNumber, "B");
	}

	public static List<NewConditioned_1I> get1IMessages(int numberOfMessages,
			String orderNumber, String buyOrSell) {
		return get1IMessages(numberOfMessages, orderNumber, buyOrSell, "");
	}

	public static List<NewConditioned_1I> get1IMessages(int numberOfMessages,
			String orderNumber, String buyOrSell, String orderType) {
		List<NewConditioned_1I> ret = new ArrayList<NewConditioned_1I>();

		NewConditioned_1I order;
		for (int i = 0; i < numberOfMessages; i++) {
			// String orderNumber = TestCommon.createRandomOrderNumber();
			String clientID = TestCommon.createRandomAcountBuy();
			String sb = TestCommon.createRandomSymbol();

			order = new NewConditioned_1I();
			order.setFirm("057");
			order.setTraderID("2120");
			order.setOrderNumber(TestCommon
					.getRandomOrderNumber(orderNumber, i));
			order.setClientID(clientID);
			order.setSecuritySymbol(sb);
			order.setSide(buyOrSell);
			order.setVolume("1000    ");
			order.setPublishedVolume("1000    ");
			if (orderType.equals("")) {
				order.setPrice(TestCommon.getPrice(sb));
			} else {
				order.setPrice(orderType);
			}

			order.setBoard("M");
			order.setFiller("");
			order.setPortClientFlag("C");
			order.setFiller2("");

			ret.add(order);

			System.out.println(order.getOrderNumber());
		}
		return ret;
	}

	public static NewConditioned_1I get1IForeignerMessage(String sb) {
		List<NewConditioned_1I> get1IMessages = get1IForeignerMessages(sb, 1);
		return get1IMessages.get(0);
	}

	public static List<NewConditioned_1I> get1IForeignerMessages(String sb,
			int numberOfMessages) {
		String randomOrderNumber = TestCommon.createRandomOrderNumber();
		return get1IForeignerMessages(sb, numberOfMessages, randomOrderNumber);
	}

	public static List<NewConditioned_1I> get1IForeignerMessages(String sb,
			int numberOfMessages, String orderNumber) {
		return get1IForeignerMessages(sb, numberOfMessages, orderNumber, "B");
	}

	public static List<NewConditioned_1I> get1IForeignerMessages(String sb,
			int numberOfMessages, String orderNumber, String buyOrSell) {
		return get1IForeignerMessages(sb, numberOfMessages, orderNumber,
				buyOrSell, "");
	}

	public static List<NewConditioned_1I> get1IForeignerMessages(String sb,
			int numberOfMessages, String orderNumber, String buyOrSell,
			String orderType) {
		List<NewConditioned_1I> ret = new ArrayList<NewConditioned_1I>();

		NewConditioned_1I order;
		for (int i = 0; i < numberOfMessages; i++) {
			// String orderNumber = TestCommon.createRandomOrderNumber();
			String clientID = TestCommon.createRandomForeignerAcountBuy();
			if (sb == null)
				sb = TestCommon.createRandomSymbol();

			order = new NewConditioned_1I();
			order.setFirm("057");
			order.setTraderID("2120");
			order.setOrderNumber(TestCommon
					.getRandomOrderNumber(orderNumber, i));
			order.setClientID(clientID);
			order.setSecuritySymbol(sb);
			order.setSide(buyOrSell);
			order.setVolume("1000    ");
			order.setPublishedVolume("1000    ");
			if (orderType.equals("")) {
				order.setPrice(TestCommon.getPrice(sb));
			} else {
				order.setPrice(orderType);
			}

			order.setBoard("M");
			order.setFiller("");
			order.setPortClientFlag("F");
			order.setFiller2("");

			ret.add(order);

			System.out.println(order.getOrderNumber());
		}
		return ret;
	}

	public static List<OrderCancellation_1C> get1CMessages(
			int numberOfMessages, String orderNumber) {
		List<OrderCancellation_1C> ret = new ArrayList<OrderCancellation_1C>();

		OrderCancellation_1C order;
		for (int i = 0; i < numberOfMessages; i++) {
			order = new OrderCancellation_1C();
			order.setFirm("057");
			order.setOrderNumber(TestCommon
					.getRandomOrderNumber(orderNumber, i));
			order.setOrderEntryDate(TestCommon.today);

			ret.add(order);
		}
		return ret;
	}

	public static List<OrderChange_1D> get1DMessages(int numberOfMessages,
			String orderNumber) {
		List<OrderChange_1D> ret = new ArrayList<OrderChange_1D>();

		OrderChange_1D order;
		for (int i = 0; i < numberOfMessages; i++) {
			String clientID = TestCommon.createRandomAcountBuy();

			order = new OrderChange_1D();
			order.setFirm("057");
			order.setOrderNumber(TestCommon
					.getRandomOrderNumber(orderNumber, i));
			order.setOrderEntryDate(TestCommon.today);
			order.setClientID(clientID);
			order.setFiller("");

			ret.add(order);
		}
		return ret;
	}

	public static Advertisement_1E get1EMessageinPreOpen() {
		Advertisement_1E send = new Advertisement_1E();
		String SecuritySymbol = TestCommon.createRandomSymbol();

		send.setFirm("057");
		send.setTraderID("2120");
		send.setSecuritySymbol(SecuritySymbol);
		send.setSide("S");

		send.setVolume("30000");

		send.setPrice(TestCommon.getPrice1E(SecuritySymbol));

		// double price =
		// Double.parseDouble(TestCommon.getCeiling(SecuritySymbol)) * 1000000;
		// send.setPrice("" + price);
		send.setBoard("B");
		send.setTime("084008");
		send.setAddCancelFlag("A");

		String temp = "";
		for (int i = 0; i < 20; i++) {
			temp += " ";
		}
		send.setContact("NguyenVanA");
		return send;
	}

	/**
	 * quang cao 1 GGTT cho nhan ve message AA
	 * 
	 * @return
	 */
	public static Advertisement_1E get1EMessage() {
		Advertisement_1E send = new Advertisement_1E();
		String SecuritySymbol = TestCommon.createRandomSymbol();

		send.setFirm("057");
		send.setTraderID("2120");
		send.setSecuritySymbol(SecuritySymbol);
		send.setSide("S");

		send.setVolume("30000");

		send.setPrice(TestCommon.getPrice1E(SecuritySymbol));

		// double price =
		// Double.parseDouble(TestCommon.getCeiling(SecuritySymbol)) * 1000000;
		// send.setPrice("" + price);
		send.setBoard("B");
		send.setTime("093508");
		send.setAddCancelFlag("A");

		String temp = "";
		for (int i = 0; i < 20; i++) {
			temp += " ";
		}
		send.setContact("NguyenVanA");
		return send;
	}

	/**
	 * quang cao 1 GGTT cho nhan ve message AA
	 * 
	 * @return
	 */
	public static Advertisement_1E get1EBondMessage() {
		Advertisement_1E send = new Advertisement_1E();
		String BondSymbol = TestCommon.createRandomBond();

		send.setFirm("057");
		send.setTraderID("2120");
		send.setSecuritySymbol(BondSymbol);
		send.setSide("S");

		send.setVolume("30000");

		send.setPrice(TestCommon.getPriceBond1E(BondSymbol));

		// double price =
		// Double.parseDouble(TestCommon.getCeiling(SecuritySymbol)) * 1000000;
		// send.setPrice("" + price);
		send.setBoard("B");
		send.setTime("093508");
		send.setAddCancelFlag("A");

		String temp = "";
		for (int i = 0; i < 20; i++) {
			temp += " ";
		}
		send.setContact("NguyenVanA");
		return send;
	}

	/**
	 * quang cao 1 GGTT cho nhan ve message AA
	 * 
	 * @return
	 */
	public static Advertisement_1E get1EMessageRunOff() {
		Advertisement_1E send = new Advertisement_1E();
		String SecuritySymbol = TestCommon.createRandomSymbol();

		send.setFirm("057");
		send.setTraderID("2120");
		send.setSecuritySymbol(SecuritySymbol);
		send.setSide("S");

		send.setVolume("30000");

		send.setPrice(TestCommon.getPrice1E(SecuritySymbol));

		// double price =
		// Double.parseDouble(TestCommon.getCeiling(SecuritySymbol)) * 1000000;
		// send.setPrice("" + price);
		send.setBoard("B");
		send.setTime("103508");
		send.setAddCancelFlag("A");

		String temp = "";
		for (int i = 0; i < 20; i++) {
			temp += " ";
		}
		send.setContact("NguyenVanA");
		return send;
	}

	/**
	 * quang cao 1 GGTT cho nhan ve message AA
	 * 
	 * @return
	 */
	public static Advertisement_1E get1EBondMessageRunoff() {
		Advertisement_1E send = new Advertisement_1E();
		String BondSymbol = TestCommon.createRandomBond();
		//BondSymbol ="HCMA0705";
		send.setFirm("057");
		send.setTraderID("2120");
		send.setSecuritySymbol(BondSymbol);
		send.setSide("S");

		send.setVolume("30000");

		send.setPrice(TestCommon.getPriceBond1E(BondSymbol));

		// double price =
		// Double.parseDouble(TestCommon.getCeiling(SecuritySymbol)) * 1000000;
		// send.setPrice("" + price);
		send.setBoard("B");
		send.setTime("103608");
		send.setAddCancelFlag("A");

		String temp = "";
		for (int i = 0; i < 20; i++) {
			temp += " ";
		}
		send.setContact("NguyenVanA");
		return send;
	}

	public static List<OneFirmPutThroughDeal_1F> get1FMessages(
			int numberOfMessages) {
		List<OneFirmPutThroughDeal_1F> ret = new ArrayList<OneFirmPutThroughDeal_1F>();
		OneFirmPutThroughDeal_1F get1FMessage;
		for (int i = 0; i < numberOfMessages; i++) {
			get1FMessage = get1FMessage();
			ret.add(get1FMessage);
		}
		return ret;
	}

	/**
	 * khach hang giao dich thoa thuan cung cong ty
	 * 
	 * @return
	 */
	public static OneFirmPutThroughDeal_1F get1FMessage() {
		String ClientID1 = TestCommon.createRandomAcountBuy();
		String ClientID2 = TestCommon.createRandomAcountBuy();
		String SecuritySymbol = TestCommon.createRandomSymbol();
		String temp = "";

		OneFirmPutThroughDeal_1F send = new OneFirmPutThroughDeal_1F();

		send.setFirm("057");
		send.setTraderID("2120");
		send.setClientIDBuyer(ClientID1);
		send.setClientIDSeller(ClientID2);
		send.setSecuritySymbol(SecuritySymbol);

		send.setPrice(TestCommon.getPrice1E(SecuritySymbol));
		// send.setPrice(TestCommon.getCeiling(SecuritySymbol));

		send.setBoard("B");
		send.setDealID("123");
		for (int i = 0; i < 8; i++) {
			temp += " ";
		}
		send.setFiller(temp);
		send.setBrokerPortfolioVolumeBuyer("");
		send.setBrokerClientVolumeBuyer("30000");
		send.setMutualFundVolumeBuyer("");
		send.setBrokerForeignVolumeBuyer("");
		temp = "";
		for (int i = 0; i < 32; i++) {
			temp += " ";
		}
		send.setFiller2(temp);
		send.setBrokerPortfolioVolumeSeller("");
		send.setBrokerClientVolumeSeller("30000");
		send.setMutualFundVolumeSeller("");
		send.setBrokerForeignVolumeSeller("");
		temp = "";
		for (int i = 0; i < 32; i++) {
			temp += " ";
		}
		send.setFiller2(temp);

		temp = "";
		for (int i = 0; i < 32; i++) {
			temp += " ";
		}
		send.setFiller3(temp);
		return send;
	}

	public static OneFirmPutThroughDeal_1F get1FBondMessage() {
		String ClientID1 = TestCommon.createRandomAcountBuy();
		String ClientID2 = TestCommon.createRandomAcountBuy();
		String BondSymbol = TestCommon.createRandomBond();
		String temp = "";

		OneFirmPutThroughDeal_1F send = new OneFirmPutThroughDeal_1F();

		send.setFirm("057");
		send.setTraderID("2120");
		send.setClientIDBuyer(ClientID1);
		send.setClientIDSeller(ClientID2);
		send.setSecuritySymbol(BondSymbol);

		send.setPrice(TestCommon.getPriceBond1E(BondSymbol));
		// send.setPrice(TestCommon.getCeiling(SecuritySymbol));

		send.setBoard("B");
		send.setDealID("123");
		for (int i = 0; i < 8; i++) {
			temp += " ";
		}
		send.setFiller(temp);
		send.setBrokerPortfolioVolumeBuyer("");
		send.setBrokerClientVolumeBuyer("30000");
		send.setMutualFundVolumeBuyer("");
		send.setBrokerForeignVolumeBuyer("");
		temp = "";
		for (int i = 0; i < 32; i++) {
			temp += " ";
		}
		send.setFiller2(temp);
		send.setBrokerPortfolioVolumeSeller("");
		send.setBrokerClientVolumeSeller("30000");
		send.setMutualFundVolumeSeller("");
		send.setBrokerForeignVolumeSeller("");
		temp = "";
		for (int i = 0; i < 32; i++) {
			temp += " ";
		}
		send.setFiller2(temp);

		temp = "";
		for (int i = 0; i < 32; i++) {
			temp += " ";
		}
		send.setFiller3(temp);
		return send;
	}

	// 1F Runoff
	/**
	 * khach hang giao dich thoa thuan cung cong ty 1 Foreigner & 1 client
	 * 
	 * @return
	 */
	public static OneFirmPutThroughDeal_1F get1FForeignerMessage() {
		// 1 : buy
		String ClientID1 = TestCommon.createRandomForeignerAcountBuy();
		String ClientID2 = TestCommon.createRandomAcountBuy();
		String SecuritySymbol = "DPM";
		String temp = "";

		OneFirmPutThroughDeal_1F send = new OneFirmPutThroughDeal_1F();

		send.setFirm("057");
		send.setTraderID("2120");
		send.setClientIDBuyer(ClientID1);
		send.setClientIDSeller(ClientID2);
		send.setSecuritySymbol(SecuritySymbol);

		send.setPrice(TestCommon.getPrice1E(SecuritySymbol));
		// send.setPrice(TestCommon.getCeiling(SecuritySymbol));

		send.setBoard("B");
		send.setDealID("123");
		for (int i = 0; i < 8; i++) {
			temp += " ";
		}
		send.setFiller(temp);
		send.setBrokerPortfolioVolumeBuyer("");
		send.setBrokerClientVolumeBuyer("");
		send.setMutualFundVolumeBuyer("");
		send.setBrokerForeignVolumeBuyer("30000");
		temp = "";
		for (int i = 0; i < 32; i++) {
			temp += " ";
		}
		send.setFiller2(temp);
		send.setBrokerPortfolioVolumeSeller("");
		send.setBrokerClientVolumeSeller("30000");
		send.setMutualFundVolumeSeller("");
		send.setBrokerForeignVolumeSeller("");
		temp = "";
		for (int i = 0; i < 32; i++) {
			temp += " ";
		}
		send.setFiller2(temp);

		temp = "";
		for (int i = 0; i < 32; i++) {
			temp += " ";
		}
		send.setFiller3(temp);
		return send;
	}

	// nhan ve 2L cua 1F :
	// 1. Message Type
	// 2. Firm
	// 3. Side
	// 4. Deal ID
	// 5. Contra Firm
	// 6. Volume
	// 7. Price
	// 8. Confirm Number
	// nguoi mua cancel giao dich thoa thuan 1F
	// MessageType=2L ; Firm=57 ; Side=X ; DealID=123 ; ContraFirm=57 ;
	// Volume=30000 ; Price=000012100000 ; ConfirmNumber=76 ;
	public static DealPutThroughCancelRequest_3C get3CMessage() {
		DealPutThroughCancelRequest_3C request = new DealPutThroughCancelRequest_3C();

		request.setFirm("057");
		request.setContraFirm("61");
		request.setTraderID("2120");
		request.setConfirmNumber("115");
		request.setSecuritySymbol("TTC");
		request.setSide("B");

		return request;
	}

	public static OneFirmPutThroughDeal_1F get1FForeignerBondMessage() {
		String ClientID1 = TestCommon.createRandomForeignerAcountBuy();
		String ClientID2 = TestCommon.createRandomAcountBuy();
		String BondSymbol = "HCMA0705";
		String temp = "";

		OneFirmPutThroughDeal_1F send = new OneFirmPutThroughDeal_1F();

		send.setFirm("057");
		send.setTraderID("2120");
		send.setClientIDBuyer(ClientID1);
		send.setClientIDSeller(ClientID2);
		send.setSecuritySymbol(BondSymbol);

		send.setPrice(TestCommon.getPriceBond1E(BondSymbol));
		// send.setPrice(TestCommon.getCeiling(SecuritySymbol));

		send.setBoard("B");
		send.setDealID("123");
		for (int i = 0; i < 8; i++) {
			temp += " ";
		}
		send.setFiller(temp);
		send.setBrokerPortfolioVolumeBuyer("");
		send.setBrokerClientVolumeBuyer("");
		send.setMutualFundVolumeBuyer("");
		send.setBrokerForeignVolumeBuyer("3000");
		temp = "";
		for (int i = 0; i < 32; i++) {
			temp += " ";
		}
		send.setFiller2(temp);
		send.setBrokerPortfolioVolumeSeller("");
		send.setBrokerClientVolumeSeller("3000");
		send.setMutualFundVolumeSeller("");
		send.setBrokerForeignVolumeSeller("");
		temp = "";
		for (int i = 0; i < 32; i++) {
			temp += " ";
		}
		send.setFiller2(temp);

		temp = "";
		for (int i = 0; i < 32; i++) {
			temp += " ";
		}
		send.setFiller3(temp);
		return send;
	}

	public static List<TwoFirmPutThroughDeal_1G> get1GMessages(
			int numberOfMessages) {
		List<TwoFirmPutThroughDeal_1G> ret = new ArrayList<TwoFirmPutThroughDeal_1G>();
		TwoFirmPutThroughDeal_1G get1FMessage;
		for (int i = 0; i < numberOfMessages; i++) {
			get1FMessage = get1GMessage();
			ret.add(get1FMessage);
		}
		return ret;
	}

	/**
	 * ben ban send 1G ban, cho nhan ve 2L
	 * 
	 */
	public static TwoFirmPutThroughDeal_1G get1GBondMessage() {
		TwoFirmPutThroughDeal_1G send = new TwoFirmPutThroughDeal_1G();
		send.setFirmSeller("057");
		send.setTraderIDSeller("2120");

		String ClientID = TestCommon.createRandomAcountBuy();
		send.setClientIDSeller(ClientID);
		String ClientID1 = TestCommon.createRandomOrderNumber();
		send.setContraFirmBuyer(ContraFirmBuyer);
		send.setTraderIDBuyer(TraderIDBuyer);
		String BondSymbol = TestCommon.createRandomBond();
		send.setSecuritySymbol(BondSymbol);

		send.setPrice(TestCommon.getPriceBond1E(BondSymbol));
		// send.setPrice(TestCommon.getFloor(SecuritySymbol));

		send.setBoard("B");
		send.setDealID("12345");

		String temp = "";
		for (int i = 0; i < 4; i++) {
			temp += " ";
		}
		send.setFiller(temp);
		send.setBrokerPortfolioVolumeSeller("");
		send.setBrokerClientVolumeSeller("30000");
		send.setMutualFundVolumeSeller("");
		send.setBrokerForeignVolumeSeller("");
		temp = "";
		for (int i = 0; i < 32; i++) {
			temp += " ";
		}
		send.setFiller2(temp);
		return send;
	}

	/**
	 * ben ban send 1G ban, cho nhan ve 2L
	 * 
	 */

	public static TwoFirmPutThroughDeal_1G get1GMessage() {
		TwoFirmPutThroughDeal_1G send = new TwoFirmPutThroughDeal_1G();
		send.setFirmSeller("057");
		send.setTraderIDSeller("2120");

		String ClientID = TestCommon.createRandomAcountBuy();
		send.setClientIDSeller(ClientID);
		send.setContraFirmBuyer(ContraFirmBuyer);
		send.setTraderIDBuyer(TraderIDBuyer);
		String SecuritySymbol = TestCommon.createRandomSymbol();
		send.setSecuritySymbol(SecuritySymbol);

		send.setPrice(TestCommon.getPrice1E(SecuritySymbol));
		// send.setPrice(TestCommon.getFloor(SecuritySymbol));

		send.setBoard("B");
		send.setDealID("12345");

		String temp = "";
		for (int i = 0; i < 4; i++) {
			temp += " ";
		}
		send.setFiller(temp);
		send.setBrokerPortfolioVolumeSeller("");
		send.setBrokerClientVolumeSeller("30000");
		send.setMutualFundVolumeSeller("");
		send.setBrokerForeignVolumeSeller("");
		temp = "";
		for (int i = 0; i < 32; i++) {
			temp += " ";
		}
		send.setFiller2(temp);
		return send;
	}

	// //Runoff session
	public static TwoFirmPutThroughDeal_1G get1GForeignerBondMessage() {
		TwoFirmPutThroughDeal_1G send = new TwoFirmPutThroughDeal_1G();
		send.setFirmSeller("057");
		send.setTraderIDSeller("2120");

		String ClientID = TestCommon.createRandomAcountBuy();
		send.setClientIDSeller(ClientID);
		send.setContraFirmBuyer(ContraFirmBuyer);
		send.setTraderIDBuyer(TraderIDBuyer);
		//String BondSymbol = TestCommon.createRandomBond();
		String BondSymbol ="HCMA0705";
		send.setSecuritySymbol(BondSymbol);

		send.setPrice(TestCommon.getPriceBond1E(BondSymbol));
		// send.setPrice(TestCommon.getFloor(SecuritySymbol));

		send.setBoard("B");
		send.setDealID("12345");

		String temp = "";
		for (int i = 0; i < 4; i++) {
			temp += " ";
		}
		send.setFiller(temp);
		send.setBrokerPortfolioVolumeSeller("");
		send.setBrokerClientVolumeSeller("3000");
		send.setMutualFundVolumeSeller("");
		send.setBrokerForeignVolumeSeller("");
		temp = "";
		for (int i = 0; i < 32; i++) {
			temp += " ";
		}
		send.setFiller2(temp);
		return send;
	}

	public static TwoFirmPutThroughDeal_1G get1GForeignerMessage() {
		TwoFirmPutThroughDeal_1G send = new TwoFirmPutThroughDeal_1G();
		send.setFirmSeller("057");
		send.setTraderIDSeller("2120");

		String ClientID = TestCommon.createRandomAcountBuy();
		send.setClientIDSeller(ClientID);
		send.setContraFirmBuyer(ContraFirmBuyer);
		send.setTraderIDBuyer(TraderIDBuyer);
		String SecuritySymbol = "DPM";
		send.setSecuritySymbol(SecuritySymbol);

		send.setPrice(TestCommon.getPrice1E(SecuritySymbol));
		// send.setPrice(TestCommon.getFloor(SecuritySymbol));

		send.setBoard("B");
		send.setDealID("12345");

		String temp = "";
		for (int i = 0; i < 4; i++) {
			temp += " ";
		}
		send.setFiller(temp);
		send.setBrokerPortfolioVolumeSeller("");
		send.setBrokerClientVolumeSeller("30000");
		send.setMutualFundVolumeSeller("");
		send.setBrokerForeignVolumeSeller("");
		temp = "";
		for (int i = 0; i < 32; i++) {
			temp += " ";
		}
		send.setFiller2(temp);
		return send;
	}

	// nhan ve 2L cua 1G:
	// 1. Message Type
	// 2. Firm
	// 3. Side
	// 4. Deal ID
	// 5. Contra Firm
	// 6. Volume
	// 7. Price
	// 8. Confirm Number
	// nguoi ban cancel giao dich thoa thuan 2Firm
	// nguoi ban la nguoi chu dong send 1G
	public static DealPutThroughCancelRequest_3C getTwoFirm3CMessage() {
		DealPutThroughCancelRequest_3C request = new DealPutThroughCancelRequest_3C();

		request.setFirm("057");
		request.setContraFirm("61");
		request.setTraderID("2120");
		request.setConfirmNumber("115");
		request.setSecuritySymbol("TTC");
		request.setSide("B");

		return request;
	}

	// MessageType=2F ; FirmBuy=57 ; TraderIDBuy=571 ; SideB=B ;
	// ContraFirmSell=1 ; TraderIDContraSideSell=2001 ; SecuritySymbol=DPM ;
	// Volume=41000 ; Price= 45500000 ; Board=B ; ConfirmNumber=104 ;
	/**
	 * nguoi mua send 3B nguoi mua thoa thuan voi nguoi ban, nguoi ban goi 1G
	 * len. Hose -> 2F khi nhan duoc message tu Hose 2F thi, nguoi mua send 3B
	 * voi thong tin co duoc tu 2F (volume, confirm number sau do he thong phai
	 * nhan duoc 2L de xac nhan da mua thanh cong
	 */

	// MessageType=2F ; FirmBuy=57 ; TraderIDBuy=571 ; SideB=B ;
	// ContraFirmSell=1 ; TraderIDContraSideSell=2001 ; SecuritySymbol=DPM ;
	// Volume=30000 ; Price= 45000000 ; Board=B ;
	// MessageType=2F ; FirmBuy=57 ; TraderIDBuy=571 ; SideB=B ;
	// ContraFirmSell=61 ; TraderIDContraSideSell=2126 ; SecuritySymbol=TP1A2205
	// ; Volume=2000 ; Price=000150000000 ; Board=B ; ConfirmNumber=24 ;
	// MessageType=2F ; FirmBuy=57 ; TraderIDBuy=571 ; SideB=B ;
	// ContraFirmSell=61 ; TraderIDContraSideSell=2126 ; SecuritySymbol=TP1A2205
	// ; Volume=2000 ; Price=000150000000 ; Board=B ; ConfirmNumber=24 ;
	public static PutThroughDealReply_3B get3BMessage(String confirmNumber) {
		PutThroughDealReply_3B send = new PutThroughDealReply_3B();
		send.setFirm("057");
		send.setConfirmNumber(confirmNumber);
		send.setDealID("12345");
		String ClientID = TestCommon.createRandomAcountBuy();
		send.setClientIDBuyer(ClientID);
		send.setReplyCode("A");
		send.setFiller("    ");
		send.setBrokerPortfolioVolume("");
		send.setBrokerClientVolume("2000");
		send.setBrokerMutualFundVolume("");
		send.setBrokerForeignVolume("");

		String temp = "";
		for (int i = 0; i < 32; i++) {
			temp += " ";
		}
		send.setFiller2(temp);

		return send;

	}

	// MessageType=2F ; FirmBuy=57 ; TraderIDBuy=571 ; SideB=B ;
	// ContraFirmSell=1 ; TraderIDContraSideSell=2001 ; SecuritySymbol=DPM ;
	// Volume=30000 ; Price= 45000000 ; Board=B ;

	public static PutThroughDealReply_3B get3BMessage() {
		PutThroughDealReply_3B send = new PutThroughDealReply_3B();
		send.setFirm("057");
		send.setConfirmNumber("115");
		send.setDealID("12345");
		String ClientID = TestCommon.createRandomAcountBuy();
		send.setClientIDBuyer(ClientID);
		send.setReplyCode("A");
		send.setFiller("    ");
		send.setBrokerPortfolioVolume("");
		send.setBrokerClientVolume("35000");
		send.setBrokerMutualFundVolume("");
		send.setBrokerForeignVolume("");

		String temp = "";
		for (int i = 0; i < 32; i++) {
			temp += " ";
		}
		send.setFiller2(temp);

		return send;

	}

	public static DealCancelReply_3D get3DMessage(String confirmNumber) {
		DealCancelReply_3D send = new DealCancelReply_3D();
		send.setFirm("057");
		send.setConfirmNumber(confirmNumber);
		String ClientID = TestCommon.createRandomAcountBuy();
		send.setReplyCode("A");
		return send;

	}

	public static void main(String args[]) {
		// byte[] b = new byte[] { 0x20, 0x20, 0x25, 0x39 };
		// System.out.println(Common.DecodeMod96(b));
		//
		// String a =
		// " W  %3  %@DT YA!2E57 S20094   2509  100     24.5  4491   W  %4  %@DT YA!2E57 S20094   2509  900     24.5  4492   W  %5  %@DT YA!2E57 S20095   2509  1000    24.5  4493   W  %6  %@DT YA!2E57 S20096   2509  1000    24.5  4494   W  %7  %@DT YA!2E57 S20097   2509  1000    24.5  4495   W  %8  %@DT YA!2E57 S20098   2509  1000    24.5  4496   W  %9  %@DT YA!2E57 S20099   2509  1000    24.5  4497   -  %:  %@ER Y"
		// ;
		// StringTokenizer stringTokenizer = new StringTokenizer(a, String
		// .valueOf((char) 03));
		// System.out.println(stringTokenizer.countTokens());
		// while (stringTokenizer.hasMoreTokens()) {
		// HosePacket hosePacket = new HosePacket(stringTokenizer.nextToken()
		// .getBytes());
		// System.out.println(hosePacket);
		// }

		// System.out.println( TestCommon._symbol[0]);
		// System.out.println( TestCommon._symbol[1]);
		//		
		// for (int i = 0; i < 10; i++) {
		// String sb = TestCommon.createRandomSymbol();
		// if (sb.trim().equals(TestCommon._symbol[0])) {
		// System.out.println(sb + "" + TestCommon._symbol[0] + ""
		// + priceOfTTC);
		// } else { // REE
		// System.out.println(sb + "" + TestCommon._symbol[1] + ""
		// + priceOfREE);
		// }
		// }

		// String valueOf = String.valueOf('3');
		// System.out.println(valueOf);
		// valueOf = String.valueOf((char) 03);
		// System.out.println(String.valueOf(12));

		get1IMessages(1, "1");
	}

}
