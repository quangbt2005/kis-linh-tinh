package eps.com.test;

import java.util.ArrayList;
import java.util.List;

import eps.com.message.sended.Advertisement_1E;
import eps.com.message.sended.NewConditioned_1I;
import eps.com.message.sended.OneFirmPutThroughDeal_1F;
import eps.com.message.sended.TwoFirmPutThroughDeal_1G;

public class C21ConformationTest {
	
//	127/1271 
	private static String ContraFirmBuyer = "001";
	private static String TraderIDBuyer = "2001";
	
//	private static String ContraFirmBuyer = "127";
//	private static String TraderIDBuyer = "1271";


	// private static String ContraFirmBuyer = "061";
	// private static String TraderIDBuyer = "611";
	// OrderType :ATO, ATC, LO
	public static NewConditioned_1I get1IForeignerMessages(String sb,
			String orderType) {
		int numberOfMessages = 1;
		String orderNumber = TestCommon.createRandomOrderNumber();
		NewConditioned_1I order = null;
		for (int i = 0; i < numberOfMessages; i++) {
			// String orderNumber = TestCommon.createRandomOrderNumber();
			String clientID = TestCommon.createRandomForeignerAcountBuy();
			String buyOrSell = "B";
			if (sb == null)
				sb = TestCommon.createRandomSymbol();

			order = new NewConditioned_1I();
			order.setFirm("057");
			order.setTraderID("571");
			order.setOrderNumber(TestCommon
					.getRandomOrderNumber(orderNumber, i));
			order.setClientID(clientID);
			order.setSecuritySymbol(sb);
			order.setSide(buyOrSell);
			order.setVolume("10      ");
			order.setPublishedVolume("10      ");
			if (orderType.equals("") || orderType.equals("LO")) {
				order.setPrice(TestCommon.getPrice(sb));
			} else {
				order.setPrice(orderType);
			}

			order.setBoard("M");
			order.setFiller("");
			order.setPortClientFlag("F");
			order.setFiller2("");
		}
		return order;
	}

	public static NewConditioned_1I get1IForeignerMessages(String sb, 
			String orderType, String buyOrSell) {
		int numberOfMessages = 1;
		String orderNumber = TestCommon.createRandomOrderNumber();
		NewConditioned_1I order = null;
		for (int i = 0; i < numberOfMessages; i++) {
			// String orderNumber = TestCommon.createRandomOrderNumber();
			String clientID = TestCommon.createRandomForeignerAcountBuy();

			if (sb == null)
				sb = TestCommon.createRandomSymbol();

			order = new NewConditioned_1I();
			order.setFirm("057");
			order.setTraderID("571");
			order.setOrderNumber(TestCommon
					.getRandomOrderNumber(orderNumber, i));
			order.setClientID(clientID);
			order.setSecuritySymbol(sb);
			order.setSide(buyOrSell);
			order.setVolume("10      ");
			order.setPublishedVolume("10      ");
			if (orderType.equals("") || orderType.equals("LO")) {
				order.setPrice(TestCommon.getPrice(sb));
			} else {
				order.setPrice(orderType);
			}

			order.setBoard("M");
			order.setFiller("");
			order.setPortClientFlag("F");
			order.setFiller2("");
		}
		return order;
	}

	
	/**
	 * get theo phien session = PREOPEN, OPEN, PRECLOSE, CLOSE
	 * 
	 * @param session
	 * @return
	 */
	public static Advertisement_1E get1EMessage(String SecuritySymbol,
			String session) {
		Advertisement_1E send = new Advertisement_1E();

		send.setFirm("057");
		send.setTraderID("571");
		send.setSecuritySymbol(SecuritySymbol);
		send.setSide("S");

		send.setVolume("30000");
		if(SecuritySymbol.trim().equals(TestCommon.bond_symbol[0])){
			send.setPrice(TestCommon.getPriceBond1E(SecuritySymbol));
		}else
			send.setPrice(TestCommon.getPrice1E(SecuritySymbol));

		// double price =
		// Double.parseDouble(TestCommon.getCeiling(SecuritySymbol)) * 1000000;
		// send.setPrice("" + price);
		send.setBoard("B");
		if (session.equalsIgnoreCase("PREOPEN")) {
			send.setTime("084008");
		} else if (session.equalsIgnoreCase("OPEN")) {
			send.setTime("092008");
		} else if (session.equalsIgnoreCase("PRECLOSE"))
			send.setTime("102008");
		else
			send.setTime("103508");

		send.setAddCancelFlag("A");

		String temp = "";
		for (int i = 0; i < 20; i++) {
			temp += " ";
		}
		send.setContact("Gia Quyen");
		return send;
	}

	/**
	 * get theo phien session = PREOPEN, OPEN, PRECLOSE, CLOSE buysell= "B, S"
	 * addcancel ="A,C"
	 * 
	 * @param session
	 * @return
	 */
	public static Advertisement_1E get1EMessage(String SecuritySymbol,
			String session, String buysell, String addcancel) {
		Advertisement_1E send = new Advertisement_1E();

		send.setFirm("057");
		send.setTraderID("571");
		send.setSecuritySymbol(SecuritySymbol);
		send.setSide(buysell);

		send.setVolume("30000");

		if(SecuritySymbol.trim().equals(TestCommon.bond_symbol[0])){
			send.setPrice(TestCommon.getPriceBond1E(SecuritySymbol));
		}else
			send.setPrice(TestCommon.getPrice1E(SecuritySymbol));

		// double price =
		// Double.parseDouble(TestCommon.getCeiling(SecuritySymbol)) * 1000000;
		// send.setPrice("" + price);
		send.setBoard("B");
		if (session.equalsIgnoreCase("PREOPEN")) {
			send.setTime("084008");
		} else if (session.equalsIgnoreCase("OPEN")) {
			send.setTime("092008");
		} else if (session.equalsIgnoreCase("PRECLOSE"))
			send.setTime("102008");
		else
			send.setTime("103508");

		send.setAddCancelFlag(addcancel);

		String temp = "";
		for (int i = 0; i < 20; i++) {
			temp += " ";
		}
		send.setContact("Gia Quyen");
		return send;
	}

	public static Advertisement_1E get1EMessageRunOff() {
		Advertisement_1E send = new Advertisement_1E();
		String SecuritySymbol = TestCommon.createRandomSymbol();

		send.setFirm("057");
		send.setTraderID("2120");
		send.setSecuritySymbol(SecuritySymbol);
		send.setSide("S");

		send.setVolume("30000");

		if(SecuritySymbol.trim().equals(TestCommon.bond_symbol[0])){
			send.setPrice(TestCommon.getPriceBond1E(SecuritySymbol));
		}else
			send.setPrice(TestCommon.getPrice1E(SecuritySymbol));


		// double price =
		// Double.parseDouble(TestCommon.getCeiling(SecuritySymbol)) * 1000000;
		// send.setPrice("" + price);
		send.setBoard("B");
		send.setTime("103508");
		send.setAddCancelFlag("A");

		String temp = "";
		for (int i = 0; i < 20; i++) {
			temp += " ";
		}
		send.setContact("NguyenVanA");
		return send;
	}

	public static Advertisement_1E get1EMessageRunOff(String SecuritySymbol) {
		String Side = "A";
		Advertisement_1E send = new Advertisement_1E();

		send.setFirm("057");
		send.setTraderID("2120");
		send.setSecuritySymbol(SecuritySymbol);
		send.setSide("S");

		send.setVolume("30000");

		if(SecuritySymbol.trim().equals(TestCommon.bond_symbol[0])){
			send.setPrice(TestCommon.getPriceBond1E(SecuritySymbol));
		}else
			send.setPrice(TestCommon.getPrice1E(SecuritySymbol));

		// double price =
		// Double.parseDouble(TestCommon.getCeiling(SecuritySymbol)) * 1000000;
		// send.setPrice("" + price);
		send.setBoard("B");
		send.setTime("103508");
		send.setAddCancelFlag(Side);

		String temp = "";
		for (int i = 0; i < 20; i++) {
			temp += " ";
		}
		send.setContact("NguyenVanA");
		return send;
	}

	public static Advertisement_1E get1EMessageRunOff(String SecuritySymbol,
			String Side) {
		Advertisement_1E send = new Advertisement_1E();

		send.setFirm("057");
		send.setTraderID("2120");
		send.setSecuritySymbol(SecuritySymbol);
		send.setSide("S");

		send.setVolume("30000");

		if(SecuritySymbol.trim().equals(TestCommon.bond_symbol[0])){
			send.setPrice(TestCommon.getPriceBond1E(SecuritySymbol));
		}else
			send.setPrice(TestCommon.getPrice1E(SecuritySymbol));

		// double price =
		// Double.parseDouble(TestCommon.getCeiling(SecuritySymbol)) * 1000000;
		// send.setPrice("" + price);
		send.setBoard("B");
		send.setTime("103508");
		send.setAddCancelFlag(Side);

		String temp = "";
		for (int i = 0; i < 20; i++) {
			temp += " ";
		}
		send.setContact("Gia Quyen");
		return send;
	}

	// get 1F for stock
	public static OneFirmPutThroughDeal_1F get1FMessage(String type) {
		String stockType = "S";
		return get1FMessage(stockType, type);
	}

	// get 1F for stock + bond
	/**
	 * stock type =S : stock D , "" = Bond type : client type : C, F , M, P
	 */
	public static OneFirmPutThroughDeal_1F get1FMessage(String stockType,
			String type) {
		String ClientID1 = TestCommon.createRandomAcountBuy();
		String ClientID2 = TestCommon.createAcount(type);
		String SecuritySymbol = "";
		String price="";
		if (stockType.equalsIgnoreCase("S")){
			SecuritySymbol = TestCommon.createRandomSymbol();
		    price= TestCommon.getPrice1E(SecuritySymbol);
		}else{
			SecuritySymbol = TestCommon.createRandomBond();
			price= TestCommon.getPriceBond1E(SecuritySymbol);
		}
		String temp = "";

		OneFirmPutThroughDeal_1F send = new OneFirmPutThroughDeal_1F();

		send.setFirm("057");
		send.setTraderID("571");
		send.setClientIDBuyer(ClientID1);
		send.setClientIDSeller(ClientID2);
		send.setSecuritySymbol(SecuritySymbol);
		
		send.setPrice(price);
		
		send.setBoard("B");
		send.setDealID("123");
		for (int i = 0; i < 8; i++) {
			temp += " ";
		}
		send.setFiller(temp);

		send.setBrokerPortfolioVolumeBuyer("");
		send.setBrokerClientVolumeBuyer("30000");
		send.setMutualFundVolumeBuyer("");
		send.setBrokerForeignVolumeBuyer("");

		temp = "";
		for (int i = 0; i < 32; i++) {
			temp += " ";
		}
		send.setFiller2(temp);
		send.setBrokerPortfolioVolumeSeller("");
		send.setBrokerClientVolumeSeller("");
		send.setMutualFundVolumeSeller("");
		send.setBrokerForeignVolumeSeller("");

		if (type.equalsIgnoreCase("C")) {
			send.setBrokerClientVolumeSeller("30000");
		} else if (type.equalsIgnoreCase("F")) {
			send.setBrokerForeignVolumeSeller("30000");
		} else if (type.equalsIgnoreCase("M")) {
			send.setMutualFundVolumeSeller("30000");
		} else if (type.equalsIgnoreCase("P")) {
			send.setBrokerPortfolioVolumeSeller("30000");
		}

		temp = "";
		for (int i = 0; i < 32; i++) {
			temp += " ";
		}
		send.setFiller2(temp);

		temp = "";
		for (int i = 0; i < 32; i++) {
			temp += " ";
		}
		send.setFiller3(temp);
		return send;
	}

	public static OneFirmPutThroughDeal_1F get1FMessage(String SecuritySymbol,
			String stockType, String type) {
		String ClientID1 = TestCommon.createRandomAcountBuy();
		String ClientID2 = TestCommon.createAcount(type);

		String temp = "";

		OneFirmPutThroughDeal_1F send = new OneFirmPutThroughDeal_1F();

		send.setFirm("057");
		send.setTraderID("571");
		send.setClientIDBuyer(ClientID1);
		send.setClientIDSeller(ClientID2);
		send.setSecuritySymbol(SecuritySymbol);

		if(SecuritySymbol.trim().equals(TestCommon.bond_symbol[0])){
			send.setPrice(TestCommon.getPriceBond1E(SecuritySymbol));
		}else
			send.setPrice(TestCommon.getPrice1E(SecuritySymbol));

		// send.setPrice(TestCommon.getCeiling(SecuritySymbol));

		send.setBoard("B");
		send.setDealID("123");
		for (int i = 0; i < 8; i++) {
			temp += " ";
		}
		send.setFiller(temp);

		send.setBrokerPortfolioVolumeBuyer("");
		send.setBrokerClientVolumeBuyer("30000");
		send.setMutualFundVolumeBuyer("");
		send.setBrokerForeignVolumeBuyer("");

		temp = "";
		for (int i = 0; i < 32; i++) {
			temp += " ";
		}
		send.setFiller2(temp);
		send.setBrokerPortfolioVolumeSeller("");
		send.setBrokerClientVolumeSeller("");
		send.setMutualFundVolumeSeller("");
		send.setBrokerForeignVolumeSeller("");

		if (type.equalsIgnoreCase("C")) {
			send.setBrokerClientVolumeSeller("30000");
		} else if (type.equalsIgnoreCase("F")) {
			send.setBrokerForeignVolumeSeller("30000");
		} else if (type.equalsIgnoreCase("M")) {
			send.setMutualFundVolumeSeller("30000");
		} else if (type.equalsIgnoreCase("P")) {
			send.setBrokerPortfolioVolumeSeller("30000");
		}

		temp = "";
		for (int i = 0; i < 32; i++) {
			temp += " ";
		}
		send.setFiller2(temp);

		temp = "";
		for (int i = 0; i < 32; i++) {
			temp += " ";
		}
		send.setFiller3(temp);
		return send;
	}

	public static TwoFirmPutThroughDeal_1G get1GForeignerMessage(
			String SecuritySymbol) {
		TwoFirmPutThroughDeal_1G send = new TwoFirmPutThroughDeal_1G();
		send.setFirmSeller("057");
		send.setTraderIDSeller("571");

		String ClientID = TestCommon.createRandomAcountBuy();
		send.setClientIDSeller(ClientID);
		send.setContraFirmBuyer(ContraFirmBuyer);
		send.setTraderIDBuyer(TraderIDBuyer);

		send.setSecuritySymbol(SecuritySymbol);
		if(SecuritySymbol.trim().equals(TestCommon.bond_symbol[0])){
			send.setPrice(TestCommon.getPriceBond1E(SecuritySymbol));
		}else
			send.setPrice(TestCommon.getPrice1E(SecuritySymbol));
		// send.setPrice(TestCommon.getFloor(SecuritySymbol));

		send.setBoard("B");
		send.setDealID("12345");

		String temp = "";
		for (int i = 0; i < 4; i++) {
			temp += " ";
		}
		send.setFiller(temp);
		send.setBrokerPortfolioVolumeSeller("");
		send.setBrokerClientVolumeSeller("30000");
		send.setMutualFundVolumeSeller("");
		send.setBrokerForeignVolumeSeller("");
		temp = "";
		for (int i = 0; i < 32; i++) {
			temp += " ";
		}
		send.setFiller2(temp);
		return send;
	}

	public static TwoFirmPutThroughDeal_1G get1GForeignerMessage(String SecuritySymbol, String type) {
		TwoFirmPutThroughDeal_1G send = new TwoFirmPutThroughDeal_1G();
		send.setFirmSeller("057");
		send.setTraderIDSeller("571");

		String ClientID = TestCommon.createAcount(type);
		send.setClientIDSeller(ClientID);
		send.setContraFirmBuyer(ContraFirmBuyer);
		send.setTraderIDBuyer(TraderIDBuyer);

		send.setSecuritySymbol(SecuritySymbol);
		if(SecuritySymbol.trim().equals(TestCommon.bond_symbol[0])){
			send.setPrice(TestCommon.getPriceBond1E(SecuritySymbol));
		}else
			send.setPrice(TestCommon.getPrice1E(SecuritySymbol));
		// send.setPrice(TestCommon.getFloor(SecuritySymbol));

		send.setBoard("B");
		send.setDealID("12345");

		String temp = "";
		for (int i = 0; i < 4; i++) {
			temp += " ";
		}
		send.setFiller(temp);

		send.setBrokerPortfolioVolumeSeller("");
		send.setBrokerClientVolumeSeller("");
		send.setMutualFundVolumeSeller("");
		send.setBrokerForeignVolumeSeller("");
		
		if (type.equalsIgnoreCase("C")) {
			send.setBrokerClientVolumeSeller("30000");
		} else if (type.equalsIgnoreCase("F")) {
			send.setBrokerForeignVolumeSeller("30000");
		} else if (type.equalsIgnoreCase("M")) {
			send.setMutualFundVolumeSeller("30000");
		} else if (type.equalsIgnoreCase("P")) {
			send.setBrokerPortfolioVolumeSeller("30000");
		}
		
		temp = "";
		for (int i = 0; i < 32; i++) {
			temp += " ";
		}
		send.setFiller2(temp);
		return send;
	}

	
	public static NewConditioned_1I getOrder(String orderType) {
		List<NewConditioned_1I> listOrders;

		if (orderType.equals("ATC")) {
			listOrders = NormalTest.get1IMessages(1, "10", "B", "ATC");
		} else if (orderType.equals("ATO")) {
			listOrders = NormalTest.get1IMessages(1, "11", "B", "ATO");
		} else {
			listOrders = NormalTest.get1IMessages(1, "12", "S", "MP");
		}

		return listOrders.get(0);
	}

	public static NewConditioned_1I get1IMessage(String buyOrSell,
			String orderType, String securitySymbol) {
		return get1IMessages(1, buyOrSell, orderType, securitySymbol).get(0);
	}

	public static List<NewConditioned_1I> get1IMessages(int numberOfMessages,
			String buyOrSell, String orderType, String securitySymbol) {
		List<NewConditioned_1I> ret = new ArrayList<NewConditioned_1I>();

		NewConditioned_1I order;
		for (int i = 0; i < numberOfMessages; i++) {
			String clientID = TestCommon.createRandomAcountBuy();

			order = new NewConditioned_1I();
			order.setFirm("057");
			order.setTraderID("2120");
			order.setOrderNumber(TestCommon.createRandomOrderNumber());
			order.setClientID(clientID);
			order.setSecuritySymbol(securitySymbol);
			order.setSide(buyOrSell);
			order.setVolume("10      ");
			order.setPublishedVolume("10      ");
			if (orderType.equals("")) {
				order.setPrice(TestCommon.getPrice(securitySymbol));
			} else {
				order.setPrice(orderType);
			}

			order.setBoard("M");
			order.setFiller("");
			order.setPortClientFlag("C");
			order.setFiller2("");

			ret.add(order);

			// System.out.println(order.getOrderNumber());
		}
		return ret;
	}

}
