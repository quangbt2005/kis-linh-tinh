package eps.com.common;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import eps.com.test.TestCommon;

public class RecoveryObject {
	public static String RECOVERY_PATH = TestCommon.DATA_SAVE_PATH
			+ "/Recovery";

	public static String RECOVERY_QUEUE_PATH = RECOVERY_PATH
			+ "/InQueueNotSent";

	static {
		// File f = new File(RECOVERY_PATH);
		// if (!f.exists()) {
		// f.mkdirs();
		// }

		File f = new File(RECOVERY_QUEUE_PATH);
		if (!f.exists()) {
			f.mkdirs();
		}
	}

	// public static String RR_RECOVERY_PATH="c:/DataSave/Recovery";
	// write file name with this sequence
	// seq = DTxxxx : xxxx la so sequence
	// seq = RRxxxx : xxxx la so sequence
	public static void write(String name, HosePacket packet) {
		// String fileName = RECOVERY_PATH + name;
		File f = new File(RECOVERY_PATH, name);

		try {
			ObjectOutputStream oos = new ObjectOutputStream(
					new FileOutputStream(f));
			oos.writeObject(packet);
			oos.flush();
			oos.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public static HosePacket read(String name) {
		// String fileName = RECOVERY_PATH + name;
		File f = new File(RECOVERY_PATH, name);
		HosePacket packet = null;
		try {
			ObjectInputStream ois = new ObjectInputStream(
					new FileInputStream(f));
			packet = (HosePacket) ois.readObject();
			ois.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return packet;

	}

	public static void delete(String name) {
		// String fileName = RECOVERY_PATH + name;
		File f = new File(RECOVERY_PATH, name);
		// HosePacket packet = null;
		try {
			// File f = new File(fileName);
			f.delete();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			// e.printStackTrace();
		}
	}

	// Lan Tra : get name increase. Ex : DT00000001, DT00000010, ...
	public static String getRecoveryName(String name, long seq) {
		String seqStr = String.valueOf(seq);
		StringBuffer sb = new StringBuffer(name);
		for (int i = 0; i < 8 - seqStr.length(); i++) {
			sb.append("0");
		}
		sb.append(seqStr);
		// TODO Auto-generated method stub
		return sb.toString();
	}

	public static void writeObjectInQueue(String name, Object object) {
		File f = new File(RECOVERY_QUEUE_PATH, name);

		try {
			ObjectOutputStream oos = new ObjectOutputStream(
					new FileOutputStream(f));
			oos.writeObject(object);
			oos.flush();
			oos.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static ValueObject readObjectInQueue(String name) {
		File f = new File(RECOVERY_QUEUE_PATH, name);
		ValueObject object = null;
		try {
			ObjectInputStream ois = new ObjectInputStream(
					new FileInputStream(f));
			object = (ValueObject) ois.readObject();
			ois.close();
		} catch (Exception e) {
			//e.printStackTrace();
		}
		return object;
	}

	public static void deleteObjectInQueue(String name) {
		File f = new File(RECOVERY_QUEUE_PATH, name);
		try {
			f.delete();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
