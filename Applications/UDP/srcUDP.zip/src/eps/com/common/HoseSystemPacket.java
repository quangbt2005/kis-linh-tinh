package eps.com.common;

import eps.com.client.proposal.EPSServiceController;
import eps.com.client.upd.Common;

/**
 * This class is used for simulating HL/HR/ACK .... packets
 * @author tuan.nguyen
 * 
 */
public class HoseSystemPacket extends HosePacket{

	public HoseSystemPacket() {
	}
	public byte[] getAutotPMessage(long seq, long ack_seq) throws Exception {
		this.content= getContent(this.opcode);
		int len = HosePacket.TOTAL_HEADER_LENGH + content.length;
		byte[] bytes = new byte[len];
		byte[] temp = null;
		// len 2 byte
		this.len = Common.EnMod96(len - 2, 2);
		bytes[0] = this.len[0];
		bytes[1] = this.len[1];
		// seq 4 byte
		this.seq = Common.EnMod96(seq, 4);
		bytes[2] = this.seq[0];
		bytes[3] = this.seq[1];
		bytes[4] = this.seq[2];
		bytes[5] = this.seq[3];
		// ackseq 4
		this.ackseq = Common.EnMod96(ack_seq, 4);
		bytes[6] = this.ackseq[0];
		bytes[7] = this.ackseq[1];
		bytes[8] = this.ackseq[2];
		bytes[9] = this.ackseq[3];
		// opcode HL
		bytes[10] = opcode[0];
		bytes[11] = opcode[1];
		// LinkID 57
		this.linkID = Common.EnMod96(EPSServiceController._linkid, 2);
		bytes[12] = this.linkID[0];
		bytes[13] = this.linkID[1];
		// CONTENT
		int n = content.length;
		if (n > 0)
			System.arraycopy(content, 0, bytes, 14, n);
		// etx
		bytes[len - 1] = 3;
		return bytes;
	}
	/**
	 * create content based on OPCODE
	 * can xu ly cac loai packet khac cho tong quat doi voi truong hop khac
	 * @param opCode
	 */
	private byte[] getContent(byte[] opCode){
		//byte result[]= new byte[];
		if(Common.compare2byteArray(opCode, Opcode.AK) ||
		   Common.compare2byteArray(opCode, Opcode.FN) ||
		   Common.compare2byteArray(opCode, Opcode.EC) ||
		   Common.compare2byteArray(opCode, Opcode.CF))
			return new byte[]{};
		return null;
	}
	
	public static void main(String arg[]) throws Exception{
		HoseSystemPacket packet = new HoseSystemPacket();
		packet.setOpcode(Opcode.AK);
		byte result[] =packet.getAutotPMessage(10, 20);
		System.out.println("test:" + new String(result));
		System.out.println("test:" + packet.toString());
		
	}
}
