package eps.com.common;

public class MessageConstanst {
	public static final String NEW_ORDER="1I"; 
}
