package eps.com.message.broadcast;

import java.io.Serializable;

import eps.com.common.ValueObject;

public class SectoralIndices_SI extends ValueObject implements Serializable{
	
	public static final String MessageType="SI";
	
	private long 	Index_Sectoral_1 ;
	private String Filler ;
	private long Index_Time  ;
	
	public SectoralIndices_SI()
	{
		
	}
	public String getFiller() {
		return Filler;
	}
	public void setFiller(String filler) {
		Filler = filler;
	}
	public long getIndex_Sectoral_1() {
		return Index_Sectoral_1;
	}
	public void setIndex_Sectoral_1(long index_Sectoral_1) {
		Index_Sectoral_1 = index_Sectoral_1;
	}
	public long getIndex_Time() {
		return Index_Time;
	}
	public void setIndex_Time(long index_Time) {
		Index_Time = index_Time;
	}
	public static String getMessage_Type() {
		return MessageType ;
	}
	
}
