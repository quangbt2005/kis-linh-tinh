package eps.com.message.broadcast;

import java.io.Serializable;

import eps.com.common.ValueObject;

public class DealCancellationNotice_DC extends ValueObject implements Serializable{
	
	public static final String MessageType="DC";
	
	private long confirmNumber;
	private long securityNumber;
	private long volume;
	private long price;
	private String board;
	
	public DealCancellationNotice_DC()
	{
		
	}
	public String getBoard() {
		return board;
	}
	
	public void setBoard(String board) {
		this.board = board;
	}
	
	public long getConfirmNumber() {
		return confirmNumber;
	}
	
	public void setConfirmNumber(long confirmNumber) {
		this.confirmNumber = confirmNumber;
	}
	
	public static String getMessageType() {
		return MessageType ;
	}
	
	public long getPrice() {
		return price;
	}
	
	public void setPrice(long price) {
		this.price = price;
	}
	
	public long getSecurityNumber() {
		return securityNumber;
	}
	
	public void setSecurityNumber(long securityNumber) {
		this.securityNumber = securityNumber;
	}
	
	public long getVolume() {
		return volume;
	}
	public void setVolume(long volume) {
		this.volume = volume;
	}
	
}
