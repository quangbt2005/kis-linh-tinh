package eps.com.message.broadcast;

import java.io.Serializable;

import eps.com.common.ValueObject;

public class SecurityUpdate_SU  extends ValueObject implements Serializable{
	
	public static final long serialVersionUID = 1L;
	
	public static final String MessageType="SU";
	private long s_SecurityNumberOld;
	private long s_SecurityNumberNew;
	private String s_Filler1;
	private long s_SectorNumber;
	private String s_Filler2;
	private String s_SecuritySymbol;
	private String s_SecurityType;
	private long 	s_CeilingPrice;
	private long 	s_FloorPrice;
	private long 	s_LastSalePrice;
	private String 	s_MarketID;
	private String 	s_Filler3;
	private String 	s_SecurityName;
	private String 	s_Filler4;
	private String 	s_Suspension;
	private String 	s_Delist;
	private String 	s_HaltResumeFlag;
	private String 	s_Split;
	private String 	s_Benefit;
	private String 	s_Meeting;
	private String 	s_Notice;
	private String 	s_ClientIDRequired;
	private long 	s_ParValue;
	private String 	s_SDCFlag;
	private long 	s_PriorClosePrice;
	private String 	s_PriorClosedate;
	private long 	s_OpenPrice;
	private long 	s_HighestPrice;
	private long 	s_LowestPrice;
	private long 	s_TotalSharesTraded;
	private long 	s_TotalValuesTraded;
	private long 	s_BoardLot;
	private String 	s_Filler5;
	
	public long getS_SecurityNumberOld() {
		return s_SecurityNumberOld;
	}
	public void setS_SecurityNumberOld(long securityNumberOld) {
		s_SecurityNumberOld = securityNumberOld;
	}
	public long getS_SecurityNumberNew() {
		return s_SecurityNumberNew;
	}
	public void setS_SecurityNumberNew(long securityNumberNew) {
		s_SecurityNumberNew = securityNumberNew;
	}
	public String getS_Filler1() {
		return s_Filler1;
	}
	public void setS_Filler1(String filler1) {
		s_Filler1 = filler1;
	}
	public long getS_SectorNumber() {
		return s_SectorNumber;
	}
	public void setS_SectorNumber(long sectorNumber) {
		s_SectorNumber = sectorNumber;
	}
	public String getS_Filler2() {
		return s_Filler2;
	}
	public void setS_Filler2(String filler2) {
		s_Filler2 = filler2;
	}
	public String getS_SecuritySymbol() {
		return s_SecuritySymbol;
	}
	public void setS_SecuritySymbol(String securitySymbol) {
		s_SecuritySymbol = securitySymbol;
	}
	public String getS_SecurityType() {
		return s_SecurityType;
	}
	public void setS_SecurityType(String securityType) {
		s_SecurityType = securityType;
	}
	public long getS_CeilingPrice() {
		return s_CeilingPrice;
	}
	public void setS_CeilingPrice(long ceilingPrice) {
		s_CeilingPrice = ceilingPrice;
	}
	public long getS_FloorPrice() {
		return s_FloorPrice;
	}
	public void setS_FloorPrice(long floorPrice) {
		s_FloorPrice = floorPrice;
	}
	public long getS_LastSalePrice() {
		return s_LastSalePrice;
	}
	public void setS_LastSalePrice(long lastSalePrice) {
		s_LastSalePrice = lastSalePrice;
	}
	public String getS_MarketID() {
		return s_MarketID;
	}
	public void setS_MarketID(String marketID) {
		s_MarketID = marketID;
	}
	public String getS_Filler3() {
		return s_Filler3;
	}
	public void setS_Filler3(String filler3) {
		s_Filler3 = filler3;
	}
	public String getS_SecurityName() {
		return s_SecurityName;
	}
	public void setS_SecurityName(String securityName) {
		s_SecurityName = securityName;
	}
	public String getS_Filler4() {
		return s_Filler4;
	}
	public void setS_Filler4(String filler4) {
		s_Filler4 = filler4;
	}
	public String getS_Suspension() {
		return s_Suspension;
	}
	public void setS_Suspension(String suspension) {
		s_Suspension = suspension;
	}
	public String getS_Delist() {
		return s_Delist;
	}
	public void setS_Delist(String delist) {
		s_Delist = delist;
	}
	public String getS_HaltResumeFlag() {
		return s_HaltResumeFlag;
	}
	public void setS_HaltResumeFlag(String haltResumeFlag) {
		s_HaltResumeFlag = haltResumeFlag;
	}
	public String getS_Split() {
		return s_Split;
	}
	public void setS_Split(String split) {
		s_Split = split;
	}
	public String getS_Benefit() {
		return s_Benefit;
	}
	public void setS_Benefit(String benefit) {
		s_Benefit = benefit;
	}
	
	public String getS_Meeting() {
		return s_Meeting;
	}
	public void setS_Meeting(String meeting) {
		s_Meeting = meeting;
	}
	public String getS_Notice() {
		return s_Notice;
	}
	public void setS_Notice(String notice) {
		s_Notice = notice;
	}
	public String getS_ClientIDRequired() {
		return s_ClientIDRequired;
	}
	public void setS_ClientIDRequired(String clientIDRequired) {
		s_ClientIDRequired = clientIDRequired;
	}
	public long getS_ParValue() {
		return s_ParValue;
	}
	public void setS_ParValue(long parValue) {
		s_ParValue = parValue;
	}
	public String getS_SDCFlag() {
		return s_SDCFlag;
	}
	public void setS_SDCFlag(String flag) {
		s_SDCFlag = flag;
	}
	public long getS_PriorClosePrice() {
		return s_PriorClosePrice;
	}
	public void setS_PriorClosePrice(long priorClosePrice) {
		s_PriorClosePrice = priorClosePrice;
	}
	public String getS_PriorClosedate() {
		return s_PriorClosedate;
	}
	public void setS_PriorClosedate(String priorClosedate) {
		s_PriorClosedate = priorClosedate;
	}
	public long getS_OpenPrice() {
		return s_OpenPrice;
	}
	public void setS_OpenPrice(long openPrice) {
		s_OpenPrice = openPrice;
	}
	public long getS_HighestPrice() {
		return s_HighestPrice;
	}
	public void setS_HighestPrice(long highestPrice) {
		s_HighestPrice = highestPrice;
	}
	public long getS_LowestPrice() {
		return s_LowestPrice;
	}
	public void setS_LowestPrice(long lowestPrice) {
		s_LowestPrice = lowestPrice;
	}
	public long getS_TotalSharesTraded() {
		return s_TotalSharesTraded;
	}
	public void setS_TotalSharesTraded(long totalSharesTraded) {
		s_TotalSharesTraded = totalSharesTraded;
	}
	public long getS_TotalValuesTraded() {
		return s_TotalValuesTraded;
	}
	public void setS_TotalValuesTraded(long totalValuesTraded) {
		s_TotalValuesTraded = totalValuesTraded;
	}
	public long getS_BoardLot() {
		return s_BoardLot;
	}
	public void setS_BoardLot(long boardLot) {
		s_BoardLot = boardLot;
	}
	public String getS_Filler5() {
		return s_Filler5;
	}
	public void setS_Filler5(String filler5) {
		s_Filler5 = filler5;
	}
	
	
	
	
}
