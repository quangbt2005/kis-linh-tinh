package eps.com.message.broadcast;

import java.io.Serializable;

import eps.com.common.ValueObject;

public class LastSale_LS extends ValueObject implements Serializable{
	
	public static final String MessageType="LS";
	
	private long confirmNumber;
	private long securityNumber;
	private long lotVolume;
	private long price;
	private String side;
	
	public LastSale_LS()
	{
		
	}
	public long getConfirmNumber() {
		return confirmNumber;
	}
	public void setConfirmNumber(long confirmNumber) {
		this.confirmNumber = confirmNumber;
	}
	public long getLotVolume() {
		return lotVolume;
	}
	public void setLotVolume(long lotVolume) {
		this.lotVolume = lotVolume;
	}
	public static String getMessageType() {
		return MessageType ;
	}
	
	public long getPrice() {
		return price;
	}
	public void setPrice(long price) {
		this.price = price;
	}
	public long getSecurityNumber() {
		return securityNumber;
	}
	public void setSecurityNumber(long securityNumber) {
		this.securityNumber = securityNumber;
	}
	public String getSide() {
		return side;
	}
	public void setSide(String side) {
		this.side = side;
	}
}
