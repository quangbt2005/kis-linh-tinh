package eps.com.message.broadcast;

import java.io.Serializable;

import eps.com.common.ValueObject;

public class NewsHeadline_NH extends ValueObject implements Serializable{
	
	public static final String MessageType="NH";
	
	private long News_number;
	private String Security_Symbol ;
	private long  News_headline_length ;
	private long  Total_News_Story_Pages;
	private String  News_headline_text ;
	
	
	public NewsHeadline_NH()
	{
		
	}
	public static String getMessage_Type() {
		return MessageType;
	}
	
	public long getNews_headline_length() {
		return News_headline_length;
	}
	public void setNews_headline_length(long news_headline_length) {
		News_headline_length = news_headline_length;
	}
	
	public String getNews_headline_text() {
		return News_headline_text;
	}
	
	public void setNews_headline_text(String news_headline_text) {
		News_headline_text = news_headline_text;
	}
	public long getNews_number() {
		return News_number;
	}
	
	public void setNews_number(long news_number) {
		News_number = news_number;
	}
	
	public String getSecurity_Symbol() {
		return Security_Symbol;
	}
	public void setSecurity_Symbol(String security_Symbol) {
		Security_Symbol = security_Symbol;
	}
	public long getTotal_News_Story_Pages() {
		return Total_News_Story_Pages;
	}
	public void setTotal_News_Story_Pages(long total_News_Story_Pages) {
		Total_News_Story_Pages = total_News_Story_Pages;
	}
	
}
