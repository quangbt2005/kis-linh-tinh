package eps.com.message.broadcast;

import java.io.Serializable;

import eps.com.common.ValueObject;

public class TopPrices_TP extends ValueObject implements Serializable{
	
	public static final String MessageType="TP";
	
	private long  Security_Number ; 
	private String Side  ;
	private long  Price_1_best  ;
	private long Lot_Volume_1 ; 
	private long  Price_2_2nd_best ;
	private long  Lot_Volume_2 ;
	private long  Price_3_3rd_best ;
	private long Lot_Volume_3 ;
	
	public TopPrices_TP()
	{
		
	}
	public long getLot_Volume_1() {
		return Lot_Volume_1;
	}
	public void setLot_Volume_1(long lot_Volume_1) {
		Lot_Volume_1 = lot_Volume_1;
	}
	public long getLot_Volume_2() {
		return Lot_Volume_2;
	}
	public void setLot_Volume_2(long lot_Volume_2) {
		Lot_Volume_2 = lot_Volume_2;
	}
	public long getLot_Volume_3() {
		return Lot_Volume_3;
	}
	public void setLot_Volume_3(long lot_Volume_3) {
		Lot_Volume_3 = lot_Volume_3;
	}
	public static String getMessage_Type() {
		return MessageType ;
	}
	
	public long getPrice_1_best() {
		return Price_1_best;
	}
	public void setPrice_1_best(long price_1_best) {
		Price_1_best = price_1_best;
	}
	public long getPrice_2_2nd_best() {
		return Price_2_2nd_best;
	}
	public void setPrice_2_2nd_best(long price_2_2nd_best) {
		Price_2_2nd_best = price_2_2nd_best;
	}
	public long getPrice_3_3rd_best() {
		return Price_3_3rd_best;
	}
	public void setPrice_3_3rd_best(long price_3_3rd_best) {
		Price_3_3rd_best = price_3_3rd_best;
	}
	public long getSecurity_Number() {
		return Security_Number;
	}
	public void setSecurity_Number(long security_Number) {
		Security_Number = security_Number;
	}
	public String getSide() {
		return Side;
	}
	public void setSide(String side) {
		Side = side;
	}
}
