package eps.com.message.received;

import java.io.Serializable;
import java.sql.Date;

import eps.com.common.ValueObject;

public class CrossingDealConfirmation_2I extends ValueObject implements
		Serializable {

	private static final long serialVersionUID = 1L;

	public static final String MessageType = "2I";
	private String Firm;
	private String OrderNumberBuy;
	private String OrderEntryDateBuy;
	private String OrderNumberSell;
	private String OrderEntryDateSell;
	private String Volume;
	private String Price;
	private String ConfirmNumber;

	public CrossingDealConfirmation_2I() {
	}

	public String getFirm() {
		return Firm;
	}

	public void setFirm(String firm) {
		Firm = firm;
	}

	public String getOrderNumberBuy() {
		return OrderNumberBuy;
	}

	public void setOrderNumberBuy(String orderNumberBuy) {
		OrderNumberBuy = orderNumberBuy;
	}

	public String getOrderEntryDateBuy() {
		return OrderEntryDateBuy;
	}

	public void setOrderEntryDateBuy(String orderEntryDateBuy) {
		OrderEntryDateBuy = orderEntryDateBuy;
	}

	public String getOrderNumberSell() {
		return OrderNumberSell;
	}

	public void setOrderNumberSell(String orderNumberSell) {
		OrderNumberSell = orderNumberSell;
	}

	public String getOrderEntryDateSell() {
		return OrderEntryDateSell;
	}

	public void setOrderEntryDateSell(String orderEntryDateSell) {
		OrderEntryDateSell = orderEntryDateSell;
	}

	public String getVolume() {
		return Volume;
	}

	public void setVolume(String volume) {
		Volume = volume;
	}

	public String getPrice() {
		return Price;
	}

	public void setPrice(String price) {
		Price = price;
	}

	public String getConfirmNumber() {
		return ConfirmNumber;
	}

	public void setConfirmNumber(String confirmNumber) {
		ConfirmNumber = confirmNumber;
	}

}
