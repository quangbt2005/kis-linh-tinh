package eps.com.message.received;

import java.io.Serializable;
import java.sql.Date;

import eps.com.common.ValueObject;

public class RetransmissionNack_RN extends ValueObject implements Serializable {

	private static final long serialVersionUID = 1L;

	public static final String MessageType = "RN";

	private long Firm;
	private String ErrorCode;
	private String OriginalMessageText;

	public RetransmissionNack_RN() {
	}

	public long getFirm() {
		return Firm;
	}

	public void setFirm(long firm) {
		Firm = firm;
	}

	public String getErrorCode() {
		return ErrorCode;
	}

	public void setErrorCode(String errorCode) {
		ErrorCode = errorCode;
	}

	public String getOriginalMessageText() {
		return OriginalMessageText;
	}

	public void setOriginalMessageText(String originalMessageText) {
		OriginalMessageText = originalMessageText;
	}

}
