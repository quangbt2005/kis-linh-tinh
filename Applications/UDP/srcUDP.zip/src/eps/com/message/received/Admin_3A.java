package eps.com.message.received;

import java.io.Serializable;

import eps.com.common.ValueObject;

public class Admin_3A extends ValueObject implements Serializable {

	private static final long serialVersionUID = 1L;

	public static final String MessageType = "3A";

	private String Firm;
	private String TraderIDSender;
	private String TraderIDReciever;
	private String ContraFirm;
	private String AdminMessageText;

	public Admin_3A() {
	}

	public String getFirm() {
		return Firm;
	}

	public void setFirm(String firm) {
		Firm = firm;
	}

	public String getTraderIDSender() {
		return TraderIDSender;
	}

	public void setTraderIDSender(String traderIDSender) {
		TraderIDSender = traderIDSender;
	}

	public String getTraderIDReciever() {
		return TraderIDReciever;
	}

	public void setTraderIDReciever(String traderIDReciever) {
		TraderIDReciever = traderIDReciever;
	}

	public String getContraFirm() {
		return ContraFirm;
	}

	public void setContraFirm(String contraFirm) {
		ContraFirm = contraFirm;
	}

	public String getAdminMessageText() {
		return AdminMessageText;
	}

	public void setAdminMessageText(String adminMessageText) {
		AdminMessageText = adminMessageText;
	}

}
