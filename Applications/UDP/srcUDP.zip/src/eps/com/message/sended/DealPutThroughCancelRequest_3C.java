package eps.com.message.sended;

import java.io.Serializable;

import eps.com.common.ValueObject;

public class DealPutThroughCancelRequest_3C extends ValueObject implements
		Serializable {

	private static final long serialVersionUID = 1L;

	public static final String MessageType = "3C";

	private String Firm;
	private String ContraFirm;
	private String TraderID;
	private String ConfirmNumber;
	private String SecuritySymbol;
	private String Side;

	public DealPutThroughCancelRequest_3C() {
	}

	public String getFirm() {
		return Firm;
	}

	public void setFirm(String firm) {
		Firm = firm;
	}

	public String getContraFirm() {
		return ContraFirm;
	}

	public void setContraFirm(String contraFirm) {
		ContraFirm = contraFirm;
	}

	public String getTraderID() {
		return TraderID;
	}

	public void setTraderID(String traderID) {
		TraderID = traderID;
	}

	public String getConfirmNumber() {
		return ConfirmNumber;
	}

	public void setConfirmNumber(String confirmNumber) {
		ConfirmNumber = confirmNumber;
	}

	public String getSecuritySymbol() {
		return SecuritySymbol;
	}

	public void setSecuritySymbol(String securitySymbol) {
		SecuritySymbol = securitySymbol;
	}

	public String getSide() {
		return Side;
	}

	public void setSide(String side) {
		Side = side;
	}

}
