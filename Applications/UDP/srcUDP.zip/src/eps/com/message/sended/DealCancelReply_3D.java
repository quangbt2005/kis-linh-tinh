package eps.com.message.sended;

import java.io.Serializable;

import eps.com.common.ValueObject;

public class DealCancelReply_3D extends ValueObject implements Serializable {

	private static final long serialVersionUID = 1L;

	public static final String MessageType = "3D";

	private String Firm;
	private String ConfirmNumber;
	private String ReplyCode;

	public DealCancelReply_3D() {
	}

	public String getFirm() {
		return Firm;
	}

	public void setFirm(String firm) {
		Firm = firm;
	}

	public String getConfirmNumber() {
		return ConfirmNumber;
	}

	public void setConfirmNumber(String confirmNumber) {
		ConfirmNumber = confirmNumber;
	}

	public String getReplyCode() {
		return ReplyCode;
	}

	public void setReplyCode(String replyCode) {
		ReplyCode = replyCode;
	}

}
