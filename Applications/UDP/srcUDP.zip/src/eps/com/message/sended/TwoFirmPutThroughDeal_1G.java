package eps.com.message.sended;

import java.io.Serializable;
import java.sql.Date;

import eps.com.common.ValueObject;

public class TwoFirmPutThroughDeal_1G extends ValueObject implements
		Serializable {

	private static final long serialVersionUID = 1L;

	public static final String MessageType = "1G";
	private String FirmSeller;
	private String TraderIDSeller;
	private String ClientIDSeller;
	private String ContraFirmBuyer;
	private String TraderIDBuyer;
	private String SecuritySymbol;
	private String Price;
	private String Board;
	private String DealID;
	private String Filler;
	private String BrokerPortfolioVolumeSeller;
	private String BrokerClientVolumeSeller;
	private String MutualFundVolumeSeller;
	private String BrokerForeignVolumeSeller;
	private String Filler2;

	public TwoFirmPutThroughDeal_1G() {
	}

	public String getFirmSeller() {
		return FirmSeller;
	}

	public void setFirmSeller(String firmSeller) {
		FirmSeller = firmSeller;
	}

	public String getTraderIDSeller() {
		return TraderIDSeller;
	}

	public void setTraderIDSeller(String traderIDSeller) {
		TraderIDSeller = traderIDSeller;
	}

	public String getClientIDSeller() {
		return ClientIDSeller;
	}

	public void setClientIDSeller(String clientIDSeller) {
		ClientIDSeller = clientIDSeller;
	}

	public String getContraFirmBuyer() {
		return ContraFirmBuyer;
	}

	public void setContraFirmBuyer(String contraFirmBuyer) {
		ContraFirmBuyer = contraFirmBuyer;
	}

	public String getTraderIDBuyer() {
		return TraderIDBuyer;
	}

	public void setTraderIDBuyer(String traderIDBuyer) {
		TraderIDBuyer = traderIDBuyer;
	}

	public String getSecuritySymbol() {
		return SecuritySymbol;
	}

	public void setSecuritySymbol(String securitySymbol) {
		SecuritySymbol = securitySymbol;
	}

	public String getPrice() {
		return Price;
	}

	public void setPrice(String price) {
		Price = price;
	}

	public String getBoard() {
		return Board;
	}

	public void setBoard(String board) {
		Board = board;
	}

	public String getDealID() {
		return DealID;
	}

	public void setDealID(String dealID) {
		DealID = dealID;
	}

	public String getFiller() {
		return Filler;
	}

	public void setFiller(String filler) {
		Filler = filler;
	}

	public String getBrokerPortfolioVolumeSeller() {
		return BrokerPortfolioVolumeSeller;
	}

	public void setBrokerPortfolioVolumeSeller(
			String brokerPortfolioVolumeSeller) {
		BrokerPortfolioVolumeSeller = brokerPortfolioVolumeSeller;
	}

	public String getBrokerClientVolumeSeller() {
		return BrokerClientVolumeSeller;
	}

	public void setBrokerClientVolumeSeller(String brokerClientVolumeSeller) {
		BrokerClientVolumeSeller = brokerClientVolumeSeller;
	}

	public String getMutualFundVolumeSeller() {
		return MutualFundVolumeSeller;
	}

	public void setMutualFundVolumeSeller(String mutualFundVolumeSeller) {
		MutualFundVolumeSeller = mutualFundVolumeSeller;
	}

	public String getBrokerForeignVolumeSeller() {
		return BrokerForeignVolumeSeller;
	}

	public void setBrokerForeignVolumeSeller(String brokerForeignVolumeSeller) {
		BrokerForeignVolumeSeller = brokerForeignVolumeSeller;
	}

	public String getFiller2() {
		return Filler2;
	}

	public void setFiller2(String filler2) {
		Filler2 = filler2;
	}

}
