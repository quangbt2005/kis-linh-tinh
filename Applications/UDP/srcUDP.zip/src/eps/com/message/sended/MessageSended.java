package eps.com.message.sended;

/**
 * Lớp này mô tả đối tượng message mà client gửi cho server.
 * 
 * @author lequocthai
 *
 */
import java.io.Serializable;
import java.sql.Date;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

public class MessageSended implements Serializable{

	private static final long serialVersionUID = 1L;
	
	// Chi�?u dài của message.
	private long length;
	// Th�?i gian gửi message.
	private Date dateSended;
	// Gi�? phút giây gửi message.
	private Timestamp dateDetail;
	// Số hiệu message client gửi đến server.
	private long seq;
	// Số hiệu message mà client mong muốn nhận được.
	private long ack_seq;
	// Mã opcode của message nhận được.
	private String opcode;
	// Trư�?ng LinkID của message nhận được.
	private long linkID;
	// Trư�?ng content trong Auto-tP Message.
	private byte[] content;
	
	// Các trư�?ng này được sử dụng cho lệnh Hủy (1C).
	private String traderID;
	private String norb;
	private String orderQtty;
	private String oorb;
	private String orderID;
	private String norc;
	private String stockCode;
	// Danh sách các mã lệnh trong message.
	private List<String> orderList;

	public String getStockCode() {
		return stockCode;
	}

	public void setStockCode(String stockCode) {
		this.stockCode = stockCode;
	}

	public String getNorc() {
		return norc;
	}

	public void setNorc(String norc) {
		this.norc = norc;
	}

	public String getOrderID() {
		return orderID;
	}

	public void setOrderID(String orderID) {
		this.orderID = orderID;
	}

	public String getOrderQtty() {
		return orderQtty;
	}

	public void setOrderQtty(String orderQtty) {
		this.orderQtty = orderQtty;
	}

	public String getNorb() {
		return norb;
	}

	public void setNorb(String norb) {
		this.norb = norb;
	}

	public String getOorb() {
		return oorb;
	}

	public void setOorb(String oorb) {
		this.oorb = oorb;
	}

	public String getTraderID() {
		return traderID;
	}

	public void setTraderID(String traderID) {
		this.traderID = traderID;
	}

	public long getAck_seq() {
		return ack_seq;
	}
	
	public void setAck_seq(long ack_seq) {
		this.ack_seq = ack_seq;
	}
	
	public byte[] getContent() {
		return content;
	}
	
	public void setContent(byte[] content) {
		this.content = content;
	}
	
	public Date getDateSended() {
		return dateSended;
	}
	
	public void setDateSended(Date dateSended) {
		this.dateSended = dateSended;
	}
	
	public long getSeq() {
		return seq;
	}
	
	public void setSeq(long seq) {
		this.seq = seq;
	}

	public Timestamp getDateDetail() {
		return dateDetail;
	}

	public void setDateDetail(Timestamp dateDetail) {
		this.dateDetail = dateDetail;
	}

	public long getLength() {
		return length;
	}

	public void setLength(long length) {
		this.length = length;
	}

	public long getLinkID() {
		return linkID;
	}

	public void setLinkID(long linkID) {
		this.linkID = linkID;
	}

	public String getOpcode() {
		return opcode;
	}

	public void setOpcode(String opcode) {
		this.opcode = opcode;
	}

	public String toString(){
		if (opcode.equalsIgnoreCase("RR"))
			return "Gói dữ liệu thứ: " + seq;
		else
			return "Gói dữ liệu thứ: " + seq + ". Gồm " + orderList.size() + " lệnh";
	}

	public List<String> getOrderList() {
		return orderList;
	}

	public void setOrderList(List<String> list) {
		orderList = new ArrayList<String>();
		for (int i = 0; i < list.size(); i++)
			orderList.add(list.get(i));
	}
}
