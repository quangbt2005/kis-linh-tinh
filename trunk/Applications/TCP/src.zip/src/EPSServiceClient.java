import java.lang.reflect.AccessibleObject;
import java.lang.reflect.Field;
import java.net.URL;

import javax.xml.rpc.ServiceException;

import classDirectlyOrderTransfer.ClassDirectlyOrderTransferPort;
import classDirectlyOrderTransfer.ClassDirectlyOrderTransferService;
import classDirectlyOrderTransfer.ClassDirectlyOrderTransferServiceLocator;
import classDirectlyOrderTransfer.GetListTransferingOrdersResult;
import classDirectlyOrderTransfer.GetListTransferingOrdersStruct;

public class EPSServiceClient {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		ClassDirectlyOrderTransferService svc = new ClassDirectlyOrderTransferServiceLocator();
		try {
			// URL url = new URL();
			ClassDirectlyOrderTransferPort getclassDirectlyOrderTransferPort = svc
					.getclassDirectlyOrderTransferPort();
			GetListTransferingOrdersResult listTransferingOrders = getclassDirectlyOrderTransferPort
					.getListTransferingOrders("2008-10-02", "ba.nd",
							"hsc080hsc2");
			System.out.println("Error code : "
					+ listTransferingOrders.getError_code());
			GetListTransferingOrdersStruct[] items = listTransferingOrders
					.getItems();
			for (int i = 0; i < items.length; i++) {
				printParameters(items[i]);
			}

		} catch (Exception e) {

			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private static void printParameters(Object obj) {
		StringBuffer result = new StringBuffer();
		Class clazz = obj.getClass();
		Field[] fields = clazz.getDeclaredFields();
		// change visibility
		AccessibleObject.setAccessible(fields, true);
		int length = fields.length;
		Field field = null;
		String str1 = null;
		String name = null;
		for (int i = 0; i < length; i++) {
			field = fields[i];
			field.setAccessible(true);

			try {
				name = field.getName();
				if (name.equals("serialVersionUID"))
					continue;
				Object object = field.get(obj);
				if (object == null)
					continue;
				str1 = object.toString();
				result.append(name).append("=");
				result.append(str1);
				if (i < length)
					result.append(" ; ");
			} catch (Exception e) {
				e.printStackTrace();
			}

		}
		System.out.println(result);
		// return result.toString();
	}

}
