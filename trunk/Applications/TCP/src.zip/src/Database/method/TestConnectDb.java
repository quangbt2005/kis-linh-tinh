package Database.method;
import java.sql.*;
import java.util.*; 

import  eps.com.message.sended.*;
import eps.com.test.TestCommon;

public class TestConnectDb {
	
	public TestConnectDb() {
		// TODO Auto-generated constructor stub
	
	}
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new TestConnectDb();
	}
		
	public ArrayList  getListLO() throws SQLException 
	{
		
		Connection conn = null;
		ResultSet rs = null;
		Statement stmt = null;
		CallableStatement proc = null ;
		String select = "" ;
		java.sql.Date date ;
		DbMrg dbMrg = new DbMrg() ;
		
		ArrayList listOrders = new ArrayList();
		try
        {
			conn = dbMrg.makeConnection() ;
			
			select = "{call sp_order_CurOrderList(?)}" ;
			proc = conn.prepareCall(select) ;
			
			date =  java.sql.Date.valueOf("2008-09-15") ;
		    proc.setDate(1, date);
		   
		     rs =proc.executeQuery();  
		     String temp= null;
		     while ( rs.next())
		     {		
		  
		    	temp =rs.getString(7);
		    	if(!temp.trim().equalsIgnoreCase("ATO") && !temp.trim().equalsIgnoreCase("ATC")){
			    	NewConditioned_1I new1i = new NewConditioned_1I() ;
			    	
			    	new1i.setFirm("057");
			    	new1i.setTraderID("2120") ;
			    	new1i.setOrderNumber(rs.getString(1)); // Ma lenh tai cong ty EPS
			    	String acount = TestCommon.createRandomAcountBuy();
			    	new1i.setClientID(acount); // default // Ma tai khoang
			    	new1i.setSecuritySymbol(rs.getString(4)); // Ma chung khoang
			    	new1i.setSide(rs.getString(3)); // Mua / Ban / Huy
			    	new1i.setVolume(rs.getString(5)) ; // So luong 
			    	new1i.setPublishedVolume("1000    ");
			    	new1i.setPrice(temp) ; // ATO ,ATC , Limit Order
			    	new1i.setBoard("M") ;
			    	new1i.setFiller("");
			    	new1i.setPortClientFlag("C"); 
			    	new1i.setFiller2("");
			    	listOrders.add(new1i) ;
		    	}
		    	   	 
	    	
	  		    	
			}// while 
        }
		catch (Exception e)
	    {
	          System.err.println ("Cannot connect to database server");
	          e.printStackTrace();
	            
	     }
	     finally
	      {
	    	 if ( rs != null)
	    		 rs = null ;
	    	 if ( proc != null)
	        	proc.close();
	         if (conn != null)
	         {
	                try
	                {
	                    
	                	dbMrg.releaseConnection(conn);
//	                    System.out.println ("Database connection terminated");
	                    
	                }
	                catch (Exception e) { /* ignore close errors */ }
	            }
	      }
	     return listOrders ;
		
	}

	
	public ArrayList  getListATO() throws SQLException 
	{
		
		Connection conn = null;
		ResultSet rs = null;
		Statement stmt = null;
		CallableStatement proc = null ;
		String select = "" ;
		java.sql.Date date ;
		DbMrg dbMrg = new DbMrg() ;
		
		ArrayList listOrders = new ArrayList();
		try
        {
			conn = dbMrg.makeConnection() ;
			
			select = "{call sp_order_CurOrderList(?)}" ;
			proc = conn.prepareCall(select) ;
			
			date =  java.sql.Date.valueOf("2008-09-15") ;
		    proc.setDate(1, date);
		   
		     rs =proc.executeQuery();  
		     String temp= null;
		     while ( rs.next())
		     {		
		  
		    	temp =rs.getString(7);
		    	if(temp.trim().equalsIgnoreCase("ATO")){
			    	NewConditioned_1I new1i = new NewConditioned_1I() ;
			    	
			    	new1i.setFirm("057");
			    	new1i.setTraderID("2120") ;
			    	new1i.setOrderNumber(rs.getString(1)); // Ma lenh tai cong ty EPS
			    	String acount = TestCommon.createRandomAcountBuy();
			    	new1i.setClientID(acount); // default // Ma tai khoang
			    	new1i.setSecuritySymbol(rs.getString(4)); // Ma chung khoang
			    	new1i.setSide(rs.getString(3)); // Mua / Ban / Huy
			    	new1i.setVolume(rs.getString(5)) ; // So luong 
			    	new1i.setPublishedVolume("1000    ");
			    	new1i.setPrice(temp) ; // ATO ,ATC , Limit Order
			    	new1i.setBoard("M") ;
			    	new1i.setFiller("");
			    	new1i.setPortClientFlag("C"); 
			    	new1i.setFiller2("");
			    	listOrders.add(new1i) ;
		    	}
			}// while 
        }
		catch (Exception e)
	    {
	          System.err.println ("Cannot connect to database server");
	          e.printStackTrace();
	            
	     }
	     finally
	      {
	    	 if ( rs != null)
	    		 rs = null ;
	    	 if ( proc != null)
	        	proc.close();
	         if (conn != null)
	         {
	                try
	                {
	                    
	                	dbMrg.releaseConnection(conn);
//	                    System.out.println ("Database connection terminated");
	                    
	                }
	                catch (Exception e) { /* ignore close errors */ }
	            }
	      }
	     return listOrders ;
		
	}

	public ArrayList  getListATC() throws SQLException 
	{
		
		Connection conn = null;
		ResultSet rs = null;
		Statement stmt = null;
		CallableStatement proc = null ;
		String select = "" ;
		java.sql.Date date ;
		DbMrg dbMrg = new DbMrg() ;
		
		ArrayList listOrders = new ArrayList();
		try
        {
			conn = dbMrg.makeConnection() ;
			
			select = "{call sp_order_CurOrderList(?)}" ;
			proc = conn.prepareCall(select) ;
			
			date =  java.sql.Date.valueOf("2008-09-15") ;
		    proc.setDate(1, date);
		   
		     rs =proc.executeQuery();  
		     String temp= null;
		     while ( rs.next())
		     {		
		  
		    	temp =rs.getString(7);
		    	if(temp.trim().equalsIgnoreCase("ATC")){
			    	NewConditioned_1I new1i = new NewConditioned_1I() ;
			    	
			    	new1i.setFirm("057");
			    	new1i.setTraderID("2120") ;
			    	new1i.setOrderNumber(rs.getString(1)); // Ma lenh tai cong ty EPS
			    	String acount = TestCommon.createRandomAcountBuy();
			    	new1i.setClientID(acount); // default // Ma tai khoang
			    	new1i.setSecuritySymbol(rs.getString(4)); // Ma chung khoang
			    	new1i.setSide(rs.getString(3)); // Mua / Ban / Huy
			    	new1i.setVolume(rs.getString(5)) ; // So luong 
			    	new1i.setPublishedVolume("1000    ");
			    	new1i.setPrice(temp) ; // ATO ,ATC , Limit Order
			    	new1i.setBoard("M") ;
			    	new1i.setFiller("");
			    	new1i.setPortClientFlag("C"); 
			    	new1i.setFiller2("");
			    	listOrders.add(new1i) ;
		    	}
			}// while 
        }
		catch (Exception e)
	    {
	          System.err.println ("Cannot connect to database server");
	          e.printStackTrace();
	            
	     }
	     finally
	      {
	    	 if ( rs != null)
	    		 rs = null ;
	    	 if ( proc != null)
	        	proc.close();
	         if (conn != null)
	         {
	                try
	                {
	                    
	                	dbMrg.releaseConnection(conn);
//	                    System.out.println ("Database connection terminated");
	                    
	                }
	                catch (Exception e) { /* ignore close errors */ }
	            }
	      }
	     return listOrders ;
		
	}

	
	public void testCallprocedure() throws SQLException 
	{
		
		Connection conn = null;
		ResultSet rs = null;
		Statement stmt = null;
		CallableStatement proc = null ;
		String select = "" ;
		java.sql.Date date ;
		
		DbMrg dbMrg = new DbMrg() ;
		try
        {
			conn = dbMrg.makeConnection() ;
			
			select = "{call sp_order_CurOrderList(?)}" ;
			proc = conn.prepareCall(select) ;
			
			date =  java.sql.Date.valueOf("2008-09-15") ;
		    proc.setDate(1, date);
		   
		     rs =proc.executeQuery();    
		    while ( rs.next())
			{
	  		    	 System.out.println("OrderID:" + rs.getString(1)+ "-"
		    			+ "OrderNumber:"+rs.getString(2)+ "-"
		    			+ "OrderSideName:" + rs.getString(3)+ "-"
		    			+ "Symbol:" +  rs.getString(4)+ "-"
		    			+ "OrderQuantity:" +  rs.getString(5)+ "-"
		    			+ "OrderPrice:" +  rs.getString(6)+ "-"
		    			+ "OrderStyleName:" + rs.getString(7)+ "-"
		    			+ "Session:" + rs.getString(8)+ "-"
		    			+ "StatusName:" + rs.getString(9)+ "-"
		    			+ "Note:"+ rs.getString(10)+ "-"
		    			+ "Exchange:"+ rs.getString(11)+ "-"
		    			 );
			}// while 
        }
		catch (Exception e)
	    {
	          System.err.println ("Cannot connect to database server");
	          e.printStackTrace();
	            
	     }
	     finally
	      {
	    	 if ( rs != null)
	    		 rs = null ;
	    	 if ( proc != null)
	        	proc.close();
	         if (conn != null)
	         {
	                try
	                {
	                    
	                	dbMrg.releaseConnection(conn);
	                    System.out.println ("Database connection terminated");
	                    
	                }
	                catch (Exception e) { /* ignore close errors */ }
	            }
	      }
		
	}
	
}
