package eps.com.message.broadcast;

import java.io.Serializable;

import eps.com.common.ValueObject;

public class TimeStamp_TS extends ValueObject implements Serializable{
	
	public static final String MessageType="TS";
	private long Timestamp  ;
	
	public TimeStamp_TS()
	{
		
	}
	public static String getMessage_Type() {
		return MessageType ;
	}
	public long getTimestamp() {
		return Timestamp;
	}
	public void setTimestamp(long timestamp) {
		Timestamp = timestamp;
	} 
}
