package eps.com.message.broadcast;


public class Common {
	
	public Common()
	{
		
	}
	//	/CONVERT MODE///////////////////////////////////////////////////////////////
	public static byte[] EnMod96(int i_Result, int i_Loop) {
	    byte[] bi_Result = new byte[i_Loop];
	    char a;
	    while (i_Loop > 0) {
	        a = (char) ((i_Result % 96) + 32);
	        bi_Result[i_Loop - 1] = (byte) a;
	        i_Result = i_Result / 96;
	        i_Loop--;
	    }
	    return bi_Result;
	} 
	
	public static int DecodeMod96(byte[] bi_Data) {
	    int i_Loop = 0;
	    int i_Result = 0;
	    do {
	        i_Result = (i_Result << 5) + (i_Result << 6);
	        i_Result += (int) (char) bi_Data[i_Loop] - 32;
	        i_Loop++;
	    } while (i_Loop < bi_Data.length);
	    return i_Result;
	}	
	/////////////////////////////////////////////////////////////////////////////
	
}
