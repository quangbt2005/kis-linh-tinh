package eps.com.message.broadcast;
import java.io.Serializable;
import java.sql.Date;
import java.sql.Timestamp;

import eps.com.common.ValueObject;

public class AdvertisementAnnouncement_AA extends ValueObject implements Serializable
{
	
	public static final String MessageType = "AA";
	private long SecurityNumber;
	private long Volume;
	private String Price;
	private long Firm;
	private long Trader;
	private String Side;
	private String Board;
	private long Time;
	private String AddCancelFlag;
	private String Contact;
	
	public AdvertisementAnnouncement_AA()
	{
		
	}
	
	public String getAddCancelFlag() {
		return AddCancelFlag;
	}
	public void setAddCancelFlag(String addCancelFlag) {
		this.AddCancelFlag = addCancelFlag;
	}
	public String getBoard() {
		return Board;
	}
	public void setBoard(String board) {
		this.Board = board;
	}
	public String getContact() {
		return Contact;
	}
	public void setContact(String contact) {
		this.Contact = contact;
	}
	public long getFirm() {
		return Firm;
	}
	public void setFirm(long firm) {
		this.Firm = firm;
	}
	public static String getMessageType() {
		return MessageType;
	}
	public String getPrice() {
		return Price;
	}
	public void setPrice(String price) {
		this.Price = price;
	}
	public long getSecurityNumber() {
		return SecurityNumber;
	}
	public void setSecurityNumber(long securityNumber) {
		this.SecurityNumber = securityNumber;
	}
	public String getSide() {
		return Side;
	}
	public void setSide(String side) {
		this.Side = side;
	}
	public long getTime() {
		return Time;
	}
	public void setTime(long time) {
		this.Time = time;
	}
	public long getTrader() {
		return Trader;
	}
	public void setTrader(long trader) {
		this.Trader = trader;
	}
	public long getVolume() {
		return Volume;
	}
	public void setVolume(long volume) {
		this.Volume = volume;
	}
	
	
	
	
}
