package eps.com.message.broadcast;

import java.io.Serializable;

import eps.com.common.ValueObject;

public class IndexUpdate_IU extends ValueObject implements Serializable{

	public static final String MessageType="IU";
	
	private long indexHoSE;
	private long totalTrades;
	private long totalSharesTraded;
	private long totalValuesTraded;
	private long upVolume;
	private long downVolume;
	private long noChangeVolume;
	private long advances;
	private long declines;
	private long noChange;
	private String filler1;
	private String marketID;
	private String filler2;
	private long indexTime;
	
	public IndexUpdate_IU()
	{
		
	}
	public long getAdvances() {
		return advances;
	}
	public void setAdvances(long advances) {
		this.advances = advances;
	}
	public long getDeclines() {
		return declines;
	}
	public void setDeclines(long declines) {
		this.declines = declines;
	}
	public long getDownVolume() {
		return downVolume;
	}
	public void setDownVolume(long downVolume) {
		this.downVolume = downVolume;
	}
	public String getFiller1() {
		return filler1;
	}
	public void setFiller1(String filler1) {
		this.filler1 = filler1;
	}
	public String getFiller2() {
		return filler2;
	}
	public void setFiller2(String filler2) {
		this.filler2 = filler2;
	}
	public long getIndexHoSE() {
		return indexHoSE;
	}
	public void setIndexHoSE(long indexHoSE) {
		this.indexHoSE = indexHoSE;
	}
	public long getIndexTime() {
		return indexTime;
	}
	public void setIndexTime(long indexTime) {
		this.indexTime = indexTime;
	}
	public String getMarketID() {
		return marketID;
	}
	public void setMarketID(String marketID) {
		this.marketID = marketID;
	}
	
	public static String getMessageType() {
		return MessageType ;
	}
	
	public long getNoChange() {
		return noChange;
	}
	public void setNoChange(long noChange) {
		this.noChange = noChange;
	}
	public long getNoChangeVolume() {
		return noChangeVolume;
	}
	public void setNoChangeVolume(long noChangeVolume) {
		this.noChangeVolume = noChangeVolume;
	}
	public long getTotalSharesTraded() {
		return totalSharesTraded;
	}
	public void setTotalSharesTraded(long totalSharesTraded) {
		this.totalSharesTraded = totalSharesTraded;
	}
	public long getTotalTrades() {
		return totalTrades;
	}
	public void setTotalTrades(long totalTrades) {
		this.totalTrades = totalTrades;
	}
	public long getTotalValuesTraded() {
		return totalValuesTraded;
	}
	public void setTotalValuesTraded(long totalValuesTraded) {
		this.totalValuesTraded = totalValuesTraded;
	}
	public long getUpVolume() {
		return upVolume;
	}
	public void setUpVolume(long upVolume) {
		this.upVolume = upVolume;
	}
}
