package eps.com.message.broadcast;

import java.io.Serializable;
import java.io.Serializable;

import eps.com.common.ValueObject;
import java.io.Serializable;
import java.sql.Date;
import java.sql.Timestamp;

import eps.com.common.ValueObject; 

public class CancelOddLot_CO  extends ValueObject implements Serializable {
	
	public static final String MessageType="CO";
	
	long  ReferenceNumber ;

	public long getReferenceNumber() {
		return ReferenceNumber;
	}

	public void setReferenceNumber(long referenceNumber) {
		ReferenceNumber = referenceNumber;
	}

	public static String getMessage_Type() {
		return MessageType ;
	}
	
	public CancelOddLot_CO()
	{
		
	}
	
	
	
}
