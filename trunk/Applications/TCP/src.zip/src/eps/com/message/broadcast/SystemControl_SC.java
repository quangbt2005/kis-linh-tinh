package eps.com.message.broadcast;

import java.io.Serializable;

import eps.com.common.ValueObject;

public class SystemControl_SC extends ValueObject implements Serializable{
	public static final String MessageType="SC";
	
	private String System_Control_Code  ;
	private long  Timestamp ;
	
	
	public SystemControl_SC()
	{
		
	}
	public static String getMessage_Type() {
		return MessageType ;
	}
		
	public String getSystem_Control_Code() {
		return System_Control_Code;
	}
	
	public void setSystem_Control_Code(String system_Control_Code) {
		System_Control_Code = system_Control_Code;
	}
	
	public long getTimestamp() {
		return Timestamp;
	}
	
	public void setTimestamp(long timestamp) {
		Timestamp = timestamp;
	}
}
