package eps.com.message.received;

import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

import javax.xml.rpc.ServiceException;

import classDirectlyOrderTransfer.ClassDirectlyOrderTransferPort;
import classDirectlyOrderTransfer.ClassDirectlyOrderTransferService;
import classDirectlyOrderTransfer.ClassDirectlyOrderTransferServiceLocator;
import classDirectlyOrderTransfer.Update1IOrderResult;
import classDirectlyOrderTransfer.UpdateOrder2CResult;

import eps.com.client.proposal.EPSServiceController;
import eps.com.client.proposal.ReceiveMessageQueue;
import eps.com.client.upd.ReTransUdpLog;
import eps.com.client.upd.UDPContent;
import eps.com.client.upd.UdpLog;
import eps.com.common.Opcode;
import eps.com.common.ValueObject;
import eps.com.message.broadcast.AdvertisementAnnouncement_AA;
import eps.com.message.broadcast.BrokerReconcile_BR;
import eps.com.message.broadcast.BrokerStatusChange_BS;
import eps.com.message.broadcast.CancelOddLot_CO;
import eps.com.message.broadcast.DealCancellationNotice_DC;
import eps.com.message.broadcast.ForeignRoom_TR;
import eps.com.message.broadcast.GeneralAdmin_GA;
import eps.com.message.broadcast.IndexUpdate_IU;
import eps.com.message.broadcast.LastOddLot_LO;
import eps.com.message.broadcast.LastSale_LS;
import eps.com.message.broadcast.MarketOpenLastSale_OS;
import eps.com.message.broadcast.NewOddLot_OL;
import eps.com.message.broadcast.NewsHeadline_NH;
import eps.com.message.broadcast.NewsStory_NS;
import eps.com.message.broadcast.ProjectedOpen_PO;
import eps.com.message.broadcast.PutThroughDealNotice_PD;
import eps.com.message.broadcast.SectoralIndices_SI;
import eps.com.message.broadcast.SecurityReconcile_SR;
import eps.com.message.broadcast.SecurityStatusChange_SS;
import eps.com.message.broadcast.SecurityUpdate_SU;
import eps.com.message.broadcast.SystemControl_SC;
import eps.com.message.broadcast.TimeStamp_TS;
import eps.com.message.broadcast.TopPrices_TP;
import eps.com.message.broadcast.TraderStatusChange_TC;
import eps.com.message.sended.DealCancelReply_3D;
import eps.com.message.sended.DealPutThroughCancelRequest_3C;
import eps.com.message.sended.NewConditioned_1I;
import eps.com.message.sended.PutThroughDealReply_3B;
import eps.com.util.MessageUtil;

public class TCP2EMessageService {

	public static String authenUser = "ba.nd";
	public static String authenPass	="hsc080hsc2";
	private  ReTransUdpLog updLog = new ReTransUdpLog(); 
	private ClassDirectlyOrderTransferService svc  = new ClassDirectlyOrderTransferServiceLocator();
	private ClassDirectlyOrderTransferPort getclassDirectlyOrderTransferPort;
	public TCP2EMessageService(){
		try {
			getclassDirectlyOrderTransferPort = svc.getclassDirectlyOrderTransferPort();
		} catch (ServiceException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void updateDealConfirmation(DealConfirmation_2E dealConfirmation){
		try {
			String  messageType ="2E";
			String  firm = dealConfirmation.getFirm();
			String  side= dealConfirmation.getSide();
			String  orderNumber = dealConfirmation.getOrderNumber();
			String  orderEntryDate= dealConfirmation.getOrderEntryDate();
			String  filler= dealConfirmation.getFiller();
			String  volume= dealConfirmation.getVolume();
			String  price= dealConfirmation.getPrice();
			String  confirmNumber= dealConfirmation.getConfirmNumber();
			getclassDirectlyOrderTransferPort.updateMatchOrder2E(messageType, firm, side, orderNumber, orderEntryDate, filler, volume, price, confirmNumber, authenUser, authenPass);
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
