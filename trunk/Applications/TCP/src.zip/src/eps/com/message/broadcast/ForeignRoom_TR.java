package eps.com.message.broadcast;

import java.io.Serializable;

import eps.com.common.ValueObject;

public class ForeignRoom_TR extends ValueObject implements Serializable{
	public static final String MessageType="TR";
	
	private long  Security_Number  ;
	private long  Total_Room  ;
	private long Current_Room ;
	
	public ForeignRoom_TR()
	{
		
	}
	
	public long getCurrent_Room() {
		return Current_Room;
	}
	public void setCurrent_Room(long current_Room) {
		Current_Room = current_Room;
	}
	public static String getMessage_Type() {
		return MessageType ;
	}
	
	public long getSecurity_Number() {
		return Security_Number;
	}
	public void setSecurity_Number(long security_Number) {
		Security_Number = security_Number;
	}
	public long getTotal_Room() {
		return Total_Room;
	}
	public void setTotal_Room(long total_Room) {
		Total_Room = total_Room;
	} 
}
