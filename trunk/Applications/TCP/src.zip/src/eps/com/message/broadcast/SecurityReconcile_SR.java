package eps.com.message.broadcast;

import java.io.Serializable;

import eps.com.common.ValueObject;

public class SecurityReconcile_SR extends ValueObject implements Serializable{
	
	public static final String MessageType="SR";
	
	private long  Security_Number  ;
	private long  Main_or_Foreign_Deal  ;
	private long  Main_or_Foreign_Acc_Volume  ;
	private long  Main_or_Foreign_Acc_Value ;
	private long Deals_in_Big_Lot_Board  ;
	private long  Big_Lot_Acc_Volume  ; 
	private long  Big_Lot_Acc_Value ;
	private long Deals_in_Odd_Lot_Board ;
	private long  Odd_Lot_Acc_Volume ;
	private long  Odd_Lot_Acc_Value  ;
	
	public SecurityReconcile_SR()
	{
		
	}
	public long getBig_Lot_Acc_Value() {
		return Big_Lot_Acc_Value;
	}
	public void setBig_Lot_Acc_Value(long big_Lot_Acc_Value) {
		Big_Lot_Acc_Value = big_Lot_Acc_Value;
	}
	public long getBig_Lot_Acc_Volume() {
		return Big_Lot_Acc_Volume;
	}
	public void setBig_Lot_Acc_Volume(long big_Lot_Acc_Volume) {
		Big_Lot_Acc_Volume = big_Lot_Acc_Volume;
	}
	public long getDeals_in_Big_Lot_Board() {
		return Deals_in_Big_Lot_Board;
	}
	public void setDeals_in_Big_Lot_Board(long deals_in_Big_Lot_Board) {
		Deals_in_Big_Lot_Board = deals_in_Big_Lot_Board;
	}
	public long getDeals_in_Odd_Lot_Board() {
		return Deals_in_Odd_Lot_Board;
	}
	public void setDeals_in_Odd_Lot_Board(long deals_in_Odd_Lot_Board) {
		Deals_in_Odd_Lot_Board = deals_in_Odd_Lot_Board;
	}
	public long getMain_or_Foreign_Acc_Value() {
		return Main_or_Foreign_Acc_Value;
	}
	public void setMain_or_Foreign_Acc_Value(long main_or_Foreign_Acc_Value) {
		Main_or_Foreign_Acc_Value = main_or_Foreign_Acc_Value;
	}
	public long getMain_or_Foreign_Acc_Volume() {
		return Main_or_Foreign_Acc_Volume;
	}
	public void setMain_or_Foreign_Acc_Volume(long main_or_Foreign_Acc_Volume) {
		Main_or_Foreign_Acc_Volume = main_or_Foreign_Acc_Volume;
	}
	public long getMain_or_Foreign_Deal() {
		return Main_or_Foreign_Deal;
	}
	public void setMain_or_Foreign_Deal(long main_or_Foreign_Deal) {
		Main_or_Foreign_Deal = main_or_Foreign_Deal;
	}
	public static String getMessage_Type() {
		return MessageType;
	}
	
	public long getOdd_Lot_Acc_Value() {
		return Odd_Lot_Acc_Value;
	}
	public void setOdd_Lot_Acc_Value(long odd_Lot_Acc_Value) {
		Odd_Lot_Acc_Value = odd_Lot_Acc_Value;
	}
	public long getOdd_Lot_Acc_Volume() {
		return Odd_Lot_Acc_Volume;
	}
	public void setOdd_Lot_Acc_Volume(long odd_Lot_Acc_Volume) {
		Odd_Lot_Acc_Volume = odd_Lot_Acc_Volume;
	}
	public long getSecurity_Number() {
		return Security_Number;
	}
	public void setSecurity_Number(long security_Number) {
		Security_Number = security_Number;
	}
}
