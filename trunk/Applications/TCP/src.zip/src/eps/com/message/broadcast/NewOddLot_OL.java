package eps.com.message.broadcast;

import java.io.Serializable;

import eps.com.common.ValueObject;

public class NewOddLot_OL extends ValueObject implements Serializable{
	
	public static final String MessageType="OL";
	
	private long  Security_Number ;
	private long Odd_Lot_Volume  ;
	private long  Price  ; 
	private String Side  ;
	private long Reference_Number ;
	
	public NewOddLot_OL()
	{
		
	}
	
	public static String getMessage_Type() {
		return MessageType ;
	}
	
	public long getOdd_Lot_Volume() {
		return Odd_Lot_Volume;
	}
	public void setOdd_Lot_Volume(long odd_Lot_Volume) {
		Odd_Lot_Volume = odd_Lot_Volume;
	}
	public long getPrice() {
		return Price;
	}
	public void setPrice(long price) {
		Price = price;
	}
	
	public long getReference_Number() {
		return Reference_Number;
	}
	
	public void setReference_Number(long reference_Number) {
		Reference_Number = reference_Number;
	}
	
	public long getSecurity_Number() {
		return Security_Number;
	}
	public void setSecurity_Number(long security_Number) {
		Security_Number = security_Number;
	}
	public String getSide() {
		return Side;
	}
	public void setSide(String side) {
		Side = side;
	} 
}
