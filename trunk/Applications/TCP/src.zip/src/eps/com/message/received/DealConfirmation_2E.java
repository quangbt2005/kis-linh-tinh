package eps.com.message.received;

import java.io.Serializable;
import java.sql.Date;

import eps.com.common.ValueObject;

public class DealConfirmation_2E extends ValueObject implements Serializable {

	private static final long serialVersionUID = 1L;

	public static final String MessageType = "2E";

	private String Firm;
	private String Side;
	private String OrderNumber;
	private String OrderEntryDate;
	private String Filler;
	private String Volume;
	private String Price;
	private String ConfirmNumber;

	public DealConfirmation_2E() {
	}

	public String getFirm() {
		return Firm;
	}

	public void setFirm(String firm) {
		Firm = firm;
	}

	public String getSide() {
		return Side;
	}

	public void setSide(String side) {
		Side = side;
	}

	public String getOrderNumber() {
		return OrderNumber;
	}

	public void setOrderNumber(String orderNumber) {
		OrderNumber = orderNumber;
	}

	public String getOrderEntryDate() {
		return OrderEntryDate;
	}

	public void setOrderEntryDate(String orderEntryDate) {
		OrderEntryDate = orderEntryDate;
	}

	public String getFiller() {
		return Filler;
	}

	public void setFiller(String filler) {
		Filler = filler;
	}

	public String getVolume() {
		return Volume;
	}

	public void setVolume(String volume) {
		Volume = volume;
	}

	public String getPrice() {
		return Price;
	}

	public void setPrice(String price) {
		Price = price;
	}

	public String getConfirmNumber() {
		return ConfirmNumber;
	}

	public void setConfirmNumber(String confirmNumber) {
		ConfirmNumber = confirmNumber;
	}

}
