package eps.com.message.received;

import java.io.Serializable;
import java.sql.Date;

import eps.com.common.ValueObject;

public class ConfirmOfOrderChange_2D extends ValueObject implements
		Serializable {

	private static final long serialVersionUID = 1L;

	public static final String MessageType = "2D";

	private String Firm;
	private String OrderNumber;
	private String OrderEntryDate;
	private String ClientID;
	private String PortClientFlag;
	private String PublishedVolume;
	private String Price;
	private String Filler;

	public ConfirmOfOrderChange_2D() {
	}

	public String getFirm() {
		return Firm;
	}

	public void setFirm(String firm) {
		Firm = firm;
	}

	public String getOrderNumber() {
		return OrderNumber;
	}

	public void setOrderNumber(String orderNumber) {
		OrderNumber = orderNumber;
	}

	public String getOrderEntryDate() {
		return OrderEntryDate;
	}

	public void setOrderEntryDate(String orderEntryDate) {
		OrderEntryDate = orderEntryDate;
	}

	public String getClientID() {
		return ClientID;
	}

	public void setClientID(String clientID) {
		ClientID = clientID;
	}

	public String getPortClientFlag() {
		return PortClientFlag;
	}

	public void setPortClientFlag(String portClientFlag) {
		PortClientFlag = portClientFlag;
	}

	public String getPublishedVolume() {
		return PublishedVolume;
	}

	public void setPublishedVolume(String publishedVolume) {
		PublishedVolume = publishedVolume;
	}

	public String getPrice() {
		return Price;
	}

	public void setPrice(String price) {
		Price = price;
	}

	public String getFiller() {
		return Filler;
	}

	public void setFiller(String filler) {
		Filler = filler;
	}

}
