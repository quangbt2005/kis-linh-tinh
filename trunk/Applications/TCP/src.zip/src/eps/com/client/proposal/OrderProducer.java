package eps.com.client.proposal;

import javax.xml.rpc.ServiceException;

import classDirectlyOrderTransfer.ClassDirectlyOrderTransferPort;
import classDirectlyOrderTransfer.ClassDirectlyOrderTransferService;
import classDirectlyOrderTransfer.ClassDirectlyOrderTransferServiceLocator;
import classDirectlyOrderTransfer.GetListTransferingOrdersResult;
import classDirectlyOrderTransfer.GetListTransferingOrdersStruct;
import classDirectlyOrderTransfer.UpdateOrder2BResult;
import classDirectlyOrderTransfer.UpdateOrder2BStruct;
import eps.com.common.HosePacket;
import eps.com.common.HoseSystemPacket;
import eps.com.common.Opcode;
import eps.com.message.received.TCPMessageService;
import eps.com.message.sended.NewConditioned_1I;
import eps.com.message.sended.OrderCancellation_1C;
import eps.com.message.sended.OrderChange_1D;
import eps.com.test.TestCommon;

public class OrderProducer extends Thread {
	// co nay duoc set khi nhan duoc SC Message co P from UDP module
	private boolean scFlagP = true;
	private MessageQueue queue;
	private WindowBuffer buffer;
	HoseSystemPacket packet;

	ClassDirectlyOrderTransferService svc = new ClassDirectlyOrderTransferServiceLocator();
	ClassDirectlyOrderTransferPort getclassDirectlyOrderTransferPort;
	private static String today = "";
	static {
		today = TestCommon.getStandardDate();
	}

	public OrderProducer(MessageQueue queue) {
		this.queue = queue;
		try {
			getclassDirectlyOrderTransferPort = svc
					.getclassDirectlyOrderTransferPort();
		} catch (ServiceException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public OrderProducer(MessageQueue queue, WindowBuffer buffer) {
		this.queue = queue;
		this.buffer = buffer;
		try {
			getclassDirectlyOrderTransferPort = svc
					.getclassDirectlyOrderTransferPort();
		} catch (ServiceException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void setStart(boolean bool) {
		scFlagP = bool;
	}

	@Override
	public void run() {
		// System.out.println("Trong EchoPacketProducer");
		while (scFlagP) {
			try {
				if (buffer.getWindowBufferSize() == WindowBuffer.WINDOW_SIZE)
					continue;
				// today="2008-10-24";
				// System.out.println("standard date:" +
				// TestCommon.getStandardDate());
				GetListTransferingOrdersResult listTransferingOrders = getclassDirectlyOrderTransferPort
						.getListTransferingOrders(today,
								TCPMessageService.authenUser,
								TCPMessageService.authenPass);
				// System.out.println("Error code : "
				// + listTransferingOrders.getError_code());
				GetListTransferingOrdersStruct[] items = listTransferingOrders
						.getItems();
				if (items != null) {
					NewConditioned_1I order = null;
					OrderCancellation_1C order1C = null;
					OrderChange_1D order1D = null;

					// UpdateOrder2BResult updateOrder2B =
					// getclassDirectlyOrderTransferPort
					// .updateOrder2B("", "", "", "", "", "", "", "");
					// UpdateOrder2BStruct[] items2 = updateOrder2B.getItems();

					for (int i = 0; i < items.length; i++) {
						if (items[i].getMessageType().equalsIgnoreCase("1I")) {
							order = new NewConditioned_1I();
							order.setFirm(items[i].getFirm());
							order.setTraderID(items[i].getTraderID());
							order.setOrderNumber(items[i].getOrderNumber());
							order.setClientID(items[i].getClientID());
							order.setSecuritySymbol(items[i]
									.getSecuritySymbol());
							order.setSide(items[i].getSide());
							order.setVolume(items[i].getVolume());
							order.setPublishedVolume(items[i]
									.getPublishedVolume());
							order.setPrice(items[i].getPrice());
							order.setBoard(items[i].getBoard());
							order.setFiller("");
							order.setPortClientFlag(items[i]
									.getPortClientFlag());
							order.setFiller2("");
							queue.putMessage(order);
							// System.out.println("reading:" +
							// order.toString());
						} else if (items[i].getMessageType().equalsIgnoreCase(
								"1C")) {
							order1C = new OrderCancellation_1C();
							order1C.setFirm(items[i].getFirm());
							order1C.setOrderNumber(items[i].getOrderNumber());
							order1C.setOrderEntryDate(items[i]
									.getOrderEntryDate());
							queue.putMessage(order1C);
						} else if (items[i].getMessageType().equalsIgnoreCase(
								"1D")) {
							order1D = new OrderChange_1D();
							order1D.setFirm(items[i].getFirm());
							order1D.setOrderNumber(items[i].getOrderNumber());
							order1D.setOrderEntryDate(items[i]
									.getOrderEntryDate());
							order1D.setClientID(items[i].getClientID());
							order1D.setFiller("");
							queue.putMessage(order1D);
						}
					}
				}
				Thread.sleep(1000);
				// Thread.sleep(10* 60000);
			} catch (InterruptedException ie) {
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

}
