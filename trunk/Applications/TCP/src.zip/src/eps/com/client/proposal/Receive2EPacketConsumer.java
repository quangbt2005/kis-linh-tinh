package eps.com.client.proposal;

import eps.com.common.ValueObject;
import eps.com.message.received.DealConfirmation_2E;
import eps.com.message.received.TCP2EMessageService;
import eps.com.message.received.TCPMessageService;

public class Receive2EPacketConsumer extends Thread {
	private boolean isStop;
	private TCP2EMessageService tcpService = new TCP2EMessageService();
	private ReceiveMessageQueue receiveQueue;
	public Receive2EPacketConsumer(ReceiveMessageQueue receiveQueue) {
		this.receiveQueue = receiveQueue;
	}

	public void setStop(boolean bool) {
		isStop = bool;
	}
	@Override
	public void run() {
		while (!isStop) {
			try {
				ValueObject message =  this.receiveQueue.getMessage();
				System.out.println("2E message:" + message);
				this.tcpService.updateDealConfirmation((DealConfirmation_2E)message);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
}
