package eps.com.client.upd;

import java.text.SimpleDateFormat;
import java.util.Date;

import eps.com.client.SaveState;
import eps.com.test.TestCommon;

public class UdpLog {
	private static SaveState _saver;

	static {
		SimpleDateFormat sdf = new SimpleDateFormat("ddMM");
		String format = sdf.format(new Date());

		_saver = new SaveState(TestCommon.DATA_SAVE_PATH + "/UDPLog_" + format
				+ ".txt");
	}

	public void printAndSave(String arg) {
		printConsole(arg);
		saveLog(arg);
	}

	public void printConsole(String arg) {
		System.out.println(arg);
	}

	public void saveLog(String arg) {
		_saver.append(new Date() + " " + arg + "\n");
	}
}
