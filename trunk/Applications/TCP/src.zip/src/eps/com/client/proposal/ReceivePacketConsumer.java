package eps.com.client.proposal;

import eps.com.common.ValueObject;
import eps.com.message.received.TCPMessageService;

public class ReceivePacketConsumer extends Thread {
	private boolean isStop;
	private TCPMessageService tcpService = new TCPMessageService();
	private ReceiveMessageQueue receiveQueue;
	public ReceivePacketConsumer(ReceiveMessageQueue receiveQueue) {
		this.receiveQueue = receiveQueue;
	}

	public void setStop(boolean bool) {
		isStop = bool;
	}
	@Override
	public void run() {
		while (!isStop) {
			try {
				ValueObject message =  this.receiveQueue.getMessage();
				this.tcpService.processTCPMessage(message);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
}
