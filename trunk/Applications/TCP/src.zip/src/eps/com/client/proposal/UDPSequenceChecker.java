package eps.com.client.proposal;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import eps.com.message.sended.RetransmissionRequest_RQ;
import eps.com.test.TestCommon;

public class UDPSequenceChecker extends Thread {
	public static int MAX_RETRANS_PACKET = 500;
	private boolean scFlagP = true;
	int currentIndex = 0;
	RandomAccessFile raf;

	public UDPSequenceChecker(int udpSeq) {
		try {
			raf = new RandomAccessFile(TestCommon.DATA_SAVE_PATH
					+ "/sequence.dat", "rw");

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			scFlagP = false;
		}
	}

	public void setStart(boolean bool) {
		scFlagP = bool;
		if (!bool) {
			try {
				if (raf != null)
					raf.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	@Override
	public void run() {
		// System.out.println("Trong EchoPacketProducer");
		while (scFlagP) {
			try {

				int size = (int) (raf.length() - 4) / 8;
				raf.seek(0);
				currentIndex = (int) raf.readInt();
				//System.out.println("test RR:" + currentIndex + "--" + size);
				if (size <= 0 || currentIndex == size) {
					Thread.sleep(60000);
					continue;
				}
				long value = 0;
				long nextValue = 0;
				raf.seek(4 + 8 * currentIndex);
				for (int index = currentIndex; index < size; index += 2) {
					value = raf.readLong();
					nextValue = raf.readLong();
					EPSServiceController.getInstance().log("RR value:" + value);
					EPSServiceController.getInstance().log(
							"RR nextvalue:" + nextValue);
					// if (nextValue > 1 && nextValue > value + 1) {
					// need to retranmission
					long startSequence = value;
					long endSequence = nextValue;
					int retransNumber = (int) (endSequence - startSequence)
							/ MAX_RETRANS_PACKET;
					int lastTime = (int) (endSequence - startSequence)
							% MAX_RETRANS_PACKET;
					long index1 = 0, index2 = 0;
					RetransmissionRequest_RQ requestRetrans = null;
					// start = end
					if (retransNumber == 0) {
						requestRetrans = new RetransmissionRequest_RQ();
						requestRetrans
								.setFirm(EPSServiceController.FIRM_CONSTANT);
						requestRetrans.setMarketID(new String(
								EPSServiceController._marketId));
						requestRetrans
								.setRetransmissionStartSequence(startSequence);
						requestRetrans
								.setRetransmissionEndSequence(endSequence);
						try {
							EPSServiceController.getInstance()
									.sendMessageToQueue(requestRetrans);
						} catch (Exception e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}

					} else {
						for (int i = 0; i < retransNumber; i++) {
							index1 += startSequence + i * MAX_RETRANS_PACKET;
							index2 = index1 + MAX_RETRANS_PACKET - 1;
							requestRetrans = new RetransmissionRequest_RQ();
							requestRetrans
									.setFirm(EPSServiceController.FIRM_CONSTANT);
							requestRetrans.setMarketID(new String(
									EPSServiceController._marketId));
							requestRetrans
									.setRetransmissionStartSequence(index1);
							requestRetrans.setRetransmissionEndSequence(index2);
							try {
								EPSServiceController.getInstance()
										.sendMessageToQueue(requestRetrans);
							} catch (Exception e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
						}
						if (lastTime > 0) {
							index1 = retransNumber * MAX_RETRANS_PACKET;
							index2 = endSequence;
							requestRetrans = new RetransmissionRequest_RQ();
							requestRetrans
									.setFirm(EPSServiceController.FIRM_CONSTANT);
							requestRetrans.setMarketID(new String(
									EPSServiceController._marketId));
							requestRetrans
									.setRetransmissionStartSequence(index1);
							requestRetrans.setRetransmissionEndSequence(index2);
							try {
								EPSServiceController.getInstance()
										.sendMessageToQueue(requestRetrans);
							} catch (Exception e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
						}

					}// end else
					// }// end if
				}// end for
				currentIndex = size;
				raf.seek(0);
				raf.writeInt(currentIndex);
				Thread.sleep(60000);
			} catch (InterruptedException ie) {
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

}

// if (value > 1 && currentIndex==0) {
// long startSequence = 1;
// long endSequence = value - 1;
// int retransNumber = (int) (endSequence - startSequence)
// / MAX_RETRANS_PACKET;
// int lastTime = (int) (endSequence - startSequence)
// % MAX_RETRANS_PACKET;
// long index1 = 0, index2 = 0;
// RetransmissionRequest_RQ requestRetrans = null;
// // start = end
// if (retransNumber == 0) {
// requestRetrans = new RetransmissionRequest_RQ();
// requestRetrans
// .setFirm(EPSServiceController.FIRM_CONSTANT);
// requestRetrans.setMarketID(new String(
// EPSServiceController._marketId));
// requestRetrans
// .setRetransmissionStartSequence(startSequence);
// requestRetrans
// .setRetransmissionEndSequence(endSequence);
// try {
// EPSServiceController.getInstance()
// .sendMessageToQueue(requestRetrans);
// } catch (Exception e) {
// // TODO Auto-generated catch block
// e.printStackTrace();
// }
//
// } else {
// for (int i = 0; i < retransNumber; i++) {
// index1 += startSequence + i * MAX_RETRANS_PACKET;
// index2 = index1 + MAX_RETRANS_PACKET - 1;
// requestRetrans = new RetransmissionRequest_RQ();
// requestRetrans
// .setFirm(EPSServiceController.FIRM_CONSTANT);
// requestRetrans.setMarketID(new String(
// EPSServiceController._marketId));
// requestRetrans
// .setRetransmissionStartSequence(index1);
// requestRetrans.setRetransmissionEndSequence(index2);
// try {
// EPSServiceController.getInstance()
// .sendMessageToQueue(requestRetrans);
// } catch (Exception e) {
// // TODO Auto-generated catch block
// e.printStackTrace();
// }
// }
// if (lastTime > 0) {
// index1 = retransNumber * MAX_RETRANS_PACKET;
// index2 = endSequence;
// requestRetrans = new RetransmissionRequest_RQ();
// requestRetrans
// .setFirm(EPSServiceController.FIRM_CONSTANT);
// requestRetrans.setMarketID(new String(
// EPSServiceController._marketId));
// requestRetrans
// .setRetransmissionStartSequence(index1);
// requestRetrans.setRetransmissionEndSequence(index2);
// try {
// EPSServiceController.getInstance()
// .sendMessageToQueue(requestRetrans);
// } catch (Exception e) {
// // TODO Auto-generated catch block
// e.printStackTrace();
// }
// }
// }
// }
