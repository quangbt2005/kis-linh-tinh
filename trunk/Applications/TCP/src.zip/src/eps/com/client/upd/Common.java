package eps.com.client.upd;

public class Common {
	// ENCODE MODE96+32
	public static byte[] EnMod96(long i_Result, int i_Loop) {
		byte[] bi_Result = new byte[i_Loop];
		char a;
		while (i_Loop > 0) {
			a = (char) ((i_Result % 96) + 32);
			bi_Result[i_Loop - 1] = (byte) a;
			i_Result = i_Result / 96;
			i_Loop--;
		}
		return bi_Result;
	}

	// DECODE MODE96+32
	public static long DecodeMod96(byte[] bi_Data) {
		int i_Loop = 0;
		long i_Result = 0;
		do {
			i_Result = (i_Result << 5) + (i_Result << 6);
			i_Result += (int) (char) bi_Data[i_Loop] - 32;
			i_Loop++;
		} while (i_Loop < bi_Data.length);
		return i_Result;
	}

	// Compare 2 first bytes of 2 arrays
	public static boolean compare2byteArray(byte[] a, byte[] b) {
		if (a.length != b.length)
			return false;
		for (int i = 0; i < a.length; i++) {
			if (a[i] != b[i])
				return false;
		}
		return true;
	}
}
