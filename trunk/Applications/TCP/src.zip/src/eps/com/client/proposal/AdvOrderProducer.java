package eps.com.client.proposal;

import javax.xml.rpc.ServiceException;

import classDirectlyOrderTransfer.ClassDirectlyOrderTransferPort;
import classDirectlyOrderTransfer.ClassDirectlyOrderTransferService;
import classDirectlyOrderTransfer.ClassDirectlyOrderTransferServiceLocator;
import classDirectlyOrderTransfer.GetListAdOrdersResult;
import classDirectlyOrderTransfer.GetListAdOrdersStruct;
import classDirectlyOrderTransfer.GetListTransferingOrdersResult;
import classDirectlyOrderTransfer.GetListTransferingOrdersStruct;
import eps.com.common.HosePacket;
import eps.com.common.HoseSystemPacket;
import eps.com.common.Opcode;
import eps.com.message.received.Admin_3A;
import eps.com.message.received.TCPMessageService;
import eps.com.message.sended.Advertisement_1E;
import eps.com.message.sended.DealCancelReply_3D;
import eps.com.message.sended.DealPutThroughCancelRequest_3C;
import eps.com.message.sended.NewConditioned_1I;
import eps.com.message.sended.OneFirmPutThroughDeal_1F;
import eps.com.message.sended.OrderCancellation_1C;
import eps.com.message.sended.OrderChange_1D;
import eps.com.message.sended.PutThroughDealReply_3B;
import eps.com.message.sended.TwoFirmPutThroughDeal_1G;
import eps.com.test.TestCommon;

public class AdvOrderProducer extends Thread {
	// co nay duoc set khi nhan duoc SC Message co P from UDP module
	private boolean scFlagP = true;
	private MessageQueue queue;
	private WindowBuffer buffer;
	HoseSystemPacket packet;

	ClassDirectlyOrderTransferService svc = new ClassDirectlyOrderTransferServiceLocator();
	ClassDirectlyOrderTransferPort getclassDirectlyOrderTransferPort;
	private static String today = "";
	static {
		today = TestCommon.getStandardDate();
	}

	public AdvOrderProducer(MessageQueue queue) {
		this.queue = queue;
		try {
			getclassDirectlyOrderTransferPort = svc
					.getclassDirectlyOrderTransferPort();
		} catch (ServiceException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public AdvOrderProducer(MessageQueue queue, WindowBuffer buffer) {
		this.queue = queue;
		this.buffer = buffer;
		try {
			getclassDirectlyOrderTransferPort = svc
					.getclassDirectlyOrderTransferPort();
		} catch (ServiceException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void setStart(boolean bool) {
		scFlagP = bool;
	}

	@Override
	public void run() {
		// System.out.println("Trong EchoPacketProducer");
		while (scFlagP) {
			try {
				if (buffer.getWindowBufferSize() == WindowBuffer.WINDOW_SIZE)
					continue;
				GetListAdOrdersResult listAdOrder = getclassDirectlyOrderTransferPort
						.getListAdOrders(today, TCPMessageService.authenUser,
								TCPMessageService.authenPass);
				// System.out.println("Error code : "
				// + listTransferingOrders.getError_code());
				GetListAdOrdersStruct[] items = listAdOrder.getItems();
				if (items != null) {
					// NewConditioned_1I order = null;
					Advertisement_1E order1E = null;
					OneFirmPutThroughDeal_1F order1F = null;
					TwoFirmPutThroughDeal_1G order1G = null;
					;
					Admin_3A admin3A = null;
					PutThroughDealReply_3B order3B = null;
					DealPutThroughCancelRequest_3C order3C = null;
					DealCancelReply_3D order3D = null;

					for (int i = 0; i < items.length; i++) {
						if (items[i].getMessageType().equalsIgnoreCase("1E")) {
							order1E = new Advertisement_1E();
							order1E.setFirm(items[i].getFirm());
							order1E.setTraderID(items[i].getTraderID());
							order1E.setSecuritySymbol(items[i]
									.getSecuritySymbol());
							order1E.setSide(items[i].getSide());
							order1E.setVolume(items[i].getVolume());
							order1E.setPrice(items[i].getPrice());
							order1E.setBoard(items[i].getBoard());
							order1E.setTime(items[i].getTime());
							order1E.setAddCancelFlag(items[i]
									.getAddCancelFlag());
							order1E.setContact(items[i].getContact());
							queue.putMessage(order1E);
						} else if (items[i].getMessageType().equalsIgnoreCase(
								"1F")) {
							order1F = new OneFirmPutThroughDeal_1F();
							order1F.setFirm(items[i].getFirm());
							order1F.setTraderID(items[i].getTraderID());
							order1F.setClientIDBuyer(items[i]
									.getClientIDBuyer());
							order1F.setClientIDSeller(items[i]
									.getClientIDSeller());
							order1F.setSecuritySymbol(items[i]
									.getSecuritySymbol());
							order1F.setPrice(items[i].getPrice());
							order1F.setBoard(items[i].getBoard());
							order1F.setDealID(items[i].getDealID());
							order1F.setFiller(items[i].getFiller());
							order1F.setBrokerPortfolioVolumeBuyer(items[i]
									.getBrokerPortfolioVolumeBuyer());
							order1F.setBrokerClientVolumeBuyer(items[i]
									.getBrokerClientVolumeBuyer());
							order1F.setMutualFundVolumeBuyer(items[i]
									.getMutualFundVolumeBuyer());
							order1F.setBrokerForeignVolumeBuyer(items[i]
									.getBrokerForeignVolumeBuyer());
							order1F.setFiller2(items[i].getFiller2());
							order1F.setBrokerPortfolioVolumeSeller(items[i]
									.getBrokerPortfolioVolumeSeller());
							order1F.setBrokerClientVolumeSeller(items[i]
									.getBrokerClientVolumeSeller());
							order1F.setMutualFundVolumeSeller(items[i]
									.getMutualFundVolumeSeller());
							order1F.setBrokerForeignVolumeSeller(items[i]
									.getBrokerForeignVolumeSeller());
							order1F.setFiller3(items[i].getFiller3());
							queue.putMessage(order1F);
						} else if (items[i].getMessageType().equalsIgnoreCase(
								"1G")) {
							order1G = new TwoFirmPutThroughDeal_1G();
							order1G.setFirmSeller(items[i].getFirmSeller());
							order1G.setTraderIDSeller(items[i]
									.getTraderIDSeller());
							order1G.setClientIDSeller(items[i]
									.getClientIDSeller());
							order1G.setContraFirmBuyer(items[i]
									.getContraFirmBuyer());
							order1G.setTraderIDBuyer(items[i]
									.getTraderIDBuyer());
							order1G.setSecuritySymbol(items[i]
									.getSecuritySymbol());
							order1G.setPrice(items[i].getPrice());
							order1G.setBoard(items[i].getBoard());
							order1G.setDealID(items[i].getDealID());
							order1G.setFiller(items[i].getFiller());
							order1G.setBrokerPortfolioVolumeSeller(items[i]
									.getBrokerPortfolioVolumeSeller());
							order1G.setBrokerClientVolumeSeller(items[i]
									.getBrokerClientVolumeSeller());
							order1G.setMutualFundVolumeSeller(items[i]
									.getMutualFundVolumeSeller());
							order1G.setBrokerForeignVolumeSeller(items[i]
									.getBrokerForeignVolumeSeller());
							order1G.setFiller2(items[i].getFiller2());
							queue.putMessage(order1G);
						} else if (items[i].getMessageType().equalsIgnoreCase(
								"3A")) {
							admin3A = new Admin_3A();
							admin3A.setFirm(items[i].getFirm());
							admin3A.setTraderIDSender(items[i]
									.getTraderIDSender());
							admin3A.setTraderIDReciever(items[i]
									.getTraderIDReciever());
							admin3A.setContraFirm(items[i].getContraFirm());
							admin3A.setAdminMessageText(items[i]
									.getAdminMessageText());
							queue.putMessage(admin3A);
						} else if (items[i].getMessageType().equalsIgnoreCase(
								"3B")) {
							order3B = new PutThroughDealReply_3B();
							order3B.setFirm(items[i].getFirm());
							order3B.setConfirmNumber(items[i]
									.getConfirmNumber());
							order3B.setDealID(items[i].getDealID());
							order3B.setClientIDBuyer(items[i]
									.getClientIDBuyer());
							order3B.setReplyCode(items[i].getReplyCode());
							order3B.setFiller(items[i].getFiller());
							order3B.setBrokerPortfolioVolume(items[i]
									.getBrokerPortfolioVolume());
							order3B.setBrokerClientVolume(items[i]
									.getBrokerClientVolume());
							order3B.setBrokerMutualFundVolume(items[i]
									.getBrokerMutualFundVolume());
							order3B.setBrokerForeignVolume(items[i]
									.getBrokerForeignVolume());
							order3B.setFiller2(items[i].getFiller2());
							queue.putMessage(order3B);
						} else if (items[i].getMessageType().equalsIgnoreCase(
								"3C")) {
							order3C = new DealPutThroughCancelRequest_3C();
							order3C.setFirm(items[i].getFirm());
							order3C.setContraFirm(items[i].getContraFirm());
							order3C.setTraderID(items[i].getTraderID());
							order3C.setConfirmNumber(items[i]
									.getConfirmNumber());
							order3C.setSecuritySymbol(items[i]
									.getSecuritySymbol());
							order3C.setSide(items[i].getSide());
							queue.putMessage(order3C);
						} else if (items[i].getMessageType().equalsIgnoreCase(
								"3D")) {
							order3D = new DealCancelReply_3D();
							order3D.setFirm(items[i].getFirm());
							order3D.setConfirmNumber(items[i]
									.getConfirmNumber());
							order3D.setReplyCode(items[i].getReplyCode());
							queue.putMessage(order3D);
						}
					}
				}
				Thread.sleep(10000);
			} catch (InterruptedException ie) {
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

	}

}
