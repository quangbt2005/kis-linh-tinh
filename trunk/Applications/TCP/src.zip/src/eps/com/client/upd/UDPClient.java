package eps.com.client.upd;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.sql.Timestamp;
import java.util.List;

import eps.com.client.proposal.ReceiveMessageQueue;
import eps.com.common.ValueObject;
import eps.com.message.broadcast.*;
import eps.com.message.sended.NewConditioned_1I;
import eps.com.util.MessageUtil;

//Tuan modify : don't change
public class UDPClient extends Thread{
	// Default port

	private DatagramSocket ds;
	private DatagramPacket p;
	private byte[] b = new byte[1024];
	private boolean stop = false;
	public static int SERVER_PORT = 30000;
	//public static final int SERVER_PORT = 33333;
	UDPContent UDP = null ;
	private ReceiveUDPMessageQueue receiveQueue= new ReceiveUDPMessageQueue();
	long messageCount = 0;

	UPDReceivePacketConsumer threadupdReceiver[]=null; 
	private static int numberThreads = 10;
	public UDPClient(int port) throws Exception {
		this.SERVER_PORT= port;
		ds = new DatagramSocket(SERVER_PORT);
		p = new DatagramPacket(b, b.length);
		UDP = new UDPContent(this.receiveQueue);
		UDP.createNewSequenceFile();
		threadupdReceiver = new UPDReceivePacketConsumer[numberThreads];
		for(int i=0; i < numberThreads; i++){
			threadupdReceiver[i]= new UPDReceivePacketConsumer(this.receiveQueue);
			threadupdReceiver[i].start();
		}
	}

	@Override
	protected void finalize() throws Throwable {
		// TODO Auto-generated method stub
		ds.disconnect();
		ds =null;
		super.finalize();
	}

	/**
	 * @param args
	 */
	
	public UDPClient() throws Exception {
		ds = new DatagramSocket(SERVER_PORT);
		p = new DatagramPacket(b, b.length);
		UDP = new UDPContent(this.receiveQueue);
		UDP.createNewSequenceFile();
		threadupdReceiver = new UPDReceivePacketConsumer[numberThreads];
		for(int i=0; i < numberThreads; i++){
			threadupdReceiver[i]= new UPDReceivePacketConsumer(this.receiveQueue);
			threadupdReceiver[i].start();
		}
	}

	public boolean isStop() {
		return stop;
	}

	public void setStop(boolean stop) {
		this.stop = stop;
	}
	@Override
	public void run() {
		while (!stop) {
			// Waiting for a datagram packet from client
			try {
				ds.receive(p);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			// Accept package
			byte[] arg = new byte[p.getLength()];
			System.arraycopy(p.getData(), 0, arg, 0, p.getLength());
			List<byte[]> messages = UDP.parseData(arg);
			if (messages == null){
				System.out.println("Can not parse message");
				//return;
			}else{
				long messageCount = UDP.getMessageCount();
				UDP.processMessage(messages, messageCount);
			}
		}
	}

	public static void main(String arg[]) throws Exception {
		UDPClient udpClient = new UDPClient();
		udpClient.start();
	}

	public static int getSERVER_PORT() {
		return SERVER_PORT;
	}

	public static void setSERVER_PORT(int server_port) {
		SERVER_PORT = server_port;
	}

}
