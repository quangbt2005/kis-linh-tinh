package eps.com.client.upd;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.ArrayList;
import java.util.List;

import eps.com.message.broadcast.BrokerReconcile_BR;
import eps.com.message.broadcast.BrokerStatusChange_BS;
import eps.com.message.broadcast.CancelOddLot_CO;
import eps.com.message.broadcast.DealCancellationNotice_DC;
import eps.com.message.broadcast.ForeignRoom_TR;
import eps.com.message.broadcast.GeneralAdmin_GA;
import eps.com.message.broadcast.IndexUpdate_IU;
import eps.com.message.broadcast.LastOddLot_LO;
import eps.com.message.broadcast.LastSale_LS;
import eps.com.message.broadcast.MarketOpenLastSale_OS;
import eps.com.message.broadcast.NewHeadLine_NH;
import eps.com.message.broadcast.NewOddLot_OL;
import eps.com.message.broadcast.NewsStory_NS;
import eps.com.message.broadcast.ProjectedOpen_PO;
import eps.com.message.broadcast.PutThroughDealNotice_PD;
import eps.com.message.broadcast.SectoralIndices_SI;
import eps.com.message.broadcast.SecurityReconcile_SR;
import eps.com.message.broadcast.SecurityStatusChange_SS;
import eps.com.message.broadcast.SecurityUpdate_SU;
import eps.com.message.broadcast.SystemControl_SC;
import eps.com.message.broadcast.TimeStamp_TS;
import eps.com.message.broadcast.TopPrices_TP;
import eps.com.message.broadcast.TraderStatusChange_TC;

public class UDPServer {
	 InetAddress destAddr = null;
	 int destPort = 30000;               // Destination port
     DatagramSocket sock = null;
 	
     public static  int SEQUENCE_NUMBER = 0;
     public static  int MESSAGECOUNT = 0;
      
	 public UDPServer() throws Exception{
		 destAddr = InetAddress.getByName("localhost");  // Destination address
	     sock = new DatagramSocket(); // UDP socket for sending
	 }
	 
	public void testSendTopPrice() throws Exception{
		
		SEQUENCE_NUMBER +=1;
		
		String marketID="A";
		long messageCount =1;
		TopPrices_TP tp = new TopPrices_TP();
		tp.setSecurity_Number(914);
		tp.setSide("S");
		tp.setPrice_1_best(253);
		tp.setLot_Volume_1(1231);	
		tp.setPrice_2_2nd_best(12536);
		tp.setLot_Volume_2(9212);
		tp.setPrice_3_3rd_best(1235423);
		tp.setLot_Volume_3(23225);
		
		
		System.out.println(tp.toString());
		
		UDPContent content = new UDPContent(SEQUENCE_NUMBER, marketID, messageCount, tp);
		byte udpContent[] = content.getUDPMessage();
		
		DatagramPacket message = new DatagramPacket(udpContent, udpContent.length,  destAddr, destPort);
		sock.send(message);
	}
	
	//BrokerReconcile
	public List getListBrokerReconcile_BR()
	{
		
		List objects = new ArrayList();
		
		BrokerReconcile_BR BR = new BrokerReconcile_BR();
		BR.setFirm(123);
		BR.setMarketID("A");
		BR.setVolumeSold("1234567890");
		BR.setValueSold("12345678901234");
		BR.setVolumeBought("1234567890");
		BR.setValueBought("12345678901234");
		
		
		objects.add(BR);
		
		
		BrokerReconcile_BR BR1 = new BrokerReconcile_BR();
		BR1.setFirm(123);
		BR1.setMarketID("A");
		BR1.setVolumeSold("1234567890");
		BR1.setValueSold("1234567890123 ");
		BR1.setVolumeBought("1234567890");
		BR1.setValueBought("12345678901234");
		
		objects.add(BR1);
		
		return objects  ;
	
	}
	
	public void testSendBrokerReconcileBR() throws Exception
	{
		
		SEQUENCE_NUMBER +=1;
		String marketID="A";
		MESSAGECOUNT = 1 ; 
		
		List objects = getListBrokerReconcile_BR();
	
		BrokerReconcile_BR BR = (BrokerReconcile_BR)objects.get(0);

		UDPContent content = new UDPContent(SEQUENCE_NUMBER, marketID, MESSAGECOUNT, BR);
		byte udpContent[] = content.getUDPMessage();
		
		DatagramPacket message = new DatagramPacket(udpContent, udpContent.length,  destAddr, destPort);
		sock.send(message);
	}
	
	public void testSendBrokerReconcile() throws Exception
	{
		
		SEQUENCE_NUMBER +=1;
		String marketID="A";
		MESSAGECOUNT = 1 ; 
		
		List objects = getListBrokerReconcile_BR();
	
		BrokerReconcile_BR BR = (BrokerReconcile_BR)objects.get(0);

		UDPContent content = new UDPContent(SEQUENCE_NUMBER, marketID, MESSAGECOUNT, BR);
		byte udpContent[] = content.getUDPMessage();
		
		DatagramPacket message = new DatagramPacket(udpContent, udpContent.length,  destAddr, destPort);
		sock.send(message);
	}
	
	public void testSendBrokerReconcileBRwithOther() throws Exception
	{
		
		SEQUENCE_NUMBER +=1;
		String marketID="A";
		MESSAGECOUNT = 2 ; 
		
		List objects = new ArrayList();
		
		List listBR = getListBrokerReconcile_BR();
		List listSI = getSectoralIndices_SI();
		
		SectoralIndices_SI si = (SectoralIndices_SI)listSI.get(0);
		BrokerReconcile_BR BR = (BrokerReconcile_BR)listBR.get(0);
		
		objects.add(BR);
		System.out.println(BR.toString());
		objects.add(si);
		System.out.println(si.toString());
		
		UDPContent content = new UDPContent(SEQUENCE_NUMBER, marketID, MESSAGECOUNT, objects);
		byte udpContent[] = content.getUDPMessage();
		
		DatagramPacket message = new DatagramPacket(udpContent, udpContent.length,  destAddr, destPort);
		sock.send(message);

	}
		
	// CancelOddLot_CO
	public List getListCancelOddLot_CO()
	{
		List objects = new ArrayList();
		
		CancelOddLot_CO co = new CancelOddLot_CO();
		co.setReferenceNumber(2000);
		
		objects.add(co);
		
		CancelOddLot_CO co1 = new CancelOddLot_CO();
		co1.setReferenceNumber(2000);
		objects.add(co1);
		
		return objects ;
		
		
	}
	public void testSendCancelOddLot_CO() throws Exception
	{
		
		SEQUENCE_NUMBER +=1;
		String marketID="A";
		MESSAGECOUNT = 1 ; 
		
		List objects = getListCancelOddLot_CO();

		CancelOddLot_CO co = (CancelOddLot_CO)objects.get(0);

		UDPContent content = new UDPContent(SEQUENCE_NUMBER, marketID, MESSAGECOUNT, co);
		byte udpContent[] = content.getUDPMessage();
		
		DatagramPacket message = new DatagramPacket(udpContent, udpContent.length,  destAddr, destPort);
		sock.send(message);
	}
	
	
	public void testSendCancelOddLot_COwithOther() throws Exception
	{
		
		SEQUENCE_NUMBER +=1;
		String marketID="A";
		MESSAGECOUNT = 2 ; 
		
		List objects = new ArrayList();
		
		List listCO = getListCancelOddLot_CO();
		List listSI = getSectoralIndices_SI();
		
		SectoralIndices_SI si = (SectoralIndices_SI)listSI.get(0);
		CancelOddLot_CO co = (CancelOddLot_CO)listCO.get(0);
		
		objects.add(co);
		System.out.println(co);
		objects.add(si);
		System.out.println(si.toString());
		
		UDPContent content = new UDPContent(SEQUENCE_NUMBER, marketID, MESSAGECOUNT, objects);
		byte udpContent[] = content.getUDPMessage();
		
		DatagramPacket message = new DatagramPacket(udpContent, udpContent.length,  destAddr, destPort);
		sock.send(message);

	}
	
	// IndexUpdate_IU
	public List getListIndexUpdate_IU()
	{
		List objects = new ArrayList();
		
		IndexUpdate_IU iu = new IndexUpdate_IU();
		
		iu.setIndexHoSE(94);
		iu.setTotalTrades(856325);
		iu.setTotalSharesTraded(444);
		iu.setTotalValuesTraded(815372);
		iu.setUpVolume(8000);
		iu.setDownVolume(7000);
		iu.setNoChangeVolume(815372697);
		iu.setAdvances(9213);
		iu.setDeclines(9000);
		iu.setNoChange(7000);
		iu.setFiller1("    ");
		iu.setMarketID("A");
		String temp = "" ;
		for (int i = 0; i < 7; i++) {
			temp+=" ";
		}
		iu.setFiller2(temp);
		iu.setIndexTime(5686);
		objects.add(iu);
		
		IndexUpdate_IU iu1 = new IndexUpdate_IU();
		
		iu1.setIndexHoSE(94);
		iu1.setTotalTrades(856325);
		iu1.setTotalSharesTraded(444);
		iu1.setTotalValuesTraded(815372);
		iu1.setUpVolume(8000);
		iu1.setDownVolume(7000);
		iu1.setNoChangeVolume(815372697);
		iu1.setAdvances(9213);
		iu1.setDeclines(9000);
		iu1.setNoChange(7000);
		iu1.setFiller1("    ");
		iu1.setMarketID("A");
		temp = "" ;
		for (int i = 0; i < 7; i++) {
			temp+=" ";
		}
		iu1.setFiller2(temp);
		iu1.setIndexTime(5686);
		objects.add(iu1);
		
		return objects ;
		
		
	}

	//ForeignRoom_TR
	public List getListForeignRoom_TR()
	{
		List objects = new ArrayList();
		
		ForeignRoom_TR tr = new ForeignRoom_TR();
		tr.setSecurity_Number(9212);
		tr.setTotal_Room(2532);
		tr.setCurrent_Room(255365);//255365
		
		objects.add(tr);
		
		ForeignRoom_TR tr1 = new ForeignRoom_TR();
		tr1.setSecurity_Number(9212);
		tr1.setTotal_Room(2532);
		tr1.setCurrent_Room(255365);//255365
		objects.add(tr1);
		
		return objects ;
	}
	
	public void testSendForeignRoom_TR() throws Exception
	{
		
		SEQUENCE_NUMBER +=1;
		String marketID="A";
		MESSAGECOUNT = 1 ; 
		
		List objects = getListForeignRoom_TR();

		ForeignRoom_TR tr = (ForeignRoom_TR)objects.get(0);

		UDPContent content = new UDPContent(SEQUENCE_NUMBER, marketID, MESSAGECOUNT, tr);
		byte udpContent[] = content.getUDPMessage();
		
		DatagramPacket message = new DatagramPacket(udpContent, udpContent.length,  destAddr, destPort);
		sock.send(message);
	}
	
	public void testSendForeignRoom_TRwithOther() throws Exception
	{
		
		SEQUENCE_NUMBER +=1;
		String marketID="A";
		MESSAGECOUNT = 2 ; 
		
		List objects = new ArrayList();
		
		List listTR = getListForeignRoom_TR();
		List listSI = getSectoralIndices_SI();
		
		SectoralIndices_SI si = (SectoralIndices_SI)listSI.get(0);
		ForeignRoom_TR tr = (ForeignRoom_TR)listTR.get(0);
		
		objects.add(tr);
		System.out.println(tr.toString());
		objects.add(si);
		System.out.println(si.toString());
		
		UDPContent content = new UDPContent(SEQUENCE_NUMBER, marketID, MESSAGECOUNT, objects);
		byte udpContent[] = content.getUDPMessage();
		
		DatagramPacket message = new DatagramPacket(udpContent, udpContent.length,  destAddr, destPort);
		sock.send(message);

	}
	// DealCancellationNotice_DC
	public List getListDealCancellationNotice_DC()
	{
		List objects = new ArrayList();
		
		DealCancellationNotice_DC dc = new DealCancellationNotice_DC();
		dc.setConfirmNumber(80000);
		dc.setSecurityNumber(2000);
		dc.setVolume(8493465);
		dc.setPrice(849346);
		dc.setBoard("B");
		objects.add(dc);
		
		
		DealCancellationNotice_DC dc1 = new DealCancellationNotice_DC();
		dc1.setConfirmNumber(80000);
		dc1.setSecurityNumber(2000);
		dc1.setVolume(8493465);
		dc1.setPrice(849346);
		dc1.setBoard("B");
		objects.add(dc1);
		
		return objects ;
				
	}
	
	public void testSendDealCancellationNotice_DC() throws Exception
	{
		
		SEQUENCE_NUMBER +=1;
		String marketID="A";
		MESSAGECOUNT = 1 ; 
		
		List objects = getListDealCancellationNotice_DC();

		DealCancellationNotice_DC dc = (DealCancellationNotice_DC)objects.get(0);

		UDPContent content = new UDPContent(SEQUENCE_NUMBER, marketID, MESSAGECOUNT, dc);
		byte udpContent[] = content.getUDPMessage();
		
		DatagramPacket message = new DatagramPacket(udpContent, udpContent.length,  destAddr, destPort);
		sock.send(message);
	}

	public void testSendDealCancellationNotice_DCwithOther() throws Exception
	{
		
		SEQUENCE_NUMBER +=1;
		String marketID="A";
		MESSAGECOUNT = 2 ; 
		
		List objects = new ArrayList();
		
		List listBR = getListDealCancellationNotice_DC();
		List listSI = getSectoralIndices_SI();
		
		SectoralIndices_SI si = (SectoralIndices_SI)listSI.get(0);
		DealCancellationNotice_DC dc = (DealCancellationNotice_DC)listBR.get(0);
		
		objects.add(dc);
		System.out.println(dc.toString());
		objects.add(si);
		System.out.println(si.toString());
		
		UDPContent content = new UDPContent(SEQUENCE_NUMBER, marketID, MESSAGECOUNT, objects);
		byte udpContent[] = content.getUDPMessage();
		
		DatagramPacket message = new DatagramPacket(udpContent, udpContent.length,  destAddr, destPort);
		sock.send(message);

	}
	
	// BrokerStatusChanges_BS
	public List getBrokerStatusChanges_BS()
	{
	
		List objects = new ArrayList();
		
		BrokerStatusChange_BS BS = new BrokerStatusChange_BS();
		BS.setFirm(123);
		BS.setAutoMatchHaltFlag("H");
		BS.setPutthroughHaltFlag("R");
		objects.add(BS);
		
		BrokerStatusChange_BS BS1 = new BrokerStatusChange_BS();
		BS1.setFirm(123);
		BS1.setAutoMatchHaltFlag("H");
		BS1.setPutthroughHaltFlag("R");
		objects.add(BS1);
		
		return objects ;
	
	}
	
	public void testSendBrokerStatusChange_BS() throws Exception
	{
		
		SEQUENCE_NUMBER +=1;
		String marketID="A";
		MESSAGECOUNT = 1 ; 
		
		List objects = getBrokerStatusChanges_BS();

		BrokerStatusChange_BS bs = (BrokerStatusChange_BS)objects.get(0);

		UDPContent content = new UDPContent(SEQUENCE_NUMBER, marketID, MESSAGECOUNT, bs);
		byte udpContent[] = content.getUDPMessage();
		
		DatagramPacket message = new DatagramPacket(udpContent, udpContent.length,  destAddr, destPort);
		sock.send(message);
	}
	
	public void testSendBrokerStatusChange_BSwithOther() throws Exception
	{
		
		SEQUENCE_NUMBER +=1;
		String marketID="A";
		MESSAGECOUNT = 2 ; 
		
		List objects = new ArrayList();
		
		List listBS = getBrokerStatusChanges_BS();
		List listSI = getSectoralIndices_SI();
		
		SectoralIndices_SI si = (SectoralIndices_SI)listSI.get(0);
		BrokerStatusChange_BS bs = (BrokerStatusChange_BS)listBS.get(0);
		
		objects.add(bs);
		System.out.println(bs.toString());
		objects.add(si);
		System.out.println(si.toString());
		
		UDPContent content = new UDPContent(SEQUENCE_NUMBER, marketID, MESSAGECOUNT, objects);
		byte udpContent[] = content.getUDPMessage();
		
		DatagramPacket message = new DatagramPacket(udpContent, udpContent.length,  destAddr, destPort);
		sock.send(message);

	}
	
	// MarketOpenLastSale_OS
	public List getListMarketOpenLastSale_OS()
	{
		
		List objects = new ArrayList();
		
		MarketOpenLastSale_OS os = new MarketOpenLastSale_OS() ;
		os.setSecurity_Number(2563);
		os.setPrice(5826522);
		objects.add(os);
		
		
		MarketOpenLastSale_OS os1 = new MarketOpenLastSale_OS() ;
		os1.setSecurity_Number(2563);
		os1.setPrice(5826522);
		objects.add(os1);
		
		return objects ;
	}
	public void testSendMarketOpenLastSale_OS() throws Exception
	{
		
		SEQUENCE_NUMBER +=1;
		String marketID="A";
		MESSAGECOUNT = 1 ; 
		
		List objects = getListMarketOpenLastSale_OS();

		MarketOpenLastSale_OS os = (MarketOpenLastSale_OS)objects.get(0);

		UDPContent content = new UDPContent(SEQUENCE_NUMBER, marketID, MESSAGECOUNT, os);
		byte udpContent[] = content.getUDPMessage();
		
		DatagramPacket message = new DatagramPacket(udpContent, udpContent.length,  destAddr, destPort);
		sock.send(message);
		
	}
	
	public void testSendMarketOpenLastSale_OSwithOther() throws Exception
	{
		
		SEQUENCE_NUMBER +=1;
		String marketID="A";
		MESSAGECOUNT = 2 ; 
		
		List objects = new ArrayList();
		
		List listOS = getListMarketOpenLastSale_OS();
		List listSI = getSectoralIndices_SI();
		
		SectoralIndices_SI si = (SectoralIndices_SI)listSI.get(0);
		MarketOpenLastSale_OS os = (MarketOpenLastSale_OS)listOS.get(0);
		
		objects.add(os);
		System.out.println(os.toString());
		objects.add(si);
		System.out.println(si.toString());
		
		UDPContent content = new UDPContent(SEQUENCE_NUMBER, marketID, MESSAGECOUNT, objects);
		byte udpContent[] = content.getUDPMessage();
		
		DatagramPacket message = new DatagramPacket(udpContent, udpContent.length,  destAddr, destPort);
		sock.send(message);

	}
	
	public List getSectoralIndices_SI()
	{
		List objects = new ArrayList();
		
		SectoralIndices_SI si = new SectoralIndices_SI();
		si.setIndex_Sectoral_1(15236544);
		String temp = "" ;
		for (int i = 0; i <120; i++) {
			temp+= " ";
		}
		si.setFiller(temp);
		si.setIndex_Time(12531);
		objects.add(si);
		
		SectoralIndices_SI si1 = new SectoralIndices_SI();
		si1.setIndex_Sectoral_1(15236544);
		temp = "" ;
		for (int i = 0; i <120; i++) {
			temp+= " ";
		}
		si1.setFiller(temp);
		si1.setIndex_Time(12531);
		objects.add(si1);
		
		return objects ;
		
	}
	
	// SecurityReconcile_SR
	public List getListSecurityReconcile_SR()
	{
		List objects = new ArrayList();
		
		SecurityReconcile_SR sr = new SecurityReconcile_SR() ;
		sr.setSecurity_Number(2532);
		sr.setMain_or_Foreign_Deal(533322);
		sr.setMain_or_Foreign_Acc_Volume(81537); // lon hon kieu so long la ?
		sr.setMain_or_Foreign_Acc_Value(1548222);
		sr.setDeals_in_Big_Lot_Board(2535);
		sr.setBig_Lot_Acc_Volume(253252);
		sr.setBig_Lot_Acc_Value(123453);
		sr.setDeals_in_Big_Lot_Board(9212);
		sr.setOdd_Lot_Acc_Volume(3253);
		sr.setOdd_Lot_Acc_Value(23522);
		objects.add(sr);
		
		SecurityReconcile_SR sr1 = new SecurityReconcile_SR() ;
		sr1.setSecurity_Number(2532);
		sr1.setMain_or_Foreign_Deal(533322);
		sr1.setMain_or_Foreign_Acc_Volume(81537); // lon hon kieu so long la ?
		sr1.setMain_or_Foreign_Acc_Value(1548222);
		sr1.setDeals_in_Big_Lot_Board(2535);
		sr1.setBig_Lot_Acc_Volume(253252);
		sr1.setBig_Lot_Acc_Value(123453);
		sr1.setDeals_in_Big_Lot_Board(9212);
		sr1.setOdd_Lot_Acc_Volume(3253);
		sr1.setOdd_Lot_Acc_Value(23522);
		objects.add(sr1);
		
		return objects ;
	}
	
	public void testSendSecurityReconcile_SR() throws Exception
	{
		
		SEQUENCE_NUMBER +=1;
		String marketID="A";
		MESSAGECOUNT = 1 ; 
		
		List objects = getListSecurityReconcile_SR();

		SecurityReconcile_SR sr = (SecurityReconcile_SR)objects.get(0);

		UDPContent content = new UDPContent(SEQUENCE_NUMBER, marketID, MESSAGECOUNT, sr);
		byte udpContent[] = content.getUDPMessage();
		
		DatagramPacket message = new DatagramPacket(udpContent, udpContent.length,  destAddr, destPort);
		sock.send(message);
	}

	public void testSendSecurityReconcile_SRwithOther() throws Exception
	{
		
		SEQUENCE_NUMBER +=1;
		String marketID="A";
		MESSAGECOUNT = 2 ; 
		
		List objects = new ArrayList();
		
		List listSR = getListSecurityReconcile_SR();
		List listSI = getSectoralIndices_SI();
		
		SectoralIndices_SI si = (SectoralIndices_SI)listSI.get(0);
		SecurityReconcile_SR sr = (SecurityReconcile_SR)listSR.get(0);
		
		objects.add(sr);
		System.out.println(sr.toString());
		objects.add(si);
		System.out.println(si.toString());
		
		UDPContent content = new UDPContent(SEQUENCE_NUMBER, marketID, MESSAGECOUNT, objects);
		byte udpContent[] = content.getUDPMessage();
		
		DatagramPacket message = new DatagramPacket(udpContent, udpContent.length,  destAddr, destPort);
		sock.send(message);

	}
	// SecurityStatusChange_SS
	public List getListSecurityStatusChange_SS()
	{
		List objects = new ArrayList();
		
		SecurityStatusChange_SS ss = new SecurityStatusChange_SS();
		ss.setSecurity_Number(8798) ;
		ss.setSector_Number(95);
		ss.setHaltorResume_Flag("H");
		ss.setSystem_Control_Code("C");
		ss.setSuspension("S");
		ss.setDelist("D");
		ss.setCeiling(2536523);
		ss.setFloor_Price(2512535);
		ss.setSecurity_Type("S");
		ss.setPrior_Close_Price(452362);
		ss.setSplit("P");
		ss.setBenefit("B");
		ss.setMeeting("M");
		ss.setNotice("N");
		ss.setBoard_Lot(8777);
		ss.setFiller1(" ");
		ss.setFiller2(" ");
		ss.setFiller3(" ");
		ss.setFiller4(" ");
		ss.setFiller5(2536545);
		ss.setFiller6(" ");
		objects.add(ss);
		
		SecurityStatusChange_SS ss1 = new SecurityStatusChange_SS();
		ss1.setSecurity_Number(8798) ;
		ss1.setSector_Number(95);
		ss1.setHaltorResume_Flag("H");
		ss1.setSystem_Control_Code("C");
		ss1.setSuspension("S");
		ss1.setDelist("D");
		ss1.setCeiling(2536523);
		ss1.setFloor_Price(2512535);
		ss1.setSecurity_Type("S");
		ss1.setPrior_Close_Price(452362);
		ss1.setSplit("P");
		ss1.setBenefit("B");
		ss1.setMeeting("M");
		ss1.setNotice("N");
		ss1.setBoard_Lot(8777);
		ss1.setFiller1(" ");
		ss1.setFiller2(" ");
		ss1.setFiller3(" ");
		ss1.setFiller4(" ");
		ss1.setFiller5(2536545);
		ss1.setFiller6(" ");
		objects.add(ss1);
		
		return objects ;
	}
	
	public void testSendSecurityStatusChange_SS() throws Exception
	{
		
		SEQUENCE_NUMBER +=1;
		String marketID="A";
		MESSAGECOUNT = 1 ; 
		
		List objects = getListSecurityStatusChange_SS();

		SecurityStatusChange_SS ss = (SecurityStatusChange_SS)objects.get(0);

		UDPContent content = new UDPContent(SEQUENCE_NUMBER, marketID, MESSAGECOUNT, ss);
		byte udpContent[] = content.getUDPMessage();
		
		DatagramPacket message = new DatagramPacket(udpContent, udpContent.length,  destAddr, destPort);
		sock.send(message);
	}
	
	public void testSendSecurityStatusChange_SSBRwithOther() throws Exception
	{
		
		SEQUENCE_NUMBER +=1;
		String marketID="A";
		MESSAGECOUNT = 2 ; 
		
		List objects = new ArrayList();
		
		List listSS = getListSecurityStatusChange_SS();
		List listSI = getSectoralIndices_SI();
		
		SectoralIndices_SI si = (SectoralIndices_SI)listSI.get(0);
		SecurityStatusChange_SS ss = (SecurityStatusChange_SS)listSS.get(0);
		
		objects.add(ss);
		System.out.println(ss.toString());
		objects.add(si);
		System.out.println(si.toString());
		
		UDPContent content = new UDPContent(SEQUENCE_NUMBER, marketID, MESSAGECOUNT, objects);
		byte udpContent[] = content.getUDPMessage();
		
		DatagramPacket message = new DatagramPacket(udpContent, udpContent.length,  destAddr, destPort);
		sock.send(message);

	}
	// SystemControl_SC
	public List getListSystemControl_SC()
	{
		List objects = new ArrayList();
	
		SystemControl_SC sc = new SystemControl_SC();
		sc.setSystem_Control_Code("C");
		sc.setTimestamp(12535);
		objects.add(sc);
		
		SystemControl_SC sc1 = new SystemControl_SC();
		sc1.setSystem_Control_Code("C");
		sc1.setTimestamp(12535);
		objects.add(sc1);
		
		return objects ;
	}
	public void testSendSystemControl_SC() throws Exception
	{
		
		SEQUENCE_NUMBER +=1;
		String marketID="A";
		MESSAGECOUNT = 1 ; 
		
		List objects = getListSystemControl_SC();

		SystemControl_SC sc = (SystemControl_SC)objects.get(0);

		UDPContent content = new UDPContent(SEQUENCE_NUMBER, marketID, MESSAGECOUNT, sc);
		byte udpContent[] = content.getUDPMessage();
		
		DatagramPacket message = new DatagramPacket(udpContent, udpContent.length,  destAddr, destPort);
		sock.send(message);
	}
	
	public void testSendSystemControl_SCwithOther() throws Exception
	{
		
		SEQUENCE_NUMBER +=1;
		String marketID="A";
		MESSAGECOUNT = 2 ; 
		
		List objects = new ArrayList();
		
		List listSC = getListSystemControl_SC();
		List listSI = getSectoralIndices_SI();
		
		SectoralIndices_SI si = (SectoralIndices_SI)listSI.get(0);
		SystemControl_SC sc = (SystemControl_SC)listSC.get(0);
		
		objects.add(sc);
		System.out.println(sc.toString());
		objects.add(si);
		System.out.println(si.toString());
		
		UDPContent content = new UDPContent(SEQUENCE_NUMBER, marketID, MESSAGECOUNT, objects);
		byte udpContent[] = content.getUDPMessage();
		
		DatagramPacket message = new DatagramPacket(udpContent, udpContent.length,  destAddr, destPort);
		sock.send(message);

	}
	//TimeStamp_TS 
	public List getListTimeStamp_TS()
	{
		List objects = new ArrayList();
		
		TimeStamp_TS ts = new TimeStamp_TS();
		ts.setTimestamp(2532);
		objects.add(ts);
		
		TimeStamp_TS ts1 = new TimeStamp_TS();
		ts1.setTimestamp(2532);
		objects.add(ts1);
		
		return objects ;
		
	}
	public void testSendTimeStamp_TS() throws Exception
	{
		
		SEQUENCE_NUMBER +=1;
		String marketID="A";
		MESSAGECOUNT = 1 ; 
		
		List objects = getListTimeStamp_TS();

		TimeStamp_TS ts = (TimeStamp_TS)objects.get(0);

		UDPContent content = new UDPContent(SEQUENCE_NUMBER, marketID, MESSAGECOUNT, ts);
		byte udpContent[] = content.getUDPMessage();
		
		DatagramPacket message = new DatagramPacket(udpContent, udpContent.length,  destAddr, destPort);
		sock.send(message);
		
	}

	public void testSendTimeStamp_TSwithOther() throws Exception
	{
		
		SEQUENCE_NUMBER +=1;
		String marketID="A";
		MESSAGECOUNT = 2 ; 
		
		List objects = new ArrayList();
		
		List listTS = getListTimeStamp_TS();
		List listSI = getSectoralIndices_SI();
		
		SectoralIndices_SI si = (SectoralIndices_SI)listSI.get(0);
		TimeStamp_TS ts = (TimeStamp_TS)listTS.get(0);
		
		objects.add(ts);
		System.out.println(ts.toString());
		objects.add(si);
		System.out.println(si.toString());
		
		UDPContent content = new UDPContent(SEQUENCE_NUMBER, marketID, MESSAGECOUNT, objects);
		byte udpContent[] = content.getUDPMessage();
		
		DatagramPacket message = new DatagramPacket(udpContent, udpContent.length,  destAddr, destPort);
		sock.send(message);

	}
	
	// NewHeadLine_NH
	public List getListNewHeadLine_NH()
	{
		List objects = new ArrayList();
		
		NewHeadLine_NH nh = new NewHeadLine_NH();
		nh.setL_NewSNumber(9212);
		nh.setS_SecuritySymbol("12345678");
		nh.setL_NewsHeadlineLength(92) ;
		nh.setL_TotalNewsStoryPages(9212);
		nh.setS_NewsHeadlineText("1234567890123456789012345678901234567890123456789012345678901234567890");
		
		objects.add(nh);
		
		NewHeadLine_NH nh1 = new NewHeadLine_NH();
		nh1.setL_NewSNumber(9212);
		nh1.setS_SecuritySymbol("12345678");
		nh1.setL_NewsHeadlineLength(92) ;
		nh1.setL_TotalNewsStoryPages(9212);
		nh1.setS_NewsHeadlineText("1234567890123456789012345678901234567890123456789012345678901234567890");
	
		objects.add(nh1);
		
		return objects ;
	}
	
	public void testSendNewHeadLine_NH() throws Exception
	{
		
		SEQUENCE_NUMBER +=1;
		String marketID="A";
		MESSAGECOUNT = 1 ; 
		
		List objects = getListNewHeadLine_NH();

		NewHeadLine_NH nh = (NewHeadLine_NH)objects.get(0);

		UDPContent content = new UDPContent(SEQUENCE_NUMBER, marketID, MESSAGECOUNT, nh);
		byte udpContent[] = content.getUDPMessage();
		
		DatagramPacket message = new DatagramPacket(udpContent, udpContent.length,  destAddr, destPort);
		sock.send(message);
	}

	public void testSendNewHeadLine_NHwithOther() throws Exception
	{
		
		SEQUENCE_NUMBER +=1;
		String marketID="A";
		MESSAGECOUNT = 2 ; 
		
		List objects = new ArrayList();
		
		List listNH = getListNewHeadLine_NH();
		List listSI = getSectoralIndices_SI();
		
		SectoralIndices_SI si = (SectoralIndices_SI)listSI.get(0);
		NewHeadLine_NH nh = (NewHeadLine_NH)listNH.get(0);
		
		objects.add(nh);
		System.out.println(nh.toString());
		objects.add(si);
		System.out.println(si.toString());
		
		UDPContent content = new UDPContent(SEQUENCE_NUMBER, marketID, MESSAGECOUNT, objects);
		byte udpContent[] = content.getUDPMessage();
		
		DatagramPacket message = new DatagramPacket(udpContent, udpContent.length,  destAddr, destPort);
		sock.send(message);

	}
	
	// NewsStory_NS
	public List getListNewsStory_NS()
	{
		List objects = new ArrayList();
		
		NewsStory_NS ns = new NewsStory_NS();
		ns.setNews_Number(8000);
		ns.setNews_Page_Number(6000);
		ns.setNews_Text_Length(5000);
		
		String text1 = "" ;
		text1 = "aaaa" ;
		for(int i=0;i<215-4;i++)
		{
			text1+=" ";
		}
		ns.setNews_Text(text1);
		objects.add(ns);
		
		NewsStory_NS ns1 = new NewsStory_NS();
		ns1.setNews_Number(8000);
		ns1.setNews_Page_Number(6000);
		ns1.setNews_Text_Length(5000);
		
		text1 = "" ;
		text1 = "aaaa" ;
		for(int i=0;i<215-4;i++)
		{
			text1+=" ";
		}
		
		ns1.setNews_Text(text1);
		objects.add(ns1);
		return objects ;
	}
	public void testSendNewsStory_NS() throws Exception
	{
		
		SEQUENCE_NUMBER +=1;
		String marketID="A";
		MESSAGECOUNT = 1 ; 
		
		List objects = getListNewsStory_NS();

		NewsStory_NS ns = (NewsStory_NS)objects.get(0);

		UDPContent content = new UDPContent(SEQUENCE_NUMBER, marketID, MESSAGECOUNT, ns);
		byte udpContent[] = content.getUDPMessage();
		
		DatagramPacket message = new DatagramPacket(udpContent, udpContent.length,  destAddr, destPort);
		sock.send(message);
	}
	public void testSendNewsStory_NSwithOther() throws Exception
	{
		
		SEQUENCE_NUMBER +=1;
		String marketID="A";
		MESSAGECOUNT = 2 ; 
		
		List objects = new ArrayList();
		
		List listNS = getListNewsStory_NS();
		List listSI = getSectoralIndices_SI();
		
		SectoralIndices_SI si = (SectoralIndices_SI)listSI.get(0);
		NewsStory_NS ns = (NewsStory_NS)listNS.get(0);
		
		objects.add(ns);
		System.out.println(ns.toString());
		objects.add(si);
		System.out.println(si.toString());
		
		UDPContent content = new UDPContent(SEQUENCE_NUMBER, marketID, MESSAGECOUNT, objects);
		byte udpContent[] = content.getUDPMessage();
		
		DatagramPacket message = new DatagramPacket(udpContent, udpContent.length,  destAddr, destPort);
		sock.send(message);

	}
	
	// PutThroughDealNotice_PD
	public List getListPutThroughDealNotice_PD()
	{
		
		List objects = new ArrayList();
	
		PutThroughDealNotice_PD pd = new PutThroughDealNotice_PD();
		pd.setConfirm_Number(582652);
		pd.setSecurity_Number(9212);
		pd.setVolume(6325423);
		pd.setPrice(84934655);
		pd.setBoard("B");
		objects.add(pd);
		
		PutThroughDealNotice_PD pd1 = new PutThroughDealNotice_PD();
		pd1.setConfirm_Number(582652);
		pd1.setSecurity_Number(9212);
		pd1.setVolume(6325423);
		pd1.setPrice(84934655);
		pd1.setBoard("B");
		objects.add(pd1);
		
		
		return objects ;
		
	}
	public void testSendPutThroughDealNotice_PD() throws Exception
	{
		
		SEQUENCE_NUMBER +=1;
		String marketID="A";
		MESSAGECOUNT = 1 ; 
		
		List objects = getListPutThroughDealNotice_PD();

		PutThroughDealNotice_PD PD = (PutThroughDealNotice_PD)objects.get(0);

		UDPContent content = new UDPContent(SEQUENCE_NUMBER, marketID, MESSAGECOUNT, PD);
		byte udpContent[] = content.getUDPMessage();
		
		DatagramPacket message = new DatagramPacket(udpContent, udpContent.length,  destAddr, destPort);
		sock.send(message);
	}
	
	public void testSendPutThroughDealNotice_PDwithOther() throws Exception
	{
		
		SEQUENCE_NUMBER +=1;
		String marketID="A";
		MESSAGECOUNT = 2 ; 
		
		List objects = new ArrayList();
		
		List listBR = getListPutThroughDealNotice_PD();
		List listSI = getSectoralIndices_SI();
		
		SectoralIndices_SI si = (SectoralIndices_SI)listSI.get(0);
		PutThroughDealNotice_PD pd = (PutThroughDealNotice_PD)listBR.get(0);
		
		objects.add(pd);
		System.out.println(pd.toString());
		objects.add(si);
		System.out.println(si.toString());
		
		UDPContent content = new UDPContent(SEQUENCE_NUMBER, marketID, MESSAGECOUNT, objects);
		byte udpContent[] = content.getUDPMessage();
		
		DatagramPacket message = new DatagramPacket(udpContent, udpContent.length,  destAddr, destPort);
		sock.send(message);

	}
	// ProjectedOpen_PO
	public List getListProjectedOpen_PO()
	{
		List objects = new ArrayList();
		
		ProjectedOpen_PO po = new ProjectedOpen_PO();
		po.setSecurity_Number(5825);
		po.setProjected_Open_Price(884735);
		objects.add(po);
		
		ProjectedOpen_PO po1 = new ProjectedOpen_PO();
		po1.setSecurity_Number(5825);
		po1.setProjected_Open_Price(884735);
		objects.add(po1);
		
		return objects ;
	}
	
	public void testSendProjectedOpen_PO() throws Exception
	{
		
		SEQUENCE_NUMBER +=1;
		String marketID="A";
		MESSAGECOUNT = 1 ; 
		
		List objects = getListProjectedOpen_PO();

		ProjectedOpen_PO PO = (ProjectedOpen_PO)objects.get(0);

		UDPContent content = new UDPContent(SEQUENCE_NUMBER, marketID, MESSAGECOUNT, PO);
		byte udpContent[] = content.getUDPMessage();
		
		DatagramPacket message = new DatagramPacket(udpContent, udpContent.length,  destAddr, destPort);
		sock.send(message);
	}
	public void testSendProjectedOpen_POwithOther() throws Exception
	{
		
		SEQUENCE_NUMBER +=1;
		String marketID="A";
		MESSAGECOUNT = 2 ; 
		
		List objects = new ArrayList();
		
		List listPO = getListProjectedOpen_PO();
		List listSI = getSectoralIndices_SI();
		
		SectoralIndices_SI si = (SectoralIndices_SI)listSI.get(0);
		ProjectedOpen_PO po = (ProjectedOpen_PO)listPO.get(0);
		
		objects.add(po);
		System.out.println(po.toString());
		objects.add(si);
		System.out.println(si.toString());
		
		UDPContent content = new UDPContent(SEQUENCE_NUMBER, marketID, MESSAGECOUNT, objects);
		byte udpContent[] = content.getUDPMessage();
		
		DatagramPacket message = new DatagramPacket(udpContent, udpContent.length,  destAddr, destPort);
		sock.send(message);

	}
	// NewOddLot_OL
	public List getListNewOddLot_OL()
	{
		List objects = new ArrayList();
		
		NewOddLot_OL ol = new NewOddLot_OL();
		ol.setSecurity_Number(8000);
		ol.setOdd_Lot_Volume(9212);	
		ol.setPrice(58256522);
		ol.setSide("S");
		ol.setReference_Number(884735);
		objects.add(ol);
		
		NewOddLot_OL ol1 = new NewOddLot_OL();
		ol1.setSecurity_Number(8000);
		ol1.setOdd_Lot_Volume(9212);	
		ol1.setPrice(58256522);
		ol1.setSide("S");
		ol1.setReference_Number(884735);
		objects.add(ol1);
		
		return objects ;
		
	}
	public void testSendNewOddLot_OL() throws Exception
	{
		
		SEQUENCE_NUMBER +=1;
		String marketID="A";
		MESSAGECOUNT = 1 ; 
		
		List objects = getListNewOddLot_OL();

		NewOddLot_OL ol = (NewOddLot_OL)objects.get(0);

		UDPContent content = new UDPContent(SEQUENCE_NUMBER, marketID, MESSAGECOUNT, ol);
		byte udpContent[] = content.getUDPMessage();
		
		DatagramPacket message = new DatagramPacket(udpContent, udpContent.length,  destAddr, destPort);
		sock.send(message);
	}
	public void testSendNewOddLot_OLwithOther() throws Exception
	{
		
		SEQUENCE_NUMBER +=1;
		String marketID="A";
		MESSAGECOUNT = 2 ; 
		
		List objects = new ArrayList();
		
		List listOL = getListNewOddLot_OL();
		List listSI = getSectoralIndices_SI();
		
		SectoralIndices_SI si = (SectoralIndices_SI)listSI.get(0);
		NewOddLot_OL ol = (NewOddLot_OL)listOL.get(0);
		
		objects.add(ol);
		System.out.println(ol.toString());
		objects.add(si);
		System.out.println(si.toString());
		
		UDPContent content = new UDPContent(SEQUENCE_NUMBER, marketID, MESSAGECOUNT, objects);
		byte udpContent[] = content.getUDPMessage();
		
		DatagramPacket message = new DatagramPacket(udpContent, udpContent.length,  destAddr, destPort);
		sock.send(message);
		

	}
	
	// LastSale_LS
	public List getListLastSale_LS()
	{
		List objects = new ArrayList();
		
		LastSale_LS ls = new LastSale_LS();
		ls.setConfirmNumber(67777);
		ls.setSecurityNumber(9212);
		ls.setLotVolume(884735) ;
		ls.setPrice(8493465);
		ls.setSide("S");
		objects.add(ls);
		
		LastSale_LS ls1 = new LastSale_LS();
		ls1.setConfirmNumber(67777);
		ls1.setSecurityNumber(9212);
		ls1.setLotVolume(884735) ;
		ls1.setPrice(8493465);
		ls1.setSide("S");
		objects.add(ls1);
		
		return objects;
	}
	
	public void testSendLastSale_LS() throws Exception
	{
		
		SEQUENCE_NUMBER +=1;
		String marketID="A";
		MESSAGECOUNT = 1 ; 
		
		List objects = getListLastSale_LS();

		LastSale_LS LS = (LastSale_LS)objects.get(0);

		UDPContent content = new UDPContent(SEQUENCE_NUMBER, marketID, MESSAGECOUNT, LS);
		byte udpContent[] = content.getUDPMessage();
		
		DatagramPacket message = new DatagramPacket(udpContent, udpContent.length,  destAddr, destPort);
		sock.send(message);
	}

	public void testSendLastSale_LSwithOther() throws Exception
	{
		
		SEQUENCE_NUMBER +=1;
		String marketID="A";
		MESSAGECOUNT = 2 ; 
		
		List objects = new ArrayList();
		
		List listLS = getListLastSale_LS();
		List listSI = getSectoralIndices_SI();
		
		SectoralIndices_SI si = (SectoralIndices_SI)listSI.get(0);
		LastSale_LS ls = (LastSale_LS)listLS.get(0);
		
		objects.add(ls);
		System.out.println(ls);
		objects.add(si);
		System.out.println(si.toString());
		
		UDPContent content = new UDPContent(SEQUENCE_NUMBER, marketID, MESSAGECOUNT, objects);
		byte udpContent[] = content.getUDPMessage();
		
		DatagramPacket message = new DatagramPacket(udpContent, udpContent.length,  destAddr, destPort);
		sock.send(message);

	}
	// TraderStatusChange_TC
	public List getListTraderStatusChange_TC()
	{
		List objects = new ArrayList();
		
		TraderStatusChange_TC tc = new TraderStatusChange_TC();
		tc.setFirm(2352);
		tc.setTrader_ID(253623);
		tc.setTrader_Status("S");
		objects.add(tc);
		
		TraderStatusChange_TC tc1 = new TraderStatusChange_TC();
		tc1.setFirm(2352);
		tc1.setTrader_ID(253623);
		tc1.setTrader_Status("S");
		objects.add(tc1);
		
		return objects;
	}
	
	public void testSendTraderStatusChange_TC() throws Exception
	{
		
		SEQUENCE_NUMBER +=1;
		String marketID="A";
		MESSAGECOUNT = 1 ; 
		
		List objects = getListTraderStatusChange_TC();

		TraderStatusChange_TC TC = (TraderStatusChange_TC)objects.get(0);

		UDPContent content = new UDPContent(SEQUENCE_NUMBER, marketID, MESSAGECOUNT, TC);
		byte udpContent[] = content.getUDPMessage();
		
		DatagramPacket message = new DatagramPacket(udpContent, udpContent.length,  destAddr, destPort);
		sock.send(message);
	}

	public void testSendTraderStatusChange_TCwithOther() throws Exception
	{
		
		SEQUENCE_NUMBER +=1;
		String marketID="A";
		MESSAGECOUNT = 2 ; 
		
		List objects = new ArrayList();
		
		List listTC = getListTraderStatusChange_TC();
		List listSI = getSectoralIndices_SI();
		
		SectoralIndices_SI si = (SectoralIndices_SI)listSI.get(0);
		TraderStatusChange_TC TC = (TraderStatusChange_TC)listTC.get(0);
		
		objects.add(TC);
		System.out.println(TC.toString());
		objects.add(si);
		System.out.println(si.toString());
		
		UDPContent content = new UDPContent(SEQUENCE_NUMBER, marketID, MESSAGECOUNT, objects);
		byte udpContent[] = content.getUDPMessage();
		
		DatagramPacket message = new DatagramPacket(udpContent, udpContent.length,  destAddr, destPort);
		sock.send(message);

	}
	
	// LastOddLot_LO
	public List getListLastOddLot_LO()
	{
		List objects = new ArrayList();
		
		LastOddLot_LO lo = new LastOddLot_LO();
		lo.setConfirm_Number(884735);
		lo.setSecurity_Number(9215)	;
		lo.setOdd_Lot_Volume(96);
		lo.setPrice(84934655);
		lo.setReference_Number(88473);
		objects.add(lo);
		
		LastOddLot_LO lo1 = new LastOddLot_LO();
		lo1.setConfirm_Number(884735);
		lo1.setSecurity_Number(9215)	;
		lo1.setOdd_Lot_Volume(96);
		lo1.setPrice(84934655);
		lo1.setReference_Number(88473);
		
		objects.add(lo1);
		
		return objects ;
		
	}
	
	public void testSendLastOddLot_LO() throws Exception
	{
		
		SEQUENCE_NUMBER +=1;
		String marketID="A";
		MESSAGECOUNT = 1 ; 
		
		List objects = getListLastOddLot_LO();

		LastOddLot_LO lo = (LastOddLot_LO)objects.get(0);

		UDPContent content = new UDPContent(SEQUENCE_NUMBER, marketID, MESSAGECOUNT, lo);
		byte udpContent[] = content.getUDPMessage();
		
		DatagramPacket message = new DatagramPacket(udpContent, udpContent.length,  destAddr, destPort);
		sock.send(message);
	}
	
	public void testSendLastOddLot_LOwithOther() throws Exception
	{
		
		SEQUENCE_NUMBER +=1;
		String marketID="A";
		MESSAGECOUNT = 2 ; 
		
		List objects = new ArrayList();
		
		List listBR = getListLastOddLot_LO();
		List listSI = getSectoralIndices_SI();
		
		SectoralIndices_SI si = (SectoralIndices_SI)listSI.get(0);
		LastOddLot_LO lo = (LastOddLot_LO)listBR.get(0);
		
		objects.add(lo);
		System.out.println(lo.toString());
		objects.add(si);
		System.out.println(si.toString());
		
		UDPContent content = new UDPContent(SEQUENCE_NUMBER, marketID, MESSAGECOUNT, objects);
		byte udpContent[] = content.getUDPMessage();
		
		DatagramPacket message = new DatagramPacket(udpContent, udpContent.length,  destAddr, destPort);
		sock.send(message);

	}
	
	public void testSendTopPrices () throws Exception{
		//long sequence = 2;
		SEQUENCE_NUMBER +=1;
		String marketID="A";
		long messageCount =1;
		
		List objects = new ArrayList();
		TopPrices_TP tp = new TopPrices_TP();
		tp.setSecurity_Number(914);
		tp.setSide("S");
		tp.setPrice_1_best(253);
		tp.setLot_Volume_1(1231);	
		tp.setPrice_2_2nd_best(12536);
		tp.setLot_Volume_2(9212);
		tp.setPrice_3_3rd_best(1235423);
		tp.setLot_Volume_3(23225);
		objects.add(tp);
		
		TopPrices_TP tp1 = new TopPrices_TP();
		tp1.setSecurity_Number(915);
		tp1.setSide("S");
		tp1.setPrice_1_best(253);
		tp1.setLot_Volume_1(1231);	
		tp1.setPrice_2_2nd_best(12536);
		tp1.setLot_Volume_2(9212);
		tp1.setPrice_3_3rd_best(1235423);
		tp1.setLot_Volume_3(23225);
		objects.add(tp1);
		
		UDPContent content = new UDPContent(SEQUENCE_NUMBER, marketID, messageCount, objects);
		byte udpContent[] = content.getUDPMessage();
		
		DatagramPacket message = new DatagramPacket(udpContent, udpContent.length,  destAddr, destPort);
		sock.send(message);
	}

	
	
	
	public void testTwoMessages() throws Exception{
		
		SEQUENCE_NUMBER +=1;
		String marketID="A";
		
		long messageCount =4;
		
		List objects = new ArrayList();
		TopPrices_TP tp = new TopPrices_TP();
		tp.setSecurity_Number(914);
		tp.setSide("S");
		tp.setPrice_1_best(253);
		tp.setLot_Volume_1(1231);	
		tp.setPrice_2_2nd_best(12536);
		tp.setLot_Volume_2(9212);
		tp.setPrice_3_3rd_best(1235423);
		tp.setLot_Volume_3(23225);
		objects.add(tp);
		
		TopPrices_TP tp1 = new TopPrices_TP();
		tp1.setSecurity_Number(915);
		tp1.setSide("S");
		tp1.setPrice_1_best(253);
		tp1.setLot_Volume_1(1231);	
		tp1.setPrice_2_2nd_best(12536);
		tp1.setLot_Volume_2(9212);
		tp1.setPrice_3_3rd_best(1235423);
		tp1.setLot_Volume_3(23225);
		objects.add(tp1);
		
		
		SecurityUpdate_SU su = new SecurityUpdate_SU() ;
		su.setS_SecurityNumberOld(9212);
		su.setS_SecurityNumberNew(8000);
		su.setS_Filler1(" ");
		su.setS_SectorNumber(95);
		su.setS_Filler2(" ");
		su.setS_SecuritySymbol("12345678");
		su.setS_SecurityType("S");
		su.setS_CeilingPrice(536232);
		su.setS_FloorPrice(23523);
		su.setS_LastSalePrice(23542);
		su.setS_MarketID("A");
		su.setS_Filler3("   ");
		su.setS_SecurityName("1234567890123456789012345");
		su.setS_Filler4(" ");
		su.setS_Suspension(" ");
		su.setS_Delist(" ");
		su.setS_HaltResumeFlag("H");
		su.setS_Split(" ");
		su.setS_Benefit("B");
		su.setS_Meeting(" ");
		su.setS_Notice(" ");
		su.setS_ClientIDRequired("R");
		su.setS_ParValue(2536541);
		su.setS_SDCFlag("S");
		su.setS_PriorClosePrice(2365322);
		su.setS_PriorClosedate("12345678");
		su.setS_OpenPrice(235232);
		su.setS_HighestPrice(23123);
		su.setS_LowestPrice(23532);
		su.setS_TotalSharesTraded(3456);
		su.setS_TotalValuesTraded(23456);
		su.setS_BoardLot(5365);
		su.setS_Filler5(" ");	
		objects.add(su);
		
		SecurityUpdate_SU su1 = new SecurityUpdate_SU() ;
		su.setS_SecurityNumberOld(9122);
		su.setS_SecurityNumberNew(8010);
		su.setS_Filler1(" ");
		su.setS_SectorNumber(95);
		su.setS_Filler2(" ");
		su.setS_SecuritySymbol("123456788");
		su.setS_SecurityType("S");
		su.setS_CeilingPrice(536232);
		su.setS_FloorPrice(23523);
		su.setS_LastSalePrice(242);
		su.setS_MarketID("A");
		su.setS_Filler3("   ");
		su.setS_SecurityName("1234567890123456789012345");
		su.setS_Filler4(" ");
		su.setS_Suspension(" ");
		su.setS_Delist(" ");
		su.setS_HaltResumeFlag("H");
		su.setS_Split(" ");
		su.setS_Benefit("B");
		su.setS_Meeting(" ");
		su.setS_Notice(" ");
		su.setS_ClientIDRequired("R");
		su.setS_ParValue(2536541);
		su.setS_SDCFlag("S");
		su.setS_PriorClosePrice(2365322);
		su.setS_PriorClosedate("12345678");
		su.setS_OpenPrice(235232);
		su.setS_HighestPrice(23123);
		su.setS_LowestPrice(23532);
		su.setS_TotalSharesTraded(3456);
		su.setS_TotalValuesTraded(23456);
		su.setS_BoardLot(5365);
		su.setS_Filler5(" ");	
		objects.add(su1);
		
		
		UDPContent content = new UDPContent(SEQUENCE_NUMBER, marketID, messageCount, objects);
		byte udpContent[] = content.getUDPMessage();
		
		DatagramPacket message = new DatagramPacket(udpContent, udpContent.length,  destAddr, destPort);
		sock.send(message);
		
	}

	
	public void testThreewoMessages() throws Exception{
		
		SEQUENCE_NUMBER +=1;
		String marketID="A";
		long messageCount =5;
		
		List objects = new ArrayList();
		TopPrices_TP tp = new TopPrices_TP();
		tp.setSecurity_Number(914);
		tp.setSide("S");
		tp.setPrice_1_best(253);
		tp.setLot_Volume_1(1231);	
		tp.setPrice_2_2nd_best(12536);
		tp.setLot_Volume_2(9212);
		tp.setPrice_3_3rd_best(1235423);
		tp.setLot_Volume_3(23225);
		objects.add(tp);
		
		TopPrices_TP tp1 = new TopPrices_TP();
		tp1.setSecurity_Number(915);
		tp1.setSide("S");
		tp1.setPrice_1_best(253);
		tp1.setLot_Volume_1(1231);	
		tp1.setPrice_2_2nd_best(12536);
		tp1.setLot_Volume_2(9212);
		tp1.setPrice_3_3rd_best(1235423);
		tp1.setLot_Volume_3(23225);
		objects.add(tp1);
		
		
		SecurityUpdate_SU su = new SecurityUpdate_SU() ;
		su.setS_SecurityNumberOld(9212);
		su.setS_SecurityNumberNew(8000);
		su.setS_Filler1(" ");
		su.setS_SectorNumber(95);
		su.setS_Filler2(" ");
		su.setS_SecuritySymbol("12345678");
		su.setS_SecurityType("S");
		su.setS_CeilingPrice(536232);
		su.setS_FloorPrice(23523);
		su.setS_LastSalePrice(23542);
		su.setS_MarketID("A");
		su.setS_Filler3("   ");
		su.setS_SecurityName("1234567890123456789012345");
		su.setS_Filler4(" ");
		su.setS_Suspension(" ");
		su.setS_Delist(" ");
		su.setS_HaltResumeFlag("H");
		su.setS_Split(" ");
		su.setS_Benefit("B");
		su.setS_Meeting(" ");
		su.setS_Notice(" ");
		su.setS_ClientIDRequired("R");
		su.setS_ParValue(2536541);
		su.setS_SDCFlag("S");
		su.setS_PriorClosePrice(2365322);
		su.setS_PriorClosedate("12345678");
		su.setS_OpenPrice(235232);
		su.setS_HighestPrice(23123);
		su.setS_LowestPrice(23532);
		su.setS_TotalSharesTraded(3456);
		su.setS_TotalValuesTraded(23456);
		su.setS_BoardLot(5365);
		su.setS_Filler5(" ");	
		objects.add(su);
		
		SecurityUpdate_SU su1 = new SecurityUpdate_SU() ;
		su.setS_SecurityNumberOld(9122);
		su.setS_SecurityNumberNew(8010);
		su.setS_Filler1(" ");
		su.setS_SectorNumber(95);
		su.setS_Filler2(" ");
		su.setS_SecuritySymbol("123456788");
		su.setS_SecurityType("S");
		su.setS_CeilingPrice(536232);
		su.setS_FloorPrice(23523);
		su.setS_LastSalePrice(242);
		su.setS_MarketID("A");
		su.setS_Filler3("   ");
		su.setS_SecurityName("1234567890123456789012345");
		su.setS_Filler4(" ");
		su.setS_Suspension(" ");
		su.setS_Delist(" ");
		su.setS_HaltResumeFlag("H");
		su.setS_Split(" ");
		su.setS_Benefit("B");
		su.setS_Meeting(" ");
		su.setS_Notice(" ");
		su.setS_ClientIDRequired("R");
		su.setS_ParValue(2536541);
		su.setS_SDCFlag("S");
		su.setS_PriorClosePrice(2365322);
		su.setS_PriorClosedate("12345678");
		su.setS_OpenPrice(235232);
		su.setS_HighestPrice(23123);
		su.setS_LowestPrice(23532);
		su.setS_TotalSharesTraded(3456);
		su.setS_TotalValuesTraded(23456);
		su.setS_BoardLot(5365);
		su.setS_Filler5(" ");	
		objects.add(su1);

		GeneralAdmin_GA ga = new GeneralAdmin_GA();
		ga.setAdminMessageLength(94);
		ga.setAdminMessageText("1034567890103456789010345678901034567890103456789010345678901034567890");
		objects.add(ga);
		
		UDPContent content = new UDPContent(SEQUENCE_NUMBER, marketID, messageCount, objects);
		byte udpContent[] = content.getUDPMessage();
		
		DatagramPacket message = new DatagramPacket(udpContent, udpContent.length,  destAddr, destPort);
		sock.send(message);
		
	}

	
	 public static void main(String args[]) throws Exception {
		 UDPServer server = new UDPServer();
		 //System.out.println("testSendTopPrice:");
		 //server.testSendTopPrice();
		 //System.out.println("testSendBrokerReconcile:");
		 //server.testSendBrokerReconciles();
		 //server.testSendBrokerReconcile();
		 //server.testSendBrokerReconcileBRwithOther();
		 //server.testSendTopPrices();
		 //System.out.println("testTwoMessages:");
		 // server.testTwoMessages();
		 //System.out.println("testThreewoMessages:");
		 //server.testThreewoMessages();
		 ///////////////////////////////////
		 //server.testSendBrokerReconcileBRwithOther();
		 //server.testSendCancelOddLot_COwithOther();
		 //server.testSendForeignRoom_TRwithOther();
		 //server.testSendDealCancellationNotice_DCwithOther();
		 //server.testSendBrokerStatusChange_BSwithOther();
		 // server.testSendMarketOpenLastSale_OSwithOther();
		 // server.testSendSecurityReconcile_SRwithOther();
		 // server.testSendSecurityStatusChange_SSBRwithOther();
		 // server.testSendSystemControl_SCwithOther();
		 // server.testSendTimeStamp_TSwithOther();
		 // server.testSendNewHeadLine_NHwithOther();
		 //server.testSendNewsStory_NSwithOther();
		 // server.testSendPutThroughDealNotice_PDwithOther();
		 //server.testSendProjectedOpen_POwithOther();
		 server.testSendNewOddLot_OLwithOther(); 
		 // server.testSendLastSale_LSwithOther();
		 //server.testSendTraderStatusChange_TCwithOther();
		 //server.testSendLastOddLot_LOwithOther();
	 }
}
