package eps.com.exception;

public enum ExceptionType {
	BYTE_ARRAY_NOTVALID,	// was used...
	INFO_NOT_VALID,
	INFO_NOT_FOUND,
	INFO_MISSING,
	OUT_OF_RANGE,		// was used...
	ERROR_GEN_KEY,
	FILE_NOT_FOUND,
	DIARY_COMMON,
	INFO_EXISTING,
	STATUS
}
