package eps.com.exception;

import java.util.ArrayList;
import java.util.List;

public abstract class TradingOnlineException extends Exception{
	private static final long serialVersionUID = 1L;
	protected int code;
	protected ExceptionLevel level = null;//ERRO, WARNING, RECOMMEND
	protected ExceptionType type;
	protected String suggestMess;//những gợi ý xử lý
	protected List<String> reasonList = new ArrayList<String>();//nguyên nhân gây lỗi
	protected String message = "";

	public String getMessage(){
		return message;
	}
	public String getSuggestMess(){
		return suggestMess;
	}
	
	public int getCode() {
		return code;
	}
	public void setCode(int code) {
		this.code = code;
		this.setMessage();
	}
	public ExceptionLevel getLevel() {
		return level;
	}
	public void setLevel(ExceptionLevel level) {
		this.level = level;
	}
	public ExceptionType getType() {
		return type;
	}
	
	public void setReason(String reason){
		this.reasonList.add(reason);
	}
	public List<String> getReasonList() {
		return reasonList;
	}
	public void setReasonList(List<String> reasonList) {
		this.reasonList = reasonList;
	}
	//*******************************
	/*
	 * Set mess and SuggestMess appropriate to Code
	 */
	protected abstract void setMessage();
	public TradingOnlineException(int code){
		this.code = code;		
		setMessage();
	}
	
}
