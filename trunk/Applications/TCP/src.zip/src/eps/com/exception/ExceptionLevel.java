package eps.com.exception;

public enum ExceptionLevel {
	ERROR,
	RECOMMEND,
	WARNING
}
