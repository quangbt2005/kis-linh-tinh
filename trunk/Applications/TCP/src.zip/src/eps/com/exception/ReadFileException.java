package eps.com.exception;
/**
 * Ngoại lệ này sẽ được đưa ra khi các thông tin trong tập tin run có khuôn dạng không hợp lệ.
 * Ngoại lệ này sẽ đưa ra thông báo lỗi cho ngư�?i dùng trong trư�?ng hợp ngư�?i dùng cố ý tự đi�?u chỉnh các thông tin
 * trong tập tin run.
 * 
 * @author lequocthai
 *
 */
public class ReadFileException extends TradingOnlineException{

	private static final long serialVersionUID = 1L;

	public ReadFileException(int code) {
		super(code + 20);
		this.type = ExceptionType.INFO_NOT_VALID;
	}
	
	public ReadFileException(int code, String mess){
		super(code + 20);
		this.type = ExceptionType.INFO_NOT_VALID;
		this.message = mess;
	}
	
	public ReadFileException(String mess){
		super(20);
		this.message = mess;
	}
	
	@Override
	protected void setMessage() {
		switch(code){
		case 21:
			this.message = "Khuôn dạng của ngày khởi hoạt dịch vụ không hợp lệ.";
			break;
		case 22:
			this.message = "Khuôn dạng của số lần khởi hoạt dịch vụ không hợp lệ.";
			break;
		}
	}

}
