package eps.com.util;

/**
 * Lớp này bao gồm các phương thức đọc và truy xuất một cấu trúc Message cụ thể.
 * 
 * @author lequocthai
 */

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.Text;
import org.xml.sax.SAXException;

import eps.com.test.MainFrame;
import eps.com.test.TestCommon;

public class MessageOperator {

	private Document doc;
	private List<String> orderIDList;

	public static InputStream inputStream;

	public MessageOperator() {
		// System.out.println("Trong MessageOperator");
		if (inputStream != null) {
			doc = parseFile(inputStream);
		} else {
			doc = parseFile(TestCommon.MESSAGE_XML_PATH);
		}
		if (doc == null) {
			System.out.println("messageconfg.xml can not found.");
			MainFrame.showMessageAndExit("messageconfg.xml can not found.");
		}
	}

	public NodeList getNodeList() {
		if (doc != null)
			return doc.getElementsByTagName("Message");

		return null;
	}

	public int getTotalSizeBelongAMessage(Node messageNode) {
		int total = 0;
		if (messageNode.getNodeType() == Node.ELEMENT_NODE) {
			Element messageNodeElement = (Element) messageNode;
			total = Integer.parseInt(messageNodeElement.getAttribute("size"));

			// NodeList typeNodeList = messageNodeElement
			// .getElementsByTagName("size");
			// for (int i = 0; i < typeNodeList.getLength(); i++) {
			// Element typeNodeElement = (Element) typeNodeList.item(i);
			// NodeList textTypeNodeList = typeNodeElement.getChildNodes();
			// String messType = ((Node) textTypeNodeList.item(0))
			// .getNodeValue().trim().toLowerCase();
			// total += Integer.parseInt(messType);
			// }
		}
		return total;
	}

	public String getBeanNameofMessage(Node messageNode) {
		String beanName = null;
		if (messageNode.getNodeType() == Node.ELEMENT_NODE) {
			Element messageNodeElement = (Element) messageNode;
			beanName = messageNodeElement.getAttribute("beanName");
		}
		return beanName;
	}

	/**
	 * Lấy tất cả các kích thước của các field trong message cụ thể. Lúc này
	 * mesgSizeList sẽ chứa các kích thước của các field trong message.
	 * 
	 * @param messageNode
	 *            Node. Node trong cấu trúc của XML document đã được xác định.
	 */
	public List<Integer> getListOfSizeBelongAMessage(Node messageNode) {
		List<Integer> sizeList = new ArrayList<Integer>();
		if (messageNode.getNodeType() == Node.ELEMENT_NODE) {
			Element messageNodeElement = (Element) messageNode;
			NodeList typeNodeList = messageNodeElement
					.getElementsByTagName("size");
			for (int i = 0; i < typeNodeList.getLength(); i++) {
				Element typeNodeElement = (Element) typeNodeList.item(i);
				NodeList textTypeNodeList = typeNodeElement.getChildNodes();
				String messType = ((Node) textTypeNodeList.item(0))
						.getNodeValue().trim().toLowerCase();
				sizeList.add(Integer.parseInt(messType));
			}
		}
		return sizeList;
	}

	/**
	 * Sau khi xác định được kiểu của message cần gửi đi, duyệt qua tất cả các
	 * nút con của tag Message và kiểm tra thuộc tính type để xác định được cấu
	 * trúc của Message cụ thể.
	 * 
	 * @param type
	 *            String Kiểu của message cần lấy ra.
	 * @return Node. Mô tả cho message đã được xác định.
	 */
	public Node getMessageWithType1(String type) {

		NodeList nodeList = doc.getElementsByTagName("Message");
		int totalMessages = nodeList.getLength();
		// Duyệt qua tất cả các Message.

		for (int i = 0; i < totalMessages; i++) {
			Node messageNode = nodeList.item(i);
			Node firstChild = messageNode.getFirstChild();
			if (firstChild.getNodeType() == Node.ELEMENT_NODE
					|| firstChild.getNodeType() == Node.TEXT_NODE) {
				Element messageElement = (Element) firstChild;
				// Lấy Message có thuộc tính type
				NodeList typeNodeList = messageElement
						.getElementsByTagName("type");
				Element typeNodeElement = (Element) typeNodeList.item(0);
				NodeList textTypeNodeList = typeNodeElement.getChildNodes();
				// So sánh để xác định kiểu Message.
				String messType = ((Node) textTypeNodeList.item(0))
						.getNodeValue().trim().toLowerCase();
				if (messType.equalsIgnoreCase(type))
					return messageNode;
			}
		}
		return null;
	}

	public Node getMessageWithType(String type) {

		NodeList nodeList = doc.getElementsByTagName("Message");
		int totalMessages = nodeList.getLength();
		// Duyệt qua tất cả các Message.
		Element e = null;
		String id;
		for (int i = 0; i < totalMessages; i++) {
			Node messageNode = nodeList.item(i);
			if (messageNode instanceof Element) {
				e = (Element) messageNode;
				id = e.getAttribute("id");
				if (id.equals(type)) {
					return messageNode;
				}
			}
		}
		return null;
	}

	/**
	 * Parses tập tin messageconfg và trả về kiểu xml document.
	 * 
	 * @param fileName
	 *            Tên tập tin xml.
	 * @return XML document or <B>null</B> if error occured
	 */
	public Document parseFile(String fileName) {
		DocumentBuilder docBuilder;
		Document doc = null;
		DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory
				.newInstance();
		docBuilderFactory.setIgnoringElementContentWhitespace(true);
		try {
			docBuilder = docBuilderFactory.newDocumentBuilder();
		} catch (ParserConfigurationException e) {
			return null;
		}
		File sourceFile = new File(fileName);
		try {
			doc = docBuilder.parse(sourceFile);
		} catch (SAXException e) {
			return null;
		} catch (IOException e) {
			return null;
		}
		return doc;
	}

	public Document parseFile(InputStream inputStream) {
		DocumentBuilder docBuilder;
		Document doc = null;
		DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory
				.newInstance();
		docBuilderFactory.setIgnoringElementContentWhitespace(true);
		try {
			docBuilder = docBuilderFactory.newDocumentBuilder();
		} catch (ParserConfigurationException e) {
			return null;
		}
		try {
			doc = docBuilder.parse(inputStream);
		} catch (SAXException e) {
			return null;
		} catch (IOException e) {
			return null;
		}
		return doc;
	}

	public byte[] getByteContent(int size, String content) {
		byte[] result = new byte[size];
		byte[] bContent = content.getBytes();
		if (result.length > bContent.length) {
			for (int i = 0; i < bContent.length; i++)
				result[i] = bContent[i];
			int index = bContent.length;
			for (int i = index; i < result.length; i++)
				result[i] = " ".getBytes()[0];
		} else {
			for (int i = 0; i < result.length; i++)
				result[i] = bContent[i];
		}
		return result;
	}

	public byte[] getRealContent(byte[] data) {
		orderIDList = new ArrayList<String>();
		StringBuffer buffer = new StringBuffer();
		StringBuffer bufOrderID = new StringBuffer();
		int i = 0;
		while ((char) data[i] != 03) {
			buffer.append((char) data[i]);
			++i;
		}
		int tmp = i + 1;
		for (int j = tmp; j < data.length; j++) {
			if ((char) data[j] != 31)
				bufOrderID.append((char) data[j]);
			else {
				orderIDList.add(bufOrderID.toString());
				bufOrderID.setLength(0);
			}
		}
		return buffer.toString().getBytes();
	}

}
