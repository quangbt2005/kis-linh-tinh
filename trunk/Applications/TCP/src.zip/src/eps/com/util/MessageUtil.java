package eps.com.util;

import java.lang.reflect.AccessibleObject;
import java.lang.reflect.Field;

import javax.naming.spi.ObjectFactory;

import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import eps.com.common.ValueObject;
import eps.com.client.upd.Common;
import eps.com.client.upd.Common.*;
import eps.com.test.TestCommon;

public class MessageUtil {
	private static MessageOperator mo = new MessageOperator();

	public static byte[] message2Bytes(ValueObject object) {
		if (object == null)
			return null;
		Class clazz = object.getClass();
		Field[] fields = clazz.getDeclaredFields();
		// change visibility
		AccessibleObject.setAccessible(fields, true);
		String messageTypeID = null;
		try {
			Field field = clazz.getDeclaredField("MessageType");
			messageTypeID = field.get(object).toString();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		Node messageNode = mo.getMessageWithType(messageTypeID);
		int length = mo.getTotalSizeBelongAMessage(messageNode);
		byte[] result = new byte[length];

		String temp = null;
		byte[] convert = null;
		NodeList nodeList = messageNode.getChildNodes();
		int totalField = nodeList.getLength();

		// for (int i = 0; i < totalField; i++) {
		// Node filedNode = nodeList.item(i);
		// System.out.println(filedNode.getNodeName() + " ; "
		// + filedNode.getNodeValue() + " ; "
		// + filedNode.getNodeType());
		// }

		int index1 = 0, index2 = 0;
		Node nodeName, nodeSize, nodeType;
		Element eFieldNode;
		String fieldName, fieldType;
		int fieldSize;
		Field field;
		for (int i = 0; i < totalField; i++) {
			Node fieldNode = nodeList.item(i);
			if (fieldNode.getNodeType() == Node.ELEMENT_NODE) {
				eFieldNode = (Element) fieldNode;
				nodeName = eFieldNode.getElementsByTagName("name").item(0);
				nodeSize = eFieldNode.getElementsByTagName("size").item(0);
				nodeType = eFieldNode.getElementsByTagName("type").item(0);
				fieldName = nodeName.getFirstChild().getNodeValue();
				fieldSize = Integer.parseInt(nodeSize.getFirstChild()
						.getNodeValue());
				if (nodeType.getFirstChild() != null)
					fieldType = nodeType.getFirstChild().getNodeValue();
				else
					fieldType = "";
				try {
					field = clazz.getDeclaredField(fieldName);
					field.setAccessible(true);
					if (field.get(object) != null)
						temp = field.get(object).toString();
					else
						temp = "";
					if (fieldType.equalsIgnoreCase("Mod-96")) {
						// convert = new Mode96Algorithm(Long.parseLong(temp),
						// fieldSize).encode();
						convert = eps.com.client.upd.Common.EnMod96(Long
								.parseLong(temp), fieldSize);
					} else {
						temp = TestCommon.fillEmptySpace(temp, fieldSize);
						convert = temp.getBytes();
					}
					index2 = index1 + fieldSize;
					System.arraycopy(convert, 0, result, index1, fieldSize);
					index1 += fieldSize;

				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		return result;
	}

	/**
	 * Importance Note: Ham nay chi nen dung cho ben UDP
	 * 
	 * @param arg
	 * @return
	 */
	public static ValueObject bytes2Message(byte[] arg) {
		Object object = null;
		try {
			byte messID[] = new byte[2];
			messID[0] = arg[0];
			messID[1] = arg[1];
			String messageID = new String(messID);
			Node messageNode = mo.getMessageWithType(messageID);
			String beanName = mo.getBeanNameofMessage(messageNode);

			Class clazz = null;
			clazz = Class.forName(beanName);
			object = clazz.newInstance();

			NodeList nodeList = messageNode.getChildNodes();
			int totalField = nodeList.getLength();

			int index1 = 0, index2 = 0;
			Node nodeName, nodeSize, nodeType;
			Element eFieldNode;
			String fieldName, fieldType;
			int fieldSize;
			Field field = null;
			byte[] convert = null;
			long temp = 0;
			String tempStr = null;
			index1 = 2;
			for (int i = 0; i < totalField; i++) {
				Node fieldNode = nodeList.item(i);
				if (fieldNode.getNodeType() == Node.ELEMENT_NODE) {
					eFieldNode = (Element) fieldNode;
					nodeName = eFieldNode.getElementsByTagName("name").item(0);
					nodeSize = eFieldNode.getElementsByTagName("size").item(0);
					nodeType = eFieldNode.getElementsByTagName("type").item(0);
					fieldName = nodeName.getFirstChild().getNodeValue();
					if (!fieldName.equals("MessageType")) {
						fieldSize = Integer.parseInt(nodeSize.getFirstChild()
								.getNodeValue());
						if (nodeType.getFirstChild() != null)
							fieldType = nodeType.getFirstChild().getNodeValue();
						else
							fieldType = "";

						try {
							// index2 = index1 + fieldSize;
							convert = new byte[fieldSize];
							System
									.arraycopy(arg, index1, convert, 0,
											fieldSize);
							index1 += fieldSize;

							field = clazz.getDeclaredField(fieldName);
							field.setAccessible(true);
							if (fieldType.equals("Mod-96")) {
								// if (fieldType.equalsIgnoreCase("Mod-96")) {
								// System.out.println("is mos 96");
								// temp = new Mode96Algorithm().decode(convert);
								temp = eps.com.client.upd.Common
										.DecodeMod96(convert);
								// only use for Long data type
								field.set(object, temp);
								tempStr = "" + temp;
							}
							// if (fieldType.equals("Mode-96"))
							// {
							// temp = new Mode96Algorithm().decode(convert);
							// field.set(object, temp);
							// tempStr = "" + temp;
							// }
							else {
								tempStr = new String(convert);
								tempStr = TestCommon.fillEmptySpace(tempStr,
										fieldSize);
								field.set(object, tempStr);
							}

						} catch (Exception e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
				}//
			}
		} catch (Exception e) {
			return null;
		}
		return (ValueObject) object;
	}

	/**
	 * Importance Note: Ham nay chi dung xu ly RR & RP message
	 * 
	 * @param arg
	 * @return
	 */
	public static ValueObject bytesRRorRQ2Message(byte[] arg) {
		Object object = null;
		try {
			int length = arg.length;
			if (length > 485) {
				String tempStr = new String(arg).substring(0, 484);
				arg = tempStr.getBytes();
			} else if (length < 485) {
				String tempStr = TestCommon
						.fillEmptySpace(new String(arg), 485);
				arg = tempStr.getBytes();
			}

			byte messID[] = new byte[2];
			// khong tinh market ID bo arg[0]
			messID[0] = arg[1];
			messID[1] = arg[2];
			String messageID = new String(messID);
			Node messageNode = mo.getMessageWithType(messageID);
			String beanName = mo.getBeanNameofMessage(messageNode);

			Class clazz = null;
			clazz = Class.forName(beanName);
			object = clazz.newInstance();

			NodeList nodeList = messageNode.getChildNodes();
			int totalField = nodeList.getLength();

			int index1 = 0, index2 = 0;
			Node nodeName, nodeSize, nodeType;
			Element eFieldNode;
			String fieldName, fieldType;
			int fieldSize;
			Field field = null;
			byte[] convert = null;
			long temp = 0;
			String tempStr = null;
			index1 = 3; // bo qua 3 byte dau
			for (int i = 0; i < totalField; i++) {
				Node fieldNode = nodeList.item(i);
				if (fieldNode.getNodeType() == Node.ELEMENT_NODE) {
					eFieldNode = (Element) fieldNode;
					nodeName = eFieldNode.getElementsByTagName("name").item(0);
					nodeSize = eFieldNode.getElementsByTagName("size").item(0);
					nodeType = eFieldNode.getElementsByTagName("type").item(0);
					fieldName = nodeName.getFirstChild().getNodeValue();
					if (!fieldName.equals("MessageType")) {
						fieldSize = Integer.parseInt(nodeSize.getFirstChild()
								.getNodeValue());
						if (nodeType.getFirstChild() != null)
							fieldType = nodeType.getFirstChild().getNodeValue();
						else
							fieldType = "";

						try {
							// index2 = index1 + fieldSize;
							convert = new byte[fieldSize];
							System
									.arraycopy(arg, index1, convert, 0,
											fieldSize);
							index1 += fieldSize;

							field = clazz.getDeclaredField(fieldName);
							field.setAccessible(true);
							if (fieldType.equals("Mod-96")) {
								temp = eps.com.client.upd.Common
										.DecodeMod96(convert);
								// only use for Long data type
								field.set(object, temp);
								// tempStr = "" + temp;
							} else {
								tempStr = new String(convert);
								tempStr = TestCommon.fillEmptySpace(tempStr,
										fieldSize);
								field.set(object, tempStr);
							}

						} catch (Exception e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
				}//
			}
		} catch (Exception e) {
			return null;
		}
		return (ValueObject) object;
	}

	/**
	 * Importance Note: Ham nay chi dung xu ly DT & LL , LO message
	 * 
	 * @param arg
	 * @return
	 */
	public static ValueObject bytesDT2Message(byte[] arg) {
		// System.out.println("test tai sao:" + new String(arg));
		Object object = null;
		try {
			byte messID[] = new byte[2];
			// khong tinh market ID & message count bo qua 2 byte dau
			messID[0] = arg[2];
			messID[1] = arg[3];
			String messageID = new String(messID);
			Node messageNode = mo.getMessageWithType(messageID);
			String beanName = mo.getBeanNameofMessage(messageNode);

			Class clazz = null;
			clazz = Class.forName(beanName);
			object = clazz.newInstance();

			NodeList nodeList = messageNode.getChildNodes();
			int totalField = nodeList.getLength();

			int index1 = 0, index2 = 0;
			Node nodeName, nodeSize, nodeType;
			Element eFieldNode;
			String fieldName, fieldType;
			int fieldSize;
			Field field = null;
			byte[] convert = null;
			long temp = 0;
			String tempStr = null;
			index1 = 4;
			for (int i = 0; i < totalField; i++) {
				Node fieldNode = nodeList.item(i);
				if (fieldNode.getNodeType() == Node.ELEMENT_NODE) {
					eFieldNode = (Element) fieldNode;
					nodeName = eFieldNode.getElementsByTagName("name").item(0);
					nodeSize = eFieldNode.getElementsByTagName("size").item(0);
					nodeType = eFieldNode.getElementsByTagName("type").item(0);
					fieldName = nodeName.getFirstChild().getNodeValue();
					if (!fieldName.equals("MessageType")) {
						fieldSize = Integer.parseInt(nodeSize.getFirstChild()
								.getNodeValue());
						if (nodeType.getFirstChild() != null)
							fieldType = nodeType.getFirstChild().getNodeValue();
						else
							fieldType = "";

						try {
							// index2 = index1 + fieldSize;
							convert = new byte[fieldSize];
							System
									.arraycopy(arg, index1, convert, 0,
											fieldSize);
							index1 += fieldSize;

							field = clazz.getDeclaredField(fieldName);
							field.setAccessible(true);
							if (fieldType.equals("Mod-96")) {
								temp = eps.com.client.upd.Common
										.DecodeMod96(convert);
								// only use for Long data type
								field.set(object, temp);
								// tempStr = "" + temp;
							} else {
								tempStr = new String(convert);
								tempStr = TestCommon.fillEmptySpace(tempStr,
										fieldSize);
								field.set(object, tempStr);
							}

						} catch (Exception e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
				}//
			}
		} catch (Exception e) {
			return null;
		}
		return (ValueObject) object;
	}

	/**
	 * 
	 * @param arg
	 * @return
	 */
	public static Object bytes2Message(byte[] arg, String messageID) {
		Node messageNode = mo.getMessageWithType(messageID);
		String beanName = mo.getBeanNameofMessage(messageNode);
		Object object = null;
		Class clazz = null;
		try {
			clazz = Class.forName(beanName);
			object = clazz.newInstance();
		} catch (InstantiationException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (IllegalAccessException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		clazz = object.getClass();
		NodeList nodeList = messageNode.getChildNodes();
		int totalField = nodeList.getLength();

		int index1 = 0, index2 = 0;
		Node nodeName, nodeSize, nodeType;
		Element eFieldNode;
		String fieldName, fieldType;
		int fieldSize;
		Field field = null;
		byte[] convert = null;
		long temp = 0;
		String tempStr = null;

		for (int i = 0; i < totalField; i++) {
			Node fieldNode = nodeList.item(i);
			if (fieldNode.getNodeType() == Node.ELEMENT_NODE) {
				eFieldNode = (Element) fieldNode;
				nodeName = eFieldNode.getElementsByTagName("name").item(0);
				nodeSize = eFieldNode.getElementsByTagName("size").item(0);
				nodeType = eFieldNode.getElementsByTagName("type").item(0);
				fieldName = nodeName.getFirstChild().getNodeValue();
				fieldSize = Integer.parseInt(nodeSize.getFirstChild()
						.getNodeValue());
				if (nodeType.getFirstChild() != null)
					fieldType = nodeType.getFirstChild().getNodeValue();
				else
					fieldType = "";

				try {
					// index2 = index1 + fieldSize;
					convert = new byte[fieldSize];
					System.arraycopy(arg, index1, convert, 0, fieldSize);
					index1 += fieldSize;

					if (fieldType.equalsIgnoreCase("Mod-96")) {
						// temp = new Mode96Algorithm().decode(convert);
						temp = Common.DecodeMod96(convert);
						tempStr = "" + temp;
					} else {
						tempStr = new String(convert);
					}
					field = clazz.getDeclaredField(fieldName);
					field.setAccessible(true);
					field.set(object, tempStr);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}

		return object;
	}

	public static String message2XML(ValueObject object) {
		Class clazz = object.getClass();
		String messageTypeID = null;
		try {
			Field field = clazz.getDeclaredField("MessageType");
			messageTypeID = field.get(object).toString();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		Node messageNode = mo.getMessageWithType(messageTypeID);
		int length = mo.getTotalSizeBelongAMessage(messageNode);

		String temp = null;
		byte[] convert = null;
		NodeList nodeList = messageNode.getChildNodes();
		int totalField = nodeList.getLength();

		Node nodeName, nodeSize, nodeType;
		Element eFieldNode;
		String fieldName, fieldType;
		int fieldSize;
		Field field;
		StringBuffer result = new StringBuffer();
		result.append("<Message>\n");
		for (int i = 0; i < totalField; i++) {
			Node fieldNode = nodeList.item(i);
			if (fieldNode.getNodeType() == Node.ELEMENT_NODE) {
				eFieldNode = (Element) fieldNode;
				nodeName = eFieldNode.getElementsByTagName("name").item(0);
				nodeSize = eFieldNode.getElementsByTagName("size").item(0);
				nodeType = eFieldNode.getElementsByTagName("type").item(0);
				fieldName = nodeName.getFirstChild().getNodeValue();
				fieldSize = Integer.parseInt(nodeSize.getFirstChild()
						.getNodeValue());
				if (nodeType.getFirstChild() != null)
					fieldType = nodeType.getFirstChild().getNodeValue();
				else
					fieldType = "";
				try {
					field = clazz.getDeclaredField(fieldName);
					field.setAccessible(true);
					if (field.get(object) != null)
						temp = field.get(object).toString();
					else
						temp = "";
					if (fieldType.equalsIgnoreCase("Mode-96")) {
						// convert = new Mode96Algorithm(Long.parseLong(temp),
						// fieldSize).encode();
						convert = Common.EnMod96(Long.parseLong(temp),
								fieldSize);
					} else {
						temp = TestCommon.fillEmptySpace(temp, fieldSize);
						convert = temp.getBytes();
					}
					result.append("  <").append(fieldName).append(">");
					result.append(new String(convert));
					result.append("</").append(fieldName).append(">\n");

				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		result.append("\n</Message>");
		return result.toString();
	}

}
