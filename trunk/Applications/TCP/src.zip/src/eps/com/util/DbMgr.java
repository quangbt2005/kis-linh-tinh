package eps.com.util;

import java.sql.*;
import java.util.*;



/**
 * This class wraps com.acom.database.ConnectionPoolManager
 */
public class DbMgr {
	
	
    
	public DbMgr() {}

	/**
	 * TODO: plang - Need to refactor system not to pass confFile 
	 * since init() already global has access to it
	 * 
	 * @param confFile
	 * @return
	 */
	
	

	public Connection makeConnection() throws SQLException {
		
		return null ;
		
	}

	public void releaseConnection(Connection dbConn) throws SQLException {
		
	}

	/**
	 * Nothing is actively calling this yet though
	 * 
	 * @author plang
	 * @throws SQLException
	 */
	public void refreshPool() throws SQLException {
		//		manager.destroy(); // TODO: This should be changed to emptyAllPools
		//		manager = new ConnectionPoolManager();
		//		if(!manager.isAlive()) manager.start();
	}
	
	

}

