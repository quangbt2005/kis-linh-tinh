package eps.com.test;

import javax.swing.border.EtchedBorder;
import javax.swing.border.Border;
import javax.swing.JPanel;
import javax.swing.JFrame;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Rectangle;
import java.awt.SystemColor;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JComboBox;
import javax.swing.JRadioButton;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;
import javax.swing.SwingUtilities;

import java.awt.event.KeyEvent;
import eps.com.client.proposal.EPSServiceController;
import eps.com.client.upd.UDPClient;
import eps.com.client.upd.UDPContent;
import eps.com.common.HosePacket;
import eps.com.common.HoseSystemPacket;
import eps.com.common.Opcode;
import eps.com.common.ValueObject;
import eps.com.message.sended.Advertisement_1E;
import eps.com.message.sended.DealCancelReply_3D;
import eps.com.message.sended.DealPutThroughCancelRequest_3C;
import eps.com.message.sended.NewConditioned_1I;
import eps.com.message.sended.OrderCancellation_1C;
import eps.com.message.sended.OrderChange_1D;
import eps.com.message.sended.OneFirmPutThroughDeal_1F;
import eps.com.message.sended.PutThroughDealReply_3B;
import eps.com.message.sended.RetransmissionRequest_RQ;
import eps.com.message.sended.TwoFirmPutThroughDeal_1G;
import eps.com.util.MessageUtil;
import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;

import eps.com.message.received.PutThroughAcknowledgment_2F;
import eps.com.message.received.PutThroughDealConfirmation_2L;
import eps.com.message.received.RetransmissionReply_RP;
import java.awt.Font;
import java.awt.Insets;
import java.util.Iterator;
import java.util.List;

public class MainFrameConformance extends JFrame {
	private JTextField ttcTextField_22;
	private JTextField txtLO_2;
	private JTextField txt19_2;
	private JTextField txt19_1;
	private JTextField txtLO_1;
	private JTextField txtSecSym_1;
	private JTextField tp4a4404TextField_1;
	private JTextField aa2TextField_3;
	private JTextField aa2TextField_2;
	private JTextField aa1TextField_1;
	private JTextField vfmvf1TextField_1;
	private JTextField cp1_0100TextField_1;
	private JTextField c;
	private JTextField cp1c0101TextField_2;
	private JTextField loTextField_13;
	private JTextField ttcTextField_21;
	private JTextField loTextField_12;
	private JTextField ttcTextField_20;
	private JTextField loTextField_11;
	private JTextField ttcTextField_19;
	private JTextField loTextField_10;
	private JTextField ttcTextField_18;
	private JTextField loTextField_9;
	private JTextField ttcTextField_17;
	private JTextField ttcTextField_16;
	private JTextField gmdTextField_3;
	private JTextField ttcTextField_15;
	private JTextField gmdTextField_2;
	private JTextField loTextField_8;
	private JTextField ttcTextField_14;
	private JTextField loTextField_7;
	private JTextField ttcTextField_13;
	private JTextField atoTextField_1;
	private JTextField ttcTextField;
	private JTextField txt19;
	private JTextField txtLO;
	private JTextField txtSecSym;
	private JTextField cp1c0101TextField_1;
	private JTextField tp4a4404TextField;
	private JTextField aa2TextField_1;
	private JTextField aa2TextField;
	private JTextField aa1TextField;
	private JTextField vfmvf1TextField;
	private JTextField cp1_0100TextField;
	private JTextField cp1c0101TextField;
	private JTextField sTextField_1;
	private JTextField textField_13;
	private JTextField textField_12;
	private JButton btnSend3C_1;
	private JTextField sTextField;
	private JTextField ttcTextField_12;
	private JTextField textField_11;
	private JTextField textField_10;
	private JTextField aTextField_1;
	private JTextField textField_9;
	private JTextField textField_8;
	private JTextField textField_7;
	private JTextField textField_6;
	private JTextField textField_5;
	private JTextField textField_4;
	private JTextField aTextField;
	private JTextField txtConfirmNumber;
	private JTextField loTextField_6;
	private JTextField ttcTextField_11;
	private JTextField loTextField_5;
	private JTextField ttcTextField_10;
	private JTextField loTextField_4;
	private JTextField ttcTextField_9;
	private JTextField loTextField_3;
	private JTextField ttcTextField_8;
	private JTextField loTextField_2;
	private JTextField ttcTextField_7;
	private JTextField ttcTextField_6;
	private JTextField gmdTextField_1;
	private JTextField ttcTextField_5;
	private JTextField gmdTextField;
	private JTextField ttcTextField_4;
	private JTextField gmdTextField_4;
	private JTextField loTextField_1;
	private JTextField ttcTextField_3;
	private JTextField loTextField;
	private JTextField atoTextField;
	private JTextField ttcTextField_2;
	private JTextField ttcTextField_1;
	private ButtonGroup buttonGroup = new ButtonGroup();
	private String opCode[] = { "HL", "HR", "CF", "DT", "LO", "LL", "RR", "RP",
			"AK", "NK", "FN", "AF", "EC", "ER" }; // @jve:decl-index=0:
	private static final long serialVersionUID = 1L;
	private EPSServiceController controller;
	private UDPClient udpClient;
	private JPanel jContentPane = null;

	private JPanel jPanel = null;

	private JLabel jLabel = null;

	private JLabel jLabel1 = null;

	private JLabel jLabel2 = null;

	private JLabel jLabel3 = null;

	private JLabel jLabel4 = null;
	Border border1 = BorderFactory.createEtchedBorder(EtchedBorder.RAISED,
			Color.white, new Color(165, 163, 151)); // @jve:decl-index=0:

	private JLabel jLabel5 = null;
	private JTextField txtFirmID = null;
	private JTextField txtServerPort = null;
	private JTextField txtServerIP = null;
	private JTextField txtSequence = null;
	private JTextField txtUDPPort = null;
	private JTextField noPacket = null;
	private JPasswordField txtPassword = null;
	private JTextField txtAck = null;
	private JLabel jLabel6 = null;
	private JLabel jLabel7 = null;
	private JTextField txtMarketID = null;
	private JLabel jLabel8 = null;
	private JLabel jLabel9 = null;
	private JComboBox cbPacketType = null;
	private JRadioButton modeA = null;
	private JRadioButton modeB = null;
	private JRadioButton modeC = null;
	private JButton btConnect = null;
	private JButton btDisconnect = null;
	private JButton startUdpListenButton = null;
	private JButton btStopUDP = null;
	private JTabbedPane jTabbedPane = null;
	public static ConformanceFrame conFrame;

	public void update3BInfo(PutThroughAcknowledgment_2F message2F) {
		// this.aTextField
		txtConfirmNumber.setText(message2F.getConfirmNumber());
		this.textField_4.setText(message2F.getVolume());
		this.textField_5.setText(message2F.getVolume());
		this.textField_6.setText(message2F.getVolume());
		this.textField_7.setText(message2F.getVolume());
	}

	public void update3CInfo(PutThroughDealConfirmation_2L message2L) {
		textField_9.setText(message2L.getFirm());
		aTextField_1.setText(message2L.getContraFirm());
		// textField_8.setText(message2L.get Firm());
		textField_11.setText(message2L.getConfirmNumber());
		// ttcTextField_1.setText(message2L.get.getFirm());
		// sTextField.setText(message2L.getSide());

	}

	public void update3DInfo(DealPutThroughCancelRequest_3C message3C) {
		textField_13.setText(message3C.getConfirmNumber());
	}

	/**
	 * This is the default constructor
	 */
	public MainFrameConformance() {
		super();
		getContentPane().setName("contentPane");
		initialize();
	}

	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
		// jContentPane = (JPanel)this.getContentPane();
		this.getContentPane().setLayout(null);
		this.getContentPane().setBackground(SystemColor.control);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.setResizable(false);
		setSize(new Dimension(800, 600));
		this.getContentPane().add(getJPanel(), null);
		this.getContentPane().add(getJTabbedPane(), null);
		this.setTitle("Test Center");
	}

	/**
	 * This method initializes jContentPane
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getJContentPane() {
		if (jContentPane == null) {
			jContentPane = new JPanel();
			jContentPane.setMinimumSize(new Dimension(800, 600));
			jContentPane.setLayout(null);
			jContentPane.add(getJPanel());
			jContentPane.add(getJTabbedPane());
		}
		return jContentPane;
	}

	/**
	 * This method initializes jPanel
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getJPanel() {
		if (jPanel == null) {
			jLabel9 = new JLabel();
			jLabel9.setBounds(new Rectangle(470, 4, 93, 23));
			jLabel9.setFont(new Font("Dialog", Font.BOLD, 10));
			jLabel9.setText("Packet Type:");
			jLabel8 = new JLabel();
			jLabel8.setBounds(new Rectangle(470, 31, 96, 23));
			jLabel8.setFont(new Font("Dialog", Font.BOLD, 10));
			jLabel8.setText("Number Packets:");
			jLabel7 = new JLabel();
			jLabel7.setBounds(new Rectangle(470, 58, 70, 23));
			jLabel7.setFont(new Font("Dialog", Font.BOLD, 10));
			jLabel7.setText("Market ID:");
			jLabel6 = new JLabel();
			jLabel6.setBounds(new Rectangle(329, 4, 66, 23));
			jLabel6.setFont(new Font("Dialog", Font.BOLD, 10));
			jLabel6.setText("UPD Port:");
			jLabel5 = new JLabel();
			jLabel5.setBounds(new Rectangle(139, 88, 68, 19));
			jLabel5.setFont(new Font("Dialog", Font.BOLD, 10));
			jLabel5.setText("Ack Seq:");
			jLabel4 = new JLabel();
			jLabel4.setBounds(new Rectangle(138, 61, 70, 23));
			jLabel4.setFont(new Font("Dialog", Font.BOLD, 10));
			jLabel4.setText("Password:");
			jLabel3 = new JLabel();
			jLabel3.setBounds(new Rectangle(6, 88, 75, 23));
			jLabel3.setFont(new Font("Dialog", Font.BOLD, 10));
			jLabel3.setText("Sequence:");
			jLabel2 = new JLabel();
			jLabel2.setBounds(new Rectangle(6, 60, 74, 23));
			jLabel2.setFont(new Font("Dialog", Font.BOLD, 10));
			jLabel2.setText("Firm ID:");
			jLabel1 = new JLabel();
			jLabel1.setBounds(new Rectangle(6, 33, 76, 23));
			jLabel1.setFont(new Font("Dialog", Font.BOLD, 10));
			jLabel1.setText("Server Port:");
			jLabel = new JLabel();
			jLabel.setBounds(new Rectangle(6, 7, 74, 23));
			jLabel.setFont(new Font("Dialog", Font.BOLD, 10));
			jLabel.setText("Server IP:");
			jPanel = new JPanel();
			jPanel.setLayout(null);
			jPanel.setBounds(new Rectangle(2, 10, 799, 117));
			// jPanel.setBorder(BorderFactory.createLineBorder(Color.gray, 5));
			jPanel.setBorder(border1);
			jPanel.add(jLabel, null);
			jPanel.add(jLabel1, null);
			jPanel.add(jLabel2, null);
			jPanel.add(jLabel3, null);
			jPanel.add(jLabel4, null);
			jPanel.add(jLabel5, null);
			jPanel.add(getTxtFirmID(), null);
			jPanel.add(getTxtServerPort(), null);
			jPanel.add(getTxtServerIP(), null);
			jPanel.add(getTxtSequence(), null);
			jPanel.add(getTxtUDPPort(), null);
			jPanel.add(getNoPacket(), null);
			jPanel.add(getTxtPassword(), null);
			jPanel.add(getTxtAck(), null);
			jPanel.add(jLabel6, null);
			jPanel.add(jLabel7, null);
			jPanel.add(getTxtMarketID(), null);
			jPanel.add(jLabel8, null);
			jPanel.add(jLabel9, null);
			jPanel.add(getCbPacketType(), null);
			jPanel.add(getModeA(), null);
			jPanel.add(getModeB(), null);
			jPanel.add(getModeC(), null);
			jPanel.add(getBtConnect(), null);
			jPanel.add(getBtDisconnect(), null);
			jPanel.add(getStartUdpListenButton(), null);
			jPanel.add(getBtStopUDP(), null);

			final JButton retransmissionButton = new JButton();
			retransmissionButton.addActionListener(new ActionListener() {
				public void actionPerformed(final ActionEvent arg0) {
					// UDPContent.maxSequence = 0;
				}
			});
			retransmissionButton.setMargin(new Insets(0, 0, 0, 0));
			retransmissionButton.setText("Reset UDP Sequence");
			retransmissionButton.setBounds(329, 85, 122, 22);
			jPanel.add(retransmissionButton);

			final JButton conformanceDay1Button = new JButton();
			conformanceDay1Button.addActionListener(new ActionListener() {
				public void actionPerformed(final ActionEvent arg0) {
					conFrame = new ConformanceFrame();
					conFrame.setModal(false);
					conFrame.setAlwaysOnTop(true);
					conFrame.setVisible(true);
				}
			});
			conformanceDay1Button.setText("Conformance Day1");
			conformanceDay1Button.setBounds(460, 85, 153, 22);
			jPanel.add(conformanceDay1Button);
		}
		return jPanel;
	}

	/**
	 * This method initializes txtFirmID
	 * 
	 * @return javax.swing.JTextField
	 */
	private JTextField getTxtFirmID() {
		if (txtFirmID == null) {
			txtFirmID = new JTextField();
			txtFirmID.setBounds(new Rectangle(92, 59, 41, 23));
			txtFirmID.setFont(new Font("Dialog", Font.PLAIN, 10));
			txtFirmID.setText("057");
		}
		return txtFirmID;
	}

	/**
	 * This method initializes txtServerPort
	 * 
	 * @return javax.swing.JTextField
	 */
	private JTextField getTxtServerPort() {
		if (txtServerPort == null) {
			txtServerPort = new JTextField();
			txtServerPort.setBounds(new Rectangle(90, 29, 110, 23));
			txtServerPort.setFont(new Font("Dialog", Font.PLAIN, 10));
			txtServerPort.setText("30057");
		}
		return txtServerPort;
	}

	/**
	 * This method initializes txtServerIP
	 * 
	 * @return javax.swing.JTextField
	 */
	private JTextField getTxtServerIP() {
		if (txtServerIP == null) {
			txtServerIP = new JTextField();
			txtServerIP.setBounds(new Rectangle(89, 4, 110, 23));
			txtServerIP.setFont(new Font("Dialog", Font.PLAIN, 10));
			txtServerIP.setText("172.16.255.30");
		}
		return txtServerIP;
	}

	/**
	 * This method initializes txtSequence
	 * 
	 * @return javax.swing.JTextField
	 */
	private JTextField getTxtSequence() {
		if (txtSequence == null) {
			txtSequence = new JTextField();
			txtSequence.setBounds(new Rectangle(92, 86, 42, 23));
			txtSequence.setFont(new Font("Dialog", Font.PLAIN, 10));
			txtSequence.setText("1");
		}
		return txtSequence;
	}

	/**
	 * This method initializes txtUDPPort
	 * 
	 * @return javax.swing.JTextField
	 */
	private JTextField getTxtUDPPort() {
		if (txtUDPPort == null) {
			txtUDPPort = new JTextField();
			txtUDPPort.setBounds(new Rectangle(384, 6, 66, 23));
			txtUDPPort.setFont(new Font("Dialog", Font.PLAIN, 10));
			txtUDPPort.setText("30000");
		}
		return txtUDPPort;
	}

	/**
	 * This method initializes noPacket
	 * 
	 * @return javax.swing.JTextField
	 */
	private JTextField getNoPacket() {
		if (noPacket == null) {
			noPacket = new JTextField();
			noPacket.setBounds(new Rectangle(562, 31, 63, 23));
			noPacket.setText("1");
		}
		return noPacket;
	}

	/**
	 * This method initializes txtPassword
	 * 
	 * @return javax.swing.JPasswordField
	 */
	private JPasswordField getTxtPassword() {
		if (txtPassword == null) {
			txtPassword = new JPasswordField();
			txtPassword.setBounds(new Rectangle(212, 60, 109, 20));
			txtPassword.setText("12345678");
		}
		return txtPassword;
	}

	/**
	 * This method initializes txtAck
	 * 
	 * @return javax.swing.JTextField
	 */
	private JTextField getTxtAck() {
		if (txtAck == null) {
			txtAck = new JTextField();
			txtAck.setBounds(new Rectangle(211, 85, 58, 23));
			txtAck.setText("1");
		}
		return txtAck;
	}

	/**
	 * This method initializes txtMarketID
	 * 
	 * @return javax.swing.JTextField
	 */
	private JTextField getTxtMarketID() {
		if (txtMarketID == null) {
			txtMarketID = new JTextField();
			txtMarketID.setBounds(new Rectangle(562, 58, 62, 23));
			txtMarketID.setText("A");
		}
		return txtMarketID;
	}

	/**
	 * This method initializes cbPacketType
	 * 
	 * @return javax.swing.JComboBox
	 */
	private JComboBox getCbPacketType() {
		if (cbPacketType == null) {
			cbPacketType = new JComboBox();
			cbPacketType.setBounds(new Rectangle(562, 4, 81, 23));
			cbPacketType.setFont(new Font("Dialog", Font.BOLD, 10));
			for (int i = 0; i < this.opCode.length; i++) {
				cbPacketType.insertItemAt(this.opCode[i], i);
			}
			cbPacketType.setSelectedIndex(3);
		}
		return cbPacketType;
	}

	/**
	 * This method initializes modeA
	 * 
	 * @return javax.swing.JRadioButton
	 */
	private JRadioButton getModeA() {
		if (modeA == null) {
			modeA = new JRadioButton();
			buttonGroup.add(modeA);
			modeA.setBounds(new Rectangle(666, 4, 82, 21));
			modeA.setText("Mode A");
			modeA.setFont(new Font("Dialog", Font.BOLD, 10));
			modeA.setSelected(true);
		}
		return modeA;
	}

	/**
	 * This method initializes modeB
	 * 
	 * @return javax.swing.JRadioButton
	 */
	private JRadioButton getModeB() {
		if (modeB == null) {
			modeB = new JRadioButton();
			buttonGroup.add(modeB);
			modeB.setBounds(new Rectangle(666, 31, 69, 21));
			modeB.setFont(new Font("Arian", Font.BOLD, 10));
			modeB.setText("Mode B");
		}
		return modeB;
	}

	/**
	 * This method initializes modeC
	 * 
	 * @return javax.swing.JRadioButton
	 */
	private JRadioButton getModeC() {
		if (modeC == null) {
			modeC = new JRadioButton();
			buttonGroup.add(modeC);
			modeC.setBounds(new Rectangle(666, 58, 89, 21));
			modeC.setFont(new Font("Arian", Font.BOLD, 10));
			modeC.setText("Mode C");
		}
		return modeC;
	}

	/**
	 * This method initializes btConnect
	 * 
	 * @return javax.swing.JButton
	 */
	private JButton getBtConnect() {
		if (btConnect == null) {
			btConnect = new JButton();
			btConnect.setBounds(new Rectangle(212, 4, 109, 23));
			btConnect.setActionCommand("btConnect");
			btConnect.setFont(new Font("Arian", Font.BOLD, 10));
			btConnect.setText("Connect");
			btConnect.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					char mode = 'A';
					if (modeA.isSelected())
						mode = 'A';
					if (modeB.isSelected())
						mode = 'B';
					if (modeC.isSelected())
						mode = 'C';

					int showConfirmDialog = JOptionPane.showConfirmDialog(
							getParent(), "Do you want to connect with mode "
									+ mode + "?", "Confirm",
							JOptionPane.YES_NO_OPTION,
							JOptionPane.QUESTION_MESSAGE);
					if (showConfirmDialog == JOptionPane.YES_OPTION) {
						btConnect_actionPerformed(e, mode);
					}
				}
			});

		}
		return btConnect;
	}

	// Connect to Server
	public void btConnect_actionPerformed(java.awt.event.ActionEvent e,
			char mode) {
		String message = "";

		int serverPort = Integer.parseInt(this.txtServerPort.getText());
		controller = null;
		try {
			this.controller = EPSServiceController.getInstance(this.txtServerIP
					.getText(), serverPort, this.txtPassword.getText(), mode);
			// boolean result =
			// controller.connectToServer(this.txtServerIP.getText(),
			// serverPort, this.txtPassword.getText(), mode);
			// if(!result){
			// message = "Can not connect to server.";
			// JOptionPane.showMessageDialog(this, message, "Information",
			// JOptionPane.OK_OPTION);
			// return;
			// }
			if (EPSServiceController.isConnectServerOK()) {
				btConnect.setEnabled(false);
				btDisconnect.setEnabled(true);
			} else {
				controller.releaseInstance();
			}
		} catch (Exception e1) {
			message = e1.getMessage();
			JOptionPane.showMessageDialog(this, message, "Information",
					JOptionPane.OK_OPTION);
			e1.printStackTrace();
		}
	}

	/**
	 * This method initializes btDisconnect
	 * 
	 * @return javax.swing.JButton
	 */
	private JButton getBtDisconnect() {
		if (btDisconnect == null) {
			btDisconnect = new JButton();
			btDisconnect.setBounds(new Rectangle(212, 33, 109, 23));
			btDisconnect.setActionCommand("btDisconnect_actionPerformed");
			btDisconnect.setFont(new Font("Arian", Font.BOLD, 10));
			btDisconnect.setText("Disconnect");
			btDisconnect.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					try {
						controller.disconnectFromClient();

						btConnect.setEnabled(true);
						btDisconnect.setEnabled(false);
					} catch (Exception e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
			});
			btDisconnect.setEnabled(false);
		}
		return btDisconnect;
	}

	/**
	 * This method initializes startUdpListenButton
	 * 
	 * @return javax.swing.JButton
	 */
	private JButton getStartUdpListenButton() {
		if (startUdpListenButton == null) {
			startUdpListenButton = new JButton();
			startUdpListenButton.setName("btStopUDP");
			// startUdpListenButton.setMargin(new Insets(0, 0, 0, 0));
			startUdpListenButton
					.addActionListener(new java.awt.event.ActionListener() {
						public void actionPerformed(
								final java.awt.event.ActionEvent e) {
							try {
								int udpPort = Integer.parseInt(txtUDPPort
										.getText());
								udpClient = new UDPClient(udpPort);

								System.out
										.println("Start UDPClient " + udpPort);
								udpClient.start();
								startUdpListenButton.setEnabled(false);
							} catch (Exception e1) {
								// TODO Auto-generated catch block
								e1.printStackTrace();
							}
						}
					});
			startUdpListenButton.setText("Start UDP Listen");
			startUdpListenButton.setBounds(327, 33, 122, 21);
		}
		return startUdpListenButton;
	}

	/**
	 * This method initializes btStopUDP
	 * 
	 * @return javax.swing.JButton
	 */
	private JButton getBtStopUDP() {
		if (btStopUDP == null) {
			btStopUDP = new JButton();
			btStopUDP.setName("btStopUDP");
			btStopUDP.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(final java.awt.event.ActionEvent e) {
					try {
						System.out.println("Stop UDPClient ");
						udpClient.setStop(true);
						udpClient.interrupt();
						udpClient.stop();
						startUdpListenButton.setEnabled(true);
						udpClient = null;
					} catch (Exception e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
			});

			btStopUDP.setText("Stop UDP Listen");
			btStopUDP.setBounds(328, 59, 122, 21);
		}
		return btStopUDP;
	}

	/**
	 * This method initializes jTabbedPane
	 * 
	 * @return javax.swing.JTabbedPane
	 */
	private JTabbedPane getJTabbedPane() {
		if (jTabbedPane == null) {
			jTabbedPane = new JTabbedPane();
			jTabbedPane.setBounds(new Rectangle(2, 121, 802, 501));

			final JPanel panel_4 = new JPanel();
			panel_4.setLayout(null);
			jTabbedPane.addTab("C2 PreOpen", null, panel_4, null);

			final JLabel maCkLabel_3 = new JLabel();
			maCkLabel_3.setBounds(223, 10, 92, 16);
			maCkLabel_3.setText("Security Symbol");
			panel_4.add(maCkLabel_3);

			ttcTextField_1 = new JTextField();
			ttcTextField_1.setBounds(320, 8, 30, 20);
			ttcTextField_1.setText("STB");
			panel_4.add(ttcTextField_1);
			// 10...
			final JButton button_3_3 = new JButton();
			button_3_3.addActionListener(new ActionListener() {
				public void actionPerformed(final ActionEvent arg0) {
					String sb = ttcTextField_1.getText().trim();
					String orderType = atoTextField.getText().trim();
					NewConditioned_1I send = C21ConformationTest
							.get1IForeignerMessages(sb, orderType);
					controller.log("Chuong trinh chan:" + send.toString());
					// sendOrder(send);
				}
			});
			button_3_3.setBounds(223, 32, 248, 26);
			button_3_3.setText("10 Send Buying order of Foreigner");
			panel_4.add(button_3_3);

			final JLabel maCkLabel_3_1 = new JLabel();
			maCkLabel_3_1.setText("Security Symbol");
			maCkLabel_3_1.setBounds(223, 64, 92, 16);
			panel_4.add(maCkLabel_3_1);

			ttcTextField_2 = new JTextField();
			ttcTextField_2.setText("FMC");
			ttcTextField_2.setBounds(320, 62, 30, 20);
			panel_4.add(ttcTextField_2);

			final JButton button_3_3_1 = new JButton();
			// 11... : buy
			button_3_3_1.addActionListener(new ActionListener() {
				public void actionPerformed(final ActionEvent arg0) {
					String sb = ttcTextField_2.getText().trim();
					String orderType = loTextField.getText().trim();
					NewConditioned_1I send = C21ConformationTest
							.get1IForeignerMessages(sb, orderType);
					sendOrder(send);
				}
			});
			button_3_3_1.setText("11 Send Buying order of Foreigner");
			button_3_3_1.setBounds(223, 86, 248, 26);
			panel_4.add(button_3_3_1);

			atoTextField = new JTextField();
			atoTextField.setText("ATO");
			atoTextField.setBounds(356, 8, 87, 20);
			panel_4.add(atoTextField);

			loTextField = new JTextField();
			loTextField.setText("LO");
			loTextField.setBounds(356, 62, 87, 20);
			panel_4.add(loTextField);

			final JLabel maCkLabel_3_1_1 = new JLabel();
			maCkLabel_3_1_1.setText("Security Symbol");
			maCkLabel_3_1_1.setBounds(223, 118, 92, 16);
			panel_4.add(maCkLabel_3_1_1);

			ttcTextField_3 = new JTextField();
			ttcTextField_3.setText("TDH");
			ttcTextField_3.setBounds(320, 116, 30, 20);
			panel_4.add(ttcTextField_3);

			loTextField_1 = new JTextField();
			loTextField_1.setText("LO");
			loTextField_1.setBounds(356, 116, 87, 20);
			panel_4.add(loTextField_1);
			// 12...
			final JButton button_3_3_1_1 = new JButton();
			button_3_3_1_1.addActionListener(new ActionListener() {
				public void actionPerformed(final ActionEvent arg0) {
					String sb = ttcTextField_3.getText().trim();
					String orderType = loTextField_1.getText().trim();
					NewConditioned_1I send = C21ConformationTest
							.get1IForeignerMessages(sb, orderType);
					// sendOrder(send);
					controller.log("Chuong trinh chan:" + send.toString());
				}
			});
			button_3_3_1_1.setText("12 Send Buying order of Foreigner");
			button_3_3_1_1.setBounds(223, 140, 248, 26);
			panel_4.add(button_3_3_1_1);

			final JButton button_2_2_1_1_1_2 = new JButton();
			// 13... : Bond
			button_2_2_1_1_1_2.addActionListener(new ActionListener() {
				public void actionPerformed(final ActionEvent e) {
					String type = "F";
					String sb = TestCommon.createRandomBond();
					TwoFirmPutThroughDeal_1G object = C21ConformationTest
							.get1GForeignerMessage(sb, type);
					// OneFirmPutThroughDeal_1F object =
					// C21ConformationTest.get1GForeignerMessage();
					sendOrder(object);
				}
			});
			button_2_2_1_1_1_2.setMargin(new Insets(0, 0, 0, 0));
			button_2_2_1_1_1_2.setText("13. Send PT Deal c1 (1G Investor)");
			button_2_2_1_1_1_2.setBounds(223, 176, 190, 26);
			panel_4.add(button_2_2_1_1_1_2);
			// 14... send bond
			final JButton button_2_2_1_1_1_3 = new JButton();
			button_2_2_1_1_1_3.addActionListener(new ActionListener() {
				public void actionPerformed(final ActionEvent e) {
					String type = "P";
					OneFirmPutThroughDeal_1F object = C21ConformationTest
							.get1FMessage("", type);
					sendOrder(object);
				}
			});
			button_2_2_1_1_1_3.setMargin(new Insets(0, 0, 0, 0));
			button_2_2_1_1_1_3.setText("14. Send PT Deal c2 (1F Portfolio)");
			button_2_2_1_1_1_3.setBounds(223, 215, 190, 26);
			panel_4.add(button_2_2_1_1_1_3);
			// 15...
			final JButton button_2_2_1_3 = new JButton();
			button_2_2_1_3.addActionListener(new ActionListener() {
				public void actionPerformed(final ActionEvent e) {
					String sb = gmdTextField_4.getText().trim();
					String session = "PREOPEN";
					Advertisement_1E object = C21ConformationTest.get1EMessage(
							sb, session);
					controller.log("Chuong trinh chan:" + object.toString());
				}
			});
			button_2_2_1_3.setText("15. Send PT Advertisement c.1");
			button_2_2_1_3.setBounds(477, 32, 223, 26);
			panel_4.add(button_2_2_1_3);
			// 16...
			final JButton button_2_2_1_4 = new JButton();
			button_2_2_1_4.addActionListener(new ActionListener() {
				public void actionPerformed(final ActionEvent arg0) {
					String SecuritySymbol = ttcTextField_4.getText().trim();
					String session = "PREOPEN";
					String buysell = "S";
					String addcancel = "A";
					Advertisement_1E object = C21ConformationTest.get1EMessage(
							SecuritySymbol, session, buysell, addcancel);
					sendOrder(object);
				}
			});
			button_2_2_1_4.setText("16. Send PT Advertisement c.2");
			button_2_2_1_4.setBounds(477, 86, 223, 26);
			panel_4.add(button_2_2_1_4);

			final JLabel maCkLabel_3_2 = new JLabel();
			maCkLabel_3_2.setText("Security Symbol");
			maCkLabel_3_2.setBounds(477, 8, 92, 16);
			panel_4.add(maCkLabel_3_2);

			gmdTextField_4 = new JTextField();
			gmdTextField_4.setText("GMD");
			gmdTextField_4.setBounds(574, 6, 38, 20);
			panel_4.add(gmdTextField_4);

			final JLabel maCkLabel_3_1_2 = new JLabel();
			maCkLabel_3_1_2.setText("Bond Symbol");
			maCkLabel_3_1_2.setBounds(477, 62, 92, 16);
			panel_4.add(maCkLabel_3_1_2);

			ttcTextField_4 = new JTextField();
			ttcTextField_4.setText("HCMA1805");
			ttcTextField_4.setBounds(574, 60, 79, 20);
			panel_4.add(ttcTextField_4);

			final JLabel maCkLabel_3_2_1 = new JLabel();
			maCkLabel_3_2_1.setText("Security Symbol");
			maCkLabel_3_2_1.setBounds(487, 118, 92, 16);
			panel_4.add(maCkLabel_3_2_1);

			gmdTextField = new JTextField();
			gmdTextField.setText("GMD");
			gmdTextField.setBounds(584, 116, 38, 20);
			panel_4.add(gmdTextField);
			// 18...
			final JButton button_2_2_1_3_1 = new JButton();
			button_2_2_1_3_1.addActionListener(new ActionListener() {
				public void actionPerformed(final ActionEvent e) {
					String SecuritySymbol = gmdTextField.getText().trim();
					String session = "PREOPEN";
					String buysell = "S";
					String addcancel = "A";
					Advertisement_1E object = C21ConformationTest.get1EMessage(
							SecuritySymbol, session, buysell, addcancel);
					controller.log("Chuong trinh chan:" + object.toString());
				}
			});
			button_2_2_1_3_1.setText("18. Send Cancel PT Advertisement c.3");
			button_2_2_1_3_1.setBounds(487, 142, 223, 26);
			panel_4.add(button_2_2_1_3_1);

			final JLabel maCkLabel_3_1_2_1 = new JLabel();
			maCkLabel_3_1_2_1.setText("Bond Symbol");
			maCkLabel_3_1_2_1.setBounds(487, 172, 92, 16);
			panel_4.add(maCkLabel_3_1_2_1);

			ttcTextField_5 = new JTextField();
			ttcTextField_5.setText("HCMA1805");
			ttcTextField_5.setBounds(584, 170, 92, 20);
			panel_4.add(ttcTextField_5);
			// 19...
			final JButton button_2_2_1_4_1 = new JButton();
			button_2_2_1_4_1.addActionListener(new ActionListener() {
				public void actionPerformed(final ActionEvent e) {
					String SecuritySymbol = ttcTextField_5.getText().trim();
					String session = "PREOPEN";
					String buysell = "S";
					String addcancel = "C";
					Advertisement_1E object = C21ConformationTest.get1EMessage(
							SecuritySymbol, session, buysell, addcancel);
					sendOrder(object);
				}
			});
			button_2_2_1_4_1.setText("19. Send Cancel PT Advertisement c.1");
			button_2_2_1_4_1.setBounds(487, 196, 223, 26);
			panel_4.add(button_2_2_1_4_1);

			txtSecSym = new JTextField();
			txtSecSym.setBounds(10, 89, 87, 20);
			panel_4.add(txtSecSym);

			txtLO = new JTextField();
			txtLO.setBounds(10, 116, 87, 20);
			panel_4.add(txtLO);

			final JLabel ssiabtLabel = new JLabel();
			ssiabtLabel.setText("(SSI,ABT)");
			ssiabtLabel.setBounds(102, 91, 66, 16);
			panel_4.add(ssiabtLabel);

			final JLabel loatcLabel = new JLabel();
			loatcLabel.setText("(LO,ATC, ...)");
			loatcLabel.setBounds(103, 118, 66, 16);
			panel_4.add(loatcLabel);

			final JButton sendOrderButton = new JButton();
			sendOrderButton.addActionListener(new ActionListener() {
				// 6...
				public void actionPerformed(final ActionEvent arg0) {
					System.out.println(txtSecSym.getText());
					System.out.println(txtLO.getText());
					NewConditioned_1I get1IMessage = C21ConformationTest
							.get1IMessage("B", txtLO.getText(), txtSecSym
									.getText());
					System.out.println(get1IMessage.toString());
					sendOrder(get1IMessage);
				}
			});
			sendOrderButton.setText("Send Order");
			sendOrderButton.setBounds(10, 142, 158, 26);
			panel_4.add(sendOrderButton);

			final JButton sendOrderButton_1 = new JButton();
			sendOrderButton_1.addActionListener(new ActionListener() {
				// 8...
				public void actionPerformed(final ActionEvent e) {
					NewConditioned_1I get1IMessages = C21ConformationTest
							.getOrder("MP");
					controller.log("Chuong trinh chan : "
							+ get1IMessages.toString());
				}
			});
			sendOrderButton_1.setText("8. Send Order c.4 ");
			sendOrderButton_1.setBounds(10, 196, 158, 26);
			panel_4.add(sendOrderButton_1);

			final JButton sendOrderButton_1_1 = new JButton();
			sendOrderButton_1_1.addActionListener(new ActionListener() {
				// 9...
				public void actionPerformed(final ActionEvent e) {
					NewConditioned_1I get1IMessages = C21ConformationTest
							.getOrder("ATC");
					controller.log("Chuong trinh chan : "
							+ get1IMessages.toString());
				}
			});
			sendOrderButton_1_1.setText("9. Send Order c.5 ");
			sendOrderButton_1_1.setBounds(10, 239, 158, 26);
			panel_4.add(sendOrderButton_1_1);

			final JButton sendOrderButton_1_1_1 = new JButton();
			sendOrderButton_1_1_1.addActionListener(new ActionListener() {
				// 20...
				public void actionPerformed(final ActionEvent e) {
					sendOrders(1);
				}
			});
			sendOrderButton_1_1_1.setText("20. Send Valid Order");
			sendOrderButton_1_1_1.setBounds(10, 314, 158, 26);
			panel_4.add(sendOrderButton_1_1_1);

			txt19 = new JTextField();
			txt19.setBounds(223, 290, 87, 20);
			panel_4.add(txt19);

			final JButton sendOrderButton_1_1_1_1 = new JButton();
			sendOrderButton_1_1_1_1.addActionListener(new ActionListener() {
				// 20...
				public void actionPerformed(final ActionEvent e) {
					System.out.println(txt19.getText());
					OrderCancellation_1C get1CMessage = Day1FunctionTest
							.get1CMessage(txt19.getText());
					sendOrder(get1CMessage);
				}
			});
			sendOrderButton_1_1_1_1
					.setText("20. Send cancel confirmed order  c.1");
			sendOrderButton_1_1_1_1.setBounds(223, 314, 280, 26);
			panel_4.add(sendOrderButton_1_1_1_1);

			final JPanel panel_5 = new JPanel();
			panel_5.setLayout(null);
			jTabbedPane.addTab("C2 Open", null, panel_5, null);

			final JLabel maCkLabel_3_2_2 = new JLabel();
			maCkLabel_3_2_2.setBounds(344, 7, 92, 16);
			maCkLabel_3_2_2.setText("Security Symbol");
			panel_5.add(maCkLabel_3_2_2);

			gmdTextField_1 = new JTextField();
			gmdTextField_1.setBounds(441, 5, 31, 20);
			gmdTextField_1.setText("BMC");
			panel_5.add(gmdTextField_1);

			final JButton button_2_2_1_3_2 = new JButton();
			// 37...
			button_2_2_1_3_2.addActionListener(new ActionListener() {
				public void actionPerformed(final ActionEvent e) {
					String sb = gmdTextField_1.getText().trim();
					String session = "OPEN";
					Advertisement_1E object = C21ConformationTest.get1EMessage(
							sb, session);
					controller.log("Chuong trinh chan:" + object.toString());
				}
			});
			button_2_2_1_3_2.setBounds(344, 31, 207, 26);
			button_2_2_1_3_2.setText("37. Send PT Advertisement c.3");
			panel_5.add(button_2_2_1_3_2);

			final JLabel maCkLabel_3_1_2_2 = new JLabel();
			maCkLabel_3_1_2_2.setBounds(344, 68, 74, 16);
			maCkLabel_3_1_2_2.setText("Bond Symbol");
			panel_5.add(maCkLabel_3_1_2_2);

			ttcTextField_6 = new JTextField();
			ttcTextField_6.setBounds(423, 66, 66, 20);
			ttcTextField_6.setText("HCM_0204");
			panel_5.add(ttcTextField_6);

			final JButton button_2_2_1_4_2 = new JButton();
			// 38...
			button_2_2_1_4_2.addActionListener(new ActionListener() {
				public void actionPerformed(final ActionEvent e) {
					String SecuritySymbol = "HCM_0204";
					String session = "OPEN";
					String buysell = "S";
					String addcancel = "A";
					Advertisement_1E object = C21ConformationTest.get1EMessage(
							SecuritySymbol, session, buysell, addcancel);
					sendOrder(object);
				}
			});
			button_2_2_1_4_2.setBounds(344, 90, 207, 26);
			button_2_2_1_4_2.setText("38. Send PT Advertisement c.4");
			panel_5.add(button_2_2_1_4_2);
			// 39...
			final JButton button_2_2_1_1_1_2_1 = new JButton();
			button_2_2_1_1_1_2_1.addActionListener(new ActionListener() {
				public void actionPerformed(final ActionEvent e) {
					String type = "F";
					String sb = "HCM_0204";
					OneFirmPutThroughDeal_1F object = C21ConformationTest
							.get1FMessage(sb, "", type);
					sendOrder(object);

				}
			});
			button_2_2_1_1_1_2_1.setMargin(new Insets(0, 0, 0, 0));
			button_2_2_1_1_1_2_1.setText("39. Send PT Deal c3 1F (Bond)");
			button_2_2_1_1_1_2_1.setBounds(344, 122, 190, 26);
			panel_5.add(button_2_2_1_1_1_2_1);
			// 39...
			final JButton button_2_2_1_1_1_3_1 = new JButton();
			button_2_2_1_1_1_3_1.addActionListener(new ActionListener() {
				public void actionPerformed(final ActionEvent e) {
					String type = "F";
					String sb = "SSC";
					OneFirmPutThroughDeal_1F object = C21ConformationTest
							.get1FMessage(sb, "", type);
					controller.log("Chuong trinh chan:" + object.toString());
				}
			});
			button_2_2_1_1_1_3_1.setMargin(new Insets(0, 0, 0, 0));
			button_2_2_1_1_1_3_1.setText("40. Send PT Deal c3 1F (SSC)");
			button_2_2_1_1_1_3_1.setBounds(344, 154, 190, 26);
			panel_5.add(button_2_2_1_1_1_3_1);

			final JLabel maCkLabel_3_1_3 = new JLabel();
			maCkLabel_3_1_3.setText("Security Symbol");
			maCkLabel_3_1_3.setBounds(344, 193, 92, 16);
			panel_5.add(maCkLabel_3_1_3);

			ttcTextField_7 = new JTextField();
			ttcTextField_7.setText("VFMVF1");
			ttcTextField_7.setBounds(441, 191, 74, 20);
			panel_5.add(ttcTextField_7);

			loTextField_2 = new JTextField();
			loTextField_2.setText("LO");
			loTextField_2.setBounds(521, 191, 31, 20);
			panel_5.add(loTextField_2);
			// 41...
			final JButton button_3_3_1_2 = new JButton();
			button_3_3_1_2.addActionListener(new ActionListener() {
				public void actionPerformed(final ActionEvent e) {
					String sb = ttcTextField_7.getText().trim();
					String orderType = loTextField_2.getText().trim();
					NewConditioned_1I send = C21ConformationTest
							.get1IForeignerMessages(sb, orderType);
					// sendOrder(send);
					controller.log("Chuong trinh chan:" + send.toString());
				}
			});
			button_3_3_1_2.setText("41 Send Order c23");
			button_3_3_1_2.setBounds(344, 215, 179, 26);
			panel_5.add(button_3_3_1_2);

			final JLabel maCkLabel_3_1_1_1 = new JLabel();
			maCkLabel_3_1_1_1.setText("Security Symbol");
			maCkLabel_3_1_1_1.setBounds(344, 247, 92, 16);
			panel_5.add(maCkLabel_3_1_1_1);

			ttcTextField_8 = new JTextField();
			ttcTextField_8.setText("KHP");
			ttcTextField_8.setBounds(441, 245, 30, 20);
			panel_5.add(ttcTextField_8);

			loTextField_3 = new JTextField();
			loTextField_3.setText("LO");
			loTextField_3.setBounds(477, 245, 41, 20);
			panel_5.add(loTextField_3);
			// 42...
			final JButton button_3_3_1_2_1 = new JButton();
			button_3_3_1_2_1.addActionListener(new ActionListener() {
				public void actionPerformed(final ActionEvent e) {
					String sb = ttcTextField_8.getText().trim();
					String orderType = loTextField_3.getText().trim();
					NewConditioned_1I send = C21ConformationTest
							.get1IForeignerMessages(sb, orderType);
					sendOrder(send);
				}
			});
			button_3_3_1_2_1.setText("42 Send Order c24");
			button_3_3_1_2_1.setBounds(344, 276, 179, 26);
			panel_5.add(button_3_3_1_2_1);

			final JLabel maCkLabel_3_1_3_1 = new JLabel();
			maCkLabel_3_1_3_1.setText("Security Symbol");
			maCkLabel_3_1_3_1.setBounds(567, 7, 92, 16);
			panel_5.add(maCkLabel_3_1_3_1);

			ttcTextField_9 = new JTextField();
			ttcTextField_9.setText("AGF");
			ttcTextField_9.setBounds(664, 5, 74, 20);
			panel_5.add(ttcTextField_9);

			loTextField_4 = new JTextField();
			loTextField_4.setText("LO");
			loTextField_4.setBounds(744, 5, 31, 20);
			panel_5.add(loTextField_4);
			// 43...
			final JButton button_3_3_1_2_2 = new JButton();
			button_3_3_1_2_2.addActionListener(new ActionListener() {
				public void actionPerformed(final ActionEvent e) {
					String sb = ttcTextField_9.getText().trim();
					String orderType = loTextField_4.getText().trim();
					NewConditioned_1I send = C21ConformationTest
							.get1IForeignerMessages(sb, orderType);
					// sendOrder(send);
					controller.log("Chuong trinh chan:" + send.toString());

				}
			});
			button_3_3_1_2_2.setText("43. Send Order c25");
			button_3_3_1_2_2.setBounds(567, 29, 179, 26);
			panel_5.add(button_3_3_1_2_2);

			final JLabel maCkLabel_3_1_1_1_1 = new JLabel();
			maCkLabel_3_1_1_1_1.setText("Security Symbol");
			maCkLabel_3_1_1_1_1.setBounds(567, 61, 92, 16);
			panel_5.add(maCkLabel_3_1_1_1_1);

			ttcTextField_10 = new JTextField();
			ttcTextField_10.setText("BT6");
			ttcTextField_10.setBounds(664, 59, 30, 20);
			panel_5.add(ttcTextField_10);

			loTextField_5 = new JTextField();
			loTextField_5.setText("LO");
			loTextField_5.setBounds(700, 59, 87, 20);
			panel_5.add(loTextField_5);
			// 44...
			final JButton button_3_3_1_2_1_1 = new JButton();
			button_3_3_1_2_1_1.addActionListener(new ActionListener() {
				public void actionPerformed(final ActionEvent e) {
					String sb = ttcTextField_10.getText().trim();
					String orderType = loTextField_5.getText().trim();
					NewConditioned_1I send = C21ConformationTest
							.get1IForeignerMessages(sb, orderType);
					// sendOrder(send);
					controller.log("Chuong trinh chan:" + send.toString());
				}
			});
			button_3_3_1_2_1_1.setText("44 Send Order c26");
			button_3_3_1_2_1_1.setBounds(567, 90, 179, 26);
			panel_5.add(button_3_3_1_2_1_1);

			final JLabel maCkLabel_3_1_1_1_1_1 = new JLabel();
			maCkLabel_3_1_1_1_1_1.setText("Security Symbol");
			maCkLabel_3_1_1_1_1_1.setBounds(567, 122, 92, 16);
			panel_5.add(maCkLabel_3_1_1_1_1_1);

			ttcTextField_11 = new JTextField();
			ttcTextField_11.setText("ANV");
			ttcTextField_11.setBounds(664, 120, 30, 20);
			panel_5.add(ttcTextField_11);

			loTextField_6 = new JTextField();
			loTextField_6.setText("LO");
			loTextField_6.setBounds(700, 120, 87, 20);
			panel_5.add(loTextField_6);
			// 45...
			final JButton button_3_3_1_2_1_1_1 = new JButton();
			button_3_3_1_2_1_1_1.addActionListener(new ActionListener() {
				public void actionPerformed(final ActionEvent e) {
					String sb = ttcTextField_11.getText().trim();
					String orderType = loTextField_6.getText().trim();
					NewConditioned_1I send = C21ConformationTest
							.get1IForeignerMessages(sb, orderType);
					sendOrder(send);
				}
			});
			button_3_3_1_2_1_1_1.setText("45 Send Order c27");
			button_3_3_1_2_1_1_1.setBounds(567, 144, 179, 26);
			panel_5.add(button_3_3_1_2_1_1_1);
			// 46...
			final JButton button_2_2_1_3_2_1 = new JButton();
			button_2_2_1_3_2_1.addActionListener(new ActionListener() {
				public void actionPerformed(final ActionEvent e) {
					String SecuritySymbol = "BMC";
					String session = "OPEN";
					String buysell = "B";
					String addcancel = "C";
					Advertisement_1E object = C21ConformationTest.get1EMessage(
							SecuritySymbol, session, buysell, addcancel);
					controller.log("Chuong trinh chan:" + object.toString());
				}
			});
			button_2_2_1_3_2_1.setMargin(new Insets(0, 0, 0, 0));
			button_2_2_1_3_2_1.setText("46. Send Cancel PT Advertisement c.3");
			button_2_2_1_3_2_1.setBounds(558, 176, 229, 26);
			panel_5.add(button_2_2_1_3_2_1);
			// 47...
			final JButton button_2_2_1_3_2_1_1 = new JButton();
			button_2_2_1_3_2_1_1.addActionListener(new ActionListener() {
				public void actionPerformed(final ActionEvent e) {
					String SecuritySymbol = "HCM_0204";
					String session = "OPEN";
					String buysell = "S";
					String addcancel = "C";
					Advertisement_1E object = C21ConformationTest.get1EMessage(
							SecuritySymbol, session, buysell, addcancel);
					sendOrder(object);
				}
			});
			button_2_2_1_3_2_1_1.setMargin(new Insets(0, 0, 0, 0));
			button_2_2_1_3_2_1_1
					.setText("47. Send Cancel PT Advertisement c.3");
			button_2_2_1_3_2_1_1.setBounds(558, 215, 229, 26);
			panel_5.add(button_2_2_1_3_2_1_1);
			// 48...
			final JButton button_2_2_1_3_2_1_2 = new JButton();
			button_2_2_1_3_2_1_2.addActionListener(new ActionListener() {
				public void actionPerformed(final ActionEvent e) {
				}
			});
			button_2_2_1_3_2_1_2.setMargin(new Insets(0, 0, 0, 0));
			button_2_2_1_3_2_1_2.setText("48. Send Cancel PT Deal c1 (3C)");
			button_2_2_1_3_2_1_2.setBounds(558, 247, 229, 26);
			panel_5.add(button_2_2_1_3_2_1_2);
			// 48...
			final JButton button_2_2_1_3_2_1_1_1 = new JButton();
			button_2_2_1_3_2_1_1_1.addActionListener(new ActionListener() {
				public void actionPerformed(final ActionEvent e) {
					controller.log("Chuong trinh chan");

				}
			});
			button_2_2_1_3_2_1_1_1.setMargin(new Insets(0, 0, 0, 0));
			button_2_2_1_3_2_1_1_1.setText("49. Send Cancel PT Deal c2 (3C)");
			button_2_2_1_3_2_1_1_1.setBounds(558, 286, 229, 26);
			panel_5.add(button_2_2_1_3_2_1_1_1);

			final JButton button_3_3_1_2_1_2 = new JButton();
			button_3_3_1_2_1_2.addActionListener(new ActionListener() {
				// 23...
				public void actionPerformed(final ActionEvent e) {
					NewConditioned_1I get1IMessages = C21ConformationTest
							.get1IMessage("B", "ATO", "SAM");
					controller.log("Chuong trinh chan : "
							+ get1IMessages.toString());
				}
			});
			button_3_3_1_2_1_2.setText("23. Send Order c.9 ");
			button_3_3_1_2_1_2.setBounds(10, 29, 179, 26);
			panel_5.add(button_3_3_1_2_1_2);

			final JButton button_3_3_1_2_1_2_1 = new JButton();
			button_3_3_1_2_1_2_1.addActionListener(new ActionListener() {
				// 24...
				public void actionPerformed(final ActionEvent e) {
					controller
							.log("Chuong trinh chan. Khong the goi LO cho ma trai phieu ");
				}
			});
			button_3_3_1_2_1_2_1.setText("24. Send Order c.10 ");
			button_3_3_1_2_1_2_1.setBounds(10, 68, 179, 26);
			panel_5.add(button_3_3_1_2_1_2_1);

			final JButton button_3_3_1_2_1_2_1_1 = new JButton();
			button_3_3_1_2_1_2_1_1.addActionListener(new ActionListener() {
				// 25...
				public void actionPerformed(final ActionEvent e) {
					controller
							.log("Chuong trinh chan. Khong the goi LO cho ma trai phieu ");
				}
			});
			button_3_3_1_2_1_2_1_1.setText("25. Send Order c.11 ");
			button_3_3_1_2_1_2_1_1.setBounds(10, 117, 179, 26);
			panel_5.add(button_3_3_1_2_1_2_1_1);

			final JButton button_3_3_1_2_1_2_1_1_1 = new JButton();
			button_3_3_1_2_1_2_1_1_1.addActionListener(new ActionListener() {
				// 26...
				public void actionPerformed(final ActionEvent e) {
					controller
							.log("Chuong trinh chan. Ma trai phieu khong ton tai");
				}
			});
			button_3_3_1_2_1_2_1_1_1.setText("26. Send Order c.12");
			button_3_3_1_2_1_2_1_1_1.setBounds(10, 154, 179, 26);
			panel_5.add(button_3_3_1_2_1_2_1_1_1);

			final JButton button_3_3_1_2_1_2_1_1_1_1 = new JButton();
			button_3_3_1_2_1_2_1_1_1_1.addActionListener(new ActionListener() {
				// 27...
				public void actionPerformed(final ActionEvent e) {
					controller
							.log("Chuong trinh chan. Ma co phieu khong ton tai");
				}
			});
			button_3_3_1_2_1_2_1_1_1_1.setText("27. Send Order c.13 ");
			button_3_3_1_2_1_2_1_1_1_1.setBounds(10, 193, 179, 26);
			panel_5.add(button_3_3_1_2_1_2_1_1_1_1);

			final JButton button_3_3_1_2_1_2_1_1_1_1_1 = new JButton();
			button_3_3_1_2_1_2_1_1_1_1_1
					.addActionListener(new ActionListener() {
						// 29...
						public void actionPerformed(final ActionEvent e) {
							NewConditioned_1I get1IMessages = C21ConformationTest
									.get1IMessage("B", "ATO", "ICF");
							controller.log("Chuong trinh chan : "
									+ get1IMessages.toString());
						}
					});
			button_3_3_1_2_1_2_1_1_1_1_1.setText("29. Send Order c.15 ");
			button_3_3_1_2_1_2_1_1_1_1_1.setBounds(10, 242, 179, 26);
			panel_5.add(button_3_3_1_2_1_2_1_1_1_1_1);

			final JButton button_3_3_1_2_1_2_1_1_1_1_1_1 = new JButton();
			button_3_3_1_2_1_2_1_1_1_1_1_1
					.addActionListener(new ActionListener() {
						// 30...
						public void actionPerformed(final ActionEvent e) {
							NewConditioned_1I get1IMessages = C21ConformationTest
									.get1IMessage("B", "ATC", "GTA");
							controller.log("Chuong trinh chan : "
									+ get1IMessages.toString());
						}
					});
			button_3_3_1_2_1_2_1_1_1_1_1_1.setText("30. Send Order c.16 ");
			button_3_3_1_2_1_2_1_1_1_1_1_1.setBounds(10, 276, 179, 26);
			panel_5.add(button_3_3_1_2_1_2_1_1_1_1_1_1);

			final JButton button_3_3_1_2_1_2_1_1_1_1_1_1_1 = new JButton();
			button_3_3_1_2_1_2_1_1_1_1_1_1_1
					.addActionListener(new ActionListener() {
						// 30
						public void actionPerformed(final ActionEvent e) {
							NewConditioned_1I get1IMessages = C21ConformationTest
									.get1IMessage("B", "", "BMC");
							controller.log("Chuong trinh chan : "
									+ get1IMessages.toString());
						}
					});
			button_3_3_1_2_1_2_1_1_1_1_1_1_1.setText("31. Send Order c.17");
			button_3_3_1_2_1_2_1_1_1_1_1_1_1.setBounds(10, 308, 179, 26);
			panel_5.add(button_3_3_1_2_1_2_1_1_1_1_1_1_1);

			final JButton button_3_3_1_2_1_2_1_1_2 = new JButton();
			button_3_3_1_2_1_2_1_1_2.addActionListener(new ActionListener() {
				// 35...
				public void actionPerformed(final ActionEvent e) {
					controller
							.log("Chuong trinh chan. Khong the goi LO cho trai phieu");
				}
			});
			button_3_3_1_2_1_2_1_1_2.setText("35. Send Order c.21 ");
			button_3_3_1_2_1_2_1_1_2.setBounds(10, 346, 179, 26);
			panel_5.add(button_3_3_1_2_1_2_1_1_2);

			final JButton button_3_3_1_2_1_2_1_1_2_1 = new JButton();
			button_3_3_1_2_1_2_1_1_2_1.addActionListener(new ActionListener() {
				// 36...
				public void actionPerformed(final ActionEvent e) {
					controller
							.log("Chuong trinh chan. Khong the goi LO cho trai phieu");
				}
			});
			button_3_3_1_2_1_2_1_1_2_1.setText("36. Send Order c.22 ");
			button_3_3_1_2_1_2_1_1_2_1.setBounds(213, 346, 179, 26);
			panel_5.add(button_3_3_1_2_1_2_1_1_2_1);

			final JPanel panel_6 = new JPanel();
			panel_6.setLayout(null);
			jTabbedPane.addTab("C2 PreClose", null, panel_6, null);
			// 57...
			final JButton button_2_3_2_1_2_1_1 = new JButton();
			button_2_3_2_1_2_1_1.addActionListener(new ActionListener() {
				public void actionPerformed(final ActionEvent e) {
					String SecuritySymbol = "BID1_106";
					String session = "RECLOSE";
					String buysell = "B";
					String addcancel = "C";
					Advertisement_1E object = C21ConformationTest.get1EMessage(
							SecuritySymbol, session, buysell, addcancel);
					// sendOrder(object);
					controller.log("Chuong trinh chan:" + object.toString());
				}
			});
			button_2_3_2_1_2_1_1.setBounds(369, 33, 204, 22);
			button_2_3_2_1_2_1_1.setMargin(new Insets(0, 0, 0, 0));
			button_2_3_2_1_2_1_1
					.setText("56. Cancel PT Advertisement c.3 (1E)");
			panel_6.add(button_2_3_2_1_2_1_1);

			final JButton button_2_3_2_1_2_1 = new JButton();
			button_2_3_2_1_2_1.setBounds(369, 5, 204, 22);
			button_2_3_2_1_2_1.addActionListener(new ActionListener() {
				public void actionPerformed(final ActionEvent arg0) {
					String sb = cp1c0101TextField_1.getText().trim();
					String session = "PRECLOSE";
					Advertisement_1E object = C21ConformationTest.get1EMessage(
							sb, session);
					sendOrder(object);
				}
			});
			button_2_3_2_1_2_1.setMargin(new Insets(0, 0, 0, 0));
			button_2_3_2_1_2_1.setText("56. Send PT Advertisement c.5 (1E)");
			panel_6.add(button_2_3_2_1_2_1);

			cp1c0101TextField_1 = new JTextField();
			cp1c0101TextField_1.setBounds(578, 6, 59, 20);
			cp1c0101TextField_1.setText("MAFPF1");
			panel_6.add(cp1c0101TextField_1);

			final JButton button_3_3_1_2_1_2_2 = new JButton();
			button_3_3_1_2_1_2_2.addActionListener(new ActionListener() {
				// 50...
				public void actionPerformed(final ActionEvent e) {
					controller
							.log("Chuong trinh chan. Khong the goi MP cho trai phieu");
				}
			});
			button_3_3_1_2_1_2_2.setText("50. Send Order c.28 ");
			button_3_3_1_2_1_2_2.setBounds(10, 31, 179, 26);
			panel_6.add(button_3_3_1_2_1_2_2);

			final JButton button_3_3_1_2_1_2_2_1 = new JButton();
			button_3_3_1_2_1_2_2_1.addActionListener(new ActionListener() {
				// 51...
				public void actionPerformed(final ActionEvent e) {
					NewConditioned_1I get1IMessages = C21ConformationTest
							.get1IMessage("B", "MP", "ITA");
					controller.log("Chuong trinh chan : "
							+ get1IMessages.toString());
				}
			});
			button_3_3_1_2_1_2_2_1.setText("51. Send Order c.29 ");
			button_3_3_1_2_1_2_2_1.setBounds(10, 63, 179, 26);
			panel_6.add(button_3_3_1_2_1_2_2_1);

			final JButton button_3_3_1_2_1_2_2_1_1 = new JButton();
			button_3_3_1_2_1_2_2_1_1.addActionListener(new ActionListener() {
				// 54...
				public void actionPerformed(final ActionEvent e) {
					NewConditioned_1I get1IMessages = C21ConformationTest
							.get1IMessage("B", "ATO", "HTV");
					controller.log("Chuong trinh chan : "
							+ get1IMessages.toString());
				}
			});
			button_3_3_1_2_1_2_2_1_1.setText("54. Send Order c.32 ");
			button_3_3_1_2_1_2_2_1_1.setBounds(10, 129, 179, 26);
			panel_6.add(button_3_3_1_2_1_2_2_1_1);

			final JPanel panel_7 = new JPanel();
			panel_7.setLayout(null);
			jTabbedPane.addTab("C2 Close", null, panel_7, null);
			// 60...
			final JButton button_2_3_2_1_2 = new JButton();
			button_2_3_2_1_2.addActionListener(new ActionListener() {
				public void actionPerformed(final ActionEvent e) {
					String sb = cp1c0101TextField.getText().trim();
					Advertisement_1E object = C21ConformationTest
							.get1EMessageRunOff(sb);
					// sendOrder(object);
					controller.log("Chuong trinh chan:" + object.toString());
				}
			});
			button_2_3_2_1_2.setMargin(new Insets(0, 0, 0, 0));
			button_2_3_2_1_2.setText("60. Send PT Advertisement c.6 (1E)");
			button_2_3_2_1_2.setBounds(24, 10, 225, 26);
			panel_7.add(button_2_3_2_1_2);

			final JButton button_2_3_2_1_1_2 = new JButton();
			button_2_3_2_1_1_2.addActionListener(new ActionListener() {
				public void actionPerformed(final ActionEvent e) {
					String sb = cp1_0100TextField.getText().trim();
					Advertisement_1E object = C21ConformationTest
							.get1EMessageRunOff(sb);
					sendOrder(object);
				}
			});
			button_2_3_2_1_1_2.setMargin(new Insets(0, 0, 0, 0));
			button_2_3_2_1_1_2
					.setText("61. Send PT Advertisement c.7 (1E Bond)");
			button_2_3_2_1_1_2.setBounds(24, 53, 225, 26);
			panel_7.add(button_2_3_2_1_1_2);
			// 62...
			final JButton button_2_2_1_2_1_4 = new JButton();
			button_2_2_1_2_1_4.addActionListener(new ActionListener() {
				public void actionPerformed(final ActionEvent e) {
					String sb = vfmvf1TextField.getText().trim();
					TwoFirmPutThroughDeal_1G send = C21ConformationTest
							.get1GForeignerMessage(sb);
					// sendOrder(send);
					controller.log("Chuong trinh chan:" + send.toString());
				}
			});
			button_2_2_1_2_1_4.setText("62. Send PT Deal c5 (1G)");
			button_2_2_1_2_1_4.setBounds(24, 97, 194, 26);
			panel_7.add(button_2_2_1_2_1_4);
			// 63...
			final JButton button_2_2_1_1_1_1_3 = new JButton();
			button_2_2_1_1_1_1_3.addActionListener(new ActionListener() {
				public void actionPerformed(final ActionEvent e) {
					String sb = aa1TextField.getText().trim();
					TwoFirmPutThroughDeal_1G send = C21ConformationTest
							.get1GForeignerMessage(sb);
					sendOrder(send);
				}
			});
			button_2_2_1_1_1_1_3.setText("63. Send PT Deal c6 (1G) ");
			button_2_2_1_1_1_1_3.setBounds(24, 140, 190, 26);
			panel_7.add(button_2_2_1_1_1_1_3);
			// 64...
			final JButton button_2_2_1_2_1_4_1 = new JButton();
			button_2_2_1_2_1_4_1.addActionListener(new ActionListener() {
				public void actionPerformed(final ActionEvent e) {
					String sb = aa2TextField.getText().trim();
					TwoFirmPutThroughDeal_1G send = C21ConformationTest
							.get1GForeignerMessage(sb);
					// sendOrder(send);
					controller.log("Chuong trinh chan:" + send.toString());
				}
			});
			button_2_2_1_2_1_4_1.setText("64. Send PT Deal c7 (1G)");
			button_2_2_1_2_1_4_1.setBounds(436, 10, 194, 26);
			panel_7.add(button_2_2_1_2_1_4_1);
			// 65...
			final JButton button_2_2_1_1_1_1_3_1 = new JButton();
			button_2_2_1_1_1_1_3_1.addActionListener(new ActionListener() {
				public void actionPerformed(final ActionEvent e) {
					String sb = aa2TextField_1.getText().trim();
					TwoFirmPutThroughDeal_1G send = C21ConformationTest
							.get1GForeignerMessage(sb);
					// sendOrder(send);
					controller.log("Chuong trinh chan:" + send.toString());
				}
			});
			button_2_2_1_1_1_1_3_1.setText("65. Send PT Deal c8 (1G Bond)");
			button_2_2_1_1_1_1_3_1.setBounds(436, 53, 190, 26);
			panel_7.add(button_2_2_1_1_1_1_3_1);

			final JButton button_2_2_1_1_1_1_3_1_1 = new JButton();
			button_2_2_1_1_1_1_3_1_1.addActionListener(new ActionListener() {
				public void actionPerformed(final ActionEvent e) {
					String sb = tp4a4404TextField.getText().trim();
					TwoFirmPutThroughDeal_1G send = C21ConformationTest
							.get1GForeignerMessage(sb);
					sendOrder(send);
				}
			});
			button_2_2_1_1_1_1_3_1_1.setText("66. Send PT Deal c9 (1G Bond)");
			button_2_2_1_1_1_1_3_1_1.setBounds(436, 85, 190, 26);
			panel_7.add(button_2_2_1_1_1_1_3_1_1);

			final JButton button_2_2_1_1_1_1_2_1 = new JButton();
			button_2_2_1_1_1_1_2_1.setText("67. Cancel PT Deal c2 (1G 63-66)");
			button_2_2_1_1_1_1_2_1.setBounds(374, 128, 252, 26);
			panel_7.add(button_2_2_1_1_1_1_2_1);

			final JLabel confirmNumberLabel_2 = new JLabel();
			confirmNumberLabel_2.setText("Confirm Number");
			confirmNumberLabel_2.setBounds(66, 218, 103, 16);
			panel_7.add(confirmNumberLabel_2);

			txtConfirmNumber = new JTextField();
			txtConfirmNumber.setBounds(163, 218, 87, 20);
			panel_7.add(txtConfirmNumber);

			final JLabel confirmNumberLabel_1_1 = new JLabel();
			confirmNumberLabel_1_1.setText("Reply Code");
			confirmNumberLabel_1_1.setBounds(93, 238, 63, 16);
			panel_7.add(confirmNumberLabel_1_1);

			aTextField = new JTextField();
			aTextField.setText("A");
			aTextField.setBounds(163, 242, 87, 20);
			panel_7.add(aTextField);

			final JLabel confirmNumberLabel_2_1 = new JLabel();
			confirmNumberLabel_2_1.setText("Portfolio Volume");
			confirmNumberLabel_2_1.setBounds(58, 263, 103, 16);
			panel_7.add(confirmNumberLabel_2_1);

			textField_4 = new JTextField();
			textField_4.setBounds(163, 264, 87, 20);
			panel_7.add(textField_4);

			final JLabel confirmNumberLabel_3 = new JLabel();
			confirmNumberLabel_3.setText("Client Volume");
			confirmNumberLabel_3.setBounds(66, 286, 103, 16);
			panel_7.add(confirmNumberLabel_3);

			textField_5 = new JTextField();
			textField_5.setBounds(163, 286, 87, 20);
			panel_7.add(textField_5);

			final JLabel confirmNumberLabel_1_1_1 = new JLabel();
			confirmNumberLabel_1_1_1.setText("Fund Volume");
			confirmNumberLabel_1_1_1.setBounds(66, 310, 103, 16);
			panel_7.add(confirmNumberLabel_1_1_1);

			textField_6 = new JTextField();
			textField_6.setBounds(163, 310, 87, 20);
			panel_7.add(textField_6);

			final JLabel confirmNumberLabel_2_1_1 = new JLabel();
			confirmNumberLabel_2_1_1.setText("Foreigner Volume");
			confirmNumberLabel_2_1_1.setBounds(48, 333, 111, 16);
			panel_7.add(confirmNumberLabel_2_1_1);

			textField_7 = new JTextField();
			textField_7.setText("30000");
			textField_7.setBounds(163, 332, 87, 20);
			panel_7.add(textField_7);

			final JLabel clientTypeLabel = new JLabel();
			clientTypeLabel.setText("Client Type");
			clientTypeLabel.setBounds(58, 360, 85, 16);
			panel_7.add(clientTypeLabel);

			textField_8 = new JTextField();
			textField_8.setText("F");
			textField_8.setBounds(162, 356, 87, 20);
			panel_7.add(textField_8);

			final JButton send3bReplyButton = new JButton();
			send3bReplyButton.addActionListener(new ActionListener() {
				public void actionPerformed(final ActionEvent arg0) {
					String confirmNumber = txtConfirmNumber.getText().trim();
					String replyCode = aTextField.getText().trim();
					String pVolumne = textField_4.getText().trim();
					String cVolumne = textField_5.getText().trim();
					String mVolumne = textField_6.getText().trim();
					String fVolumne = textField_7.getText().trim();
					String clientType = textField_8.getText().trim();
					PutThroughDealReply_3B send = C1ConformanceTest
							.get3BMessage(confirmNumber, replyCode, pVolumne,
									cVolumne, mVolumne, fVolumne, clientType);
					sendOrder(send);
				}
			});
			send3bReplyButton.setText("50. Send 3B reply for 1G");
			send3bReplyButton.setBounds(84, 382, 194, 26);
			panel_7.add(send3bReplyButton);

			textField_9 = new JTextField();
			textField_9.setText("57");
			textField_9.setBounds(370, 230, 87, 20);
			panel_7.add(textField_9);

			final JLabel confirmNumberLabel_4 = new JLabel();
			confirmNumberLabel_4.setText("Firm");
			confirmNumberLabel_4.setBounds(330, 232, 25, 16);
			panel_7.add(confirmNumberLabel_4);

			final JLabel confirmNumberLabel_1_2 = new JLabel();
			confirmNumberLabel_1_2.setText("Contra Firm");
			confirmNumberLabel_1_2.setBounds(284, 255, 77, 16);
			panel_7.add(confirmNumberLabel_1_2);

			aTextField_1 = new JTextField();
			aTextField_1.setText("57");
			aTextField_1.setBounds(370, 254, 87, 20);
			panel_7.add(aTextField_1);

			final JLabel confirmNumberLabel_3_1 = new JLabel();
			confirmNumberLabel_3_1.setText("Trader ID");
			confirmNumberLabel_3_1.setBounds(293, 275, 63, 16);
			panel_7.add(confirmNumberLabel_3_1);

			textField_10 = new JTextField();
			textField_10.setText("571");
			textField_10.setBounds(371, 275, 87, 20);
			panel_7.add(textField_10);

			final JLabel confirmNumberLabel_1_1_1_1 = new JLabel();
			confirmNumberLabel_1_1_1_1.setText("Confirm Number");
			confirmNumberLabel_1_1_1_1.setBounds(274, 299, 103, 16);
			panel_7.add(confirmNumberLabel_1_1_1_1);

			textField_11 = new JTextField();
			textField_11.setBounds(371, 299, 87, 20);
			panel_7.add(textField_11);

			final JLabel confirmNumberLabel_2_2 = new JLabel();
			confirmNumberLabel_2_2.setText("Security Symbol");
			confirmNumberLabel_2_2.setBounds(264, 325, 103, 16);
			panel_7.add(confirmNumberLabel_2_2);

			ttcTextField_12 = new JTextField();
			ttcTextField_12.setText("DPM");
			ttcTextField_12.setBounds(374, 320, 87, 20);
			panel_7.add(ttcTextField_12);

			final JLabel confirmNumberLabel_2_1_1_1 = new JLabel();
			confirmNumberLabel_2_1_1_1.setText("Side");
			confirmNumberLabel_2_1_1_1.setBounds(330, 345, 25, 16);
			panel_7.add(confirmNumberLabel_2_1_1_1);

			sTextField = new JTextField();
			sTextField.setText("S");
			sTextField.setBounds(374, 344, 87, 20);
			panel_7.add(sTextField);

			btnSend3C_1 = new JButton();
			btnSend3C_1.addActionListener(new ActionListener() {
				public void actionPerformed(final ActionEvent e) {
					String Firm = textField_9.getText().trim();
					String ContraFirm = aTextField_1.getText().trim();
					String TraderID = textField_10.getText().trim();
					String ConfirmNumber = textField_11.getText().trim();
					String SecuritySymbol = ttcTextField_12.getText().trim();
					String Side = sTextField.getText().trim();
					DealPutThroughCancelRequest_3C send = C1ConformanceTest
							.getTwoFirm3CMessage(Firm, ContraFirm, TraderID,
									ConfirmNumber, SecuritySymbol, Side);
					sendOrder(send);
				}
			});
			btnSend3C_1.setToolTipText("send 2 firm put-through deal (1G)");
			btnSend3C_1.setFont(new Font("Dialog", Font.BOLD, 10));
			btnSend3C_1.setText("51. Send 3C");
			btnSend3C_1.setBounds(370, 383, 94, 27);
			panel_7.add(btnSend3C_1);

			final JLabel confirmNumberLabel_4_1 = new JLabel();
			confirmNumberLabel_4_1.setText("Firm");
			confirmNumberLabel_4_1.setBounds(541, 294, 25, 16);
			panel_7.add(confirmNumberLabel_4_1);

			textField_12 = new JTextField();
			textField_12.setText("57");
			textField_12.setBounds(581, 292, 87, 20);
			panel_7.add(textField_12);

			final JLabel confirmNumberLabel_1_1_1_1_1 = new JLabel();
			confirmNumberLabel_1_1_1_1_1.setText("Confirm Number");
			confirmNumberLabel_1_1_1_1_1.setBounds(485, 318, 103, 16);
			panel_7.add(confirmNumberLabel_1_1_1_1_1);

			textField_13 = new JTextField();
			textField_13.setBounds(582, 318, 87, 20);
			panel_7.add(textField_13);

			final JLabel confirmNumberLabel_2_1_1_1_1 = new JLabel();
			confirmNumberLabel_2_1_1_1_1.setText("Reply Code");
			confirmNumberLabel_2_1_1_1_1.setBounds(495, 345, 78, 16);
			panel_7.add(confirmNumberLabel_2_1_1_1_1);

			sTextField_1 = new JTextField();
			sTextField_1.setText("A");
			sTextField_1.setBounds(582, 342, 87, 20);
			panel_7.add(sTextField_1);

			final JButton button_2_2_1_2_1_2_1_1_1 = new JButton();
			button_2_2_1_2_1_2_1_1_1.addActionListener(new ActionListener() {
				public void actionPerformed(final ActionEvent arg0) {
					String confirmNumber = textField_13.getText().trim();
					DealCancelReply_3D send = C1ConformanceTest
							.get3DMessage(confirmNumber);
					sendOrder(send);
				}
			});
			button_2_2_1_2_1_2_1_1_1.setText("52. Send 3D reply for 3C");
			button_2_2_1_2_1_2_1_1_1.setBounds(501, 382, 194, 26);
			panel_7.add(button_2_2_1_2_1_2_1_1_1);

			cp1c0101TextField = new JTextField();
			cp1c0101TextField.setText("CP4A0102");
			cp1c0101TextField.setBounds(255, 13, 87, 20);
			panel_7.add(cp1c0101TextField);

			cp1_0100TextField = new JTextField();
			cp1_0100TextField.setText("HCMA0305");
			cp1_0100TextField.setBounds(255, 56, 87, 20);
			panel_7.add(cp1_0100TextField);

			vfmvf1TextField = new JTextField();
			vfmvf1TextField.setText("BMP");
			vfmvf1TextField.setBounds(255, 100, 87, 20);
			panel_7.add(vfmvf1TextField);

			aa1TextField = new JTextField();
			aa1TextField.setText("ASP");
			aa1TextField.setBounds(255, 143, 87, 20);
			panel_7.add(aa1TextField);

			aa2TextField = new JTextField();
			aa2TextField.setText("BMC");
			aa2TextField.setBounds(636, 13, 87, 20);
			panel_7.add(aa2TextField);

			aa2TextField_1 = new JTextField();
			aa2TextField_1.setText("SGH");
			aa2TextField_1.setBounds(636, 56, 87, 20);
			panel_7.add(aa2TextField_1);

			tp4a4404TextField = new JTextField();
			tp4a4404TextField.setText("SAF");
			tp4a4404TextField.setBounds(636, 88, 87, 20);
			panel_7.add(tp4a4404TextField);

			final JPanel panel_8 = new JPanel();
			panel_8.setLayout(null);
			jTabbedPane.addTab("C22 PreOpen", null, panel_8, null);

			final JLabel maCkLabel_3_3 = new JLabel();
			maCkLabel_3_3.setText("Security Symbol");
			maCkLabel_3_3.setBounds(279, 10, 92, 16);
			panel_8.add(maCkLabel_3_3);

			ttcTextField = new JTextField();
			ttcTextField.setText("REE");
			ttcTextField.setBounds(376, 8, 30, 20);
			panel_8.add(ttcTextField);

			atoTextField_1 = new JTextField();
			atoTextField_1.setText("ATO");
			atoTextField_1.setBounds(412, 8, 87, 20);
			panel_8.add(atoTextField_1);
			// 13...
			final JButton button_3_3_2 = new JButton();
			button_3_3_2.addActionListener(new ActionListener() {
				public void actionPerformed(final ActionEvent e) {
					String sb = ttcTextField.getText().trim();
					String orderType = atoTextField_1.getText().trim();
					NewConditioned_1I send = C21ConformationTest
							.get1IForeignerMessages(sb, orderType);
					controller.log("Chuong trinh chan:" + send.toString());
					// sendOrder(send);
				}
			});
			button_3_3_2.setText("10 Send Buying order of Foreigner");
			button_3_3_2.setBounds(279, 32, 248, 26);
			panel_8.add(button_3_3_2);

			final JLabel maCkLabel_3_1_4 = new JLabel();
			maCkLabel_3_1_4.setText("Security Symbol");
			maCkLabel_3_1_4.setBounds(279, 64, 92, 16);
			panel_8.add(maCkLabel_3_1_4);

			ttcTextField_13 = new JTextField();
			ttcTextField_13.setText("STB");
			ttcTextField_13.setBounds(376, 62, 30, 20);
			panel_8.add(ttcTextField_13);

			loTextField_7 = new JTextField();
			loTextField_7.setText("LO");
			loTextField_7.setBounds(412, 62, 87, 20);
			panel_8.add(loTextField_7);
			// 14...
			final JButton button_3_3_1_3 = new JButton();
			button_3_3_1_3.addActionListener(new ActionListener() {
				public void actionPerformed(final ActionEvent e) {
					String sb = ttcTextField_13.getText().trim();
					String orderType = loTextField_7.getText().trim();
					NewConditioned_1I send = C21ConformationTest
							.get1IForeignerMessages(sb, orderType);
					controller.log("Chuong trinh chan:" + send.toString());
					// sendOrder(send);
				}
			});
			button_3_3_1_3.setText("11 Send Buying order of Foreigner");
			button_3_3_1_3.setBounds(279, 86, 248, 26);
			panel_8.add(button_3_3_1_3);

			final JLabel maCkLabel_3_1_1_2 = new JLabel();
			maCkLabel_3_1_1_2.setText("Security Symbol");
			maCkLabel_3_1_1_2.setBounds(279, 118, 92, 16);
			panel_8.add(maCkLabel_3_1_1_2);

			ttcTextField_14 = new JTextField();
			ttcTextField_14.setText("VNM");
			ttcTextField_14.setBounds(376, 116, 30, 20);
			panel_8.add(ttcTextField_14);

			loTextField_8 = new JTextField();
			loTextField_8.setText("LO");
			loTextField_8.setBounds(412, 116, 87, 20);
			panel_8.add(loTextField_8);
			// 15...
			final JButton button_3_3_1_1_1 = new JButton();
			button_3_3_1_1_1.addActionListener(new ActionListener() {
				public void actionPerformed(final ActionEvent e) {
					String sb = ttcTextField_14.getText().trim();
					String orderType = loTextField_8.getText().trim();
					NewConditioned_1I send = C21ConformationTest
							.get1IForeignerMessages(sb, orderType);
					// controller.log("Chuong trinh chan:" + send.toString());
					sendOrder(send);
				}
			});
			button_3_3_1_1_1.setText("15 Send Buying order of Foreigner");
			button_3_3_1_1_1.setBounds(279, 140, 248, 26);
			panel_8.add(button_3_3_1_1_1);
			// 16...
			final JButton button_2_2_1_1_1_2_2 = new JButton();
			button_2_2_1_1_1_2_2.addActionListener(new ActionListener() {
				public void actionPerformed(final ActionEvent e) {
					String type = "F";
					OneFirmPutThroughDeal_1F object = C21ConformationTest
							.get1FMessage("", type);
					sendOrder(object);
					// controller.log("Chuong trinh chan:" + send.toString());
				}
			});
			button_2_2_1_1_1_2_2.setMargin(new Insets(0, 0, 0, 0));
			button_2_2_1_1_1_2_2.setText("12. Send PT Deal c1 (1F Foreigner)");
			button_2_2_1_1_1_2_2.setBounds(279, 176, 220, 26);
			panel_8.add(button_2_2_1_1_1_2_2);
			// 17...
			final JButton button_2_2_1_1_1_3_2 = new JButton();
			button_2_2_1_1_1_3_2.addActionListener(new ActionListener() {
				public void actionPerformed(final ActionEvent e) {
					String type = "P";
					OneFirmPutThroughDeal_1F object = C21ConformationTest
							.get1FMessage("", type);
					sendOrder(object);
				}
			});
			button_2_2_1_1_1_3_2.setMargin(new Insets(0, 0, 0, 0));
			button_2_2_1_1_1_3_2.setText("13. Send PT Deal c2 (1F Portfolio)");
			button_2_2_1_1_1_3_2.setBounds(279, 215, 220, 26);
			panel_8.add(button_2_2_1_1_1_3_2);

			final JLabel maCkLabel_3_2_3 = new JLabel();
			maCkLabel_3_2_3.setText("Security Symbol");
			maCkLabel_3_2_3.setBounds(533, 8, 92, 16);
			panel_8.add(maCkLabel_3_2_3);

			gmdTextField_2 = new JTextField();
			gmdTextField_2.setText("MAFPF1");
			gmdTextField_2.setBounds(630, 6, 92, 20);
			panel_8.add(gmdTextField_2);
			// 18...
			final JButton button_2_2_1_3_3 = new JButton();
			button_2_2_1_3_3.addActionListener(new ActionListener() {
				public void actionPerformed(final ActionEvent e) {
					String sb = gmdTextField_2.getText().trim();
					String session = "PREOPEN";
					Advertisement_1E object = C21ConformationTest.get1EMessage(
							sb, session);
					controller.log("Chuong trinh chan:" + object.toString());
				}
			});
			button_2_2_1_3_3.setText("14. Send PT Advertisement c.1");
			button_2_2_1_3_3.setBounds(533, 32, 223, 26);
			panel_8.add(button_2_2_1_3_3);

			ttcTextField_15 = new JTextField();
			ttcTextField_15.setText("HCMA0705");
			ttcTextField_15.setBounds(630, 60, 79, 20);
			panel_8.add(ttcTextField_15);

			final JLabel maCkLabel_3_1_2_3 = new JLabel();
			maCkLabel_3_1_2_3.setText("Bond Symbol");
			maCkLabel_3_1_2_3.setBounds(533, 62, 92, 16);
			panel_8.add(maCkLabel_3_1_2_3);
			// 19...
			final JButton button_2_2_1_4_3 = new JButton();
			button_2_2_1_4_3.addActionListener(new ActionListener() {
				public void actionPerformed(final ActionEvent e) {
					String sb = ttcTextField_15.getText().trim();
					String SecuritySymbol = ttcTextField_15.getText().trim();
					String session = "PREOPEN";
					String buysell = "S";
					String addcancel = "A";
					Advertisement_1E object = C21ConformationTest.get1EMessage(
							SecuritySymbol, session, buysell, addcancel);
					sendOrder(object);

				}
			});
			button_2_2_1_4_3.setText("15. Send PT Advertisement c.2");
			button_2_2_1_4_3.setBounds(533, 86, 223, 26);
			panel_8.add(button_2_2_1_4_3);
			// 20
			final JButton button_2_2_1_3_1_1 = new JButton();
			button_2_2_1_3_1_1.addActionListener(new ActionListener() {
				public void actionPerformed(final ActionEvent e) {
					// String sb = ttcTextField_15.getText().trim();
					String SecuritySymbol = ttcTextField_15.getText().trim();
					String session = "PREOPEN";
					String buysell = "S";
					String addcancel = "C";
					Advertisement_1E object = C21ConformationTest.get1EMessage(
							SecuritySymbol, session, buysell, addcancel);
					sendOrder(object);
				}
			});
			button_2_2_1_3_1_1.setText("17. Send Cancel PT Advertisement c.3");
			button_2_2_1_3_1_1.setBounds(533, 118, 223, 26);
			panel_8.add(button_2_2_1_3_1_1);

			txtSecSym_1 = new JTextField();
			txtSecSym_1.setBounds(10, 10, 87, 20);
			panel_8.add(txtSecSym_1);

			final JLabel ssiabtLabel_1 = new JLabel();
			ssiabtLabel_1.setText("(SSI,ABT)");
			ssiabtLabel_1.setBounds(102, 12, 66, 16);
			panel_8.add(ssiabtLabel_1);

			final JLabel loatcLabel_1 = new JLabel();
			loatcLabel_1.setText("(LO,ATC, ...)");
			loatcLabel_1.setBounds(103, 39, 66, 16);
			panel_8.add(loatcLabel_1);

			txtLO_1 = new JTextField();
			txtLO_1.setBounds(10, 37, 87, 20);
			panel_8.add(txtLO_1);

			final JButton sendOrderButton_2 = new JButton();
			sendOrderButton_2.addActionListener(new ActionListener() {
				// 6...
				public void actionPerformed(final ActionEvent arg0) {
					System.out.println(txtSecSym_1.getText());
					System.out.println(txtLO_1.getText());
					System.out.println(txtLO_2.getText());
					NewConditioned_1I get1IMessage = C21ConformationTest
							.get1IMessage(txtLO_2.getText(), txtLO_1.getText(),
									txtSecSym_1.getText());
					// System.out.println(get1IMessage.toString());
					sendOrder(get1IMessage);
				}
			});
			sendOrderButton_2.setText("Send Order");
			sendOrderButton_2.setBounds(10, 101, 158, 26);
			panel_8.add(sendOrderButton_2);

			final JButton sendOrderButton_1_1_1_2 = new JButton();
			sendOrderButton_1_1_1_2.addActionListener(new ActionListener() {
				// 21...
				public void actionPerformed(final ActionEvent e) {
					sendOrders(1);
				}
			});
			sendOrderButton_1_1_1_2.setText("18. Send Valid Order");
			sendOrderButton_1_1_1_2.setBounds(10, 289, 158, 26);
			panel_8.add(sendOrderButton_1_1_1_2);

			txt19_1 = new JTextField();
			txt19_1.setBounds(223, 265, 87, 20);
			panel_8.add(txt19_1);

			final JButton sendOrderButton_1_1_1_1_1 = new JButton();
			sendOrderButton_1_1_1_1_1.addActionListener(new ActionListener() {
				// 18...
				public void actionPerformed(final ActionEvent e) {
					System.out.println(txt19_1.getText());
					OrderCancellation_1C get1CMessage = Day1FunctionTest
							.get1CMessage(txt19_1.getText());
					sendOrder(get1CMessage);
				}
			});
			sendOrderButton_1_1_1_1_1
					.setText("18. Send cancel confirmed order  c.1");
			sendOrderButton_1_1_1_1_1.setBounds(223, 289, 280, 26);
			panel_8.add(sendOrderButton_1_1_1_1_1);

			txt19_2 = new JTextField();
			txt19_2.setBounds(509, 265, 87, 20);
			panel_8.add(txt19_2);

			final JButton sendOrderButton_1_1_1_1_1_1 = new JButton();
			sendOrderButton_1_1_1_1_1_1.addActionListener(new ActionListener() {
				// 36...
				public void actionPerformed(final ActionEvent e) {
					System.out.println(txt19_2.getText());
					OrderChange_1D get1DMessage = Day1FunctionTest
							.get1DMessage(txt19_2.getText());
					sendOrder(get1DMessage);
				}
			});
			sendOrderButton_1_1_1_1_1_1.setText("36. Send Change Order");
			sendOrderButton_1_1_1_1_1_1.setBounds(509, 289, 280, 26);
			panel_8.add(sendOrderButton_1_1_1_1_1_1);

			final JButton sendOrderButton_1_1_1_2_1_1_1_1_1 = new JButton();
			sendOrderButton_1_1_1_2_1_1_1_1_1
					.addActionListener(new ActionListener() {
						// 8...
						public void actionPerformed(final ActionEvent e) {
							controller.log("Chuong trinh chan. Khong goi MP");
						}
					});
			sendOrderButton_1_1_1_2_1_1_1_1_1.setText("8. Khong goi MP");
			sendOrderButton_1_1_1_2_1_1_1_1_1.setBounds(10, 156, 221, 26);
			panel_8.add(sendOrderButton_1_1_1_2_1_1_1_1_1);

			final JButton sendOrderButton_1_1_1_2_1_1_1_1_1_1 = new JButton();
			sendOrderButton_1_1_1_2_1_1_1_1_1_1
					.addActionListener(new ActionListener() {
						// 9...
						public void actionPerformed(final ActionEvent e) {
							controller.log("Chuong trinh chan. Khong goi ATC");
						}
					});
			sendOrderButton_1_1_1_2_1_1_1_1_1_1.setText("9. Khong goi ATC");
			sendOrderButton_1_1_1_2_1_1_1_1_1_1.setBounds(10, 199, 221, 26);
			panel_8.add(sendOrderButton_1_1_1_2_1_1_1_1_1_1);

			txtLO_2 = new JTextField();
			txtLO_2.setText("B");
			txtLO_2.setBounds(10, 62, 87, 20);
			panel_8.add(txtLO_2);

			final JLabel loatcLabel_1_1 = new JLabel();
			loatcLabel_1_1.setText("(B, S, ...)");
			loatcLabel_1_1.setBounds(102, 64, 66, 16);
			panel_8.add(loatcLabel_1_1);

			final JLabel maCkLabel_3_1_2_3_1 = new JLabel();
			maCkLabel_3_1_2_3_1.setText("Bond Symbol");
			maCkLabel_3_1_2_3_1.setBounds(533, 150, 92, 16);
			panel_8.add(maCkLabel_3_1_2_3_1);

			ttcTextField_22 = new JTextField();
			ttcTextField_22.setText("MAFPF1");
			ttcTextField_22.setBounds(630, 148, 79, 20);
			panel_8.add(ttcTextField_22);

			final JButton button_2_2_1_4_3_1 = new JButton();
			button_2_2_1_4_3_1.addActionListener(new ActionListener() {
				public void actionPerformed(final ActionEvent arg0) {
					// ttcTextField_22

					String SecuritySymbol = ttcTextField_22.getText().trim();
					String session = "PREOPEN";
					String buysell = "S";
					String addcancel = "C";
					Advertisement_1E object = C21ConformationTest.get1EMessage(
							SecuritySymbol, session, buysell, addcancel);
					// sendOrder(object);
					controller.log("Chuong trinh chan:" + object.toString());
				}
			});
			button_2_2_1_4_3_1.setText("16. Send PT Advertisement c.2");
			button_2_2_1_4_3_1.setBounds(533, 174, 223, 26);
			panel_8.add(button_2_2_1_4_3_1);

			final JPanel panel_9 = new JPanel();
			panel_9.setLayout(null);
			jTabbedPane.addTab("C22 Open", null, panel_9, null);

			final JLabel maCkLabel_3_2_2_1 = new JLabel();
			maCkLabel_3_2_2_1.setText("Security Symbol");
			maCkLabel_3_2_2_1.setBounds(321, 10, 92, 16);
			panel_9.add(maCkLabel_3_2_2_1);

			gmdTextField_3 = new JTextField();
			gmdTextField_3.setText("PPC");
			gmdTextField_3.setBounds(418, 8, 31, 20);
			panel_9.add(gmdTextField_3);
			// 41...
			final JButton button_2_2_1_3_2_2 = new JButton();
			button_2_2_1_3_2_2.addActionListener(new ActionListener() {
				public void actionPerformed(final ActionEvent e) {
					String sb = ttcTextField_15.getText().trim();
					String SecuritySymbol = ttcTextField_4.getText().trim();
					String session = "OPEN";
					String buysell = "S";
					String addcancel = "A";
					Advertisement_1E object = C21ConformationTest.get1EMessage(
							SecuritySymbol, session, buysell, addcancel);
					// sendOrder(object);
					controller.log("Chuong trinh chan:" + object.toString());
				}
			});
			button_2_2_1_3_2_2.setText("36. Send PT Advertisement c.3");
			button_2_2_1_3_2_2.setBounds(321, 34, 207, 26);
			panel_9.add(button_2_2_1_3_2_2);

			final JLabel maCkLabel_3_1_2_2_1 = new JLabel();
			maCkLabel_3_1_2_2_1.setText("Bond Symbol");
			maCkLabel_3_1_2_2_1.setBounds(321, 71, 74, 16);
			panel_9.add(maCkLabel_3_1_2_2_1);

			ttcTextField_16 = new JTextField();
			ttcTextField_16.setText("HCM_1107");
			ttcTextField_16.setBounds(400, 69, 66, 20);
			panel_9.add(ttcTextField_16);
			// 43...
			final JButton button_2_2_1_4_2_1 = new JButton();
			button_2_2_1_4_2_1.addActionListener(new ActionListener() {
				public void actionPerformed(final ActionEvent e) {
					String SecuritySymbol = "BCI40106";
					String session = "OPEN";
					String buysell = "S";
					String addcancel = "A";
					Advertisement_1E object = C21ConformationTest.get1EMessage(
							SecuritySymbol, session, buysell, addcancel);
					sendOrder(object);
				}
			});
			button_2_2_1_4_2_1.setText("35. Send PT Advertisement (44)");
			button_2_2_1_4_2_1.setBounds(307, 93, 221, 26);
			panel_9.add(button_2_2_1_4_2_1);
			// 45...
			final JButton button_2_2_1_1_1_2_1_1 = new JButton();
			button_2_2_1_1_1_2_1_1.addActionListener(new ActionListener() {
				public void actionPerformed(final ActionEvent e) {
					String type = "C";
					String sb = "HCMA0506";
					OneFirmPutThroughDeal_1F object = C21ConformationTest
							.get1FMessage(sb, "", type);
					sendOrder(object);

				}
			});
			button_2_2_1_1_1_2_1_1.setMargin(new Insets(0, 0, 0, 0));
			button_2_2_1_1_1_2_1_1.setText("45. Send PT Deal 1F (Bond 60)");
			button_2_2_1_1_1_2_1_1.setBounds(321, 157, 190, 26);
			panel_9.add(button_2_2_1_1_1_2_1_1);
			// 46...
			final JButton button_2_2_1_1_1_3_1_1 = new JButton();
			button_2_2_1_1_1_3_1_1.addActionListener(new ActionListener() {
				public void actionPerformed(final ActionEvent e) {
					String type = "C";
					String sb = "SSI";
					OneFirmPutThroughDeal_1F object = C21ConformationTest
							.get1FMessage(sb, "", type);
					// sendOrder(object);
					controller.log("Chuong trinh chan:" + object.toString());
				}
			});
			button_2_2_1_1_1_3_1_1.setMargin(new Insets(0, 0, 0, 0));
			button_2_2_1_1_1_3_1_1.setText("37-38. Send PT Deal c3 1F Stock");
			button_2_2_1_1_1_3_1_1.setBounds(319, 199, 190, 26);
			panel_9.add(button_2_2_1_1_1_3_1_1);

			final JLabel maCkLabel_3_1_3_2 = new JLabel();
			maCkLabel_3_1_3_2.setText("Security Symbol");
			maCkLabel_3_1_3_2.setBounds(319, 238, 92, 16);
			panel_9.add(maCkLabel_3_1_3_2);

			ttcTextField_17 = new JTextField();
			ttcTextField_17.setText("HMC");
			ttcTextField_17.setBounds(416, 236, 74, 20);
			panel_9.add(ttcTextField_17);

			loTextField_9 = new JTextField();
			loTextField_9.setText("LO");
			loTextField_9.setBounds(496, 236, 31, 20);
			panel_9.add(loTextField_9);
			// 47...
			final JButton button_3_3_1_2_3 = new JButton();
			button_3_3_1_2_3.addActionListener(new ActionListener() {
				public void actionPerformed(final ActionEvent e) {
					String sb = ttcTextField_17.getText().trim();
					String orderType = loTextField_9.getText().trim();
					NewConditioned_1I send = C21ConformationTest
							.get1IForeignerMessages(sb, orderType);
					// sendOrder(send);
					controller.log("Chuong trinh chan:" + send.toString());
				}
			});
			button_3_3_1_2_3.setText("39 Send Order");
			button_3_3_1_2_3.setBounds(319, 260, 179, 26);
			panel_9.add(button_3_3_1_2_3);

			final JLabel maCkLabel_3_1_1_1_2 = new JLabel();
			maCkLabel_3_1_1_1_2.setText("Security Symbol");
			maCkLabel_3_1_1_1_2.setBounds(319, 292, 92, 16);
			panel_9.add(maCkLabel_3_1_1_1_2);

			ttcTextField_18 = new JTextField();
			ttcTextField_18.setText("IFS");
			ttcTextField_18.setBounds(416, 290, 30, 20);
			panel_9.add(ttcTextField_18);

			loTextField_10 = new JTextField();
			loTextField_10.setText("LO");
			loTextField_10.setBounds(452, 290, 41, 20);
			panel_9.add(loTextField_10);
			// 48...
			final JButton button_3_3_1_2_1_3 = new JButton();
			button_3_3_1_2_1_3.addActionListener(new ActionListener() {
				public void actionPerformed(final ActionEvent arg0) {
					String sb = ttcTextField_18.getText().trim();
					String orderType = loTextField_10.getText().trim();
					NewConditioned_1I send = C21ConformationTest
							.get1IForeignerMessages(sb, orderType);
					controller.log("Chuong trinh chan:" + send.toString());
					// sendOrder(send);
				}
			});
			button_3_3_1_2_1_3.setText("40 Send Order ");
			button_3_3_1_2_1_3.setBounds(321, 320, 179, 26);
			panel_9.add(button_3_3_1_2_1_3);

			final JLabel maCkLabel_3_1_3_1_1 = new JLabel();
			maCkLabel_3_1_3_1_1.setText("Security Symbol");
			maCkLabel_3_1_3_1_1.setBounds(544, 10, 92, 16);
			panel_9.add(maCkLabel_3_1_3_1_1);

			ttcTextField_19 = new JTextField();
			ttcTextField_19.setText("MCV");
			ttcTextField_19.setBounds(641, 8, 74, 20);
			panel_9.add(ttcTextField_19);

			loTextField_11 = new JTextField();
			loTextField_11.setText("LO");
			loTextField_11.setBounds(721, 8, 31, 20);
			panel_9.add(loTextField_11);
			// 49...
			final JButton button_3_3_1_2_2_1 = new JButton();
			button_3_3_1_2_2_1.addActionListener(new ActionListener() {
				public void actionPerformed(final ActionEvent arg0) {

					String sb = ttcTextField_19.getText().trim();
					String orderType = loTextField_11.getText().trim();
					NewConditioned_1I send = C21ConformationTest
							.get1IForeignerMessages(sb, orderType, "S");
					sendOrder(send);
					// controller.log("Chuong trinh chan:" + send.toString());
					send = C21ConformationTest.get1IForeignerMessages(sb,
							orderType, "B");
					// sendOrder(send);
					controller.log("Chuong trinh chan:" + send.toString());
				}
			});
			button_3_3_1_2_2_1.setText("41. Send Order5");
			button_3_3_1_2_2_1.setBounds(544, 32, 179, 26);
			panel_9.add(button_3_3_1_2_2_1);

			final JLabel maCkLabel_3_1_1_1_1_2 = new JLabel();
			maCkLabel_3_1_1_1_1_2.setText("Security Symbol");
			maCkLabel_3_1_1_1_1_2.setBounds(544, 64, 92, 16);
			panel_9.add(maCkLabel_3_1_1_1_1_2);

			ttcTextField_20 = new JTextField();
			ttcTextField_20.setText("VTC");
			ttcTextField_20.setBounds(641, 62, 30, 20);
			panel_9.add(ttcTextField_20);

			loTextField_12 = new JTextField();
			loTextField_12.setText("LO");
			loTextField_12.setBounds(677, 62, 87, 20);
			panel_9.add(loTextField_12);
			// 50
			final JButton button_3_3_1_2_1_1_2 = new JButton();
			button_3_3_1_2_1_1_2.addActionListener(new ActionListener() {
				public void actionPerformed(final ActionEvent arg0) {
					String sb = ttcTextField_20.getText().trim();
					String orderType = loTextField_12.getText().trim();
					NewConditioned_1I send = C21ConformationTest
							.get1IForeignerMessages(sb, orderType, "S");
					sendOrder(send);
				}
			});
			button_3_3_1_2_1_1_2.setText("42 Send Order");
			button_3_3_1_2_1_1_2.setBounds(544, 93, 179, 26);
			panel_9.add(button_3_3_1_2_1_1_2);

			final JLabel maCkLabel_3_1_1_1_1_1_1 = new JLabel();
			maCkLabel_3_1_1_1_1_1_1.setText("Security Symbol");
			maCkLabel_3_1_1_1_1_1_1.setBounds(544, 125, 92, 16);
			panel_9.add(maCkLabel_3_1_1_1_1_1_1);

			ttcTextField_21 = new JTextField();
			ttcTextField_21.setText("VNE");
			ttcTextField_21.setBounds(641, 123, 30, 20);
			panel_9.add(ttcTextField_21);

			loTextField_13 = new JTextField();
			loTextField_13.setText("LO");
			loTextField_13.setBounds(677, 123, 87, 20);
			panel_9.add(loTextField_13);
			// 51...
			final JButton button_3_3_1_2_1_1_1_1 = new JButton();
			button_3_3_1_2_1_1_1_1.addActionListener(new ActionListener() {
				public void actionPerformed(final ActionEvent e) {
					String sb = ttcTextField_21.getText().trim();
					String orderType = loTextField_13.getText().trim();
					NewConditioned_1I send = C21ConformationTest
							.get1IForeignerMessages(sb, orderType);
					sendOrder(send);
				}
			});
			button_3_3_1_2_1_1_1_1.setText("43 Send Order");
			button_3_3_1_2_1_1_1_1.setBounds(544, 147, 179, 26);
			panel_9.add(button_3_3_1_2_1_1_1_1);
			// 52...
			final JButton button_2_2_1_3_2_1_3 = new JButton();
			button_2_2_1_3_2_1_3.addActionListener(new ActionListener() {
				public void actionPerformed(final ActionEvent e) {
					String SecuritySymbol = "PPC";
					String session = "OPEN";
					String buysell = "B";
					String addcancel = "C";
					Advertisement_1E object = C21ConformationTest.get1EMessage(
							SecuritySymbol, session, buysell, addcancel);
					controller.log("Chuong trinh chan:" + object.toString());
				}
			});
			button_2_2_1_3_2_1_3.setMargin(new Insets(0, 0, 0, 0));
			button_2_2_1_3_2_1_3.setText("44. Send Cancel PT Advertisement ");
			button_2_2_1_3_2_1_3.setBounds(535, 179, 229, 26);
			panel_9.add(button_2_2_1_3_2_1_3);
			// 53...
			final JButton button_2_2_1_3_2_1_1_2 = new JButton();
			button_2_2_1_3_2_1_1_2.addActionListener(new ActionListener() {
				public void actionPerformed(final ActionEvent e) {
					String SecuritySymbol = "BCI40106";
					String session = "OPEN";
					String buysell = "S";
					String addcancel = "C";
					Advertisement_1E object = C21ConformationTest.get1EMessage(
							SecuritySymbol, session, buysell, addcancel);
					// controller.log("Chuong trinh chan:" + object.toString());
					sendOrder(object);
				}
			});
			button_2_2_1_3_2_1_1_2.setMargin(new Insets(0, 0, 0, 0));
			button_2_2_1_3_2_1_1_2.setText("45. Send Cancel PT Advertisement ");
			button_2_2_1_3_2_1_1_2.setBounds(535, 218, 229, 26);
			panel_9.add(button_2_2_1_3_2_1_1_2);
			// 60...
			final JButton button_2_2_1_3_2_1_2_1 = new JButton();
			button_2_2_1_3_2_1_2_1.addActionListener(new ActionListener() {
				public void actionPerformed(final ActionEvent e) {
					controller.log("Chuong trinh chan");

				}
			});
			button_2_2_1_3_2_1_2_1.setMargin(new Insets(0, 0, 0, 0));
			button_2_2_1_3_2_1_2_1.setText("46. Send Cancel PT Deal c1 (3C)");
			button_2_2_1_3_2_1_2_1.setBounds(535, 250, 229, 26);
			panel_9.add(button_2_2_1_3_2_1_2_1);
			// 61...
			final JButton button_2_2_1_3_2_1_1_1_1 = new JButton();
			button_2_2_1_3_2_1_1_1_1.addActionListener(new ActionListener() {
				public void actionPerformed(final ActionEvent e) {
					controller.log("Chuong trinh chan.");
				}
			});
			button_2_2_1_3_2_1_1_1_1.setMargin(new Insets(0, 0, 0, 0));
			button_2_2_1_3_2_1_1_1_1.setText("47. Send Cancel PT Deal c2 (3C)");
			button_2_2_1_3_2_1_1_1_1.setBounds(535, 289, 229, 26);
			panel_9.add(button_2_2_1_3_2_1_1_1_1);
			// 44...
			final JButton button_2_2_1_3_2_1_3_1 = new JButton();
			button_2_2_1_3_2_1_3_1.addActionListener(new ActionListener() {
				public void actionPerformed(final ActionEvent e) {
					String SecuritySymbol = "HCM_1107";
					String session = "OPEN";
					String buysell = "S";
					String addcancel = "C";
					Advertisement_1E object = C21ConformationTest.get1EMessage(
							SecuritySymbol, session, buysell, addcancel);
					sendOrder(object);
				}
			});
			button_2_2_1_3_2_1_3_1.setMargin(new Insets(0, 0, 0, 0));
			button_2_2_1_3_2_1_3_1.setText("44. Send Cancel PT Advertisement");
			button_2_2_1_3_2_1_3_1.setBounds(307, 125, 229, 26);
			panel_9.add(button_2_2_1_3_2_1_3_1);

			final JButton sendOrderButton_1_1_1_2_1 = new JButton();
			sendOrderButton_1_1_1_2_1.addActionListener(new ActionListener() {
				// 39...
				public void actionPerformed(final ActionEvent e) {
					controller.log("Chuong trinh chan. Gia cao hon gia tran ");
				}
			});
			sendOrderButton_1_1_1_2_1.setText("39. Send order c.23");
			sendOrderButton_1_1_1_2_1.setBounds(10, 157, 158, 26);
			panel_9.add(sendOrderButton_1_1_1_2_1);

			final JButton sendOrderButton_1_1_1_2_1_1_1 = new JButton();
			sendOrderButton_1_1_1_2_1_1_1
					.addActionListener(new ActionListener() {
						// 26...
						public void actionPerformed(final ActionEvent e) {
							controller
									.log("Chuong trinh chan. Khong the goi LO cho trai phieu");
						}
					});
			sendOrderButton_1_1_1_2_1_1_1
					.setText("33. Khong goi LO trai phieu");
			sendOrderButton_1_1_1_2_1_1_1.setBounds(10, 125, 190, 26);
			panel_9.add(sendOrderButton_1_1_1_2_1_1_1);

			final JButton sendOrderButton_1_1_1_2_1_1_1_1 = new JButton();
			sendOrderButton_1_1_1_2_1_1_1_1
					.addActionListener(new ActionListener() {
						// 27...
						public void actionPerformed(final ActionEvent e) {
							controller
									.log("Chuong trinh chan. Khong the goi ATO");
						}
					});
			sendOrderButton_1_1_1_2_1_1_1_1.setText("28. Khong goi ATO");
			sendOrderButton_1_1_1_2_1_1_1_1.setBounds(10, 5, 221, 26);
			panel_9.add(sendOrderButton_1_1_1_2_1_1_1_1);

			final JButton sendOrderButton_1_1_1_2_1_1_2_1_1_1 = new JButton();
			sendOrderButton_1_1_1_2_1_1_2_1_1_1
					.addActionListener(new ActionListener() {
						// 54...
						public void actionPerformed(final ActionEvent e) {
							controller.log("Chuong trinh chan. Sai buoc gia");
						}
					});
			sendOrderButton_1_1_1_2_1_1_2_1_1_1.setText("30. Log sai buoc gia");
			sendOrderButton_1_1_1_2_1_1_2_1_1_1.setBounds(10, 66, 179, 26);
			panel_9.add(sendOrderButton_1_1_1_2_1_1_2_1_1_1);

			final JButton sendOrderButton_1_1_1_2_1_2 = new JButton();
			sendOrderButton_1_1_1_2_1_2.addActionListener(new ActionListener() {
				// 29...
				public void actionPerformed(final ActionEvent e) {
					controller.log("Chuong trinh chan. Khong goi VPL");
				}
			});
			sendOrderButton_1_1_1_2_1_2.setText("29. Send Order c.17");
			sendOrderButton_1_1_1_2_1_2.setBounds(10, 34, 158, 26);
			panel_9.add(sendOrderButton_1_1_1_2_1_2);

			final JButton sendOrderButton_1_1_1_2_1_3 = new JButton();
			sendOrderButton_1_1_1_2_1_3.addActionListener(new ActionListener() {
				// 32...
				public void actionPerformed(final ActionEvent e) {
					controller.log("Chuong trinh chan. Ma bi HALT");
				}
			});
			sendOrderButton_1_1_1_2_1_3.setText("32. Log ma Halt");
			sendOrderButton_1_1_1_2_1_3.setBounds(10, 93, 158, 26);
			panel_9.add(sendOrderButton_1_1_1_2_1_3);

			final JPanel panel_10 = new JPanel();
			panel_10.setLayout(null);
			jTabbedPane.addTab("C22 PreClose", null, panel_10, null);
			// 68...
			final JButton button_2_3_2_1_2_1_2 = new JButton();
			button_2_3_2_1_2_1_2.addActionListener(new ActionListener() {
				public void actionPerformed(final ActionEvent e) {
					String SecuritySymbol = cp1c0101TextField_2.getText()
							.trim();
					String session = "PRECLOSE";
					String buysell = "S";
					String addcancel = "A";
					Advertisement_1E object = C21ConformationTest.get1EMessage(
							SecuritySymbol, session, buysell, addcancel);
					// sendOrder(object);
					controller.log("Chuong trinh chan:" + object.toString());
				}
			});
			button_2_3_2_1_2_1_2.setMargin(new Insets(0, 0, 0, 0));
			button_2_3_2_1_2_1_2.setText("54. Send PT Advertisement c.5 (1E)");
			button_2_3_2_1_2_1_2.setBounds(424, 25, 204, 22);
			panel_10.add(button_2_3_2_1_2_1_2);
			// 69...
			final JButton button_2_3_2_1_2_1_1_1 = new JButton();
			button_2_3_2_1_2_1_1_1.addActionListener(new ActionListener() {
				public void actionPerformed(final ActionEvent e) {
					String SecuritySymbol = cp1c0101TextField_2.getText()
							.trim();
					String session = "PRECLOSE";
					String buysell = "S";
					String addcancel = "C";
					Advertisement_1E object = C21ConformationTest.get1EMessage(
							SecuritySymbol, session, buysell, addcancel);
					// sendOrder(object);
					controller.log("Chuong trinh chan:" + object.toString());
				}
			});
			button_2_3_2_1_2_1_1_1.setMargin(new Insets(0, 0, 0, 0));
			button_2_3_2_1_2_1_1_1
					.setText("55. Cancel PT Advertisement c.3 (1E)");
			button_2_3_2_1_2_1_1_1.setBounds(424, 53, 204, 22);
			panel_10.add(button_2_3_2_1_2_1_1_1);

			cp1c0101TextField_2 = new JTextField();
			cp1c0101TextField_2.setText("SGDCC1");
			cp1c0101TextField_2.setBounds(633, 26, 59, 20);
			panel_10.add(cp1c0101TextField_2);

			final JButton button_2_3_2_1_2_1_2_1_1 = new JButton();
			button_2_3_2_1_2_1_2_1_1.addActionListener(new ActionListener() {
				// 50...
				public void actionPerformed(final ActionEvent e) {
					controller.log("Chuong trinh chan. Ma khong ton tai ");
				}
			});
			button_2_3_2_1_2_1_2_1_1.setMargin(new Insets(0, 0, 0, 0));
			button_2_3_2_1_2_1_2_1_1.setText("50. Log ma khong ton tai");
			button_2_3_2_1_2_1_2_1_1.setBounds(36, 25, 204, 22);
			panel_10.add(button_2_3_2_1_2_1_2_1_1);

			final JPanel panel_11 = new JPanel();
			panel_11.setLayout(null);
			jTabbedPane.addTab("C22 Close", null, panel_11, null);
			// 72...
			final JButton button_2_3_2_1_2_2 = new JButton();
			button_2_3_2_1_2_2.addActionListener(new ActionListener() {
				public void actionPerformed(final ActionEvent e) {
					String sb = c.getText().trim();
					String session = "CLOSE";
					Advertisement_1E object = C21ConformationTest.get1EMessage(
							sb, session);
					sendOrder(object);
				}
			});
			button_2_3_2_1_2_2.setMargin(new Insets(0, 0, 0, 0));
			button_2_3_2_1_2_2.setText("58. Send PT Advertisement c.6 (1E)");
			button_2_3_2_1_2_2.setBounds(41, 10, 225, 26);
			panel_11.add(button_2_3_2_1_2_2);

			c = new JTextField();
			c.setText("BCI40106");
			c.setBounds(272, 13, 87, 20);
			panel_11.add(c);
			// 73...
			final JButton button_2_3_2_1_1_2_1 = new JButton();
			button_2_3_2_1_1_2_1.addActionListener(new ActionListener() {
				public void actionPerformed(final ActionEvent e) {
					String sb = cp1_0100TextField_1.getText().trim();
					String session = "CLOSE";
					Advertisement_1E object = C21ConformationTest.get1EMessage(
							sb, session);
					sendOrder(object);
				}
			});
			button_2_3_2_1_1_2_1.setMargin(new Insets(0, 0, 0, 0));
			button_2_3_2_1_1_2_1
					.setText("59. Send PT Advertisement c.7 (1E Bond)");
			button_2_3_2_1_1_2_1.setBounds(41, 53, 225, 26);
			panel_11.add(button_2_3_2_1_1_2_1);

			cp1_0100TextField_1 = new JTextField();
			cp1_0100TextField_1.setText("SAM");
			cp1_0100TextField_1.setBounds(272, 56, 87, 20);
			panel_11.add(cp1_0100TextField_1);
			// 74...
			final JButton button_2_2_1_2_1_4_2 = new JButton();
			button_2_2_1_2_1_4_2.addActionListener(new ActionListener() {
				public void actionPerformed(final ActionEvent e) {
					String sb = vfmvf1TextField_1.getText().trim();
					TwoFirmPutThroughDeal_1G send = C21ConformationTest
							.get1GForeignerMessage(sb);
					//sendOrder(send);
					controller.log("Chuong trinh chan:" + send.toString());
				}
			});
			button_2_2_1_2_1_4_2.setText("60. Send PT Deal c5 (1G)");
			button_2_2_1_2_1_4_2.setBounds(41, 97, 194, 26);
			panel_11.add(button_2_2_1_2_1_4_2);

			vfmvf1TextField_1 = new JTextField();
			vfmvf1TextField_1.setText("SGDCC3");
			vfmvf1TextField_1.setBounds(272, 100, 87, 20);
			panel_11.add(vfmvf1TextField_1);
			// 75...
			final JButton button_2_2_1_1_1_1_3_2 = new JButton();
			button_2_2_1_1_1_1_3_2.addActionListener(new ActionListener() {
				public void actionPerformed(final ActionEvent e) {
					String sb = aa1TextField_1.getText().trim();
					TwoFirmPutThroughDeal_1G send = C21ConformationTest
							.get1GForeignerMessage(sb);
					sendOrder(send);
					// controller.log("Chuong trinh chan:" + send.toString());
				}
			});
			button_2_2_1_1_1_1_3_2.setText("61. Send PT Deal c6 (1G) ");
			button_2_2_1_1_1_1_3_2.setBounds(41, 140, 190, 26);
			panel_11.add(button_2_2_1_1_1_1_3_2);

			aa1TextField_1 = new JTextField();
			aa1TextField_1.setText("VIS");
			aa1TextField_1.setBounds(272, 143, 87, 20);
			panel_11.add(aa1TextField_1);
			// 76...
			final JButton button_2_2_1_2_1_4_1_1 = new JButton();
			button_2_2_1_2_1_4_1_1.addActionListener(new ActionListener() {
				public void actionPerformed(final ActionEvent e) {
					String sb = aa2TextField_2.getText().trim();
					TwoFirmPutThroughDeal_1G send = C21ConformationTest
							.get1GForeignerMessage(sb);
					sendOrder(send);
					// controller.log("Chuong trinh chan:" + send.toString());
				}
			});
			button_2_2_1_2_1_4_1_1.setText("62. Send PT Deal c7 (1G)");
			button_2_2_1_2_1_4_1_1.setBounds(453, 10, 194, 26);
			panel_11.add(button_2_2_1_2_1_4_1_1);

			aa2TextField_2 = new JTextField();
			aa2TextField_2.setText("TCR");
			aa2TextField_2.setBounds(653, 13, 87, 20);
			panel_11.add(aa2TextField_2);
			// 77...
			final JButton button_2_2_1_1_1_1_3_1_2 = new JButton();
			button_2_2_1_1_1_1_3_1_2.addActionListener(new ActionListener() {
				public void actionPerformed(final ActionEvent e) {
					String sb = aa2TextField_3.getText().trim();
					TwoFirmPutThroughDeal_1G send = C21ConformationTest
							.get1GForeignerMessage(sb);
					sendOrder(send);
					// controller.log("Chuong trinh chan:" + send.toString());
				}
			});
			button_2_2_1_1_1_1_3_1_2.setText("63. Send PT Deal c8 (1G Bond)");
			button_2_2_1_1_1_1_3_1_2.setBounds(453, 53, 190, 26);
			panel_11.add(button_2_2_1_1_1_1_3_1_2);

			aa2TextField_3 = new JTextField();
			aa2TextField_3.setText("TSC");
			aa2TextField_3.setBounds(653, 56, 87, 20);
			panel_11.add(aa2TextField_3);
			// 78...
			final JButton button_2_2_1_1_1_1_3_1_1_1 = new JButton();
			button_2_2_1_1_1_1_3_1_1_1.addActionListener(new ActionListener() {
				public void actionPerformed(final ActionEvent e) {
					String sb = tp4a4404TextField_1.getText().trim();
					TwoFirmPutThroughDeal_1G send = C21ConformationTest
							.get1GForeignerMessage(sb);
					// sendOrder(send);
					controller.log("Chuong trinh chan:" + send.toString());
				}
			});
			button_2_2_1_1_1_1_3_1_1_1.setText("64. Send PT Deal c9 (1G Bond)");
			button_2_2_1_1_1_1_3_1_1_1.setBounds(453, 85, 190, 26);
			panel_11.add(button_2_2_1_1_1_1_3_1_1_1);

			tp4a4404TextField_1 = new JTextField();
			tp4a4404TextField_1.setText("ALT");
			tp4a4404TextField_1.setBounds(653, 88, 87, 20);
			panel_11.add(tp4a4404TextField_1);

			final JButton button_2_2_1_1_1_1_2_1_1 = new JButton();
			button_2_2_1_1_1_1_2_1_1
					.setText("79. Cancel PT Deal c2 (1G 58-64)");
			button_2_2_1_1_1_1_2_1_1.setBounds(391, 128, 252, 26);
			panel_11.add(button_2_2_1_1_1_1_2_1_1);
		}
		return jTabbedPane;
	}

	public void sendOrder(ValueObject object) {
		try {
			controller.sendMessageToQueue(object);
		} catch (Exception e1) {
			e1.printStackTrace();
		}
	}

	public void sendOrders(List listOrders, String marketStatus) {
		try {
			Object object;
			NewConditioned_1I new1I;
			for (int i = 0; i < listOrders.size(); i++) {
				System.out.println("Load Test : number " + i);
				object = listOrders.get(i);
				if (object instanceof NewConditioned_1I) {
					new1I = (NewConditioned_1I) object;
					if (marketStatus.equalsIgnoreCase("PreOpen")) {
						if (new1I.getPrice().equalsIgnoreCase("ATC")
								|| new1I.getPrice().equalsIgnoreCase("MP")) {
							controller
									.log("Chuong trinh chan. Can't send order: "
											+ new1I.toString());
							continue;
						}
					} else if (marketStatus.equalsIgnoreCase("Open")) {
						if (new1I.getPrice().equalsIgnoreCase("ATC")
								|| new1I.getPrice().equalsIgnoreCase("MP")
								|| new1I.getPrice().equalsIgnoreCase("ATO")) {
							controller
									.log("Chuong trinh chan. Can't send order: "
											+ new1I.toString());
							continue;
						}
					} else if (marketStatus.equalsIgnoreCase("PreClose")) {
						if (new1I.getPrice().equalsIgnoreCase("MP")
								|| new1I.getPrice().equalsIgnoreCase("ATO")) {
							controller
									.log("Chuong trinh chan. Can't send order: "
											+ new1I.toString());
							continue;
						}
					} else if (marketStatus.equalsIgnoreCase("Close")) {
						// Can't send ATO,ATC,MP,LO trong Close
						controller.log("Chuong trinh chan. Can't send order: "
								+ new1I.toString());
						continue;
					}
				}
				controller.sendMessageToQueue(object);
			}
		} catch (Exception e1) {
			e1.printStackTrace();
		}
	}

	public void sendOrders(int numberOfOrders) {
		List<NewConditioned_1I> get1IMessages = NormalTest
				.get1IMessages(numberOfOrders);
		for (NewConditioned_1I new1I : get1IMessages) {
			sendOrder(new1I);
		}
	}

	public static void showMessageAndExit(final String message) {
		Runnable doWorkRunnable = new Runnable() {
			public void run() {
				JOptionPane
						.showMessageDialog(MainFrameConformance.getFrames()[0], message);
				System.exit(0);
			}
		};
		SwingUtilities.invokeLater(doWorkRunnable);
	}

} // @jve:decl-index=0:visual-constraint="2,6"
