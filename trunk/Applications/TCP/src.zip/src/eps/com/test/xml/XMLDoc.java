/*
 * XMLDoc.java
 *
 * Created on July 3, 2002, 1:43 PM
 */


package eps.com.test.xml;

import java.io.InputStream;

/**
 *
 * @author  plang
 * @version
 */
public class XMLDoc extends XMLBase {
    
    /** Creates new XMLDoc */
    public XMLDoc() throws Exception {
        createDOM();
    }
    
    /** Creates new XMLDoc */
    public XMLDoc(String file) throws Exception {
        document = getDOM(file);
    }
    
    /** Creates new XMLDoc */
    public XMLDoc(String file, boolean isValidating) throws Exception {
        document = getDOM(file, isValidating);
    }
    
    /** Creates new XMLDoc */
    public XMLDoc(InputStream is, boolean isValidating, String systemId, org.xml.sax.ErrorHandler errorHandler) throws Exception {
        document = getDOM(is, isValidating, systemId, errorHandler);
    }
    
}
