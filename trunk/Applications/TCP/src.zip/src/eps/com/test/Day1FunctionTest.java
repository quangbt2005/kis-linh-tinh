package eps.com.test;

import java.util.ArrayList;
import java.util.List;

import eps.com.message.sended.NewConditioned_1I;
import eps.com.message.sended.OneFirmPutThroughDeal_1F;
import eps.com.message.sended.OrderCancellation_1C;
import eps.com.message.sended.OrderChange_1D;
import eps.com.message.sended.TwoFirmPutThroughDeal_1G;

public class Day1FunctionTest {
	// 7. Send order c.1
	public static NewConditioned_1I getInvalidOrder(String orderType) {
		List<NewConditioned_1I> listOrders;

		if (orderType.equals("ATC")) {
			listOrders = NormalTest.get1IMessages(1, "10", "B", "ATC");
		} else if (orderType.equals("ATO")) {
			listOrders = NormalTest.get1IMessages(1, "11", "B", "ATO");
		} else {
			listOrders = NormalTest.get1IMessages(1, "12", "S", "MP");
		}

		return listOrders.get(0);
	}

	// 9. Cancel valid Order
	public static OrderCancellation_1C get1CMessage(String orderNumber) {
		OrderCancellation_1C order;

		order = new OrderCancellation_1C();
		order.setFirm("057");
		order.setOrderNumber(orderNumber);
		order.setOrderEntryDate(TestCommon.today);

		return order;
	}

	// 21. Change unmatched order
	public static OrderChange_1D get1DMessage(String orderNumber) {
		OrderChange_1D order;

		order = new OrderChange_1D();
		String clientID = TestCommon.createRandomAcountBuy();

		order = new OrderChange_1D();
		order.setFirm("057");
		order.setOrderNumber(orderNumber);
		order.setOrderEntryDate(TestCommon.today);
		order.setClientID(clientID);
		order.setFiller("");

		return order;
	}

	// Pre-open session
	public static List<NewConditioned_1I> loadTest1() {
		List<NewConditioned_1I> ret = new ArrayList<NewConditioned_1I>();

		// 5 orders at ATC
		List<NewConditioned_1I> listOrders = NormalTest.get1IMessages(5, "1",
				"B", "ATC");
		ret.addAll(listOrders);

		// 5 orders at MP
		listOrders = NormalTest.get1IMessages(5, "2", "S", "MP");
		ret.addAll(listOrders);

		// 290 orders at ATO or LO (valid price)
		// 80 orders at ATO
		listOrders = NormalTest.get1IMessages(80, "3", "B", "ATO");
		ret.addAll(listOrders);

		// 70 orders at LO
		listOrders = NormalTest.get1IMessages(70, "4", "S", "");
		ret.addAll(listOrders);

		// 140 orders at LO
		listOrders = NormalTest.get1IMessages(140);
		ret.addAll(listOrders);

		return ret;
	}

	// Open session
	public static List<NewConditioned_1I> loadTest2() {
		List<NewConditioned_1I> ret = new ArrayList<NewConditioned_1I>();

		// 5 orders at ATO
		List<NewConditioned_1I> listOrders = NormalTest.get1IMessages(5, "4",
				"S", "ATO");
		ret.addAll(listOrders);

		// 5 orders at MP
		listOrders = NormalTest.get1IMessages(5, "5", "B", "MP");
		ret.addAll(listOrders);

		// 5 orders at ATC
		listOrders = NormalTest.get1IMessages(5, "6", "S", "ATC");
		ret.addAll(listOrders);

		// 100 orders at LO (valid price)
		listOrders = NormalTest.get1IMessages(100, "7", "S", "");
		ret.addAll(listOrders);

		// 185 orders at LO (valid price)
		listOrders = NormalTest.get1IMessages(185);
		ret.addAll(listOrders);

		return ret;
	}

	// Pre-close session
	public static List<NewConditioned_1I> loadTest3() {
		List<NewConditioned_1I> ret = new ArrayList<NewConditioned_1I>();

		// 5 orders at ATO
		List<NewConditioned_1I> listOrders = NormalTest.get1IMessages(5, "7",
				"S", "ATO");
		ret.addAll(listOrders);

		// 5 orders at MP
		listOrders = NormalTest.get1IMessages(5, "8", "B", "MP");
		ret.addAll(listOrders);

		// 100 orders at LO (valid price)
		listOrders = NormalTest.get1IMessages(100, "9", "S", "");
		ret.addAll(listOrders);

		// 190 orders at ATC or LO (valid price)
		listOrders = NormalTest.get1IMessages(190);
		ret.addAll(listOrders);

		return ret;
	}

	// Close/Run-off
	public static List loadTest4() {
		List ret = new ArrayList();

		// 5 one firm PT deals
		List<OneFirmPutThroughDeal_1F> get1FMessages = NormalTest
				.get1FMessages(5);
		ret.addAll(get1FMessages);

		// 5 two firm PT deals
		List<TwoFirmPutThroughDeal_1G> get1GMessages = NormalTest
				.get1GMessages(5);
		ret.addAll(get1GMessages);

		// 2 matching orders(ATO,ATC,MP,LO)
		List<NewConditioned_1I> get1IMessages = NormalTest.get1IMessages(2,
				"8", "B", "MP");
		ret.addAll(get1IMessages);

		// 2 matching orders(ATO,ATC,MP,LO)
		get1IMessages = NormalTest.get1IMessages(3, "9", "B", "ATO");
		ret.addAll(get1IMessages);

		return ret;
	}

	// ///////////////// PRE_OPEN Functions
	public static NewConditioned_1I get1IForeignerMessage(String sb) {
		return NormalTest.get1IForeignerMessage(sb);
	}

}
