package eps.junit;

import junit.framework.TestCase;


import org.junit.Test;

import eps.com.common.ValueObject;
import eps.com.message.broadcast.*;
import eps.com.message.sended.*;
import eps.com.message.received.*;
import eps.com.test.TestCommon;
import eps.com.util.MessageUtil;
import static junit.framework.Assert.*;

import org.junit.Test;
public class testTCPMessage{

	public testTCPMessage()
	{
		testMessage2tobyteAndbytetoMessage_2C();
	}
	@Test 
	public void testMessage2tobyteAndbytetoMessage_1I()
	{
		String OrderNumber = TestCommon.createRandomOrderNumber();
		String ClientID = TestCommon.createRandomAcountBuy();
		String SecuritySymbol = TestCommon.createRandomSymbol();

		NewConditioned_1I order = new NewConditioned_1I();
		order.setFirm("057");
		order.setTraderID("212 ");
		order.setOrderNumber(OrderNumber);
		order.setClientID(ClientID);
		order.setSecuritySymbol(SecuritySymbol);
		order.setSide("B");
		order.setVolume("1000    ");
		order.setPublishedVolume("1000    ");
		order.setPrice("ATO   ");
		order.setBoard("M");
		order.setFiller("     ");
		order.setPortClientFlag("C");
		order.setFiller2("     ");
		
		byte[] message2Bytes = MessageUtil.message2Bytes(order);
		System.out.print(new String(message2Bytes));
		
		ValueObject object = (ValueObject) MessageUtil.bytes2Message(message2Bytes);
		
		if (object instanceof  NewConditioned_1I )
		{
			NewConditioned_1I order1 = (NewConditioned_1I)object ;
			assertTrue(order1.compareTo(order));
		}
	}
	
	
	@Test
	public void testMessage2tobyteAndbytetoMessage_1C()
	{
		String OrderNumber = TestCommon.createRandomOrderNumber();
		String orderEntryDate = "101 "; 
		
		OrderCancellation_1C order = new OrderCancellation_1C();
		
		order.setFirm("057");
		order.setOrderNumber(OrderNumber);
		order.setOrderEntryDate(orderEntryDate);
		
		byte[] message2Bytes = MessageUtil.message2Bytes(order);
		System.out.print(new String(message2Bytes));
			
		ValueObject object = (ValueObject) MessageUtil.bytes2Message(message2Bytes);
		
		if (object instanceof  OrderCancellation_1C )
		{
			OrderCancellation_1C order1 = (OrderCancellation_1C)object ;
			assertTrue(order1.compareTo(order));
		}
	}

	
	@Test
	public void testMessage2tobyteAndbytetoMessage_1D()
	{
		String OrderNumber = TestCommon.createRandomOrderNumber();
		String orderEntryDate = "1512";  // DDMM
		String ClientID = TestCommon.createRandomAcountBuy(); 
		
		String temp = "" ;
		temp ="123456";
		for (int i = temp.length() ; i < 17 ; i++) {
			temp += " ";
		}
		
		OrderChange_1D order = new OrderChange_1D() ;
		
		order.setFirm("057");
		order.setOrderNumber(OrderNumber);
		order.setOrderEntryDate(orderEntryDate) ;
		order.setClientID(ClientID);
		order.setFiller(temp) ;
		
		byte[] message2Bytes = MessageUtil.message2Bytes(order);
		System.out.print(new String(message2Bytes));
			
		ValueObject object = (ValueObject) MessageUtil.bytes2Message(message2Bytes);
		
		if (object instanceof  OrderChange_1D )
		{
			OrderChange_1D order1 = (OrderChange_1D)object ;
			assertTrue(order1.compareTo(order));
		}
		
	}
	
	
	@Test
	public void testMessage2tobyteAndbytetoMessage_1E()
	{
		String SecuritySymbol = TestCommon.createRandomSymbol();

		Advertisement_1E send = new Advertisement_1E();
		
		send.setFirm("057");
		send.setTraderID("2120");
		send.setSecuritySymbol(SecuritySymbol);
		send.setSide("B");
		
		send.setVolume("1000    ");
		send.setPrice("12345678901 ");
		send.setBoard("M");
		send.setTime("120508");
		send.setAddCancelFlag("C");
		
		String temp = "" ;
		for (int i = 0; i < 20 ; i++) {
			temp += " ";
		}
		send.setContact(temp) ;
		
		
		byte[] message2Bytes = MessageUtil.message2Bytes(send);
		System.out.print(new String(message2Bytes));
			
		ValueObject object = (ValueObject) MessageUtil.bytes2Message(message2Bytes);
		
		if (object instanceof  Advertisement_1E )
		{
			Advertisement_1E order1 = (Advertisement_1E)object ;
			assertTrue(order1.compareTo(send));
		}
		
		
	}
	
	@Test
	public void testMessage2tobyteAndbytetoMessage_1F()
	{
		String ClientID = TestCommon.createRandomAcountBuy();
		String SecuritySymbol = TestCommon.createRandomSymbol();
		String temp = "";
		
		OneFirmPutThroughDeal_1F send = new OneFirmPutThroughDeal_1F();
		
		send.setFirm("057");
		send.setTraderID("2120");
		send.setClientIDBuyer(ClientID);
		send.setClientIDSeller(ClientID);
		send.setSecuritySymbol(SecuritySymbol);
		send.setPrice("1234567890  ");
		send.setBoard("M");
		send.setDealID(" 2345");
		for (int i = 0; i < 8; i++) {
			temp += " " ;
		}
		send.setFiller(temp);
		send.setBrokerPortfolioVolumeBuyer("123456  ");
		send.setBrokerClientVolumeBuyer("12345678");
		send.setMutualFundVolumeBuyer("12345678");
		send.setBrokerForeignVolumeBuyer("123456  ");
		temp = "" ;
		for (int i = 0; i < 32; i++) {
			temp += " " ;
		}
		send.setFiller2(temp) ;
		send.setBrokerPortfolioVolumeSeller("12345678");
		send.setBrokerClientVolumeSeller("12345678");
		send.setMutualFundVolumeSeller("12345678");
		send.setBrokerForeignVolumeSeller("12345678");
		temp = "" ;
		for (int i = 0; i < 32; i++) {
			temp += " " ;
		}
		send.setFiller2(temp);
	
		temp = "" ;
		for (int i = 0; i < 32; i++) {
			temp += " " ;
		}
		send.setFiller3(temp) ;
		
		byte[] message2Bytes = MessageUtil.message2Bytes(send);
		System.out.print(new String(message2Bytes));
			
		ValueObject object = (ValueObject) MessageUtil.bytes2Message(message2Bytes);
		
		if (object instanceof  OneFirmPutThroughDeal_1F )
		{
			OneFirmPutThroughDeal_1F order1 = (OneFirmPutThroughDeal_1F)object ;
			assertTrue(order1.compareTo(send));
		}
		
	}
	@Test
	public void testMessage2tobyteAndbytetoMessage_1G()
	{
		TwoFirmPutThroughDeal_1G send = new TwoFirmPutThroughDeal_1G();
		send.setFirmSeller("057");
		send.setTraderIDSeller("2010");
			
		String ClientID = TestCommon.createRandomAcountBuy(); 
		send.setClientIDSeller(ClientID);
		send.setContraFirmBuyer("123");
		send.setTraderIDBuyer("2345");
		String SecuritySymbol = TestCommon.createRandomSymbol();
		send.setSecuritySymbol(SecuritySymbol);
		send.setPrice("1234  789012");
		send.setBoard("M");
		send.setDealID("12345");
		
		String temp = "" ;
		for (int i = 0; i < 4; i++) {
			temp += " " ;
		}
		send.setFiller(temp);
		send.setBrokerPortfolioVolumeSeller("12345678");
		send.setBrokerClientVolumeSeller("1234567 ");
		send.setMutualFundVolumeSeller("12345678");
		send.setBrokerForeignVolumeSeller("1234567 ");
		temp = "" ;
		for (int i = 0; i < 32; i++) {
			temp += " " ;
		}
		send.setFiller2(temp);
	
		byte[] message2Bytes = MessageUtil.message2Bytes(send);
		System.out.print(new String(message2Bytes));
			
		ValueObject object = (ValueObject) MessageUtil.bytes2Message(message2Bytes);
		
		if (object instanceof  OneFirmPutThroughDeal_1F )
		{
			TwoFirmPutThroughDeal_1G order1 = (TwoFirmPutThroughDeal_1G)object ;
			assertTrue(order1.compareTo(send));
		}
	}
	
	@Test
	public void testMessage2tobyteAndbytetoMessage_2B()
	{
		String OrderNumber = TestCommon.createRandomOrderNumber();
		OrderConfirmation_2B receive = new OrderConfirmation_2B();
	
		receive.setFirm("05 ");
		receive.setOrderNumber(OrderNumber) ;
		receive.setOrderEntryDate("2010");
		
		byte[] message2Bytes = MessageUtil.message2Bytes(receive);
		System.out.print(new String(message2Bytes));
			
		ValueObject object = (ValueObject) MessageUtil.bytes2Message(message2Bytes);
		
		if (object instanceof  OrderConfirmation_2B )
		{
			OrderConfirmation_2B order1 = (OrderConfirmation_2B)object ;
			assertTrue(order1.compareTo(receive));
		}
		
		
	}
	@Test
	public void testMessage2tobyteAndbytetoMessage_2C()
	{
		 
		String OrderNumber = TestCommon.createRandomOrderNumber();
		ConfirmOfOrderCancel_2C receive = new ConfirmOfOrderCancel_2C();
		
		receive.setFirm("057");
		receive.setCancelShares("12345678");
		//receive.setOrderNumber(OrderNumber);
		receive.setOrderNumber("12345678");
		receive.setOrderEntryDate("1509");
		receive.setOrderCancelStatus("C");
		
		byte[] message2Bytes = MessageUtil.message2Bytes(receive);
		System.out.print(new String(message2Bytes));
			
		ValueObject object = (ValueObject) MessageUtil.bytes2Message(message2Bytes);
		
		if (object instanceof  ConfirmOfOrderCancel_2C )
		{
			ConfirmOfOrderCancel_2C order1 = (ConfirmOfOrderCancel_2C)object ;
			assertTrue(order1.compareTo(receive));
		}
		
	}
	@Test
	public void testMessage2tobyteAndbytetoMessage_2D()
	{
		String OrderNumber = TestCommon.createRandomOrderNumber();
		String ClientID = TestCommon.createRandomAcountBuy(); 

		ConfirmOfOrderChange_2D receive = new ConfirmOfOrderChange_2D();
		
		receive.setFirm("057");
		receive.setOrderNumber(OrderNumber);
		receive.setOrderEntryDate("2001");
		receive.setClientID(ClientID);
		receive.setPortClientFlag(" ");
		receive.setPublishedVolume("12345678");
		receive.setPrice("12345 ");
		String temp = "" ;
		for (int i = 0; i < 8; i++) {
			temp += " " ;
		}
		receive.setFiller(temp);
		
		byte[] message2Bytes = MessageUtil.message2Bytes(receive);
		System.out.print(new String(message2Bytes));
			
		ValueObject object = (ValueObject) MessageUtil.bytes2Message(message2Bytes);
		
		if (object instanceof  ConfirmOfOrderChange_2D )
		{
			ConfirmOfOrderChange_2D order1 = (ConfirmOfOrderChange_2D)object ;
			assertTrue(order1.compareTo(receive));
		}
	}
	
	@Test
	public void testMessage2tobyteAndbytetoMessage_2E()
	{
		DealConfirmation_2E receive = new DealConfirmation_2E();
		
		receive.setFirm("057");
		receive.setSide("B");
		String OrderNumber = TestCommon.createRandomOrderNumber();
		receive.setOrderNumber(OrderNumber);
		receive.setOrderEntryDate(" 510");
		receive.setFiller("  ");
		
		receive.setVolume("12345678");
		receive.setPrice("123456");
		receive.setConfirmNumber("12345 ");
		
		byte[] message2Bytes = MessageUtil.message2Bytes(receive);
		System.out.print(new String(message2Bytes));
			
		ValueObject object = (ValueObject) MessageUtil.bytes2Message(message2Bytes);
		
		if (object instanceof  DealConfirmation_2E )
		{
			DealConfirmation_2E order1 = (DealConfirmation_2E)object ;
			assertTrue(order1.compareTo(receive));
		}
	}
	
	@Test
	public void testMessage2tobyteAndbytetoMessage_2F()
	{
		String SecuritySymbol = TestCommon.createRandomSymbol();
		PutThroughAcknowledgment_2F receive = new PutThroughAcknowledgment_2F();
		
		receive.setFirmBuy("057");
		receive.setTraderIDBuy("2010");
		receive.setSideB("B");
		receive.setContraFirmSell("123");
		receive.setTraderIDContraSideSell("4444");
		receive.setSecuritySymbol(SecuritySymbol);
		receive.setVolume("12  5678");
		receive.setPrice("1234567890  ");
		receive.setBoard("M");
		receive.setConfirmNumber("123456");
		
		byte[] message2Bytes = MessageUtil.message2Bytes(receive);
		System.out.print(new String(message2Bytes));
			
		ValueObject object = (ValueObject) MessageUtil.bytes2Message(message2Bytes);
		
		if (object instanceof  PutThroughAcknowledgment_2F )
		{
			PutThroughAcknowledgment_2F order1 = (PutThroughAcknowledgment_2F)object ;
			assertTrue(order1.compareTo(receive));
		}
	}
	
	@Test
	public void testMessage2tobyteAndbytetoMessage_2G()
	{
		Reject_2G recieve = new Reject_2G();
		
		recieve.setFirm("057");
		recieve.setRejectReasonCode("A ");

		String temp = "" ;
		for (int i = 0; i < 233; i++) {
			temp += " " ;
		}
		recieve.setOriginalMessageText(temp);

		byte[] message2Bytes = MessageUtil.message2Bytes(recieve);
		System.out.print(new String(message2Bytes));
			
		ValueObject object = (ValueObject) MessageUtil.bytes2Message(message2Bytes);
		
		if (object instanceof  Reject_2G )
		{
			Reject_2G order1 = (Reject_2G)object ;
			assertTrue(order1.compareTo(recieve));
		}
		
	}
	
	@Test
	public void testMessage2tobyteAndbytetoMessage_2I()
	{
		String OrderNumber = TestCommon.createRandomOrderNumber();
		CrossingDealConfirmation_2I recieve = new CrossingDealConfirmation_2I();
		
		recieve.setFirm("057");
		recieve.setOrderNumberBuy(OrderNumber);
		recieve.setOrderEntryDateBuy("1203");
		recieve.setOrderNumberSell(OrderNumber);
		recieve.setOrderEntryDateSell("0105");
		recieve.setVolume("21002100");
		recieve.setPrice("123456");
		recieve.setConfirmNumber("123456");
		
		byte[] message2Bytes = MessageUtil.message2Bytes(recieve);
		System.out.print(new String(message2Bytes));
			
		ValueObject object = (ValueObject) MessageUtil.bytes2Message(message2Bytes);
		
		if (object instanceof  CrossingDealConfirmation_2I )
		{
			CrossingDealConfirmation_2I order1 = (CrossingDealConfirmation_2I)object ;
			assertTrue(recieve.compareTo(order1));
		}
	}
	
	@Test
	public void testMessage2tobyteAndbytetoMessage_2L()
	{
		PutThroughDealConfirmation_2L recieve = new PutThroughDealConfirmation_2L();
		
		recieve.setFirm("057");
		recieve.setSide("B");
		recieve.setDealID("12345");
		recieve.setContraFirm("123");
		recieve.setVolume("12345678");
		recieve.setPrice("123456789   ");
		recieve.setConfirmNumber("123456");
		
		byte[] message2Bytes = MessageUtil.message2Bytes(recieve);
		System.out.print(new String(message2Bytes));
			
		ValueObject object = (ValueObject) MessageUtil.bytes2Message(message2Bytes);
		
		if (object instanceof  PutThroughDealConfirmation_2L )
		{
			PutThroughDealConfirmation_2L order1 = (PutThroughDealConfirmation_2L)object ;
			assertTrue(order1.compareTo(recieve));
		}
		
	}
	
	@Test
	public void testMessage2tobyteAndbytetoMessage_3A()
	{
		Admin_3A recieve = new Admin_3A();
		
		recieve.setFirm("057");
		recieve.setTraderIDSender("2010");
		recieve.setTraderIDReciever("102 ");
		recieve.setContraFirm("123");
		
		String temp = "" ;
		for (int i = 0; i < 33; i++) {
			temp += "23" ;
		}
		recieve.setAdminMessageText(temp);
		
		
		byte[] message2Bytes = MessageUtil.message2Bytes(recieve);
		System.out.println(new String(message2Bytes));
			
		ValueObject object = (ValueObject) MessageUtil.bytes2Message(message2Bytes);
		
		if (object instanceof  Admin_3A )
		{
			Admin_3A order1 = (Admin_3A)object ;
			assertTrue(order1.compareTo(recieve));
		}
		
	}
	
	@Test
	public void testMessage2tobyteAndbytetoMessage_3B()
	{
		
		PutThroughDealReply_3B send = new PutThroughDealReply_3B();
		
		send.setFirm("057");
		send.setConfirmNumber("12345 ");
		send.setDealID("1234 ");
		String ClientID = TestCommon.createRandomAcountBuy(); 
		send.setClientIDBuyer(ClientID);
		send.setReplyCode(" ");
		send.setFiller("    ");
		send.setBrokerPortfolioVolume("1234567 ");
		send.setBrokerClientVolume("12345678");
		send.setBrokerMutualFundVolume("12345678");
		send.setBrokerForeignVolume("123456  ");
		
		String temp = "" ;
		for (int i = 0; i < 32; i++) {
			temp += " " ;
		}
		send.setFiller2(temp) ;
		
		byte[] message2Bytes = MessageUtil.message2Bytes(send);
		System.out.println(new String(message2Bytes));
			
		ValueObject object = (ValueObject) MessageUtil.bytes2Message(message2Bytes);
		
		if (object instanceof  PutThroughDealReply_3B )
		{
			PutThroughDealReply_3B order1 = (PutThroughDealReply_3B)object ;
			assertTrue(order1.compareTo(send));
		}
		
		
	}
	@Test
	public void testMessage2tobyteAndbytetoMessage_3C()
	{
		DealPutThroughCancelRequest_3C send = new DealPutThroughCancelRequest_3C();
		
		send.setFirm("057");
		send.setContraFirm("056");
		send.setTraderID("1523");
		send.setConfirmNumber("123450");
		
		String SecuritySymbol = TestCommon.createRandomSymbol();
		send.setSecuritySymbol(SecuritySymbol);
		send.setSide("B");
		
		byte[] message2Bytes = MessageUtil.message2Bytes(send);
		System.out.println(new String(message2Bytes));
			
		ValueObject object = (ValueObject) MessageUtil.bytes2Message(message2Bytes);
		
		if (object instanceof  OrderChange_1D )
		{
			DealPutThroughCancelRequest_3C order1 = (DealPutThroughCancelRequest_3C)object ;
			assertTrue(order1.compareTo(send));
		}
		
	}
	
	@Test
	public void testMessage2tobyteAndbytetoMessage_3D()
	{
		DealCancelReply_3D send = new DealCancelReply_3D();
		
		send.setFirm("056");
		send.setConfirmNumber("1234  ");
		send.setReplyCode(" ");
		
		byte[] message2Bytes = MessageUtil.message2Bytes(send);
		System.out.println(new String(message2Bytes));
			
		ValueObject object = (ValueObject) MessageUtil.bytes2Message(message2Bytes);
		
		if (object instanceof  OrderChange_1D )
		{
			OrderChange_1D order1 = (OrderChange_1D)object ;
			assertTrue(order1.compareTo(send));
		}
	}
	
	@Test
	public void testMessage2tobyteAndbytetoMessage_RN()
	{
		RetransmissionNack_RN recieve = new RetransmissionNack_RN ();
		
		recieve.setFirm(8623);
		recieve.setErrorCode("ER");
		
		String temp = "" ;
		
		temp = "aaaa";
		for (int i =temp.length(); i < 478; i++) {
			temp += " " ;
		}

		recieve.setOriginalMessageText(temp);
		byte[] message2Bytes = MessageUtil.message2Bytes(recieve);
		System.out.println(new String(message2Bytes));
			
		ValueObject object = (ValueObject) MessageUtil.bytes2Message(message2Bytes);
		
		if (object instanceof  RetransmissionNack_RN )
		{
			RetransmissionNack_RN order1 = (RetransmissionNack_RN)object ;
			assertTrue(order1.compareTo(recieve));
		}
		
		
	}
	@Test
	public void testMessage2tobyteAndbytetoMessage_RP()
	{
		RetransmissionReply_RP recieve = new RetransmissionReply_RP();
		
		recieve.setFirm(5623);
		recieve.setMarketID("A");
		recieve.setPreviousSequenceNumber(623);
		recieve.setSequenceNumber(721);
		recieve.setMessageCount(92);
		
		String temp = "" ;
		
		for (int i = 0; i <300  ; i++) {
			temp += "1" ;
		}

		recieve.setOriginalBroadcastMessage(temp);
		
		byte[] message2Bytes = MessageUtil.message2Bytes(recieve);
		String strTemp = new String(message2Bytes);
		strTemp = "A" +strTemp;
		message2Bytes = strTemp.getBytes();
		
			
		ValueObject object = (ValueObject) MessageUtil.bytesRRorRQ2Message(message2Bytes);
		System.out.println("test----");
		System.out.println(object.toString());
		System.out.println("test----");
		
//		if (object instanceof  RetransmissionReply_RP )
//		{
//			RetransmissionReply_RP order1 = (RetransmissionReply_RP)object ;
//			assertTrue(order1.compareTo(recieve));
//		}
		
	}
	@Test
	public void testMessage2tobyteAndbytetoMessage_RQ()
	{
		RetransmissionRequest_RQ send = new RetransmissionRequest_RQ(); 
		
		send.setFirm(57);
		send.setMarketID("A");
		send.setRetransmissionStartSequence(884) ;
		send.setRetransmissionEndSequence(884735);	
		
		byte[] message2Bytes = MessageUtil.message2Bytes(send);
		System.out.println("send:" + send);
//		message2Bytes = "RQ YA#8P#9T".getBytes();	
		ValueObject object = (ValueObject) MessageUtil.bytes2Message(message2Bytes);
		System.out.println("receive:" + object);
		if (object instanceof  RetransmissionRequest_RQ )
		{
			RetransmissionRequest_RQ order1 = (RetransmissionRequest_RQ)object ;
			assertTrue(order1.compareTo(send));
		}
	}
	
	
}
