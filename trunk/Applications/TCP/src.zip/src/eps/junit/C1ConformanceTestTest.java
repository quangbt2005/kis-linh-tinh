package eps.junit;

import static junit.framework.Assert.*;

import java.util.List;

import org.junit.Test;

import eps.com.client.proposal.EPSServiceController;
import eps.com.common.ValueObject;
import eps.com.message.sended.Advertisement_1E;
import eps.com.message.sended.NewConditioned_1I;
import eps.com.message.sended.RetransmissionRequest_RQ;
import eps.com.test.C1ConformanceTest;
import eps.com.test.Day1FunctionTest;
import eps.com.test.TestCommon;
import eps.com.util.MessageUtil;

public class C1ConformanceTestTest {
	@Test
	public void loadTest() throws Exception {
		List<NewConditioned_1I> loadTest1 = C1ConformanceTest.loadTest1();
		assertEquals(1100, loadTest1.size());

		String price;
		int numATO = 0, numATC = 0, numMP = 0, numLO = 0;
		for (NewConditioned_1I new1I : loadTest1) {
			price = new1I.getPrice();
			if (price.equals("ATO")) {
				numATO++;
			} else if (price.equals("ATC")) {
				numATC++;
			} else if (price.equals("MP")) {
				numMP++;
			} else {
				numLO++;
			}
		}

		assertEquals(800, numLO);
		assertEquals(200, numATO);
		assertEquals(50, numMP);
		assertEquals(50, numATC);

		numATO = 0;
		numATC = 0;
		numMP = 0;
		numLO = 0;

		List<NewConditioned_1I> loadTest2 = C1ConformanceTest.loadTest2();
		assertEquals(2600, loadTest2.size());

		for (NewConditioned_1I new1I : loadTest2) {
			price = new1I.getPrice();
			if (price.equals("ATO")) {
				numATO++;
			} else if (price.equals("ATC")) {
				numATC++;
			} else if (price.equals("MP")) {
				numMP++;
			} else {
				numLO++;
			}
		}

		assertEquals(2100, numLO);
		assertEquals(100, numATO);
		assertEquals(100, numMP);
		assertEquals(300, numATC);

		numATO = 0;
		numATC = 0;
		numMP = 0;
		numLO = 0;

		List<NewConditioned_1I> loadTest3 = C1ConformanceTest.loadTest3();
		assertEquals(1100, loadTest3.size());
		
		for (NewConditioned_1I new1I : loadTest3) {
			price = new1I.getPrice();
			if (price.equals("ATO")) {
				numATO++;
			} else if (price.equals("ATC")) {
				numATC++;
			} else if (price.equals("MP")) {
				numMP++;
			} else {
				numLO++;
			}
		}

		assertEquals(800, numLO);
		assertEquals(50, numATO);
		assertEquals(50, numMP);
		assertEquals(200, numATC);

	}
}
