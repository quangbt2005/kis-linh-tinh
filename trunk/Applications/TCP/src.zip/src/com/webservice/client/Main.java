package com.webservice.client;

import java.io.IOException;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.graphics.Rectangle;
public class Main {

	private Shell sShell = null;  //  @jve:decl-index=0:visual-constraint="41,66"
	private Group group1 = null;
	private Group group2 = null;
	private Button btnTest = null;
	private Button btnConnect = null;
	private Text txtIP = null;
	private Text txtPort = null;
	private Label label = null;
	private Label label1 = null;
	private Button rdModeA = null;
	private Button rdModeB = null;
	private Button rdModeC = null;
	private Group group = null;
	private Group group3 = null;
	//Connecter connecter=null;
	
	private Label label2 = null;
	private Label label3 = null;
	private Text txtuser = null;
	private Text txtpass = null;
	/**
	 * This method initializes group1	
	 *
	 */
	private void createGroup1() {
		group1 = new Group(sShell, SWT.NONE);
		
		group1.setText("Mode");
		group1.setBounds(new Rectangle(296, 7, 289, 80));
		rdModeA = new Button(group1, SWT.RADIO);
		rdModeA.setBounds(new Rectangle(19, 14, 248, 23));
		rdModeA.setText("A - New connection");
		rdModeB = new Button(group1, SWT.RADIO);
		rdModeB.setBounds(new Rectangle(19, 37, 248, 23));
		rdModeB.setText("B - Forced continued connection");
		rdModeC = new Button(group1, SWT.RADIO);
		rdModeC.setBounds(new Rectangle(19, 58, 248, 23));
		rdModeC.setText("C - Continue connection");
	}

	/**
	 * This method initializes group2	
	 *
	 */
	private void createGroup2() {
		group2 = new Group(sShell, SWT.NONE);		
		group2.setText("Admin");
		group2.setBounds(new Rectangle(6, 7, 284, 80));
		btnTest = new Button(group2, SWT.NONE);
		btnTest.setText("Test");
		btnTest.setBounds(new Rectangle(183, 45, 89, 21));		
		btnTest.addMouseListener(new org.eclipse.swt.events.MouseAdapter() {
			public void mouseDown(org.eclipse.swt.events.MouseEvent e) {
				System.out.println("test"); // TODO Auto-generated Event stub mouseDown()
				try {
					//connecter.test();
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		btnConnect = new Button(group2, SWT.NONE);
		btnConnect.setBounds(new Rectangle(183, 13, 89, 21));
		btnConnect.setText("Connect");
		btnConnect.addMouseListener(new org.eclipse.swt.events.MouseAdapter() {
			public void mouseDown(org.eclipse.swt.events.MouseEvent e) {
				System.out.println("mouseDown()"); // TODO Auto-generated Event stub mouseDown()				
				try {
					
					//connecter.connect(txtpass.getText());
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}			 
				
				
			}
		});
		
		
		txtIP = new Text(group2, SWT.BORDER);
		txtIP.setBounds(new Rectangle(71, 16, 104, 19));
		txtIP.setText("172.16.255.30");
		txtPort = new Text(group2, SWT.BORDER);
		txtPort.setBounds(new Rectangle(70, 46, 104, 19));
		txtPort.setText("30057");
		label = new Label(group2, SWT.NONE);
		label.setBounds(new Rectangle(9, 15, 54, 19));
		label.setText("Server IP:");
		label1 = new Label(group2, SWT.NONE);
		label1.setBounds(new Rectangle(8, 47, 60, 16));
		label1.setText("Server Port:");
	}

	/**
	 * This method initializes group	
	 *
	 */
	private void createGroup() {
		group = new Group(sShell, SWT.NONE);		
		group.setText("Information");
		group.setBounds(new Rectangle(6, 88, 580, 54));
		label2 = new Label(group, SWT.NONE);
		label2.setBounds(new Rectangle(26, 20, 37, 21));
		label2.setText("User");
		label3 = new Label(group, SWT.NONE);
		label3.setBounds(new Rectangle(184, 19, 54, 21));
		label3.setText("Password");
		txtuser = new Text(group, SWT.BORDER);
		txtuser.setBounds(new Rectangle(70, 18, 102, 21));
		txtuser.setText("057");
		txtpass = new Text(group, SWT.SINGLE | SWT.PASSWORD);
		
		txtpass.setBounds(new Rectangle(243, 18, 120, 21));
		txtpass.setText("12345678");
	}

	/**
	 * This method initializes group3	
	 *
	 */
	private void createGroup3() {
		group3 = new Group(sShell, SWT.NONE);
		group3.setLayout(new GridLayout());
		group3.setBounds(new Rectangle(6, 139, 580, 310));
	}

	/**
	 * @param args 
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/* Before this is run, be sure to set up the launch configuration (Arguments->VM Arguments)
		 * for the correct SWT library path in order to run with the SWT dlls. 
		 * The dlls are located in the SWT plugin jar.  
		 * For example, on Windows the Eclipse SWT 3.1 plugin jar is:
		 *       installation_directory\plugins\org.eclipse.swt.win32_3.1.0.jar
		 */
		Display display = Display.getDefault();
		Main thisClass = new Main();
		thisClass.createSShell();
		thisClass.sShell.open();

		while (!thisClass.sShell.isDisposed()) {
			if (!display.readAndDispatch())
				display.sleep();
		}
		display.dispose();
	}
	

	/**
	 * This method initializes sShell
	 */
	private void createSShell() {
		
		sShell = new Shell();
		sShell.setText("Test 1.0");
		
		createGroup1();
		createGroup2();
		createGroup();
		createGroup3();
		//connecter=new Connecter(txtIP.getText(), Integer.parseInt(txtPort.getText()) );
		sShell.setSize(new Point(600, 500));
		
		sShell.addShellListener(new org.eclipse.swt.events.ShellAdapter() {
			public void shellClosed(org.eclipse.swt.events.ShellEvent e) {
				try {
					//connecter.close();
				} catch (Exception e1) {					
					e1.printStackTrace();
				}
				System.out.println("shellClosed()"); // TODO Auto-generated Event stub shellClosed()
				
			}
		});
		
	}

}
