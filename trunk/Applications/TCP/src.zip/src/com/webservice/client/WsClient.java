package com.webservice.client;

import org.codehaus.xfire.XFire;
import org.codehaus.xfire.XFireFactory;
import org.codehaus.xfire.client.XFireProxyFactory;
import org.codehaus.xfire.service.Service;
import org.codehaus.xfire.service.binding.ObjectServiceFactory;

import eps.com.client.EPSServiceInterface;
import eps.com.test.TestCommon;

public class WsClient {

	public WsClient() {
		super();
	}

	public String sendOrder(String Firm, String TraderID, String OrderNumber,
			String ClientID, String SecuritySymbol, String Side, String Volume,
			String PublishedVolume, String Price, String Board, String Filler,
			String ClientFlag, String Filler2) {
		// create a proxy for the deployed service
		XFire xfire = XFireFactory.newInstance().getXFire();
		Service serviceModel = new ObjectServiceFactory(xfire
				.getTransportManager()).create(EPSServiceInterface.class);
		XFireProxyFactory factory = new XFireProxyFactory(xfire);
		String serviceUrl = "http://localhost:8080/HoseEasyTrading/services/EPSService";
		EPSServiceInterface client = null;
		try {
			client = (EPSServiceInterface) factory.create(serviceModel,
					serviceUrl);
			String serviceResponse = client.newConditionedOrder1I(Firm,
					TraderID, OrderNumber, ClientID, SecuritySymbol, Side,
					Volume, PublishedVolume, Price, Board, Filler, ClientFlag,
					Filler2);
			return serviceResponse;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "Error.";
	}

	public static void main(String arg[]) {
		try {
			WsClient wsClient = new WsClient();

			for (int i = 0; i < 1; i++) {
				String order = TestCommon.createRandomOrderNumber();
				String acount = TestCommon.createRandomAcountBuy();
				String sb = TestCommon.createRandomSymbol();
				System.out.println(order + ";" + acount + ";" + sb);
				String sendOrder = wsClient.sendOrder("057", "2120", order,
						acount, sb, "B", "1000    ", "1000    ", "ATO     ",
						"M", "", "C", "");
				System.out.println(sendOrder);
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
	}
}
