/**
 * GetListAdOrdersStruct.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package classDirectlyOrderTransfer;

public class GetListAdOrdersStruct  implements java.io.Serializable {
    private java.lang.String messageType;

    private java.lang.String firm;

    private java.lang.String traderID;

    private java.lang.String securitySymbol;

    private java.lang.String side;

    private java.lang.String volume;

    private java.lang.String price;

    private java.lang.String board;

    private java.lang.String time;

    private java.lang.String addCancelFlag;

    private java.lang.String contact;

    private java.lang.String clientIDBuyer;

    private java.lang.String clientIDSeller;

    private java.lang.String dealID;

    private java.lang.String filler;

    private java.lang.String brokerPortfolioVolumeBuyer;

    private java.lang.String brokerClientVolumeBuyer;

    private java.lang.String mutualFundVolumeBuyer;

    private java.lang.String brokerForeignVolumeBuyer;

    private java.lang.String filler2;

    private java.lang.String brokerPortfolioVolumeSeller;

    private java.lang.String brokerClientVolumeSeller;

    private java.lang.String mutualFundVolumeSeller;

    private java.lang.String brokerForeignVolumeSeller;

    private java.lang.String filler3;

    private java.lang.String firmSeller;

    private java.lang.String traderIDSeller;

    private java.lang.String contraFirmBuyer;

    private java.lang.String traderIDBuyer;

    private java.lang.String traderIDSender;

    private java.lang.String traderIDReciever;

    private java.lang.String contraFirm;

    private java.lang.String adminMessageText;

    private java.lang.String confirmNumber;

    private java.lang.String replyCode;

    private java.lang.String brokerPortfolioVolume;

    private java.lang.String brokerClientVolume;

    private java.lang.String brokerMutualFundVolume;

    private java.lang.String brokerForeignVolume;

    public GetListAdOrdersStruct() {
    }

    public GetListAdOrdersStruct(
           java.lang.String messageType,
           java.lang.String firm,
           java.lang.String traderID,
           java.lang.String securitySymbol,
           java.lang.String side,
           java.lang.String volume,
           java.lang.String price,
           java.lang.String board,
           java.lang.String time,
           java.lang.String addCancelFlag,
           java.lang.String contact,
           java.lang.String clientIDBuyer,
           java.lang.String clientIDSeller,
           java.lang.String dealID,
           java.lang.String filler,
           java.lang.String brokerPortfolioVolumeBuyer,
           java.lang.String brokerClientVolumeBuyer,
           java.lang.String mutualFundVolumeBuyer,
           java.lang.String brokerForeignVolumeBuyer,
           java.lang.String filler2,
           java.lang.String brokerPortfolioVolumeSeller,
           java.lang.String brokerClientVolumeSeller,
           java.lang.String mutualFundVolumeSeller,
           java.lang.String brokerForeignVolumeSeller,
           java.lang.String filler3,
           java.lang.String firmSeller,
           java.lang.String traderIDSeller,
           java.lang.String contraFirmBuyer,
           java.lang.String traderIDBuyer,
           java.lang.String traderIDSender,
           java.lang.String traderIDReciever,
           java.lang.String contraFirm,
           java.lang.String adminMessageText,
           java.lang.String confirmNumber,
           java.lang.String replyCode,
           java.lang.String brokerPortfolioVolume,
           java.lang.String brokerClientVolume,
           java.lang.String brokerMutualFundVolume,
           java.lang.String brokerForeignVolume) {
           this.messageType = messageType;
           this.firm = firm;
           this.traderID = traderID;
           this.securitySymbol = securitySymbol;
           this.side = side;
           this.volume = volume;
           this.price = price;
           this.board = board;
           this.time = time;
           this.addCancelFlag = addCancelFlag;
           this.contact = contact;
           this.clientIDBuyer = clientIDBuyer;
           this.clientIDSeller = clientIDSeller;
           this.dealID = dealID;
           this.filler = filler;
           this.brokerPortfolioVolumeBuyer = brokerPortfolioVolumeBuyer;
           this.brokerClientVolumeBuyer = brokerClientVolumeBuyer;
           this.mutualFundVolumeBuyer = mutualFundVolumeBuyer;
           this.brokerForeignVolumeBuyer = brokerForeignVolumeBuyer;
           this.filler2 = filler2;
           this.brokerPortfolioVolumeSeller = brokerPortfolioVolumeSeller;
           this.brokerClientVolumeSeller = brokerClientVolumeSeller;
           this.mutualFundVolumeSeller = mutualFundVolumeSeller;
           this.brokerForeignVolumeSeller = brokerForeignVolumeSeller;
           this.filler3 = filler3;
           this.firmSeller = firmSeller;
           this.traderIDSeller = traderIDSeller;
           this.contraFirmBuyer = contraFirmBuyer;
           this.traderIDBuyer = traderIDBuyer;
           this.traderIDSender = traderIDSender;
           this.traderIDReciever = traderIDReciever;
           this.contraFirm = contraFirm;
           this.adminMessageText = adminMessageText;
           this.confirmNumber = confirmNumber;
           this.replyCode = replyCode;
           this.brokerPortfolioVolume = brokerPortfolioVolume;
           this.brokerClientVolume = brokerClientVolume;
           this.brokerMutualFundVolume = brokerMutualFundVolume;
           this.brokerForeignVolume = brokerForeignVolume;
    }


    /**
     * Gets the messageType value for this GetListAdOrdersStruct.
     * 
     * @return messageType
     */
    public java.lang.String getMessageType() {
        return messageType;
    }


    /**
     * Sets the messageType value for this GetListAdOrdersStruct.
     * 
     * @param messageType
     */
    public void setMessageType(java.lang.String messageType) {
        this.messageType = messageType;
    }


    /**
     * Gets the firm value for this GetListAdOrdersStruct.
     * 
     * @return firm
     */
    public java.lang.String getFirm() {
        return firm;
    }


    /**
     * Sets the firm value for this GetListAdOrdersStruct.
     * 
     * @param firm
     */
    public void setFirm(java.lang.String firm) {
        this.firm = firm;
    }


    /**
     * Gets the traderID value for this GetListAdOrdersStruct.
     * 
     * @return traderID
     */
    public java.lang.String getTraderID() {
        return traderID;
    }


    /**
     * Sets the traderID value for this GetListAdOrdersStruct.
     * 
     * @param traderID
     */
    public void setTraderID(java.lang.String traderID) {
        this.traderID = traderID;
    }


    /**
     * Gets the securitySymbol value for this GetListAdOrdersStruct.
     * 
     * @return securitySymbol
     */
    public java.lang.String getSecuritySymbol() {
        return securitySymbol;
    }


    /**
     * Sets the securitySymbol value for this GetListAdOrdersStruct.
     * 
     * @param securitySymbol
     */
    public void setSecuritySymbol(java.lang.String securitySymbol) {
        this.securitySymbol = securitySymbol;
    }


    /**
     * Gets the side value for this GetListAdOrdersStruct.
     * 
     * @return side
     */
    public java.lang.String getSide() {
        return side;
    }


    /**
     * Sets the side value for this GetListAdOrdersStruct.
     * 
     * @param side
     */
    public void setSide(java.lang.String side) {
        this.side = side;
    }


    /**
     * Gets the volume value for this GetListAdOrdersStruct.
     * 
     * @return volume
     */
    public java.lang.String getVolume() {
        return volume;
    }


    /**
     * Sets the volume value for this GetListAdOrdersStruct.
     * 
     * @param volume
     */
    public void setVolume(java.lang.String volume) {
        this.volume = volume;
    }


    /**
     * Gets the price value for this GetListAdOrdersStruct.
     * 
     * @return price
     */
    public java.lang.String getPrice() {
        return price;
    }


    /**
     * Sets the price value for this GetListAdOrdersStruct.
     * 
     * @param price
     */
    public void setPrice(java.lang.String price) {
        this.price = price;
    }


    /**
     * Gets the board value for this GetListAdOrdersStruct.
     * 
     * @return board
     */
    public java.lang.String getBoard() {
        return board;
    }


    /**
     * Sets the board value for this GetListAdOrdersStruct.
     * 
     * @param board
     */
    public void setBoard(java.lang.String board) {
        this.board = board;
    }


    /**
     * Gets the time value for this GetListAdOrdersStruct.
     * 
     * @return time
     */
    public java.lang.String getTime() {
        return time;
    }


    /**
     * Sets the time value for this GetListAdOrdersStruct.
     * 
     * @param time
     */
    public void setTime(java.lang.String time) {
        this.time = time;
    }


    /**
     * Gets the addCancelFlag value for this GetListAdOrdersStruct.
     * 
     * @return addCancelFlag
     */
    public java.lang.String getAddCancelFlag() {
        return addCancelFlag;
    }


    /**
     * Sets the addCancelFlag value for this GetListAdOrdersStruct.
     * 
     * @param addCancelFlag
     */
    public void setAddCancelFlag(java.lang.String addCancelFlag) {
        this.addCancelFlag = addCancelFlag;
    }


    /**
     * Gets the contact value for this GetListAdOrdersStruct.
     * 
     * @return contact
     */
    public java.lang.String getContact() {
        return contact;
    }


    /**
     * Sets the contact value for this GetListAdOrdersStruct.
     * 
     * @param contact
     */
    public void setContact(java.lang.String contact) {
        this.contact = contact;
    }


    /**
     * Gets the clientIDBuyer value for this GetListAdOrdersStruct.
     * 
     * @return clientIDBuyer
     */
    public java.lang.String getClientIDBuyer() {
        return clientIDBuyer;
    }


    /**
     * Sets the clientIDBuyer value for this GetListAdOrdersStruct.
     * 
     * @param clientIDBuyer
     */
    public void setClientIDBuyer(java.lang.String clientIDBuyer) {
        this.clientIDBuyer = clientIDBuyer;
    }


    /**
     * Gets the clientIDSeller value for this GetListAdOrdersStruct.
     * 
     * @return clientIDSeller
     */
    public java.lang.String getClientIDSeller() {
        return clientIDSeller;
    }


    /**
     * Sets the clientIDSeller value for this GetListAdOrdersStruct.
     * 
     * @param clientIDSeller
     */
    public void setClientIDSeller(java.lang.String clientIDSeller) {
        this.clientIDSeller = clientIDSeller;
    }


    /**
     * Gets the dealID value for this GetListAdOrdersStruct.
     * 
     * @return dealID
     */
    public java.lang.String getDealID() {
        return dealID;
    }


    /**
     * Sets the dealID value for this GetListAdOrdersStruct.
     * 
     * @param dealID
     */
    public void setDealID(java.lang.String dealID) {
        this.dealID = dealID;
    }


    /**
     * Gets the filler value for this GetListAdOrdersStruct.
     * 
     * @return filler
     */
    public java.lang.String getFiller() {
        return filler;
    }


    /**
     * Sets the filler value for this GetListAdOrdersStruct.
     * 
     * @param filler
     */
    public void setFiller(java.lang.String filler) {
        this.filler = filler;
    }


    /**
     * Gets the brokerPortfolioVolumeBuyer value for this GetListAdOrdersStruct.
     * 
     * @return brokerPortfolioVolumeBuyer
     */
    public java.lang.String getBrokerPortfolioVolumeBuyer() {
        return brokerPortfolioVolumeBuyer;
    }


    /**
     * Sets the brokerPortfolioVolumeBuyer value for this GetListAdOrdersStruct.
     * 
     * @param brokerPortfolioVolumeBuyer
     */
    public void setBrokerPortfolioVolumeBuyer(java.lang.String brokerPortfolioVolumeBuyer) {
        this.brokerPortfolioVolumeBuyer = brokerPortfolioVolumeBuyer;
    }


    /**
     * Gets the brokerClientVolumeBuyer value for this GetListAdOrdersStruct.
     * 
     * @return brokerClientVolumeBuyer
     */
    public java.lang.String getBrokerClientVolumeBuyer() {
        return brokerClientVolumeBuyer;
    }


    /**
     * Sets the brokerClientVolumeBuyer value for this GetListAdOrdersStruct.
     * 
     * @param brokerClientVolumeBuyer
     */
    public void setBrokerClientVolumeBuyer(java.lang.String brokerClientVolumeBuyer) {
        this.brokerClientVolumeBuyer = brokerClientVolumeBuyer;
    }


    /**
     * Gets the mutualFundVolumeBuyer value for this GetListAdOrdersStruct.
     * 
     * @return mutualFundVolumeBuyer
     */
    public java.lang.String getMutualFundVolumeBuyer() {
        return mutualFundVolumeBuyer;
    }


    /**
     * Sets the mutualFundVolumeBuyer value for this GetListAdOrdersStruct.
     * 
     * @param mutualFundVolumeBuyer
     */
    public void setMutualFundVolumeBuyer(java.lang.String mutualFundVolumeBuyer) {
        this.mutualFundVolumeBuyer = mutualFundVolumeBuyer;
    }


    /**
     * Gets the brokerForeignVolumeBuyer value for this GetListAdOrdersStruct.
     * 
     * @return brokerForeignVolumeBuyer
     */
    public java.lang.String getBrokerForeignVolumeBuyer() {
        return brokerForeignVolumeBuyer;
    }


    /**
     * Sets the brokerForeignVolumeBuyer value for this GetListAdOrdersStruct.
     * 
     * @param brokerForeignVolumeBuyer
     */
    public void setBrokerForeignVolumeBuyer(java.lang.String brokerForeignVolumeBuyer) {
        this.brokerForeignVolumeBuyer = brokerForeignVolumeBuyer;
    }


    /**
     * Gets the filler2 value for this GetListAdOrdersStruct.
     * 
     * @return filler2
     */
    public java.lang.String getFiller2() {
        return filler2;
    }


    /**
     * Sets the filler2 value for this GetListAdOrdersStruct.
     * 
     * @param filler2
     */
    public void setFiller2(java.lang.String filler2) {
        this.filler2 = filler2;
    }


    /**
     * Gets the brokerPortfolioVolumeSeller value for this GetListAdOrdersStruct.
     * 
     * @return brokerPortfolioVolumeSeller
     */
    public java.lang.String getBrokerPortfolioVolumeSeller() {
        return brokerPortfolioVolumeSeller;
    }


    /**
     * Sets the brokerPortfolioVolumeSeller value for this GetListAdOrdersStruct.
     * 
     * @param brokerPortfolioVolumeSeller
     */
    public void setBrokerPortfolioVolumeSeller(java.lang.String brokerPortfolioVolumeSeller) {
        this.brokerPortfolioVolumeSeller = brokerPortfolioVolumeSeller;
    }


    /**
     * Gets the brokerClientVolumeSeller value for this GetListAdOrdersStruct.
     * 
     * @return brokerClientVolumeSeller
     */
    public java.lang.String getBrokerClientVolumeSeller() {
        return brokerClientVolumeSeller;
    }


    /**
     * Sets the brokerClientVolumeSeller value for this GetListAdOrdersStruct.
     * 
     * @param brokerClientVolumeSeller
     */
    public void setBrokerClientVolumeSeller(java.lang.String brokerClientVolumeSeller) {
        this.brokerClientVolumeSeller = brokerClientVolumeSeller;
    }


    /**
     * Gets the mutualFundVolumeSeller value for this GetListAdOrdersStruct.
     * 
     * @return mutualFundVolumeSeller
     */
    public java.lang.String getMutualFundVolumeSeller() {
        return mutualFundVolumeSeller;
    }


    /**
     * Sets the mutualFundVolumeSeller value for this GetListAdOrdersStruct.
     * 
     * @param mutualFundVolumeSeller
     */
    public void setMutualFundVolumeSeller(java.lang.String mutualFundVolumeSeller) {
        this.mutualFundVolumeSeller = mutualFundVolumeSeller;
    }


    /**
     * Gets the brokerForeignVolumeSeller value for this GetListAdOrdersStruct.
     * 
     * @return brokerForeignVolumeSeller
     */
    public java.lang.String getBrokerForeignVolumeSeller() {
        return brokerForeignVolumeSeller;
    }


    /**
     * Sets the brokerForeignVolumeSeller value for this GetListAdOrdersStruct.
     * 
     * @param brokerForeignVolumeSeller
     */
    public void setBrokerForeignVolumeSeller(java.lang.String brokerForeignVolumeSeller) {
        this.brokerForeignVolumeSeller = brokerForeignVolumeSeller;
    }


    /**
     * Gets the filler3 value for this GetListAdOrdersStruct.
     * 
     * @return filler3
     */
    public java.lang.String getFiller3() {
        return filler3;
    }


    /**
     * Sets the filler3 value for this GetListAdOrdersStruct.
     * 
     * @param filler3
     */
    public void setFiller3(java.lang.String filler3) {
        this.filler3 = filler3;
    }


    /**
     * Gets the firmSeller value for this GetListAdOrdersStruct.
     * 
     * @return firmSeller
     */
    public java.lang.String getFirmSeller() {
        return firmSeller;
    }


    /**
     * Sets the firmSeller value for this GetListAdOrdersStruct.
     * 
     * @param firmSeller
     */
    public void setFirmSeller(java.lang.String firmSeller) {
        this.firmSeller = firmSeller;
    }


    /**
     * Gets the traderIDSeller value for this GetListAdOrdersStruct.
     * 
     * @return traderIDSeller
     */
    public java.lang.String getTraderIDSeller() {
        return traderIDSeller;
    }


    /**
     * Sets the traderIDSeller value for this GetListAdOrdersStruct.
     * 
     * @param traderIDSeller
     */
    public void setTraderIDSeller(java.lang.String traderIDSeller) {
        this.traderIDSeller = traderIDSeller;
    }


    /**
     * Gets the contraFirmBuyer value for this GetListAdOrdersStruct.
     * 
     * @return contraFirmBuyer
     */
    public java.lang.String getContraFirmBuyer() {
        return contraFirmBuyer;
    }


    /**
     * Sets the contraFirmBuyer value for this GetListAdOrdersStruct.
     * 
     * @param contraFirmBuyer
     */
    public void setContraFirmBuyer(java.lang.String contraFirmBuyer) {
        this.contraFirmBuyer = contraFirmBuyer;
    }


    /**
     * Gets the traderIDBuyer value for this GetListAdOrdersStruct.
     * 
     * @return traderIDBuyer
     */
    public java.lang.String getTraderIDBuyer() {
        return traderIDBuyer;
    }


    /**
     * Sets the traderIDBuyer value for this GetListAdOrdersStruct.
     * 
     * @param traderIDBuyer
     */
    public void setTraderIDBuyer(java.lang.String traderIDBuyer) {
        this.traderIDBuyer = traderIDBuyer;
    }


    /**
     * Gets the traderIDSender value for this GetListAdOrdersStruct.
     * 
     * @return traderIDSender
     */
    public java.lang.String getTraderIDSender() {
        return traderIDSender;
    }


    /**
     * Sets the traderIDSender value for this GetListAdOrdersStruct.
     * 
     * @param traderIDSender
     */
    public void setTraderIDSender(java.lang.String traderIDSender) {
        this.traderIDSender = traderIDSender;
    }


    /**
     * Gets the traderIDReciever value for this GetListAdOrdersStruct.
     * 
     * @return traderIDReciever
     */
    public java.lang.String getTraderIDReciever() {
        return traderIDReciever;
    }


    /**
     * Sets the traderIDReciever value for this GetListAdOrdersStruct.
     * 
     * @param traderIDReciever
     */
    public void setTraderIDReciever(java.lang.String traderIDReciever) {
        this.traderIDReciever = traderIDReciever;
    }


    /**
     * Gets the contraFirm value for this GetListAdOrdersStruct.
     * 
     * @return contraFirm
     */
    public java.lang.String getContraFirm() {
        return contraFirm;
    }


    /**
     * Sets the contraFirm value for this GetListAdOrdersStruct.
     * 
     * @param contraFirm
     */
    public void setContraFirm(java.lang.String contraFirm) {
        this.contraFirm = contraFirm;
    }


    /**
     * Gets the adminMessageText value for this GetListAdOrdersStruct.
     * 
     * @return adminMessageText
     */
    public java.lang.String getAdminMessageText() {
        return adminMessageText;
    }


    /**
     * Sets the adminMessageText value for this GetListAdOrdersStruct.
     * 
     * @param adminMessageText
     */
    public void setAdminMessageText(java.lang.String adminMessageText) {
        this.adminMessageText = adminMessageText;
    }


    /**
     * Gets the confirmNumber value for this GetListAdOrdersStruct.
     * 
     * @return confirmNumber
     */
    public java.lang.String getConfirmNumber() {
        return confirmNumber;
    }


    /**
     * Sets the confirmNumber value for this GetListAdOrdersStruct.
     * 
     * @param confirmNumber
     */
    public void setConfirmNumber(java.lang.String confirmNumber) {
        this.confirmNumber = confirmNumber;
    }


    /**
     * Gets the replyCode value for this GetListAdOrdersStruct.
     * 
     * @return replyCode
     */
    public java.lang.String getReplyCode() {
        return replyCode;
    }


    /**
     * Sets the replyCode value for this GetListAdOrdersStruct.
     * 
     * @param replyCode
     */
    public void setReplyCode(java.lang.String replyCode) {
        this.replyCode = replyCode;
    }


    /**
     * Gets the brokerPortfolioVolume value for this GetListAdOrdersStruct.
     * 
     * @return brokerPortfolioVolume
     */
    public java.lang.String getBrokerPortfolioVolume() {
        return brokerPortfolioVolume;
    }


    /**
     * Sets the brokerPortfolioVolume value for this GetListAdOrdersStruct.
     * 
     * @param brokerPortfolioVolume
     */
    public void setBrokerPortfolioVolume(java.lang.String brokerPortfolioVolume) {
        this.brokerPortfolioVolume = brokerPortfolioVolume;
    }


    /**
     * Gets the brokerClientVolume value for this GetListAdOrdersStruct.
     * 
     * @return brokerClientVolume
     */
    public java.lang.String getBrokerClientVolume() {
        return brokerClientVolume;
    }


    /**
     * Sets the brokerClientVolume value for this GetListAdOrdersStruct.
     * 
     * @param brokerClientVolume
     */
    public void setBrokerClientVolume(java.lang.String brokerClientVolume) {
        this.brokerClientVolume = brokerClientVolume;
    }


    /**
     * Gets the brokerMutualFundVolume value for this GetListAdOrdersStruct.
     * 
     * @return brokerMutualFundVolume
     */
    public java.lang.String getBrokerMutualFundVolume() {
        return brokerMutualFundVolume;
    }


    /**
     * Sets the brokerMutualFundVolume value for this GetListAdOrdersStruct.
     * 
     * @param brokerMutualFundVolume
     */
    public void setBrokerMutualFundVolume(java.lang.String brokerMutualFundVolume) {
        this.brokerMutualFundVolume = brokerMutualFundVolume;
    }


    /**
     * Gets the brokerForeignVolume value for this GetListAdOrdersStruct.
     * 
     * @return brokerForeignVolume
     */
    public java.lang.String getBrokerForeignVolume() {
        return brokerForeignVolume;
    }


    /**
     * Sets the brokerForeignVolume value for this GetListAdOrdersStruct.
     * 
     * @param brokerForeignVolume
     */
    public void setBrokerForeignVolume(java.lang.String brokerForeignVolume) {
        this.brokerForeignVolume = brokerForeignVolume;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof GetListAdOrdersStruct)) return false;
        GetListAdOrdersStruct other = (GetListAdOrdersStruct) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.messageType==null && other.getMessageType()==null) || 
             (this.messageType!=null &&
              this.messageType.equals(other.getMessageType()))) &&
            ((this.firm==null && other.getFirm()==null) || 
             (this.firm!=null &&
              this.firm.equals(other.getFirm()))) &&
            ((this.traderID==null && other.getTraderID()==null) || 
             (this.traderID!=null &&
              this.traderID.equals(other.getTraderID()))) &&
            ((this.securitySymbol==null && other.getSecuritySymbol()==null) || 
             (this.securitySymbol!=null &&
              this.securitySymbol.equals(other.getSecuritySymbol()))) &&
            ((this.side==null && other.getSide()==null) || 
             (this.side!=null &&
              this.side.equals(other.getSide()))) &&
            ((this.volume==null && other.getVolume()==null) || 
             (this.volume!=null &&
              this.volume.equals(other.getVolume()))) &&
            ((this.price==null && other.getPrice()==null) || 
             (this.price!=null &&
              this.price.equals(other.getPrice()))) &&
            ((this.board==null && other.getBoard()==null) || 
             (this.board!=null &&
              this.board.equals(other.getBoard()))) &&
            ((this.time==null && other.getTime()==null) || 
             (this.time!=null &&
              this.time.equals(other.getTime()))) &&
            ((this.addCancelFlag==null && other.getAddCancelFlag()==null) || 
             (this.addCancelFlag!=null &&
              this.addCancelFlag.equals(other.getAddCancelFlag()))) &&
            ((this.contact==null && other.getContact()==null) || 
             (this.contact!=null &&
              this.contact.equals(other.getContact()))) &&
            ((this.clientIDBuyer==null && other.getClientIDBuyer()==null) || 
             (this.clientIDBuyer!=null &&
              this.clientIDBuyer.equals(other.getClientIDBuyer()))) &&
            ((this.clientIDSeller==null && other.getClientIDSeller()==null) || 
             (this.clientIDSeller!=null &&
              this.clientIDSeller.equals(other.getClientIDSeller()))) &&
            ((this.dealID==null && other.getDealID()==null) || 
             (this.dealID!=null &&
              this.dealID.equals(other.getDealID()))) &&
            ((this.filler==null && other.getFiller()==null) || 
             (this.filler!=null &&
              this.filler.equals(other.getFiller()))) &&
            ((this.brokerPortfolioVolumeBuyer==null && other.getBrokerPortfolioVolumeBuyer()==null) || 
             (this.brokerPortfolioVolumeBuyer!=null &&
              this.brokerPortfolioVolumeBuyer.equals(other.getBrokerPortfolioVolumeBuyer()))) &&
            ((this.brokerClientVolumeBuyer==null && other.getBrokerClientVolumeBuyer()==null) || 
             (this.brokerClientVolumeBuyer!=null &&
              this.brokerClientVolumeBuyer.equals(other.getBrokerClientVolumeBuyer()))) &&
            ((this.mutualFundVolumeBuyer==null && other.getMutualFundVolumeBuyer()==null) || 
             (this.mutualFundVolumeBuyer!=null &&
              this.mutualFundVolumeBuyer.equals(other.getMutualFundVolumeBuyer()))) &&
            ((this.brokerForeignVolumeBuyer==null && other.getBrokerForeignVolumeBuyer()==null) || 
             (this.brokerForeignVolumeBuyer!=null &&
              this.brokerForeignVolumeBuyer.equals(other.getBrokerForeignVolumeBuyer()))) &&
            ((this.filler2==null && other.getFiller2()==null) || 
             (this.filler2!=null &&
              this.filler2.equals(other.getFiller2()))) &&
            ((this.brokerPortfolioVolumeSeller==null && other.getBrokerPortfolioVolumeSeller()==null) || 
             (this.brokerPortfolioVolumeSeller!=null &&
              this.brokerPortfolioVolumeSeller.equals(other.getBrokerPortfolioVolumeSeller()))) &&
            ((this.brokerClientVolumeSeller==null && other.getBrokerClientVolumeSeller()==null) || 
             (this.brokerClientVolumeSeller!=null &&
              this.brokerClientVolumeSeller.equals(other.getBrokerClientVolumeSeller()))) &&
            ((this.mutualFundVolumeSeller==null && other.getMutualFundVolumeSeller()==null) || 
             (this.mutualFundVolumeSeller!=null &&
              this.mutualFundVolumeSeller.equals(other.getMutualFundVolumeSeller()))) &&
            ((this.brokerForeignVolumeSeller==null && other.getBrokerForeignVolumeSeller()==null) || 
             (this.brokerForeignVolumeSeller!=null &&
              this.brokerForeignVolumeSeller.equals(other.getBrokerForeignVolumeSeller()))) &&
            ((this.filler3==null && other.getFiller3()==null) || 
             (this.filler3!=null &&
              this.filler3.equals(other.getFiller3()))) &&
            ((this.firmSeller==null && other.getFirmSeller()==null) || 
             (this.firmSeller!=null &&
              this.firmSeller.equals(other.getFirmSeller()))) &&
            ((this.traderIDSeller==null && other.getTraderIDSeller()==null) || 
             (this.traderIDSeller!=null &&
              this.traderIDSeller.equals(other.getTraderIDSeller()))) &&
            ((this.contraFirmBuyer==null && other.getContraFirmBuyer()==null) || 
             (this.contraFirmBuyer!=null &&
              this.contraFirmBuyer.equals(other.getContraFirmBuyer()))) &&
            ((this.traderIDBuyer==null && other.getTraderIDBuyer()==null) || 
             (this.traderIDBuyer!=null &&
              this.traderIDBuyer.equals(other.getTraderIDBuyer()))) &&
            ((this.traderIDSender==null && other.getTraderIDSender()==null) || 
             (this.traderIDSender!=null &&
              this.traderIDSender.equals(other.getTraderIDSender()))) &&
            ((this.traderIDReciever==null && other.getTraderIDReciever()==null) || 
             (this.traderIDReciever!=null &&
              this.traderIDReciever.equals(other.getTraderIDReciever()))) &&
            ((this.contraFirm==null && other.getContraFirm()==null) || 
             (this.contraFirm!=null &&
              this.contraFirm.equals(other.getContraFirm()))) &&
            ((this.adminMessageText==null && other.getAdminMessageText()==null) || 
             (this.adminMessageText!=null &&
              this.adminMessageText.equals(other.getAdminMessageText()))) &&
            ((this.confirmNumber==null && other.getConfirmNumber()==null) || 
             (this.confirmNumber!=null &&
              this.confirmNumber.equals(other.getConfirmNumber()))) &&
            ((this.replyCode==null && other.getReplyCode()==null) || 
             (this.replyCode!=null &&
              this.replyCode.equals(other.getReplyCode()))) &&
            ((this.brokerPortfolioVolume==null && other.getBrokerPortfolioVolume()==null) || 
             (this.brokerPortfolioVolume!=null &&
              this.brokerPortfolioVolume.equals(other.getBrokerPortfolioVolume()))) &&
            ((this.brokerClientVolume==null && other.getBrokerClientVolume()==null) || 
             (this.brokerClientVolume!=null &&
              this.brokerClientVolume.equals(other.getBrokerClientVolume()))) &&
            ((this.brokerMutualFundVolume==null && other.getBrokerMutualFundVolume()==null) || 
             (this.brokerMutualFundVolume!=null &&
              this.brokerMutualFundVolume.equals(other.getBrokerMutualFundVolume()))) &&
            ((this.brokerForeignVolume==null && other.getBrokerForeignVolume()==null) || 
             (this.brokerForeignVolume!=null &&
              this.brokerForeignVolume.equals(other.getBrokerForeignVolume())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getMessageType() != null) {
            _hashCode += getMessageType().hashCode();
        }
        if (getFirm() != null) {
            _hashCode += getFirm().hashCode();
        }
        if (getTraderID() != null) {
            _hashCode += getTraderID().hashCode();
        }
        if (getSecuritySymbol() != null) {
            _hashCode += getSecuritySymbol().hashCode();
        }
        if (getSide() != null) {
            _hashCode += getSide().hashCode();
        }
        if (getVolume() != null) {
            _hashCode += getVolume().hashCode();
        }
        if (getPrice() != null) {
            _hashCode += getPrice().hashCode();
        }
        if (getBoard() != null) {
            _hashCode += getBoard().hashCode();
        }
        if (getTime() != null) {
            _hashCode += getTime().hashCode();
        }
        if (getAddCancelFlag() != null) {
            _hashCode += getAddCancelFlag().hashCode();
        }
        if (getContact() != null) {
            _hashCode += getContact().hashCode();
        }
        if (getClientIDBuyer() != null) {
            _hashCode += getClientIDBuyer().hashCode();
        }
        if (getClientIDSeller() != null) {
            _hashCode += getClientIDSeller().hashCode();
        }
        if (getDealID() != null) {
            _hashCode += getDealID().hashCode();
        }
        if (getFiller() != null) {
            _hashCode += getFiller().hashCode();
        }
        if (getBrokerPortfolioVolumeBuyer() != null) {
            _hashCode += getBrokerPortfolioVolumeBuyer().hashCode();
        }
        if (getBrokerClientVolumeBuyer() != null) {
            _hashCode += getBrokerClientVolumeBuyer().hashCode();
        }
        if (getMutualFundVolumeBuyer() != null) {
            _hashCode += getMutualFundVolumeBuyer().hashCode();
        }
        if (getBrokerForeignVolumeBuyer() != null) {
            _hashCode += getBrokerForeignVolumeBuyer().hashCode();
        }
        if (getFiller2() != null) {
            _hashCode += getFiller2().hashCode();
        }
        if (getBrokerPortfolioVolumeSeller() != null) {
            _hashCode += getBrokerPortfolioVolumeSeller().hashCode();
        }
        if (getBrokerClientVolumeSeller() != null) {
            _hashCode += getBrokerClientVolumeSeller().hashCode();
        }
        if (getMutualFundVolumeSeller() != null) {
            _hashCode += getMutualFundVolumeSeller().hashCode();
        }
        if (getBrokerForeignVolumeSeller() != null) {
            _hashCode += getBrokerForeignVolumeSeller().hashCode();
        }
        if (getFiller3() != null) {
            _hashCode += getFiller3().hashCode();
        }
        if (getFirmSeller() != null) {
            _hashCode += getFirmSeller().hashCode();
        }
        if (getTraderIDSeller() != null) {
            _hashCode += getTraderIDSeller().hashCode();
        }
        if (getContraFirmBuyer() != null) {
            _hashCode += getContraFirmBuyer().hashCode();
        }
        if (getTraderIDBuyer() != null) {
            _hashCode += getTraderIDBuyer().hashCode();
        }
        if (getTraderIDSender() != null) {
            _hashCode += getTraderIDSender().hashCode();
        }
        if (getTraderIDReciever() != null) {
            _hashCode += getTraderIDReciever().hashCode();
        }
        if (getContraFirm() != null) {
            _hashCode += getContraFirm().hashCode();
        }
        if (getAdminMessageText() != null) {
            _hashCode += getAdminMessageText().hashCode();
        }
        if (getConfirmNumber() != null) {
            _hashCode += getConfirmNumber().hashCode();
        }
        if (getReplyCode() != null) {
            _hashCode += getReplyCode().hashCode();
        }
        if (getBrokerPortfolioVolume() != null) {
            _hashCode += getBrokerPortfolioVolume().hashCode();
        }
        if (getBrokerClientVolume() != null) {
            _hashCode += getBrokerClientVolume().hashCode();
        }
        if (getBrokerMutualFundVolume() != null) {
            _hashCode += getBrokerMutualFundVolume().hashCode();
        }
        if (getBrokerForeignVolume() != null) {
            _hashCode += getBrokerForeignVolume().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(GetListAdOrdersStruct.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("urn:classDirectlyOrderTransfer", "getListAdOrdersStruct"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("messageType");
        elemField.setXmlName(new javax.xml.namespace.QName("", "MessageType"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("firm");
        elemField.setXmlName(new javax.xml.namespace.QName("", "Firm"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("traderID");
        elemField.setXmlName(new javax.xml.namespace.QName("", "TraderID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("securitySymbol");
        elemField.setXmlName(new javax.xml.namespace.QName("", "SecuritySymbol"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("side");
        elemField.setXmlName(new javax.xml.namespace.QName("", "Side"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("volume");
        elemField.setXmlName(new javax.xml.namespace.QName("", "Volume"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("price");
        elemField.setXmlName(new javax.xml.namespace.QName("", "Price"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("board");
        elemField.setXmlName(new javax.xml.namespace.QName("", "Board"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("time");
        elemField.setXmlName(new javax.xml.namespace.QName("", "Time"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("addCancelFlag");
        elemField.setXmlName(new javax.xml.namespace.QName("", "AddCancelFlag"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("contact");
        elemField.setXmlName(new javax.xml.namespace.QName("", "Contact"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("clientIDBuyer");
        elemField.setXmlName(new javax.xml.namespace.QName("", "ClientIDBuyer"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("clientIDSeller");
        elemField.setXmlName(new javax.xml.namespace.QName("", "ClientIDSeller"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dealID");
        elemField.setXmlName(new javax.xml.namespace.QName("", "DealID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("filler");
        elemField.setXmlName(new javax.xml.namespace.QName("", "Filler"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("brokerPortfolioVolumeBuyer");
        elemField.setXmlName(new javax.xml.namespace.QName("", "BrokerPortfolioVolumeBuyer"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("brokerClientVolumeBuyer");
        elemField.setXmlName(new javax.xml.namespace.QName("", "BrokerClientVolumeBuyer"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("mutualFundVolumeBuyer");
        elemField.setXmlName(new javax.xml.namespace.QName("", "MutualFundVolumeBuyer"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("brokerForeignVolumeBuyer");
        elemField.setXmlName(new javax.xml.namespace.QName("", "BrokerForeignVolumeBuyer"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("filler2");
        elemField.setXmlName(new javax.xml.namespace.QName("", "Filler2"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("brokerPortfolioVolumeSeller");
        elemField.setXmlName(new javax.xml.namespace.QName("", "BrokerPortfolioVolumeSeller"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("brokerClientVolumeSeller");
        elemField.setXmlName(new javax.xml.namespace.QName("", "BrokerClientVolumeSeller"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("mutualFundVolumeSeller");
        elemField.setXmlName(new javax.xml.namespace.QName("", "MutualFundVolumeSeller"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("brokerForeignVolumeSeller");
        elemField.setXmlName(new javax.xml.namespace.QName("", "BrokerForeignVolumeSeller"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("filler3");
        elemField.setXmlName(new javax.xml.namespace.QName("", "Filler3"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("firmSeller");
        elemField.setXmlName(new javax.xml.namespace.QName("", "FirmSeller"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("traderIDSeller");
        elemField.setXmlName(new javax.xml.namespace.QName("", "TraderIDSeller"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("contraFirmBuyer");
        elemField.setXmlName(new javax.xml.namespace.QName("", "ContraFirmBuyer"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("traderIDBuyer");
        elemField.setXmlName(new javax.xml.namespace.QName("", "TraderIDBuyer"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("traderIDSender");
        elemField.setXmlName(new javax.xml.namespace.QName("", "TraderIDSender"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("traderIDReciever");
        elemField.setXmlName(new javax.xml.namespace.QName("", "TraderIDReciever"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("contraFirm");
        elemField.setXmlName(new javax.xml.namespace.QName("", "ContraFirm"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("adminMessageText");
        elemField.setXmlName(new javax.xml.namespace.QName("", "AdminMessageText"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("confirmNumber");
        elemField.setXmlName(new javax.xml.namespace.QName("", "ConfirmNumber"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("replyCode");
        elemField.setXmlName(new javax.xml.namespace.QName("", "ReplyCode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("brokerPortfolioVolume");
        elemField.setXmlName(new javax.xml.namespace.QName("", "BrokerPortfolioVolume"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("brokerClientVolume");
        elemField.setXmlName(new javax.xml.namespace.QName("", "BrokerClientVolume"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("brokerMutualFundVolume");
        elemField.setXmlName(new javax.xml.namespace.QName("", "BrokerMutualFundVolume"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("brokerForeignVolume");
        elemField.setXmlName(new javax.xml.namespace.QName("", "BrokerForeignVolume"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
