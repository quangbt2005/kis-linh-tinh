/**
 * GetListTransferingOrdersStruct.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package classDirectlyOrderTransfer;

public class GetListTransferingOrdersStruct  implements java.io.Serializable {
    private java.lang.String messageType;

    private java.lang.String firm;

    private java.lang.String traderID;

    private java.lang.String orderNumber;

    private java.lang.String clientID;

    private java.lang.String securitySymbol;

    private java.lang.String side;

    private java.lang.String volume;

    private java.lang.String publishedVolume;

    private java.lang.String price;

    private java.lang.String board;

    private java.lang.String filler;

    private java.lang.String portClientFlag;

    private java.lang.String filler2;

    private java.lang.String orderEntryDate;

    public GetListTransferingOrdersStruct() {
    }

    public GetListTransferingOrdersStruct(
           java.lang.String messageType,
           java.lang.String firm,
           java.lang.String traderID,
           java.lang.String orderNumber,
           java.lang.String clientID,
           java.lang.String securitySymbol,
           java.lang.String side,
           java.lang.String volume,
           java.lang.String publishedVolume,
           java.lang.String price,
           java.lang.String board,
           java.lang.String filler,
           java.lang.String portClientFlag,
           java.lang.String filler2,
           java.lang.String orderEntryDate) {
           this.messageType = messageType;
           this.firm = firm;
           this.traderID = traderID;
           this.orderNumber = orderNumber;
           this.clientID = clientID;
           this.securitySymbol = securitySymbol;
           this.side = side;
           this.volume = volume;
           this.publishedVolume = publishedVolume;
           this.price = price;
           this.board = board;
           this.filler = filler;
           this.portClientFlag = portClientFlag;
           this.filler2 = filler2;
           this.orderEntryDate = orderEntryDate;
    }


    /**
     * Gets the messageType value for this GetListTransferingOrdersStruct.
     * 
     * @return messageType
     */
    public java.lang.String getMessageType() {
        return messageType;
    }


    /**
     * Sets the messageType value for this GetListTransferingOrdersStruct.
     * 
     * @param messageType
     */
    public void setMessageType(java.lang.String messageType) {
        this.messageType = messageType;
    }


    /**
     * Gets the firm value for this GetListTransferingOrdersStruct.
     * 
     * @return firm
     */
    public java.lang.String getFirm() {
        return firm;
    }


    /**
     * Sets the firm value for this GetListTransferingOrdersStruct.
     * 
     * @param firm
     */
    public void setFirm(java.lang.String firm) {
        this.firm = firm;
    }


    /**
     * Gets the traderID value for this GetListTransferingOrdersStruct.
     * 
     * @return traderID
     */
    public java.lang.String getTraderID() {
        return traderID;
    }


    /**
     * Sets the traderID value for this GetListTransferingOrdersStruct.
     * 
     * @param traderID
     */
    public void setTraderID(java.lang.String traderID) {
        this.traderID = traderID;
    }


    /**
     * Gets the orderNumber value for this GetListTransferingOrdersStruct.
     * 
     * @return orderNumber
     */
    public java.lang.String getOrderNumber() {
        return orderNumber;
    }


    /**
     * Sets the orderNumber value for this GetListTransferingOrdersStruct.
     * 
     * @param orderNumber
     */
    public void setOrderNumber(java.lang.String orderNumber) {
        this.orderNumber = orderNumber;
    }


    /**
     * Gets the clientID value for this GetListTransferingOrdersStruct.
     * 
     * @return clientID
     */
    public java.lang.String getClientID() {
        return clientID;
    }


    /**
     * Sets the clientID value for this GetListTransferingOrdersStruct.
     * 
     * @param clientID
     */
    public void setClientID(java.lang.String clientID) {
        this.clientID = clientID;
    }


    /**
     * Gets the securitySymbol value for this GetListTransferingOrdersStruct.
     * 
     * @return securitySymbol
     */
    public java.lang.String getSecuritySymbol() {
        return securitySymbol;
    }


    /**
     * Sets the securitySymbol value for this GetListTransferingOrdersStruct.
     * 
     * @param securitySymbol
     */
    public void setSecuritySymbol(java.lang.String securitySymbol) {
        this.securitySymbol = securitySymbol;
    }


    /**
     * Gets the side value for this GetListTransferingOrdersStruct.
     * 
     * @return side
     */
    public java.lang.String getSide() {
        return side;
    }


    /**
     * Sets the side value for this GetListTransferingOrdersStruct.
     * 
     * @param side
     */
    public void setSide(java.lang.String side) {
        this.side = side;
    }


    /**
     * Gets the volume value for this GetListTransferingOrdersStruct.
     * 
     * @return volume
     */
    public java.lang.String getVolume() {
        return volume;
    }


    /**
     * Sets the volume value for this GetListTransferingOrdersStruct.
     * 
     * @param volume
     */
    public void setVolume(java.lang.String volume) {
        this.volume = volume;
    }


    /**
     * Gets the publishedVolume value for this GetListTransferingOrdersStruct.
     * 
     * @return publishedVolume
     */
    public java.lang.String getPublishedVolume() {
        return publishedVolume;
    }


    /**
     * Sets the publishedVolume value for this GetListTransferingOrdersStruct.
     * 
     * @param publishedVolume
     */
    public void setPublishedVolume(java.lang.String publishedVolume) {
        this.publishedVolume = publishedVolume;
    }


    /**
     * Gets the price value for this GetListTransferingOrdersStruct.
     * 
     * @return price
     */
    public java.lang.String getPrice() {
        return price;
    }


    /**
     * Sets the price value for this GetListTransferingOrdersStruct.
     * 
     * @param price
     */
    public void setPrice(java.lang.String price) {
        this.price = price;
    }


    /**
     * Gets the board value for this GetListTransferingOrdersStruct.
     * 
     * @return board
     */
    public java.lang.String getBoard() {
        return board;
    }


    /**
     * Sets the board value for this GetListTransferingOrdersStruct.
     * 
     * @param board
     */
    public void setBoard(java.lang.String board) {
        this.board = board;
    }


    /**
     * Gets the filler value for this GetListTransferingOrdersStruct.
     * 
     * @return filler
     */
    public java.lang.String getFiller() {
        return filler;
    }


    /**
     * Sets the filler value for this GetListTransferingOrdersStruct.
     * 
     * @param filler
     */
    public void setFiller(java.lang.String filler) {
        this.filler = filler;
    }


    /**
     * Gets the portClientFlag value for this GetListTransferingOrdersStruct.
     * 
     * @return portClientFlag
     */
    public java.lang.String getPortClientFlag() {
        return portClientFlag;
    }


    /**
     * Sets the portClientFlag value for this GetListTransferingOrdersStruct.
     * 
     * @param portClientFlag
     */
    public void setPortClientFlag(java.lang.String portClientFlag) {
        this.portClientFlag = portClientFlag;
    }


    /**
     * Gets the filler2 value for this GetListTransferingOrdersStruct.
     * 
     * @return filler2
     */
    public java.lang.String getFiller2() {
        return filler2;
    }


    /**
     * Sets the filler2 value for this GetListTransferingOrdersStruct.
     * 
     * @param filler2
     */
    public void setFiller2(java.lang.String filler2) {
        this.filler2 = filler2;
    }


    /**
     * Gets the orderEntryDate value for this GetListTransferingOrdersStruct.
     * 
     * @return orderEntryDate
     */
    public java.lang.String getOrderEntryDate() {
        return orderEntryDate;
    }


    /**
     * Sets the orderEntryDate value for this GetListTransferingOrdersStruct.
     * 
     * @param orderEntryDate
     */
    public void setOrderEntryDate(java.lang.String orderEntryDate) {
        this.orderEntryDate = orderEntryDate;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof GetListTransferingOrdersStruct)) return false;
        GetListTransferingOrdersStruct other = (GetListTransferingOrdersStruct) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.messageType==null && other.getMessageType()==null) || 
             (this.messageType!=null &&
              this.messageType.equals(other.getMessageType()))) &&
            ((this.firm==null && other.getFirm()==null) || 
             (this.firm!=null &&
              this.firm.equals(other.getFirm()))) &&
            ((this.traderID==null && other.getTraderID()==null) || 
             (this.traderID!=null &&
              this.traderID.equals(other.getTraderID()))) &&
            ((this.orderNumber==null && other.getOrderNumber()==null) || 
             (this.orderNumber!=null &&
              this.orderNumber.equals(other.getOrderNumber()))) &&
            ((this.clientID==null && other.getClientID()==null) || 
             (this.clientID!=null &&
              this.clientID.equals(other.getClientID()))) &&
            ((this.securitySymbol==null && other.getSecuritySymbol()==null) || 
             (this.securitySymbol!=null &&
              this.securitySymbol.equals(other.getSecuritySymbol()))) &&
            ((this.side==null && other.getSide()==null) || 
             (this.side!=null &&
              this.side.equals(other.getSide()))) &&
            ((this.volume==null && other.getVolume()==null) || 
             (this.volume!=null &&
              this.volume.equals(other.getVolume()))) &&
            ((this.publishedVolume==null && other.getPublishedVolume()==null) || 
             (this.publishedVolume!=null &&
              this.publishedVolume.equals(other.getPublishedVolume()))) &&
            ((this.price==null && other.getPrice()==null) || 
             (this.price!=null &&
              this.price.equals(other.getPrice()))) &&
            ((this.board==null && other.getBoard()==null) || 
             (this.board!=null &&
              this.board.equals(other.getBoard()))) &&
            ((this.filler==null && other.getFiller()==null) || 
             (this.filler!=null &&
              this.filler.equals(other.getFiller()))) &&
            ((this.portClientFlag==null && other.getPortClientFlag()==null) || 
             (this.portClientFlag!=null &&
              this.portClientFlag.equals(other.getPortClientFlag()))) &&
            ((this.filler2==null && other.getFiller2()==null) || 
             (this.filler2!=null &&
              this.filler2.equals(other.getFiller2()))) &&
            ((this.orderEntryDate==null && other.getOrderEntryDate()==null) || 
             (this.orderEntryDate!=null &&
              this.orderEntryDate.equals(other.getOrderEntryDate())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getMessageType() != null) {
            _hashCode += getMessageType().hashCode();
        }
        if (getFirm() != null) {
            _hashCode += getFirm().hashCode();
        }
        if (getTraderID() != null) {
            _hashCode += getTraderID().hashCode();
        }
        if (getOrderNumber() != null) {
            _hashCode += getOrderNumber().hashCode();
        }
        if (getClientID() != null) {
            _hashCode += getClientID().hashCode();
        }
        if (getSecuritySymbol() != null) {
            _hashCode += getSecuritySymbol().hashCode();
        }
        if (getSide() != null) {
            _hashCode += getSide().hashCode();
        }
        if (getVolume() != null) {
            _hashCode += getVolume().hashCode();
        }
        if (getPublishedVolume() != null) {
            _hashCode += getPublishedVolume().hashCode();
        }
        if (getPrice() != null) {
            _hashCode += getPrice().hashCode();
        }
        if (getBoard() != null) {
            _hashCode += getBoard().hashCode();
        }
        if (getFiller() != null) {
            _hashCode += getFiller().hashCode();
        }
        if (getPortClientFlag() != null) {
            _hashCode += getPortClientFlag().hashCode();
        }
        if (getFiller2() != null) {
            _hashCode += getFiller2().hashCode();
        }
        if (getOrderEntryDate() != null) {
            _hashCode += getOrderEntryDate().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(GetListTransferingOrdersStruct.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("urn:classDirectlyOrderTransfer", "getListTransferingOrdersStruct"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("messageType");
        elemField.setXmlName(new javax.xml.namespace.QName("", "MessageType"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("firm");
        elemField.setXmlName(new javax.xml.namespace.QName("", "Firm"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("traderID");
        elemField.setXmlName(new javax.xml.namespace.QName("", "TraderID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("orderNumber");
        elemField.setXmlName(new javax.xml.namespace.QName("", "OrderNumber"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("clientID");
        elemField.setXmlName(new javax.xml.namespace.QName("", "ClientID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("securitySymbol");
        elemField.setXmlName(new javax.xml.namespace.QName("", "SecuritySymbol"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("side");
        elemField.setXmlName(new javax.xml.namespace.QName("", "Side"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("volume");
        elemField.setXmlName(new javax.xml.namespace.QName("", "Volume"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("publishedVolume");
        elemField.setXmlName(new javax.xml.namespace.QName("", "PublishedVolume"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("price");
        elemField.setXmlName(new javax.xml.namespace.QName("", "Price"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("board");
        elemField.setXmlName(new javax.xml.namespace.QName("", "Board"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("filler");
        elemField.setXmlName(new javax.xml.namespace.QName("", "Filler"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("portClientFlag");
        elemField.setXmlName(new javax.xml.namespace.QName("", "PortClientFlag"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("filler2");
        elemField.setXmlName(new javax.xml.namespace.QName("", "Filler2"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("orderEntryDate");
        elemField.setXmlName(new javax.xml.namespace.QName("", "OrderEntryDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
