package eps.junit;

import static junit.framework.Assert.assertTrue;

import org.junit.Test;

import classDirectlyOrderTransfer.ClassDirectlyOrderTransferPort;
import classDirectlyOrderTransfer.ClassDirectlyOrderTransferService;
import classDirectlyOrderTransfer.ClassDirectlyOrderTransferServiceLocator;
import eps.com.common.ValueObject;
import eps.com.message.broadcast.AdvertisementAnnouncement_AA;
import eps.com.message.broadcast.BroadcastMessageService;
import eps.com.message.broadcast.BrokerReconcile_BR;
import eps.com.message.broadcast.BrokerStatusChange_BS;
import eps.com.message.broadcast.CancelOddLot_CO;
import eps.com.message.broadcast.DealCancellationNotice_DC;
import eps.com.message.broadcast.ForeignRoom_TR;
import eps.com.message.broadcast.GeneralAdmin_GA;
import eps.com.message.broadcast.IndexUpdate_IU;
import eps.com.message.broadcast.LastOddLot_LO;
import eps.com.message.broadcast.LastSale_LS;
import eps.com.message.broadcast.MarketOpenLastSale_OS;
import eps.com.message.broadcast.NewHeadLine_NH;
import eps.com.message.broadcast.NewOddLot_OL;
import eps.com.message.broadcast.NewsHeadline_NH;
import eps.com.message.broadcast.NewsStory_NS;
import eps.com.message.broadcast.ProjectedOpen_PO;
import eps.com.message.broadcast.PutThroughDealNotice_PD;
import eps.com.message.broadcast.SectoralIndices_SI;
import eps.com.message.broadcast.SecurityReconcile_SR;
import eps.com.message.broadcast.SecurityStatusChange_SS;
import eps.com.message.broadcast.SecurityUpdate_SU;
import eps.com.message.broadcast.SystemControl_SC;
import eps.com.message.broadcast.TimeStamp_TS;
import eps.com.message.broadcast.TopPrices_TP;
import eps.com.message.broadcast.TraderStatusChange_TC;
import eps.com.util.MessageUtil;

public class TestUPDWebService {
	private ClassDirectlyOrderTransferService svc ;
	private ClassDirectlyOrderTransferPort getclassDirectlyOrderTransferPort;
	BroadcastMessageService udpService = new BroadcastMessageService(); 
	
	public TestUPDWebService() throws Exception{
		svc = new ClassDirectlyOrderTransferServiceLocator();
		getclassDirectlyOrderTransferPort = svc.getclassDirectlyOrderTransferPort();
		udpService.setGetclassDirectlyOrderTransferPort(getclassDirectlyOrderTransferPort);
	}
	
	@Test 
	public void testMessage2tobyteAndbytetoMessage_TS()
	{
	}
	
	@Test 
	public void testMessage2tobyteAndbytetoMessage_SU() //1
	{
		SecurityUpdate_SU su = new SecurityUpdate_SU() ;
		su.setS_SecurityNumberOld(9212);
		su.setS_SecurityNumberNew(8000);
		su.setS_Filler1(" ");
		su.setS_SectorNumber(95);
		su.setS_Filler2(" ");
		su.setS_SecuritySymbol("12345678");
		su.setS_SecurityType("S");
		su.setS_CeilingPrice(536232);
		su.setS_FloorPrice(23523);
		su.setS_LastSalePrice(23542);
		su.setS_MarketID("A");
		su.setS_Filler3("   ");
		su.setS_SecurityName("1234567890123456789012345");
		su.setS_Filler4(" ");
		su.setS_Suspension(" ");
		su.setS_Delist(" ");
		su.setS_HaltResumeFlag("H");
		su.setS_Split(" ");
		su.setS_Benefit("B");
		su.setS_Meeting(" ");
		su.setS_Notice(" ");
		su.setS_ClientIDRequired("R");
		su.setS_ParValue(2536541);
		su.setS_SDCFlag("S");
		su.setS_PriorClosePrice(2365322);
		su.setS_PriorClosedate("12345678");
		su.setS_OpenPrice(235232);
		su.setS_HighestPrice(23123);
		su.setS_LowestPrice(23532);
		su.setS_TotalSharesTraded(3456);
		su.setS_TotalValuesTraded(23456);
		su.setS_BoardLot(5365);
		su.setS_Filler5(" ");	
		udpService.processMessage(su);
	}
	
 
	@Test 
	public void testMessage2tobyteAndbytetoMessage_TR() //2
	{
		ForeignRoom_TR tr = new ForeignRoom_TR();
		
		tr.setSecurity_Number(9212);
		tr.setTotal_Room(2532);
		tr.setCurrent_Room(255365);//255365
		udpService.processMessage(tr);
	}
	
	@Test 
	public void testMessage2tobyteAndbytetoMessage_TP() //3
	{
		TopPrices_TP tp = new TopPrices_TP () ;
		
		tp.setSecurity_Number(914);
		tp.setSide("S");
		tp.setPrice_1_best(253551);
		tp.setLot_Volume_1(1231);	
		tp.setPrice_2_2nd_best(12536);
		tp.setLot_Volume_2(9212);
		tp.setPrice_3_3rd_best(1235423);
		tp.setLot_Volume_3(23225);
		udpService.processMessage(tp);
	}
	@Test 
	public void testMessage2tobyteAndbytetoMessage_TC() //4
	{
		TraderStatusChange_TC tc = new TraderStatusChange_TC();
		
		tc.setFirm(2352);
		tc.setTrader_ID(253623);
		tc.setTrader_Status("S");
		udpService.processMessage(tc);
	}
	
	@Test 
	public void testMessage2tobyteAndbytetoMessage_SS() //5
	{
		SecurityStatusChange_SS ss = new SecurityStatusChange_SS();
		
		ss.setSecurity_Number(8798) ;
		ss.setSector_Number(95);
		ss.setHaltorResume_Flag("H");
		ss.setSystem_Control_Code("C");
		ss.setSuspension("S");
		ss.setDelist("D");
		ss.setCeiling(2536523);
		ss.setFloor_Price(2512535);
		ss.setSecurity_Type("S");
		ss.setPrior_Close_Price(452362);
		ss.setSplit("P");
		ss.setBenefit("B");
		ss.setMeeting("M");
		ss.setNotice("N");
		ss.setBoard_Lot(8777);
		ss.setFiller1(" ");
		ss.setFiller2(" ");
		ss.setFiller3(" ");
		ss.setFiller4(" ");
		ss.setFiller5(2536545);
		ss.setFiller6(" ");
		udpService.processMessage(ss);
	}
	
	
	@Test 
	// coi lai 
	public void testMessage2tobyteAndbytetoMessage_SR() //6
	{
		SecurityReconcile_SR sr = new SecurityReconcile_SR() ;
		
		sr.setSecurity_Number(2532);
		sr.setMain_or_Foreign_Deal(533322);
		sr.setMain_or_Foreign_Acc_Volume(81537); // lon hon kieu so long la ?
		sr.setMain_or_Foreign_Acc_Value(1548222);
		sr.setDeals_in_Big_Lot_Board(2535);
		sr.setBig_Lot_Acc_Volume(253252);
		sr.setBig_Lot_Acc_Value(123453);
		sr.setDeals_in_Big_Lot_Board(9212);
		sr.setOdd_Lot_Acc_Volume(3253);
		sr.setOdd_Lot_Acc_Value(23522);
		udpService.processMessage(sr);
	}
	@Test 
	public void testMessage2tobyteAndbytetoMessage_SI() //7
	{
		SectoralIndices_SI si = new SectoralIndices_SI();
		si.setIndex_Sectoral_1(15236544);
		String temp = "" ;
		for (int i = 0; i <120; i++) {
			temp+= " ";
		}
		si.setFiller(temp);
		si.setIndex_Time(12531);
		udpService.processMessage(si);
	}
	
	
	@Test 
	public void testMessage2tobyteAndbytetoMessage_SC() //8
	{
		SystemControl_SC sc = new SystemControl_SC();
		sc.setSystem_Control_Code("C");
		sc.setTimestamp(12535);
		udpService.processMessage(sc);		
	}
	
	@Test 
	public void testMessage2tobyteAndbytetoMessage_PO() //9
	{
		ProjectedOpen_PO po = new ProjectedOpen_PO();
		po.setSecurity_Number(5825);
		po.setProjected_Open_Price(884735);
		udpService.processMessage(po);
	}
	@Test 
	public void testMessage2tobyteAndbytetoMessage_PD() //10
	{
		PutThroughDealNotice_PD pd = new PutThroughDealNotice_PD();
		
		pd.setConfirm_Number(582652);
		pd.setSecurity_Number(9212);
		pd.setVolume(6325423);
		pd.setPrice(84934655);
		pd.setBoard("B");
		udpService.processMessage(pd);
	}
	
	@Test 
	public void testMessage2tobyteAndbytetoMessage_OS() //11
	{
		MarketOpenLastSale_OS os = new MarketOpenLastSale_OS() ;
		os.setSecurity_Number(2563);
		os.setPrice(5826522);
		udpService.processMessage(os);
	}
	
	@Test 
	public void testMessage2tobyteAndbytetoMessage_OL() //12
	{
		NewOddLot_OL ol = new NewOddLot_OL();
		ol.setSecurity_Number(8000);
		ol.setOdd_Lot_Volume(9212);	
		ol.setPrice(58256522);
		ol.setSide("S");
		ol.setReference_Number(884735);
		udpService.processMessage(ol);
	}
	@Test 
	public void testMessage2tobyteAndbytetoMessage_NS() //13
	{
		NewsStory_NS ns = new NewsStory_NS();
		ns.setNews_Number(8000);
		ns.setNews_Page_Number(6000);
		ns.setNews_Text_Length(5000);
		
		String text1 = "" ;
		text1 = "aaaa" ;
		for(int i=0;i<215-4;i++)
		{
			text1+=" ";
		}
		ns.setNews_Text(text1);
		udpService.processMessage(ns);
	}
	@Test 
	public void testMessage2tobyteAndbytetoMessage_NH() //14
	{
		NewHeadLine_NH nh = new NewHeadLine_NH();
		
		nh.setL_NewSNumber(9212);
		nh.setS_SecuritySymbol("12345678");
		nh.setL_NewsHeadlineLength(92) ;
		nh.setL_TotalNewsStoryPages(9212);
		nh.setS_NewsHeadlineText("1234567890123456789012345678901234567890123456789012345678901234567890");
		udpService.processMessage(nh);
	}
	
	@Test 
	public void testMessage2tobyteAndbytetoMessage_LS() //15
	{
		LastSale_LS ls = new LastSale_LS();
		
		ls.setConfirmNumber(67777);
		ls.setSecurityNumber(9212);
		ls.setLotVolume(884735) ;
		ls.setPrice(8493465);
		ls.setSide("S");
		udpService.processMessage(ls);	
	}
	
	@Test
	public void testMessage2tobyteAndbytetoMessage_LO() //16
	{
		LastOddLot_LO lo = new LastOddLot_LO();
		
		lo.setConfirm_Number(884735);
		lo.setSecurity_Number(9215)	;
		lo.setOdd_Lot_Volume(96);
		lo.setPrice(84934655);
		lo.setReference_Number(88473);
		udpService.processMessage(lo);
	}
	@Test
	public void testMessage2tobyteAndbytetoMessage_IU() //17
	{
		IndexUpdate_IU iu = new IndexUpdate_IU();
		
		iu.setIndexHoSE(94);
		iu.setTotalTrades(856325);
		iu.setTotalSharesTraded(444);
		iu.setTotalValuesTraded(815372);
		iu.setUpVolume(8000);
		iu.setDownVolume(7000);
		iu.setNoChangeVolume(815372697);
		iu.setAdvances(9213);
		iu.setDeclines(9000);
		iu.setNoChange(7000);
		iu.setFiller1("    ");
		iu.setMarketID("A");
		String temp = "" ;
		for (int i = 0; i < 7; i++) {
			temp+=" ";
		}
		iu.setFiller2(temp);
		iu.setIndexTime(5686);
		udpService.processMessage(iu);
		
	}
	@Test
	public void testMessage2tobyteAndbytetoMessage_GA() //18
	{
		GeneralAdmin_GA ga = new GeneralAdmin_GA();
		ga.setAdminMessageLength(94);
		ga.setAdminMessageText("1034567890103456789010345678901034567890103456789010345678901034567890");
		udpService.processMessage(ga);
	}
	@Test
	public void testMessage2tobyteAndbytetoMessage_DC() //18
	{
		DealCancellationNotice_DC dc = new DealCancellationNotice_DC();
		
		dc.setConfirmNumber(80000);
		dc.setSecurityNumber(2000);
		dc.setVolume(8493465);
		dc.setPrice(849346);
		dc.setBoard("B");
		udpService.processMessage(dc);
	}
	
	@Test
	public void testMessage2tobyteAndbytetoMessage_CO() //20
	{
		CancelOddLot_CO co = new CancelOddLot_CO();
		co.setReferenceNumber(2000);
		udpService.processMessage(co);
	}
	
	@Test 
	public void testMessage2tobyteAndbytetoMessage_BS() //21
	{
		BrokerStatusChange_BS msgBS = new BrokerStatusChange_BS();
		
		msgBS.setFirm(123);
		msgBS.setAutoMatchHaltFlag("H");
		msgBS.setPutthroughHaltFlag("R");
		udpService.processMessage(msgBS);
	}
	
	@Test
	public void testMessage2tobyteAndbytetoMessage_BR() //22
	{
		BrokerReconcile_BR msgBR = new BrokerReconcile_BR();
		msgBR.setFirm(123);
		msgBR.setMarketID("A");
		msgBR.setVolumeSold("1234567890");
		msgBR.setValueSold("12345678901234");
		msgBR.setVolumeBought("1234567890");
		msgBR.setValueBought("12345678901234");
		udpService.processMessage(msgBR);
	}
	
	
	@Test
	public void testMessage2tobyteAndbytetoMessage_AA() { //23
		AdvertisementAnnouncement_AA msgAA = new AdvertisementAnnouncement_AA();
	
		msgAA.setSecurityNumber(9);
		msgAA.setVolume(84934655);
		msgAA.setPrice("2000000000000");
		msgAA.setFirm(9215);
		msgAA.setTrader(884735);
		msgAA.setSide("A");
		msgAA.setBoard("A");
		msgAA.setTime(884735);
		msgAA.setAddCancelFlag("A");
		msgAA.setContact("aaaaaaaaaaaaaaaaaaaa");
		udpService.processMessage(msgAA);
	}
	
	public static void main(String arg[]) throws Exception{
		TestUPDWebService service = new TestUPDWebService(); 
	}
}
