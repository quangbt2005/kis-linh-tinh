package eps.junit;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses( { MessageOperatorTest.class, Mode96Test.class,
		RecoveryObjectTest.class, testBroastcastMessage.class,
		testTCPMessage.class, Day1FunctionTestTest.class,
		C1ConformanceTestTest.class })
public class AllTests {

}
