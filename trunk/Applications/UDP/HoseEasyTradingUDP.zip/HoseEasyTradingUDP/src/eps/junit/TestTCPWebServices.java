package eps.junit;

import static junit.framework.Assert.assertTrue;

import java.rmi.RemoteException;
import java.util.List;

import org.junit.Test;

import classDirectlyOrderTransfer.ClassDirectlyOrderTransferPort;
import classDirectlyOrderTransfer.ClassDirectlyOrderTransferService;
import classDirectlyOrderTransfer.ClassDirectlyOrderTransferServiceLocator;
import classDirectlyOrderTransfer.GetListAdOrdersResult;
import classDirectlyOrderTransfer.GetListAdOrdersStruct;
import classDirectlyOrderTransfer.GetListTransferingOrdersResult;
import classDirectlyOrderTransfer.GetListTransferingOrdersStruct;
import eps.com.client.proposal.EPSServiceController;
import eps.com.client.upd.UDPContent;
import eps.com.common.ValueObject;
import eps.com.message.received.Admin_3A;
import eps.com.message.received.ConfirmOfOrderCancel_2C;
import eps.com.message.received.ConfirmOfOrderChange_2D;
import eps.com.message.received.CrossingDealConfirmation_2I;
import eps.com.message.received.DealConfirmation_2E;
import eps.com.message.received.OrderConfirmation_2B;
import eps.com.message.received.PutThroughAcknowledgment_2F;
import eps.com.message.received.PutThroughDealConfirmation_2L;
import eps.com.message.received.Reject_2G;
import eps.com.message.received.RetransmissionNack_RN;
import eps.com.message.received.RetransmissionReply_RP;
import eps.com.message.received.TCPMessageService;
import eps.com.message.sended.Advertisement_1E;
import eps.com.message.sended.DealCancelReply_3D;
import eps.com.message.sended.DealPutThroughCancelRequest_3C;
import eps.com.message.sended.NewConditioned_1I;
import eps.com.message.sended.OneFirmPutThroughDeal_1F;
import eps.com.message.sended.OrderCancellation_1C;
import eps.com.message.sended.OrderChange_1D;
import eps.com.message.sended.PutThroughDealReply_3B;
import eps.com.message.sended.RetransmissionRequest_RQ;
import eps.com.message.sended.TwoFirmPutThroughDeal_1G;
import eps.com.test.TestCommon;
import eps.com.util.MessageUtil;

public class TestTCPWebServices {
	private ClassDirectlyOrderTransferService svc;
	private ClassDirectlyOrderTransferPort getclassDirectlyOrderTransferPort;
	private TCPMessageService tcpService = new TCPMessageService();

	public TestTCPWebServices() throws Exception {
		svc = new ClassDirectlyOrderTransferServiceLocator();
		getclassDirectlyOrderTransferPort = svc
				.getclassDirectlyOrderTransferPort();
		tcpService
				.setGetclassDirectlyOrderTransferPort(getclassDirectlyOrderTransferPort);
	}

	@Test
	public void testReadingOrders() throws Exception {
		GetListTransferingOrdersResult listTransferingOrders = getclassDirectlyOrderTransferPort
				.getListTransferingOrders("2008-10-14",
						TCPMessageService.authenUser,
						TCPMessageService.authenPass);
		GetListTransferingOrdersStruct[] items = listTransferingOrders
				.getItems();
		System.out.println("test item:" + items.length);

	}

	@Test
	public void testReadingAdOrders() throws Exception {
		GetListAdOrdersResult listTransferingOrders = getclassDirectlyOrderTransferPort
				.getListAdOrders("2008-10-14", TCPMessageService.authenUser,
						TCPMessageService.authenPass);
		GetListAdOrdersStruct[] items = listTransferingOrders.getItems();
		System.out.println("test Ad item:" + items.length);

	}

	@Test
	public void testMessage2tobyteAndbytetoMessage_2B() // 1
	{
		String OrderNumber = TestCommon.createRandomOrderNumber();
		OrderConfirmation_2B receive = new OrderConfirmation_2B();

		receive.setFirm("57");
		receive.setOrderNumber(OrderNumber);
		receive.setOrderEntryDate(TestCommon.getToday());
		tcpService.processTCPMessage(receive);

	}

	@Test
	public void testMessage2tobyteAndbytetoMessage_2C() // 2
	{
		String OrderNumber = TestCommon.createRandomOrderNumber();
		ConfirmOfOrderCancel_2C receive = new ConfirmOfOrderCancel_2C();

		receive.setFirm("" + EPSServiceController.FIRM_CONSTANT);
		receive.setCancelShares("12345678");
		receive.setOrderNumber(OrderNumber);
		receive.setOrderEntryDate(TestCommon.getToday());
		receive.setOrderCancelStatus("C");
		tcpService.processTCPMessage(receive);

	}

	@Test
	public void testMessage2tobyteAndbytetoMessage_2D() // 3
	{
		String OrderNumber = TestCommon.createRandomOrderNumber();
		String ClientID = TestCommon.createRandomAcountBuy();

		ConfirmOfOrderChange_2D receive = new ConfirmOfOrderChange_2D();

		receive.setFirm("" + EPSServiceController.FIRM_CONSTANT);
		receive.setOrderNumber(OrderNumber);
		receive.setOrderEntryDate("2001");
		receive.setClientID(ClientID);
		receive.setPortClientFlag(" ");
		receive.setPublishedVolume("12345678");
		receive.setPrice("12345 ");
		String temp = "";
		for (int i = 0; i < 8; i++) {
			temp += " ";
		}
		receive.setFiller(temp);
		tcpService.processTCPMessage(receive);
	}

	@Test
	public void testMessage2tobyteAndbytetoMessage_2E() // 4
	{
		DealConfirmation_2E receive = new DealConfirmation_2E();

		receive.setFirm("" + EPSServiceController.FIRM_CONSTANT);
		receive.setSide("B");
		String OrderNumber = TestCommon.createRandomOrderNumber();
		receive.setOrderNumber(OrderNumber);
		receive.setOrderEntryDate(TestCommon.getToday());
		receive.setFiller("  ");

		receive.setVolume("2000");
		receive.setPrice("34.5");
		receive.setConfirmNumber("12345");
		tcpService.processTCPMessage(receive);
	}

	@Test
	public void testMessage2tobyteAndbytetoMessage_2F() // 5
	{
		String SecuritySymbol = TestCommon.createRandomSymbol();
		PutThroughAcknowledgment_2F receive = new PutThroughAcknowledgment_2F();

		receive.setFirmBuy("" + EPSServiceController.FIRM_CONSTANT);
		receive.setTraderIDBuy("2010");
		receive.setSideB("B");
		receive.setContraFirmSell("061");
		receive.setTraderIDContraSideSell("611");
		receive.setSecuritySymbol(SecuritySymbol);
		receive.setVolume("30000");
		receive.setPrice("300000000");
		receive.setBoard("M");
		receive.setConfirmNumber("123456");
		tcpService.processTCPMessage(receive);
	}

	@Test
	public void testMessage2tobyteAndbytetoMessage_2G() // 6
	{
		Reject_2G receive = new Reject_2G();

		receive.setFirm("" + EPSServiceController.FIRM_CONSTANT);
		receive.setRejectReasonCode("A ");

	}

	@Test
	public void testMessage2tobyteAndbytetoMessage_2I() // 7
	{
		String OrderNumber = TestCommon.createRandomOrderNumber();
		CrossingDealConfirmation_2I receive = new CrossingDealConfirmation_2I();

		receive.setFirm("" + EPSServiceController.FIRM_CONSTANT);
		receive.setOrderNumberBuy(OrderNumber);
		receive.setOrderEntryDateBuy(TestCommon.getToday());
		receive.setOrderNumberSell(OrderNumber);
		receive.setOrderEntryDateSell(TestCommon.getToday());
		receive.setVolume("200");
		receive.setPrice("50");
		receive.setConfirmNumber("123456");
		tcpService.processTCPMessage(receive);
	}

	@Test
	public void testMessage2tobyteAndbytetoMessage_2L() // 8
	{
		PutThroughDealConfirmation_2L receive = new PutThroughDealConfirmation_2L();

		receive.setFirm("" + EPSServiceController.FIRM_CONSTANT);
		receive.setSide("B");
		receive.setDealID("12345");
		receive.setContraFirm("123");
		receive.setVolume("30000");
		receive.setPrice("300000000");
		receive.setConfirmNumber("123456");
		tcpService.processTCPMessage(receive);

	}

	@Test
	public void testMessage2tobyteAndbytetoMessage_3A() // 9
	{
		Admin_3A recieve = new Admin_3A();

		recieve.setFirm("" + EPSServiceController.FIRM_CONSTANT);
		recieve.setTraderIDSender("2010");
		recieve.setTraderIDReciever("102 ");
		recieve.setContraFirm("123");
		recieve.setAdminMessageText("AdminMessageText");
		tcpService.processTCPMessage(recieve);

	}

	@Test
	public void testMessage2tobyteAndbytetoMessage_3B() // 10
	{

		PutThroughDealReply_3B send = new PutThroughDealReply_3B();

		send.setFirm("" + EPSServiceController.FIRM_CONSTANT);
		send.setConfirmNumber("12345 ");
		send.setDealID("1234 ");
		String ClientID = TestCommon.createRandomAcountBuy();
		send.setClientIDBuyer(ClientID);
		send.setReplyCode(" ");
		send.setFiller("    ");
		send.setBrokerPortfolioVolume("");
		send.setBrokerClientVolume("30000");
		send.setBrokerMutualFundVolume("");
		send.setBrokerForeignVolume("");
		tcpService.processTCPMessage(send);

	}

	@Test
	public void testMessage2tobyteAndbytetoMessage_3C() // 11
	{
		DealPutThroughCancelRequest_3C send = new DealPutThroughCancelRequest_3C();

		send.setFirm("" + EPSServiceController.FIRM_CONSTANT);
		send.setContraFirm("056");
		send.setTraderID("561");
		send.setConfirmNumber("123450");

		String SecuritySymbol = TestCommon.createRandomSymbol();
		send.setSecuritySymbol(SecuritySymbol);
		send.setSide("B");
		tcpService.processTCPMessage(send);

	}

	@Test
	public void testMessage2tobyteAndbytetoMessage_3D() // 12
	{
		DealCancelReply_3D send = new DealCancelReply_3D();

		send.setFirm("" + EPSServiceController.FIRM_CONSTANT);
		send.setConfirmNumber("1234  ");
		send.setReplyCode("A");
		tcpService.processTCPMessage(send);
	}

}
