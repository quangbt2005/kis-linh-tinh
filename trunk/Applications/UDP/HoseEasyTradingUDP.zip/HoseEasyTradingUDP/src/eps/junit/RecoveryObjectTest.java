package eps.junit;

import java.io.File;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.notification.Failure;

import eps.com.common.HosePacket;
import eps.com.common.HoseSystemPacket;
import eps.com.common.Opcode;
import eps.com.common.RecoveryObject;
import eps.com.test.TestCommon;

import static org.junit.Assert.*;

public class RecoveryObjectTest {
	static String nameOfFile = "TestDT001";

	@Test
	public void read() {
		HosePacket read = RecoveryObject.read(nameOfFile);
		assertArrayEquals(read.getOpcode(), Opcode.AK);
		assertEquals(1, read.get_seqVal());
		assertEquals(10, read.get_ackseqVal());
	}

	@Test
	public void write() {
		HoseSystemPacket hp = new HoseSystemPacket();
		hp.setOpcode(Opcode.AK);
		try {
			hp.getAutotPMessage(1, 10);
			RecoveryObject.write(nameOfFile, hp);
		} catch (Exception e) {
			// e.printStackTrace();
			fail();
		}
	}

	@Test
	public void getRecoveryName() {
		String recoveryName = RecoveryObject.getRecoveryName("DT", 1);
		assertEquals("DT00000001", recoveryName);

		recoveryName = RecoveryObject.getRecoveryName("DT", 510);
		assertEquals("DT00000510", recoveryName);
	}

	@AfterClass
	public static void xong() {
		RecoveryObject.delete(nameOfFile);
	}
}
