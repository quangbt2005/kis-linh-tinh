package eps.junit;

import static junit.framework.Assert.*;

import org.junit.Test;

import eps.com.client.proposal.EPSServiceController;
import eps.com.common.ValueObject;
import eps.com.message.sended.Advertisement_1E;
import eps.com.message.sended.NewConditioned_1I;
import eps.com.message.sended.RetransmissionRequest_RQ;
import eps.com.test.TestCommon;
import eps.com.util.MessageUtil;

public class MessageOperatorTest {
	@Test
	public void testMessage2Bytes() {
		// wsClient.sendOrder("057", "2120", order, acount, sb, "B",
		// "1000    ", "1000    ", "ATO     ", "M", "C");
		String OrderNumber = TestCommon.createRandomOrderNumber();
		String ClientID = TestCommon.createRandomAcountBuy();
		String SecuritySymbol = TestCommon.createRandomSymbol();

		NewConditioned_1I order = new NewConditioned_1I();
		order.setFirm("057");
		order.setTraderID("2120");
		order.setOrderNumber(OrderNumber);
		order.setClientID(ClientID);
		order.setSecuritySymbol(SecuritySymbol);
		order.setSide("B");
		order.setVolume("1000");
		order.setPublishedVolume("1000");
		order.setPrice("ATO");
		order.setBoard("M");
		order.setPortClientFlag("C");
		byte[] message2Bytes = MessageUtil.message2Bytes(order);
		System.out.print(new String(message2Bytes));

		assertEquals(true, true);
	}

	@Test
	public void testBytes2Message() {
		// String oneIMessage =
		// "1I057212075778001057C000789VIC     B1000    1000    ATO   M     C     "
		// ;
		// byte array[] = oneIMessage.getBytes();
		// ValueObject object = (ValueObject)MessageUtil.bytes2Message(array);
		// System.out.println(object.toString());
                                                                                                                                                                       
		String oneIMessage = "2B57 757780011609";
		byte array[] = oneIMessage.getBytes();
		ValueObject object = (ValueObject) MessageUtil.bytes2Message(array);
		System.out.println(object.toString());

	}

	@Test
	public void testMessage2XmL() {
		// wsClient.sendOrder("057", "2120", order, acount, sb, "B",
		// "1000    ", "1000    ", "ATO     ", "M", "C");
		String OrderNumber = TestCommon.createRandomOrderNumber();
		String ClientID = TestCommon.createRandomAcountBuy();
		String SecuritySymbol = TestCommon.createRandomSymbol();

		NewConditioned_1I order = new NewConditioned_1I();
		order.setFirm("057");
		order.setTraderID("2120");
		order.setOrderNumber(OrderNumber);
		order.setClientID(ClientID);
		order.setSecuritySymbol(SecuritySymbol);
		order.setSide("B");
		order.setVolume("1000");
		order.setPublishedVolume("1000");
		order.setPrice("ATO");
		order.setBoard("M");
		order.setPortClientFlag("C");
		String message = MessageUtil.message2XML(order);
		System.out.print(message);

		assertEquals(true, true);
	}

	@Test
	public void testMessage1E2XmL() {
		// wsClient.sendOrder("057", "2120", order, acount, sb, "B",
		// "1000    ", "1000    ", "ATO     ", "M", "C");
		String SecuritySymbol = TestCommon.createRandomSymbol();

		Advertisement_1E send = new Advertisement_1E();

		send.setFirm("057");
		send.setTraderID("2120");
		send.setSecuritySymbol(SecuritySymbol);
		send.setSide("B");

		send.setVolume("1000    ");
		send.setPrice("12345678901 ");
		send.setBoard("M");
		send.setTime("120508");
		send.setAddCancelFlag("C");

		String temp = "";
		for (int i = 0; i < 20; i++) {
			temp += "x";
		}
		send.setContact(temp);

		System.out.print(send);
		String message = MessageUtil.message2XML(send);
		System.out.print(message);
	}

	@Test
	public void testRetransmissionRQ() {
		RetransmissionRequest_RQ requestRetrans = new RetransmissionRequest_RQ();
		requestRetrans.setFirm(EPSServiceController.FIRM_CONSTANT);
		requestRetrans.setMarketID(new String(EPSServiceController._marketId));
		long startSequence = 10;
		requestRetrans.setRetransmissionStartSequence(startSequence);
		long endSequence = 20;
		requestRetrans.setRetransmissionEndSequence(endSequence);
		byte[] message2Bytes = MessageUtil.message2Bytes(requestRetrans);
		System.out.print(new String(message2Bytes));

	}

}
