package eps.junit;

import org.junit.Test;

import eps.com.client.upd.Common;
import static org.junit.Assert.*;

public class Mode96Test {
	@Test
	public void EnMod96() {
		long number = 57;
		byte[] bEncoded = Common.EnMod96(number, 2);
		assertArrayEquals(new byte[] { 32, 89 }, bEncoded);

		number = 0;
		bEncoded = Common.EnMod96(number, 3);
		System.out.println("bEncoded:" + new String(bEncoded));
		// assertArrayEquals(new byte[] { 32, 32, 32, 33 }, bEncoded);
	}

	@Test
	public void DecodeMod96() {
		byte[] bDecoded = new byte[] { 32, 89 };
		long temp = Common.DecodeMod96(bDecoded);
		assertEquals(57, temp);

		bDecoded = new byte[] { 32, 32, 32, 33 };
		temp = Common.DecodeMod96(bDecoded);
		assertEquals(1, temp);
	}

	@Test
	public void compare2byteArray() {
		boolean compare2byteArray = Common.compare2byteArray(
				new byte[] { 5, 45 }, new byte[] { 5, 45 });
		assertTrue(compare2byteArray);
	}

	
}
