/**
 * 
 */
package eps.com.common;

/**
 * @author nghia.tt
 *
 */
public class Opcode {
	public static byte[] HL=new byte[]{'H','L'};  
	public static byte[] HR=new byte[]{'H','R'};
	public static byte[] CF=new byte[]{'C','F'};
	public static byte[] DT=new byte[]{'D','T'};
	public static byte[] LO=new byte[]{'L','O'};
	public static byte[] LL=new byte[]{'L','L'};
	public static byte[] RR=new byte[]{'R','R'};
	public static byte[] RP=new byte[]{'R','P'};
	public static byte[] AK=new byte[]{'A','K'};
	public static byte[] NK=new byte[]{'N','K'};
	public static byte[] FN=new byte[]{'F','N'};
	public static byte[] AF=new byte[]{'A','F'};
	public static byte[] EC=new byte[]{'E','C'};
	public static byte[] ER=new byte[]{'E','R'};
}
