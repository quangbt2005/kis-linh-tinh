package eps.com.common;

import java.io.Serializable;
import java.lang.reflect.AccessibleObject;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;

public class ValueObject implements Serializable {

	/** Creates a new instance of ValueObject */
	public ValueObject() {
	}
	public String toString() {
		StringBuffer result=new StringBuffer();
		Class clazz = this.getClass();
		Field[] fields = clazz.getDeclaredFields();
		// change visibility
		AccessibleObject.setAccessible(fields, true);
		int length =fields.length;
		Field field= null;
		String str1=null;
		String str2=null;
		String name=null;
		for(int i=0; i < length; i++){
			field= fields[i];
			field.setAccessible(true);

			try {
				name = field.getName();
				if(name.equals("serialVersionUID")) continue;
				str1 = field.get(this).toString();
				result.append(name).append("=");
				result.append(str1);
				if(i < length)
					result.append(" ; " );
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} 
		
		}
		return result.toString();
	}
	

	public boolean compareTo(Object o){
		Class clazz = o.getClass();
		Field[] fields = clazz.getDeclaredFields();
		// change visibility
		AccessibleObject.setAccessible(fields, true);
		int length =fields.length;
		Field field= null;
		Class oClazz = this.getClass();
		Field oField= null;
		String str1=null;
		String str2=null;
		String name=null;
		for(int i=0; i < length; i++){
			field= fields[i];
			field.setAccessible(true);
			try {
				name = field.getName();
				oField = oClazz.getDeclaredField(name);
				oField.setAccessible(true);
				str1 = field.get(o).toString();
				str2= oField.get(this).toString();
				if(str1== null && str2== null)
					continue;
				if(!str1.equals(str2))
					return false;
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} 
		
		}
		return true;
	}
	//public abstract 

	
	public static boolean compareTo(Object o, Object other){
		Class clazz = o.getClass();
		Field[] fields = clazz.getDeclaredFields();
		// change visibility
		AccessibleObject.setAccessible(fields, true);
		int length =fields.length;
		Field field= null;
		Class oClazz = other.getClass();
		Field oField= null;
		String str1=null;
		String str2=null;
		String name=null;
		for(int i=0; i < length; i++){
			field= fields[i];
			field.setAccessible(true);
			try {
				name = field.getName();
				oField = oClazz.getDeclaredField(name);
				oField.setAccessible(true);
				str1 = field.get(o).toString();
				str2= oField.get(other).toString();
				if(str1== null && str2== null)
					continue;
				if(!str1.equals(str2))
					return false;
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} 
		
		}
		return true;
	}
	//public abstract 

}
