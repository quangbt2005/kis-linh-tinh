package eps.com.message.broadcast;

import java.io.Serializable;

import eps.com.common.ValueObject;

public class PutThroughDealNotice_PD extends ValueObject implements Serializable{
	
	public static final String MessageType="PD";
	
	private long Confirm_Number  ;
	private long  Security_Number  ; 
	private long  Volume ;
	private long  Price ; 
	private String  Board ;
	
	public PutThroughDealNotice_PD()
	{
		
	}
	public String getBoard() {
		return Board;
	}
	public void setBoard(String board) {
		Board = board;
	}
	public long getConfirm_Number() {
		return Confirm_Number;
	}
	public void setConfirm_Number(long confirm_Number) {
		Confirm_Number = confirm_Number;
	}
	public static String getMessage_Type() {
		return MessageType ;
	}
	
	public long getPrice() {
		return Price;
	}
	public void setPrice(long price) {
		Price = price;
	}
	public long getSecurity_Number() {
		return Security_Number;
	}
	public void setSecurity_Number(long security_Number) {
		Security_Number = security_Number;
	}
	public long getVolume() {
		return Volume;
	}
	public void setVolume(long volume) {
		Volume = volume;
	}
}
