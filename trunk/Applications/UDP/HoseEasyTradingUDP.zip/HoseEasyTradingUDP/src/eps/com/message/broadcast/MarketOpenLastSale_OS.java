package eps.com.message.broadcast;

import java.io.Serializable;

import eps.com.common.ValueObject;

public class MarketOpenLastSale_OS extends ValueObject implements Serializable{
	
	public static final String MessageType="OS";
	
	private long Security_Number ; 
	private long  Price ;
	
	public MarketOpenLastSale_OS()
	{
		
	}
	
	public static String getMessage_Type() {
		return MessageType;
	}
	
	public long getPrice() {
		return Price;
	}
	public void setPrice(long price) {
		Price = price;
	}
	public long getSecurity_Number() {
		return Security_Number;
	}
	public void setSecurity_Number(long security_Number) {
		Security_Number = security_Number;
	}
	
}
