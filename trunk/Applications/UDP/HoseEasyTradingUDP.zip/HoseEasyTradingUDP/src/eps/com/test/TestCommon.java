package eps.com.test;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.List;
import java.util.Properties;
import java.util.Random;

import eps.com.client.proposal.EPSServiceController;
import eps.com.common.HosePacket;
import eps.com.common.RecoveryObject;
import eps.com.message.broadcast.SecurityUpdate_SU;
import eps.com.message.received.TCPMessageService;
import eps.com.message.sended.NewConditioned_1I;
import eps.com.util.MessageOperator;

public class TestCommon {
	public static String SERVER_IP = "172.16.255.30";

	public static String SERVER_PORT = "30057";

	public static String SERVER_PASSWORD = "12345678";

	public static String UDP_PORT = "30000";

	public static String DATA_SAVE_PATH = "c:/DataSave";

	public static String SECURITY_PRICE_PATH = DATA_SAVE_PATH + "/Price";

	static String updLogFilePath = DATA_SAVE_PATH + "/UDPLog_2611.txt"; // UDPLog_1311.txt";

	public static String MESSAGE_XML_PATH = "D:/Lan/EclipseWorkspace1/HoseEasyTrading/WebContent/WEB-INF/messageconfg.xml";

	// symbol co dang {ten, id}
	public static String[][] _symbol = new String[][] { { "HAP", "1291" },
			{ "REE", "2735" }, { "STB", "2908" }, { "PJT", "2550" },
			{ "VTO", "3814" },

			{ "TDH", "3476" }, { "UNI", "3636" }, { "VPL", "3818" },
			{ "DPM", "634" }, { "ABT", "3" },

			{ "DHG", "629" }, { "SJS", "2907" }, { "HMC", "1336" },
			{ "IFS", "1414" }, { "MCV", "2018" }

	};

	// { "VTO", "19.3" },{ "DHG", "145.0" },
	public static String[][] lPrice = new String[][] { { "VTO", "19.5" },
		{ "UNI", "10.5" },
		{ "TDH", "74.0" },
		{ "ABT", "41.0" },
		{ "HAP", "26.5" },
		{ "VPL", "131.0" },
		{ "DPM", "62.5" },
		{ "DHG", "150.0" },
		{ "MCV", "13.2" },
		{ "SJS", "68.0" },
		{ "REE", "39.3" },
		{ "IFS", "13.6" },
		{ "HMC", "16.2" },
		{ "STB", "33.0" },
		{ "PJT", "13.3" },
 };

	static Hashtable<String, String> hashPrice = new Hashtable<String, String>();

	public static String[][] bond_symbol = new String[][] {
			{ "HCMA0705", "1306" }, { "DNAA0105", "623" },
			{ "BCI40106", "200" }, { "AA1_0107", "10" }, };
	static double lPriceOfBond = 30;

	private static Random generator = new Random(19580427);

	static String today; // DDMM

	// Only use for Normal Test
	static String orderNumberFor34 = "3";
	static String orderNumberFor35 = "5";
	static String orderNumberFor78 = "7";
	static String orderNumberFor79 = "9";

	static {
		SimpleDateFormat sdf = new SimpleDateFormat("ddMM");
		today = sdf.format(new Date());
	}

	public static String getToday() {
		SimpleDateFormat sdf = new SimpleDateFormat("ddMM");
		today = sdf.format(new Date());
		return today;
	}

	public static String createRandomSymbol() {
		int c = generator.nextInt() % _symbol.length;
		while (c < 0) {
			c = generator.nextInt() % _symbol.length;
		}

		String s = _symbol[c][0];
		int length = s.length();
		if (length != 8) {
			for (int i = 0; i < 8 - length; i++) {
				s += " ";
			}
		}

		return s;
	}

	public static String getPriceBond(String sb) {
		return String.valueOf(lPriceOfBond);
	}

	public static String getPriceBond1E(String sb) {
		long unitInMillion = 1000000;
		return String.valueOf((long) (lPriceOfBond * unitInMillion));
	}

	public static String createRandomBond() {
		int c = generator.nextInt() % bond_symbol.length;
		while (c < 0) {
			c = generator.nextInt() % bond_symbol.length;
		}

		String s = bond_symbol[c][0];
		return s;
	}

	public static String getPrice(String sb) {
		for (int i = 0; i < lPrice.length; i++) {
			if (sb.trim().equals(lPrice[i][0])) {
				return lPrice[i][1];
			}
		}
		return lPrice[lPrice.length - 1][1];
	}

	public static String getPrice1E(String sb) {
		long unitInMillion = 1000000;
		for (int i = 0; i < lPrice.length; i++) {
			if (sb.trim().equals(lPrice[i][0])) {
				return String
						.valueOf((long) (Double.parseDouble(lPrice[i][1]) * unitInMillion));
			}
		}

		return String.valueOf((long) (30 * unitInMillion));
	}

	public static String getRandomOrderNumber(String orderNumber, int index) {
		if (orderNumber.length() >= 8) {
			orderNumber = orderNumber.substring(0, 3);
		}
		return orderNumber + "00" + index;
	}

	public static String createRandomOrderNumber() {
		String re = "7";
		int c = generator.nextInt() % 10;
		for (int i = 0; i < 7; i++) {
			c = generator.nextInt() % 10;
			while (c < 0) {
				c = generator.nextInt() % 10;
			}
			re = re + String.valueOf(c);

		}
		return re;
	}

	public static String createRandomAcountBuy() {
		String re = "057C000";
		int c = generator.nextInt() % 10;
		for (int i = 0; i < 3; i++) {
			c = generator.nextInt() % 10;
			while (c < 0) {
				c = generator.nextInt() % 10;
			}
			re = re + String.valueOf(c);

		}
		return re;
	}

	public static String createRandomForeignerAcountBuy() {
		String re = "057F000";
		int c = generator.nextInt() % 10;
		for (int i = 0; i < 3; i++) {
			c = generator.nextInt() % 10;
			while (c < 0) {
				c = generator.nextInt() % 10;
			}
			re = re + String.valueOf(c);

		}
		return re;
	}

	public static String createAcount(String type) {
		String re = "057C000";
		if (type.equalsIgnoreCase("C")) {
			re = "057C000";
		} else if (type.equalsIgnoreCase("F")) {
			re = "057F000";
		} else if (type.equalsIgnoreCase("M")) {
			re = "057M000";
		} else if (type.equalsIgnoreCase("P")) {
			re = "057P000";
		}
		int c = generator.nextInt() % 10;
		for (int i = 0; i < 3; i++) {
			c = generator.nextInt() % 10;
			while (c < 0) {
				c = generator.nextInt() % 10;
			}
			re = re + String.valueOf(c);

		}
		return re;
	}

	public static String createRandomAnotherAcount() {
		String re = "058C000";
		int c = generator.nextInt() % 10;
		for (int i = 0; i < 3; i++) {
			c = generator.nextInt() % 10;
			while (c < 0) {
				c = generator.nextInt() % 10;
			}
			re = re + String.valueOf(c);

		}
		return re;
	}

	public static String createRandomAcountSell() {
		String re = "057C";
		int c = generator.nextInt() % 10;

		for (int i = 0; i < 3; i++) {
			c = generator.nextInt() % 10;
			while (c < 0) {
				c = generator.nextInt() % 10;
			}
			re = re + String.valueOf(c);

		}
		re += "000";
		return re;
	}

	public static List<HosePacket> generateWriteRecoveryDTPackets(
			long numberOfPackets, long seq, long ackseq) {
		// Generate
		List<HosePacket> ret = new ArrayList<HosePacket>();
		HosePacket hosePacket;
		NewConditioned_1I new1I;
		try {
			for (int i = 0; i < numberOfPackets; i++) {
				new1I = NormalTest.get1IMessage();
				hosePacket = new HosePacket(seq + i, ackseq, 57, new1I);

				ret.add(hosePacket);
			}

			// Write
			String recoveryName;
			for (HosePacket hosePacketWrite : ret) {
				recoveryName = RecoveryObject.getRecoveryName("DT",
						hosePacketWrite.get_seqVal());
				RecoveryObject.write(recoveryName, hosePacketWrite);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return ret;
	}

	public static String fillEmptySpace(String origin, int size) {
		StringBuffer sb = new StringBuffer(origin);
		if (origin.length() < size) {
			int distance = size - origin.length();
			for (int k = 0; k < distance; k++) {
				sb.append(" ");
			}
		}
		return sb.toString();
	}

	public static String getHosePacketFormatString(String len, String seq,
			String ackseq, String opcode, String linkid, String contentLen,
			String content) {
		len = fillEmptySpace(len, 8);
		seq = fillEmptySpace(seq, 9);
		ackseq = fillEmptySpace(ackseq, 12);
		opcode = fillEmptySpace(opcode, 11);
		linkid = fillEmptySpace(linkid, 11);
		contentLen = fillEmptySpace(contentLen, 15);
		content = fillEmptySpace(content, 0);

		StringBuffer sb = new StringBuffer();
		sb.append(len);
		sb.append(seq);
		sb.append(ackseq);
		sb.append(opcode);
		sb.append(linkid);
		sb.append(contentLen);
		sb.append(content);

		return sb.toString();
	}

	public static void printPriceAndStatus(String[][] _symbol) {
		try {
			BufferedReader br;
			String s, price;
			int idxSU, idxSS, idxTR, idxSus;
			// Duyet qua tung ma
			for (int i = 0; i < _symbol.length; i++) {
				System.out.println(_symbol[i][0] + " ; " + _symbol[i][1]);
				// Doi voi moi ma tim SU,SS,TR (doc tu tren xuong duoi)
				br = new BufferedReader(new FileReader(updLogFilePath));
				while ((s = br.readLine()) != null) {
					// SU
					idxSU = s
							.indexOf("s_SecuritySymbol=" + _symbol[i][0] + " ");
					if (idxSU != -1) {
						idxSus = s.indexOf("s_Suspension");
						System.out.println(s.substring(idxSU + 17, idxSU + 89)
								+ s.substring(idxSus, idxSus + 50));
						price = getPriceFromLog(s, "s_LastSalePrice");
						System.out.println("Gia : " + _symbol[i][0] + " "
								+ price);
						hashPrice.put(_symbol[i][0], price);
					}
					idxSS = s.indexOf("MessageType=SS ; Security_Number="
							+ _symbol[i][1] + " ");
					if (idxSS != -1) {
						System.out.println(s);
						price = getPriceFromLog(s, "Prior_Close_Price");
						System.out.println("Gia : " + _symbol[i][0] + " "
								+ price);
						hashPrice.put(_symbol[i][0], price);
					}
					idxTR = s.indexOf("MessageType=TR ; Security_Number="
							+ _symbol[i][1] + " ");
					if (idxTR != -1) {
						System.out.println(s);
					}
				}
				System.out.println("-----------------------------");
			}

			// In hashPrice
			Enumeration<String> keys = hashPrice.keys();
			String key, value;

			while (keys.hasMoreElements()) {
				key = keys.nextElement();
				value = hashPrice.get(key);
				System.out.println("{ \"" + key + "\", \"" + value + "\" },");
			}

			if (hashPrice.size() != _symbol.length) {
				System.out.println("Chieu dai symbol va gia ko bang nhau : "
						+ _symbol.length + " ; " + hashPrice.size());
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private static String getPriceFromLog(String s, String prefix) {
		int idx = s.indexOf(prefix);
		int idxLast = s.indexOf(";", idx);
		String sNum = s.substring(idx + prefix.length() + 1, idxLast - 1);
		String ret = String.valueOf(Long.parseLong(sNum) / 100d);
		// System.out.println(ret);
		return ret;

	}

	public void loadConfiguration() {
		InputStream is;
		Properties properties = new Properties();
		try {
			// Lay trong file jar
			// is = getClass().getResourceAsStream("/config.prop");
			// if (is == null) {
			// // Dung khi chay tu Eclipse
			// is = new FileInputStream("config.prop");
			// }
			is = new FileInputStream("config.prop");
			properties.load(is);

			String dataSavePath = properties.getProperty("DATA_SAVE_PATH");
			if (dataSavePath != null && !dataSavePath.equals("")) {
				TestCommon.DATA_SAVE_PATH = dataSavePath;
				System.out.println(TestCommon.DATA_SAVE_PATH);
			}

			String messageXMLPath = properties.getProperty("MESSAGE_XML_PATH");
			if (messageXMLPath != null && !messageXMLPath.equals("")) {
				TestCommon.MESSAGE_XML_PATH = messageXMLPath;
				System.out.println(TestCommon.MESSAGE_XML_PATH);
			}

			InputStream inputStream = getClass().getResourceAsStream(
					"/WebContent/WEB-INF/messageconfg.xml");
			System.out.println(inputStream);
			MessageOperator.inputStream = inputStream;

			String WEB_SERVICE_URL = properties.getProperty("WEB_SERVICE_URL");
			if (WEB_SERVICE_URL != null && !WEB_SERVICE_URL.equals("")) {
				TCPMessageService.url = WEB_SERVICE_URL;
				System.out.println(TCPMessageService.url);
			}

			String webServiceUserName = properties
					.getProperty("WEB_SERVICE_USERNAME");
			if (webServiceUserName != null && !webServiceUserName.equals("")) {
				TCPMessageService.authenUser = webServiceUserName;
				System.out.println(TCPMessageService.authenUser);
			}

			String webServicePassword = properties
					.getProperty("WEB_SERVICE_PASSWORD");
			if (webServicePassword != null && !webServicePassword.equals("")) {
				TCPMessageService.authenPass = webServicePassword;
				System.out.println(TCPMessageService.authenPass);
			}

			String noConsumers = properties.getProperty("noConsumers");
			if (noConsumers != null && !noConsumers.equals("")) {
				EPSServiceController.noConsumers = Integer
						.parseInt(noConsumers);
				System.out.println(EPSServiceController.noConsumers);
			}

			// String no2EConsumers = properties.getProperty("no2EConsumers");
			// if (no2EConsumers != null && !no2EConsumers.equals("")) {
			// EPSServiceController.no2EConsumers = Integer
			// .parseInt(no2EConsumers);
			// System.out.println(EPSServiceController.no2EConsumers);
			// }

			String _SERVER_IP = properties.getProperty("SERVER_IP");
			if (_SERVER_IP != null && !_SERVER_IP.equals("")) {
				SERVER_IP = _SERVER_IP;
				System.out.println(SERVER_IP);
			}

			String _SERVER_PORT = properties.getProperty("SERVER_PORT");
			if (_SERVER_PORT != null && !_SERVER_PORT.equals("")) {
				SERVER_PORT = _SERVER_PORT;
				System.out.println(SERVER_PORT);
			}

			String _SERVER_PASSWORD = properties.getProperty("SERVER_PASSWORD");
			if (_SERVER_PASSWORD != null && !_SERVER_PASSWORD.equals("")) {
				SERVER_PASSWORD = _SERVER_PASSWORD;
				System.out.println(SERVER_PASSWORD);
			}

			String _UDP_PORT = properties.getProperty("UDP_PORT");
			if (_UDP_PORT != null && !_UDP_PORT.equals("")) {
				UDP_PORT = _UDP_PORT;
				System.out.println(UDP_PORT);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {
		// generateWriteRecoveryDTPackets(5, 7, 11);
		if (_symbol.length != lPrice.length) {
			System.out.println("Chieu dai symbol va gia ko bang nhau");
		}

		// String randomSymbol;
		// for (int i = 0; i < _symbol.length; i++) {
		// // randomSymbol = createRandomSymbol();
		// randomSymbol = _symbol[i][0];
		// System.out.println(randomSymbol + " ; " + getPrice(randomSymbol)
		// + " ; " + getPrice1E(randomSymbol));
		// }

		printPriceAndStatus(_symbol);

		// printPriceAndStatus(bond_symbol);

		// System.out
		// .println(getPriceFromLog(
		// "Sat Oct 11 11:04:48 ICT 2008 MessageType=SU ; s_SecurityNumberOld=2916 ; s_SecurityNumberNew=2916 ; s_Filler1=  ; s_SectorNumber=1 ; s_Filler2=  ; s_SecuritySymbol=SAF      ; s_SecurityType=S ; s_CeilingPrice=2560 ; s_FloorPrice=2460 ; s_LastSalePrice=2510 ; s_MarketID=A ; s_Filler3=    ; s_SecurityName=CTCP LT TP SAFOCO         ; s_Filler4=  ; s_Suspension=  ; s_Delist=  ; s_HaltResumeFlag=  ; s_Split=  ; s_Benefit=  ; s_Meeting=  ; s_Notice=  ; s_ClientIDRequired=  ; s_ParValue=1000 ; s_SDCFlag=  ; s_PriorClosePrice=2510 ; s_PriorClosedate=20081002 ; s_OpenPrice=0 ; s_HighestPrice=0 ; s_LowestPrice=0 ; s_TotalSharesTraded=0 ; s_TotalValuesTraded=0 ; s_BoardLot=10 ; s_Filler5=  ; "
		// ,
		// "s_LastSalePrice"));

		// float price = (float) 12.300000;
		// DecimalFormat df = new DecimalFormat("###.##");
		// System.out.println(df.format(price));
	}

	public static String getStandardDate() {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		today = sdf.format(new Date());
		return today;

	}
}
