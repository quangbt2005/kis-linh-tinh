package eps.com.client;

import eps.com.client.proposal.EPSServiceController;
import eps.com.message.sended.NewConditioned_1I;
import eps.com.message.sended.OrderCancellation_1C;
import eps.com.message.sended.OrderChange_1D;

public class WebServiceFacade implements EPSServiceInterface {
	// default constructor
	EPSServiceController controller;
	public WebServiceFacade() {
	}

	/**
	 * send order to Hose
	 * 
	 * @param order
	 * @return 1 :
	 */
	public int sendOrder(NewConditioned_1I order) {
		return 1;
	}

	/**
	 * 
	 * @param Firm
	 * @param TraderID
	 * @param OrderNumber
	 * @param ClientID
	 * @param SecuritySymbol
	 * @param Side
	 * @param Volume
	 * @param PublishedVolume
	 * @param Price
	 * @param ClientFlag
	 * @return
	 */
	public void newConditionedOrder1I(String Firm, String TraderID,
			String OrderNumber, String ClientID, String SecuritySymbol,
			String Side, String Volume, String PublishedVolume, String Price,
			String Board, String Filler, String PortClientFlag, String Filler2) {

		NewConditioned_1I order = new NewConditioned_1I();
			order.setFirm(Firm);
			order.setTraderID(TraderID);
			order.setOrderNumber(OrderNumber);
			order.setClientID(ClientID);
			order.setSecuritySymbol(SecuritySymbol);
			order.setSide(Side);
			order.setVolume(Volume);
			order.setPublishedVolume(PublishedVolume);
			order.setPrice(Price);
			order.setBoard(Board);
			order.setFiller(Filler);
			order.setPortClientFlag(PortClientFlag);
			order.setFiller2(Filler2);
		try {
			EPSServiceController.getInstance().sendMessageToQueue(order);
		} catch (Exception e) {
			e.printStackTrace();
		}
		// return "";
	}

	public void orderCancellation1C(String Firm, String OrderNumber,
			String OrderEntryDate) {
		
		OrderCancellation_1C order = new OrderCancellation_1C();
		order.setFirm(Firm);
		order.setOrderNumber(OrderNumber);
		order.setOrderEntryDate(OrderEntryDate);
		try {
			EPSServiceController.getInstance().sendMessageToQueue(order);
		} catch (Exception e) {
			e.printStackTrace();
		}

		
	}

	public void orderChange1D(String Firm, String OrderNumber,
			String OrderEntryDate, String ClientID, String Filler) {
		OrderChange_1D order = new OrderChange_1D() ;
		order.setFirm(Firm);
		order.setOrderNumber(OrderNumber);
		order.setOrderEntryDate(OrderEntryDate) ;
		order.setClientID(ClientID);
		order.setFiller(Filler) ;
		try {
			EPSServiceController.getInstance().sendMessageToQueue(order);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public void advertisement1E(String Firm, String TraderID,
			String SecuritySymbol, String Side, String Volume, String Price,
			String Board, String Time, String AddCancelFlag, String Contact) {
		// TODO Auto-generated method stub
		// return null;
	}
	public void oneFirmPutThroughDeal1F(String Firm, String TraderID,
			String ClientIDBuyer, String ClientIDSeller, String SecuritySymbol,
			String Price, String Board, String DealID, String Filler,
			String BrokerPortfolioVolumeBuyer, String BrokerClientVolumeBuyer,
			String MutualFundVolumeBuyer, String BrokerForeignVolumeBuyer,
			String Filler2, String BrokerPortfolioVolumeSeller,
			String BrokerClientVolumeSeller, String MutualFundVolumeSeller,
			String BrokerForeignVolumeSeller, String Filler3) {
		// TODO Auto-generated method stub
		// return null;
	}
	
	public void twoFirmPutThroughDeal1G(String FirmSeller,
			String TraderIDSeller, String ClientIDSeller,
			String ContraFirmBuyer, String TraderIDBuyer,
			String SecuritySymbol, String Price, String Board, String DealID,
			String Filler, String BrokerPortfolioVolumeSeller,
			String BrokerClientVolumeSeller, String MutualFundVolumeSeller,
			String BrokerForeignVolumeSeller, String Filler2) {
		
		
	}

	public void admin3A(String Firm, String TraderIDSender,
			String TraderIDReciever, String ContraFirm, String AdminMessageText) {
		// TODO Auto-generated method stub
		// return null;
	}


	public void dealCancelReply3D(String Firm, String ConfirmNumber,
			String ReplyCode) {
		// TODO Auto-generated method stub
		// return null;
	}

	public void dealPutThroughCancelRequest3C(String Firm, String ContraFirm,
			String TraderID, String ConfirmNumber, String SecuritySymbol,
			String Side) {
		// TODO Auto-generated method stub
		// return null;
	}

	
	public void putThroughDealReply3B(String Firm, String ConfirmNumber,
			String DealID, String ClientIDBuyer, String ReplyCode,
			String Filler, String BrokerPortfolioVolume,
			String BrokerClientVolume, String BrokerMutualFundVolume,
			String BrokerForeignVolume, String Filler2) {
		// TODO Auto-generated method stub
		// return null;
	}

	public boolean connect() {
		try {
			controller= EPSServiceController.getInstance();
		} catch (Exception e) {
			return false;
		}
		return true;
	}

	public boolean disconnect() {
		try {
			controller.disconnectFromClient();
		} catch (Exception e) {
			return false;
		}
		return true;
	}
}
