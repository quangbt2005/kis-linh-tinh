package eps.com.client.proposal;

import eps.com.client.upd.Common;
import eps.com.common.HosePacket;
import eps.com.common.Opcode;
import eps.com.common.RecoveryObject;
import eps.com.message.sended.RetransmissionRequest_RQ;
import eps.com.test.TestCommon;

public class PacketSender extends Thread {
	private boolean isStop = false;

	MessageQueue queue;
	WindowBuffer buffer;

	public PacketSender(MessageQueue queue) {
		this.queue = queue;
	}

	public PacketSender(MessageQueue queue, WindowBuffer buffer) {
		this.queue = queue;
		this.buffer = buffer;
	}

	public void setStop(boolean bool) {
		isStop = bool;
	}
	public boolean getStop() {
		return isStop;
	}

	@Override
	public void run() {
		while (!isStop) {
			try {

				Object message;
				if (this.buffer.getWindowBufferSize() < 7) {
					message = this.queue.getMessage();
					HosePacket packet = EPSServiceController.getInstance()
							.threadSendMessage(message);
					// sequence cua packet vua duoc send di
					long seq = packet.get_seqVal();
					// name += seq;
					if (Common.compare2byteArray(packet.get_opcode(), Opcode.DT)) {
						String name = new String(packet.get_opcode());
						name = RecoveryObject.getRecoveryName(name, seq);
						this.buffer.increaseWindowBuffer(seq);
						RecoveryObject.write(name, packet);
					}	
				}
				//Thread.sleep(30);
			} catch (Exception e) {
				isStop=true;
				return;
				//e.printStackTrace();
			}
		}
	}
}
