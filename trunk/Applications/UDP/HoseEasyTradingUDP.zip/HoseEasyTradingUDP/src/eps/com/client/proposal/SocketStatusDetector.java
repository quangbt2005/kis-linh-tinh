package eps.com.client.proposal;

public class SocketStatusDetector extends Thread{
	private boolean flag = false;
	@Override
	public void run() {
		while(!isFlag()){
			try {
				EPSServiceController controller = EPSServiceController.getInstance(); 
				if(!controller.getSocketStatus()){
					// need to reconnect
					controller.autoReconnect();
					return;
				}
				Thread.sleep(60000);
				
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	public void setFlag(boolean flag) {
		this.flag = flag;
	}
	public boolean isFlag() {
		return flag;
	}
	
}
