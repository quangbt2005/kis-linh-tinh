package eps.com.client.proposal;

import java.net.*;
import java.io.*;

import java.util.*;

import eps.com.client.HosePacketManagement;
import eps.com.client.Log;
import eps.com.client.SaveState;
import eps.com.client.upd.Common;
import eps.com.client.upd.UDPClient;
import eps.com.common.HosePacket;
import eps.com.common.HoseSystemPacket;
import eps.com.common.Opcode;
import eps.com.common.RecoveryObject;
import eps.com.common.ValueObject;
import eps.com.test.MainFrame;
import eps.com.test.TestCommon;

public class EPSServiceController {
	// queue for adding packets
	private MessageQueue queue = new MessageQueue();
	private ReceiveMessageQueue receiveQueue = new ReceiveMessageQueue();

	private WindowBuffer buffer = new WindowBuffer();
	// send packet thread
	private PacketSender threadPacketSender = null;
	private PacketReceiver threadPacketReceiver = null;
	private EchoPacketProducer threadEchoPacketProducer = null;
	private UDPSequenceChecker threadSeqChecker = null;
	private OrderProducer threadOrderProducer = null;
	private AdvOrderProducer threadAdOrderProducer = null;

	public static int noConsumers = 3;
	private ReceivePacketConsumer threadreceiveConsumer[] = null;
	// 40 s
	private static int interval = 40000;
	private static int receive_timeout = 25000;
	private static EPSServiceController instance = null;

	/* Tham so ket noi Server */
	private String _serverIP = "172.16.255.30";
	private int _serverPort = 30057;
	private byte[] _password = new byte[] { '1', '2', '3', '4', '5', '6', '7',
			'8' };
	private int _numberOfmarket = 1;
	public static byte[] _marketId = new byte[] { 'A' };
	public static byte[] _firmid = new byte[] { '0', '5', '7' };
	public static long FIRM_CONSTANT = 057;
	public static int _linkid = 57;
	/* End Tham so ket noi Server */

	private Socket _socket = null;
	private Log _log = new Log();
	// use for packet
	private HosePacketManagement _pkt = new HosePacketManagement();
	private Opcode _opcode = new Opcode();

	public static long _client_seq = 1; // sended seq
	public static long _client_ack_seq = 1;
	public static long _server_seq = 1; // HOSE seq
	public static long _server_ack_seq = 1;
	public static int udpSequence = 0;

	private boolean isFirstTimeConnect = true;

	// private HosePacket _rcv_packet = null;
	// save state
	private SaveState _saver = new SaveState(TestCommon.DATA_SAVE_PATH
			+ "/SavedState.txt");

	// content
	private byte _mode;

	// Common
	// Random generator = new Random(19580427);

	private static boolean connectServerOK = false;

	boolean udpCheckerEnable = true;

	public boolean threadSendMessageFinished = false;
	// count so packet
	private int dtrpCount = 0;
	private int dtCount = 0;

	private EPSServiceController(String serverIP, int serverPort,
			String password, char mode) throws Exception {
		_serverIP = serverIP;
		_serverPort = serverPort;
		_password = password.getBytes();
		_mode = (byte) mode;
		connectServerAndStartThreads();
		if (connectServerOK)
			startDaemonThread();
	}

	private EPSServiceController() throws Exception {
		connectServerAndStartThreads();
		if (connectServerOK)
			startDaemonThread();
	}

	private void startDaemonThread() {
		ReceivePacketConsumer threadreceiveConsumer[] = new ReceivePacketConsumer[noConsumers];
		for (int i = 0; i < noConsumers; i++) {
			threadreceiveConsumer[i] = new ReceivePacketConsumer(
					this.receiveQueue);
			threadreceiveConsumer[i].setPriority(4);
			threadreceiveConsumer[i].setDaemon(true);
			threadreceiveConsumer[i].start();
		}
	}

	public void connectServerAndStartThreads() throws Exception {

		connectServerOK = connectToServer();
		if (connectServerOK) {
			System.out.println("Start all Threads.");
			this.startReadingOrders();
			threadEchoPacketProducer = new EchoPacketProducer(queue);
			threadEchoPacketProducer.setPriority(Thread.MIN_PRIORITY);
			threadEchoPacketProducer.start();

			threadPacketSender = new PacketSender(queue, buffer);
			threadPacketSender.setPriority(8);
			threadPacketSender.start();

			threadPacketReceiver = new PacketReceiver(buffer, receiveQueue);
			threadPacketReceiver.setPriority(8);
			threadPacketReceiver.start();
			
			if (udpCheckerEnable) {
				threadSeqChecker = new UDPSequenceChecker(udpSequence);
				threadSeqChecker.setPriority(Thread.MIN_PRIORITY);
				threadSeqChecker.start();
			}
			System.out.println("Start Reading Order.");
		} else {
			throw new Exception("Can not connect to server");
		}
	}

	public void autoReconnect() throws Exception {

		if (threadPacketSender != null)
			threadPacketSender.setStop(true);

		if (threadEchoPacketProducer != null) {
			threadEchoPacketProducer.setStop(true);
			threadEchoPacketProducer.interrupt();
			threadEchoPacketProducer = null;
		}
		 if (threadSeqChecker != null) {
			 threadSeqChecker.setStart(false);
			 threadSeqChecker.interrupt();
			 threadSeqChecker = null;
		 }
		_log.printConsole("Auto Reconnect");

		connectServerAndStartThreads();
		if (connectServerOK)
			MainFrame.startSocketDetector();
	}

	public synchronized static EPSServiceController getInstance(
			String serverIP, int serverPort, String password, char mode)
			throws Exception {
		if (instance == null)
			instance = new EPSServiceController(serverIP, serverPort, password,
					mode);
		return instance;
	}

	public synchronized static EPSServiceController getInstance()
			throws Exception {
		if (instance == null)
			instance = new EPSServiceController();
		return instance;
	}

	public boolean getSocketStatus() {
		// if (!this.threadPacketSender.isAlive()
		// || !this.threadPacketReceiver.isAlive())
		// return false;
		if (this.threadPacketSender.getStop()
				|| this.threadPacketReceiver.getStop())
			return false;
		return true;
	}

	public void startReadingOrders() {
		_log.printConsole("Before Re-Open 10 minutes");

		threadOrderProducer = new OrderProducer(queue, buffer);
		threadOrderProducer.setPriority(Thread.MIN_PRIORITY);
		threadOrderProducer.setStart(true);
		threadOrderProducer.start();
		threadAdOrderProducer = new AdvOrderProducer(queue, buffer);
		threadAdOrderProducer.setPriority(Thread.MIN_PRIORITY);
		threadAdOrderProducer.setStart(true);
		threadAdOrderProducer.start();
	}

	// for sending Data message
	/**
	 * neu nhu send data thi phai return so sequence vua send nguoc lai thi
	 * return: 0;
	 */
	// public synchronized long threadSendMessage(Object object) throws
	// Exception {
	// byte autoTMessage[] = null;
	// long result = 0;
	// HosePacket packet = null;
	// // if (object != null && object instanceof HosePacket) {
	// // packet = (HosePacket) object;
	// // autoTMessage = packet.getAutotPMessage();
	// // } else
	// if (object != null && object instanceof HoseSystemPacket) {
	// packet = (HoseSystemPacket) object;
	// if (Common.compare2byteArray(packet.getOpcode(), Opcode.AK)) {
	// // xac nhan voi server da nhan den this._server_seq
	// autoTMessage = ((HoseSystemPacket) packet).getAutotPMessage(
	// this._client_seq, this._server_seq + 1);
	// } else
	// autoTMessage = ((HoseSystemPacket) packet).getAutotPMessage(
	// this._client_seq, this._client_ack_seq);
	// } else {
	// // Hose packet
	// packet = new HosePacket(this._client_seq, this._client_ack_seq,
	// this._linkid, (ValueObject) object);
	// autoTMessage = packet.getAutotPMessage();
	// }
	// sendByte(autoTMessage);
	// // After send message DT always increase _client_seq
	// if (Common.compare2byteArray(packet.get_opcode(), Opcode.DT)) {
	// result = _client_seq;
	// _client_seq++;
	// }
	// return result;
	// }
	//
	//	
	/**
	 * neu nhu send data thi phai return so sequence vua send nguoc lai thi
	 * return: 0;
	 */
	public synchronized HosePacket threadSendMessage(Object object)
			throws Exception {
		threadSendMessageFinished = false;

		byte autoTMessage[] = null;
		HosePacket packet = null;
		try {
			// if (object != null && object instanceof HosePacket) {
			// packet = (HosePacket) object;
			// autoTMessage = packet.getAutotPMessage();
			// } else
			if (object instanceof HoseSystemPacket) {
				packet = (HoseSystemPacket) object;
				// xac nhan voi server da nhan den this._server_seq
				autoTMessage = ((HoseSystemPacket) packet).getAutotPMessage(
						_client_seq, _client_ack_seq);
			} else if (object instanceof HosePacket) {
				// Case 166, ... Communication Test
				packet = (HosePacket) object;
				autoTMessage = packet.getAutotPMessage();
			} else {
				// Hose packet
				packet = new HosePacket(_client_seq, _client_ack_seq, _linkid,
						(ValueObject) object);
				// .System.out.println("Send Data:" + object.toString());
				autoTMessage = packet.getAutotPMessage();
			}
			sendByte(autoTMessage);
			// After send message DT always increase _client_seq
			if (Common.compare2byteArray(packet.get_opcode(), Opcode.DT)) {
				_client_seq++;
				saveState();
			}
		} catch (Exception e) {
			// Save current object and remaining objects in queue
			this.threadOrderProducer.setStart(false);
			this.threadAdOrderProducer.setStart(false);
			Thread.sleep(5000);
			this.threadOrderProducer.join();
			this.threadAdOrderProducer.join();
			while (this.threadOrderProducer.isAlive()
					|| this.threadAdOrderProducer.isAlive()) {
				// infinite loop
			}
			if(object instanceof ValueObject)
				queue.saveObjectsInQueue(object);
			else
				queue.saveObjectsInQueue(null);
			throw e;
		}

		threadSendMessageFinished = true;

		return packet;
	}

	public synchronized List<HosePacket> receivePackets() throws Exception {
		List<HosePacket> rcvHosePackets = null;
		try {
			if (_socket == null || _socket.isClosed() || !_socket.isConnected()) {
				_log
						.printConsole("Do socket closed. Error in receive Packets.");
				throw new IOException(
						"Do socket closed. Error in receive Packets");
			}
			// long startTime = System.currentTimeMillis();
			InputStream in = _socket.getInputStream();
			// System.out.println("receive1");
			if (in.available() > 0) {
				rcvHosePackets = new ArrayList<HosePacket>();
				// System.out.println("receive2");
				byte[] input = new byte[in.available()];
				int reads = in.read(input, 0, input.length);
				if (reads < input.length) {
					byte[] input_ = new byte[reads];
					System.arraycopy(input, 0, input_, 0, reads);
					input = input_;
				}
				//
				// rcvHosePacket = new HosePacket(input);
				String receiveStr = new String(input);
				StringTokenizer stringTokenizer = new StringTokenizer(
						receiveStr, String.valueOf((char) 03));
				// _log.printConsole("number of packet: "
				// + stringTokenizer.countTokens());
				// _log.print("Input: " + receiveStr);
				String strTemp = null;
				// int tCount=0;
				while (stringTokenizer.hasMoreTokens()) {
					strTemp = stringTokenizer.nextToken()
							+ String.valueOf((char) 03);
					HosePacket rcvHosePacket = new HosePacket(strTemp
							.getBytes());
					_log.printAndSave("Receive: " + rcvHosePacket.toString());
					_server_seq = rcvHosePacket.get_seqVal();
					_server_ack_seq = rcvHosePacket.get_ackseqVal();
					if (Common.compare2byteArray(rcvHosePacket.get_opcode(),
							Opcode.DT)) {
						buffer.decreaseWindowBuffer(_server_ack_seq);
						_client_ack_seq = rcvHosePacket.get_seqVal() + 1;
						dtrpCount++;
						dtCount++;
						String name = null;

						long start = (_server_ack_seq - 7 > 0) ? _server_ack_seq - 7
								: 1;
						for (long index = start; index < _server_ack_seq; index++) {
							name = RecoveryObject.getRecoveryName("DT", index);
							RecoveryObject.delete(name);
						}
						// parse DT
						int noMessage = (int) Common
								.DecodeMod96(new byte[] { rcvHosePacket
										.getContent()[1] });
						//System.out.println("noMessage:" + noMessage);
						if (noMessage > 1) {
							try {
								String realContent = new String(rcvHosePacket
										.getContent()).substring(2);
								StringTokenizer tokenizer = new StringTokenizer(
										realContent, String.valueOf((char) 31));
								String strTemp1 = null;
								while (tokenizer.hasMoreTokens()) {
									strTemp1 = "  " + tokenizer.nextToken();
									HosePacket tPacket = new HosePacket();
									tPacket.setContent(strTemp1.getBytes());
									tPacket.setOpcode(Opcode.DT);
									rcvHosePackets.add(tPacket);
								}
							} catch (Exception e) {
								// TODO Auto-generated catch block
								System.out.println("---Bi loi khi parse data nhieu message. need to review");
							}
						} else {
							rcvHosePackets.add(rcvHosePacket);
						}
					} else if (Common.compare2byteArray(rcvHosePacket
							.get_opcode(), Opcode.RP)) {
						rcvHosePackets.add(rcvHosePacket);
						_client_ack_seq = rcvHosePacket.get_seqVal() + 1;
						dtrpCount++;
					} else if (Common.compare2byteArray(rcvHosePacket
							.get_opcode(), Opcode.AK)
							|| Common.compare2byteArray(rcvHosePacket
									.get_opcode(), Opcode.ER)) {
						buffer.decreaseWindowBuffer(_server_ack_seq);
						String name = null;
						long start = (_server_ack_seq - 7 > 0) ? _server_ack_seq - 7
								: 1;
						for (long index = start; index < _server_ack_seq; index++) {
							name = RecoveryObject.getRecoveryName("DT", index);
							RecoveryObject.delete(name);
						}

					} else if (Common.compare2byteArray(rcvHosePacket
							.get_opcode(), Opcode.NK)) {
						this.decreaseClientSeq();
						this.saveState();
						// Disconnect from Server
						MainFrame
								.showMessageAndExit("Receive NK from Server : "
										+ new String(rcvHosePacket.getContent()));
					} else if (Common.compare2byteArray(rcvHosePacket
							.get_opcode(), Opcode.FN)) {
						// Disconnect from Server
						this.disconnectFromServer();
					}
				}
				saveState();
				if (dtrpCount >= 5) {
					// send AK
					HoseSystemPacket systemPacket = new HoseSystemPacket();
					systemPacket.setOpcode(Opcode.AK);
					queue.putMessageinFirst(systemPacket);
					dtrpCount = 0;
				}

				return rcvHosePackets;
			}
		} catch (Exception iioe) {
			throw iioe;
		}
		return rcvHosePackets;
	}

	public void sendMessageToQueue(Object object) throws Exception {
		this.queue.putMessage(object);
	}

	public void sendMessageToBeginofQueue(Object object) throws Exception {
		this.queue.putMessageinFirst(object);
	}

	public boolean closeSocket() {
		if (_socket != null)
			try {
				_socket.close();
				_socket = null;
				Thread.sleep(2000);
			} catch (Exception e) {
				// e.printStackTrace();
				_log.printConsole("Error in closeSocket() " + e.getMessage());
			}
		return true;
	}

	public boolean saveState() {
		// _saver.saveConfig(_client_seq, _client_ack_seq, _mode, _server_seq,
		// _server_ack_seq);
		// return true;
		return saveState(udpSequence);
	}

	// Lan Tra : save state of UDP Sequence
	public boolean saveState(int udpSeq) {
		udpSequence = udpSeq;
		_saver.saveConfig(_client_seq, _client_ack_seq, _mode, _server_seq,
				_server_ack_seq, udpSequence);
		return true;
	}

	public boolean connectToServer(String serverIP, int serverPort,
			String password, char mode) throws Exception {
		_serverIP = serverIP;
		_serverPort = serverPort;
		_password = password.getBytes();
		_mode = (byte) mode;

		return connectToServer();
	}

	public boolean connectToServer() throws Exception {
		InetAddress addr = InetAddress.getByName(_serverIP);

		// read state
		int[] conf = _saver.readConfig();
		_client_seq = conf[0];
		_client_ack_seq = conf[1];
		if (_mode == 0) {
			_mode = (byte) conf[2];
		}
		_server_seq = conf[3];
		_server_ack_seq = conf[4];

		if (_mode == 65) {// 'A'
			_client_seq = _client_ack_seq = 1;
		} else if (_mode == 66) {// 'B'
			_client_seq = _client_ack_seq = 1;
		}
		udpSequence = conf[5];

		// if (firstSendInDay) {
		// _seq = 1;
		// _ack_seq = 1;
		// _mode = (byte) 'A';
		// }

		// send Hello
		boolean connectOK = false, sentCF = false;
		byte[] packetRecieve = null;
		byte[] packetSend;
		HosePacket pk = null;
		HoseSystemPacket hoseSystemPacket;
		while (!connectOK) {// Server and Client must connect in same mode
			// bind socket
			try {
				if (_socket == null) {
					_socket = new Socket(addr, _serverPort);
					_socket.setReuseAddress(true);
					_socket.setSoTimeout(60000);
				} else {
					if (!_socket.isClosed()) {
						// disconnect();
						closeSocket();

						// Thread.sleep(5000);
					}
					// trying to reconnect, max 10 times
					boolean reconnectOK = false;
					int numberOfTry = 0;
					while (!reconnectOK && numberOfTry <= 10) {
						Thread.sleep(15000);
						try {
							_socket = new Socket(addr, _serverPort);
							_socket.setSoTimeout(60000);
							reconnectOK = true;
						} catch (IOException e) {
							System.out.println("Reconnect fail!!!");
							numberOfTry++;
						}
					}
				}
			} catch (IOException ioException) {
				// ioException.printStackTrace();
				// _log.print("Can't connect to server.");
			}
			if (_socket == null) {
				_log.printConsole("Can't connect to server. Reconnect in 10s.");
				try {
					Thread.sleep(10000);
				} catch (Exception e) {
				}
				continue;
				// return false;
			}

			byte[] content = _pkt.createHelloContent(_mode, _password,
					_numberOfmarket, _marketId, _firmid);
			HosePacket helloPacket = new HosePacket(_client_seq,
					_client_ack_seq, Opcode.HL, _linkid, content);
			packetSend = helloPacket.getAutotPMessage();
			sendByte(packetSend);
			// recieve some data
			// packetRecieve = recieveByte();
			pk = receivePacketConnectToServer();
			if (pk == null)
				_log.printConsole("Error in receivePacketConnectToServer()");
			else {
				while (!sentCF) {
					// pk = new HosePacket(packetRecieve);
					final String pkContent = new String(pk.getContent());
					if (Common.compare2byteArray(pk.get_opcode(), Opcode.NK)) {
						if (pkContent.contains("Mismatched")) {
							// Get last byte mode A,B,C
							_mode = (byte) pkContent
									.charAt(pkContent.length() - 1);
							if (_mode == 65) {// 'A'
								_client_seq = 1;
								_client_ack_seq = 1;
							}
						} else if (pkContent.contains("Invalid sequence")) {
							// Then connect mode B
							_mode = 66; // 'B'
							_client_seq = 1;
							_client_ack_seq = 1;
						} else {
							connectOK = true;
						}
						saveState();
						MainFrame.showMessageAndExit(pkContent);
						return false;
					} else {
						connectOK = true;
						if (Common
								.compare2byteArray(pk.get_opcode(), Opcode.LO)
								|| Common.compare2byteArray(pk.get_opcode(),
										Opcode.LL)) {
							hoseSystemPacket = new HoseSystemPacket();
							hoseSystemPacket.setOpcode(Opcode.AK);
							packetSend = hoseSystemPacket.getAutotPMessage(
									_client_seq, _client_ack_seq);
							// Left over
							// packetSend = createPacket(Opcode.AK, new byte[]
							// {});
							sendByte(packetSend);
							// new
							// TCPMessageService().processTCPMessage(pk.getDataMessage());
							this.receiveQueue.putMessage(pk);
						} else if (Common.compare2byteArray(pk.get_opcode(),
								Opcode.HR)
								|| Common.compare2byteArray(pk.get_opcode(),
										Opcode.AK)) {
							if (_client_seq > _server_ack_seq) {
								byte[] msgType = null;

								if (_server_ack_seq == _client_seq - 1) { // LL
									msgType = Opcode.LL;
								} else { // LO
									msgType = Opcode.LO;
								}

								// Get list of recovery files
								HosePacket recoveryHosePacket;
								// byte[] contentRecoveryPacket;
								boolean sentLOLL = false;

								File ff = new File(RecoveryObject.RECOVERY_PATH);
								String[] listFiles = ff.list();
								for (int i = 0; i < listFiles.length; i++) {
									recoveryHosePacket = RecoveryObject
											.read(listFiles[i]);
									if (recoveryHosePacket != null) {
										if (recoveryHosePacket.get_seqVal() == _server_ack_seq
												&& recoveryHosePacket
														.get_ackseqVal() == _server_seq) {
											recoveryHosePacket
													.setOpcode(msgType);
											sendByte(recoveryHosePacket
													.getAutotPMessage());
											sentLOLL = true;
											RecoveryObject.delete(listFiles[i]);
											break;
										}
									}
									// Not found any valid recovery files, send
									// empty LO,LL
									if (i == listFiles.length) {
										sentLOLL = false;
									}
								}
								if (!sentLOLL) {
									content = _pkt.createLOLLContent(
											(byte) 'A', 1, new byte[] {});
									pk = new HosePacket(_server_ack_seq,
											_server_seq, msgType, _linkid,
											content);

									sendByte(pk.getAutotPMessage());
								}
							} else {
								_client_seq = _server_ack_seq;
								_client_ack_seq = _server_seq;
								_mode = (byte) 'C';

								// send Confirm
								hoseSystemPacket = new HoseSystemPacket();
								hoseSystemPacket.setOpcode(Opcode.CF);
								packetSend = hoseSystemPacket.getAutotPMessage(
										_client_seq, _client_ack_seq);
								sendByte(packetSend);

								sentCF = true;

								// Load saved Object and send
								ValueObject readObjectInQueue;
								File f = new File(
										RecoveryObject.RECOVERY_QUEUE_PATH);
								String[] list = f.list();
								for (int i = 0; i < list.length; i++) {
									readObjectInQueue = RecoveryObject
											.readObjectInQueue(list[i]);
									if (readObjectInQueue != null) {
										sendMessageToQueue(readObjectInQueue);
										RecoveryObject
												.deleteObjectInQueue(list[i]);
									}
								}

								return true;
							}
						} else {
							connectOK = true;
						}

						pk = receivePacketConnectToServer();
					}
				}
			}
		}
		return true;
	}

	// private void threadWait(Thread thread) {
	// try {
	// if (thread != null) {
	// thread.wait();
	// }
	// } catch (Exception e) {
	// _log.print("Error in threadWait. Can't make thread "
	// + thread.getName() + " wait");
	// }
	// }

	public void disconnectFromClient() throws Exception {
		if (!connectServerOK) {
			return;
		}
		MainFrame.stopSocketDetector();
		if (threadOrderProducer != null)
			threadOrderProducer.setStart(false);
		if (threadAdOrderProducer != null)
			threadAdOrderProducer.setStart(false);

		if(threadSeqChecker != null)
			threadSeqChecker.setStart(false);
			
		threadEchoPacketProducer.setStop(true);

		while (receiveQueue.getMessageSize() != 0) {
			// infinite loop
		}

		// Only disconnect when we have nothing to send
		while (threadPacketSender.queue.getMessageSize() != 0) {

		}
		int numberOfTry = 0;
		while (numberOfTry < 4) {
			if (threadPacketSender.buffer.getWindowBufferSize() == 0) {
				break;
			}
			Thread.sleep(10000);
			System.out.println("Trong disconnectFromClient : number Of Try "
					+ ++numberOfTry);
		}

		threadPacketReceiver.setStop(true);
		threadPacketSender.setStop(true);

		// FINE message
		HosePacket packet = new HosePacket(_client_seq, _client_ack_seq,
				Opcode.FN, _linkid, new byte[] {});
		sendByte(packet.getAutotPMessage());

		// sendMessageToQueue(packet);

		// recieve HR
		boolean receiveAF = false;
		while (!receiveAF) {
			packet = receivePacketConnectToServer();
			if (Common.compare2byteArray(packet.get_opcode(), Opcode.AF)) {
				receiveAF = true;
				packet = new HosePacket(_client_seq, _client_ack_seq,
						Opcode.AF, _linkid, new byte[] {});
				sendByte(packet.getAutotPMessage());
			} else if (Common.compare2byteArray(packet.get_opcode(), Opcode.NK)) {

			}
		}

		closeSocketAndStopThreads();
	}

	private void closeSocketAndStopThreads() {
		closeSocket();
		// Stop all thread
		try {
			if (threadEchoPacketProducer != null) {
				threadEchoPacketProducer.setStop(true);
				threadEchoPacketProducer.interrupt();
				threadEchoPacketProducer = null;
			}
			if (threadPacketReceiver != null) {
				threadPacketReceiver.setStop(true);
				threadPacketReceiver.interrupt();
				threadPacketReceiver = null;
			}
			if (threadPacketSender != null) {
				threadPacketSender.setStop(true);
				threadPacketSender = null;
			}
			connectServerOK = false;
		} catch (Exception e) {
			// _log.print("Error in disconnect. Can't stop threads");
		}
	}

	public boolean disconnectFromServer() throws Exception {
		// Stop all thread
		// try {
		// threadBroadcast.interrupt();
		// threadEchoPacketProducer.interrupt();
		// threadPacketReceiver.interrupt();
		// threadPacketSender.interrupt();
		// } catch (Exception e) {
		// _log.print("Error in disconnect. Can't stop threads");
		// }

		threadPacketReceiver.setStop(true);
		threadPacketSender.setStop(true);

		// FINE message
		HosePacket packet = new HosePacket(_client_seq, _client_ack_seq,
				Opcode.AF, _linkid, new byte[] {});
		sendByte(packet.getAutotPMessage());
		try {
			packet = receivePacketConnectToServer();
			if (!Common.compare2byteArray(packet.get_opcode(), Opcode.AF)) {
				return false;
			}
		} catch (Exception e) {
			// TODO: handle exception
		}

		if (this._socket.isConnected()) {
			closeSocket();
		}
		MainFrame.showMessageAndExit("Disconnect from Server");
		return true;
	}

	private synchronized int sendByte(byte[] data) throws Exception {
		if (_socket == null || _socket.isClosed() || !_socket.isConnected()) {
			_log.printConsole("Do socket closed. Error in sendByte : "
					+ new String(data));
			throw new Exception("Error in sendByte : " + new String(data));
		} else {
			try {
				OutputStream out = _socket.getOutputStream();
				out.write(data, 0, data.length);
				out.flush();
				_log.printAndSave("Send:    " + HosePacket.getString(data));
			} catch (Exception e) {
				_log.printConsole("Error in sendByte : " + new String(data));
				throw new Exception("Error in sendByte : " + new String(data));
			}
		}
		return data.length;
	}

	public synchronized HosePacket receivePacketConnectToServer()
			throws IOException {
		if (_socket == null)
			new IOException();
		HosePacket rcvHosePacket;
		long startTime = System.currentTimeMillis();
		while (true) {
			InputStream in = _socket.getInputStream();
			if (in.available() > 0) {
				byte[] input = new byte[in.available()];
				int reads = in.read(input, 0, input.length);
				if (reads < input.length) {
					byte[] input_ = new byte[reads];
					System.arraycopy(input, 0, input_, 0, reads);
					input = input_;
				}
				//
				rcvHosePacket = new HosePacket(input);

				if (Common.compare2byteArray(rcvHosePacket.get_opcode(),
						Opcode.DT)
						|| Common.compare2byteArray(rcvHosePacket.get_opcode(),
								Opcode.RP)
						|| Common.compare2byteArray(rcvHosePacket.get_opcode(),
								Opcode.LO)
						|| Common.compare2byteArray(rcvHosePacket.get_opcode(),
								Opcode.LL)) {
					_client_ack_seq = rcvHosePacket.get_seqVal() + 1;

				}
				_server_seq = rcvHosePacket.get_seqVal();
				_server_ack_seq = rcvHosePacket.get_ackseqVal();
				saveState();
				// print;
				_log.printAndSave("Receive: " + HosePacket.getString(input));
				return rcvHosePacket;
			}
			// check time respone
			long endTime = System.currentTimeMillis();
			if ((endTime - startTime) > 60000) {
				_log.printConsole("Error: Timeout - Can't recieve packet");
				return null;
			}
		}
	}

	public static void main(String[] args) {
		try {
			new EPSServiceController();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		// int numOfDTs = 0;
		// boolean connect1stTimes = false;
		// try {
		// EPSServiceController svcController = EPSServiceController
		// .getInstance();
		//
		// // for (int i = 0; i < 7; i++) {
		// // byte[] packetSend = svcController.createPacket(Opcode.AK, new
		// // byte[] {});
		// // svcController.sendByte(packetSend);
		// // }
		//
		// // HosePacket hosePacket = new HoseSysPacket(packetSend);
		// // svcController.sendMessageToQueue(hosePacket);
		//
		// ValueObject object;
		// ArrayList listMessage;
		// if (true) {
		// if (connectServerOK) {
		// for (int i = 0; i < numOfDTs; i++) {
		// String orderNumber = TestCommon
		// .createRandomOrderNumber();
		// String acount = TestCommon.createRandomAcountBuy();
		// String sb = TestCommon.createRandomSymbol();
		// // System.out.println(orderNumber + ";" + acount + ";"
		// // + sb);
		// // String sendOrder = wsClient.sendOrder("057", "2120",
		// // orderNumber,
		// // acount, sb, "B", "1000    ", "1000    ", "ATO     ",
		// // "M",
		// // "", "C", "");
		// NewConditioned_1I order = new NewConditioned_1I();
		// order.setFirm("057");
		// order.setTraderID("2120");
		// order.setOrderNumber(orderNumber);
		// order.setClientID(acount);
		// order.setSecuritySymbol(sb);
		// order.setSide("B");
		// order.setVolume("1000    ");
		// order.setPublishedVolume("1000    ");
		// order.setPrice("ATO     ");
		// order.setBoard("M");
		// order.setFiller("");
		// order.setPortClientFlag("C");
		// order.setFiller2("");
		// svcController.sendMessageToQueue(order);
		// }
		//
		// // listMessage = db.getListATO();
		// // if (listMessage.size() != 0) {
		// // for (int i = 0; i < 1; i++) {
		// // object = (ValueObject) listMessage.get(i);
		// // // System.out.println(object.toString());
		// // svcController.sendMessageToQueue(object);
		// // }
		// //
		// // }
		// }
		// Thread.sleep(3000);
		// }
		// } catch (Exception e) {
		// e.printStackTrace();
		// } finally {
		// try {
		// if (connectServerOK) {
		// // EPSServiceController.getInstance().disconnectFromClient();
		// }
		// } catch (Exception e1) {
		// e1.printStackTrace();
		// }
		// }

	}

	// public static byte[] get_marketId() {
	// return _marketId;
	// }
	//
	// public static void set_marketId(byte[] id) {
	// _marketId = id;
	// }

	public void decreaseClientSeq() {
		_client_seq--;
	}

	public void log(String message) {
		_log.printAndSave(message);
	}

	public static boolean isConnectServerOK() {
		return connectServerOK;
	}

	public void releaseInstance() {
		instance = null;
	}

	public long getClientSeq() {
		return _client_seq;
	}

	public long getClientAckSeq() {
		return _client_ack_seq;
	}

	public long getServerSeq() {
		return _server_seq;
	}

	public long getServerAckSeq() {
		return _server_ack_seq;
	}

	public long getLinkID() {
		return _linkid;
	}

	public void stopPacketReceiver(boolean enable) {
		if (threadPacketReceiver != null) {
			threadPacketReceiver.setStop(enable);
		}
	}
}
