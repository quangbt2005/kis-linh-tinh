package eps.com.test;

import eps.com.client.proposal.EPSServiceController;
import eps.com.common.HosePacket;
import eps.com.common.Opcode;
import eps.com.common.ValueObject;
import eps.com.message.received.RetransmissionReply_RP;
import eps.com.message.sended.NewConditioned_1I;
import eps.com.util.MessageUtil;

public class CommunicationTest {
	// Broker send with invalid Market id ( the valid is 'A')
	public static HosePacket case163() throws Exception {
		String orderNumber = TestCommon.createRandomOrderNumber();
		String acount = TestCommon.createRandomAcountBuy();
		String sb = TestCommon.createRandomSymbol();
		System.out.println(orderNumber + ";" + acount + ";" + sb);

		NewConditioned_1I order = new NewConditioned_1I();
		order.setFirm("057");
		order.setTraderID("2120");
		order.setOrderNumber(orderNumber);
		order.setClientID(acount);
		order.setSecuritySymbol(sb);
		order.setSide("B");
		order.setVolume("1000    ");
		order.setPublishedVolume("1000    ");
		order.setPrice(TestCommon.getPrice(sb));
		order.setBoard("M");
		order.setFiller("");
		order.setPortClientFlag("C");
		order.setFiller2("");

		EPSServiceController svcController = EPSServiceController.getInstance();

		HosePacket packet = new HosePacket(svcController.getClientSeq(),
				svcController.getClientAckSeq(), svcController.getLinkID(),
				(ValueObject) order, "MarketIdB");

		// EPSServiceController.getInstance().sendMessageToQueue(packet);

		return packet;
	}

	// Broker send content with the length that not equal field 'length'
	public static HosePacket case165() throws Exception {
		String orderNumber = TestCommon.createRandomOrderNumber();
		String acount = TestCommon.createRandomAcountBuy();
		String sb = TestCommon.createRandomSymbol();
		System.out.println(orderNumber + ";" + acount + ";" + sb);

		NewConditioned_1I order = new NewConditioned_1I();
		order.setFirm("057");
		order.setTraderID("2120");
		order.setOrderNumber(orderNumber);
		order.setClientID(acount);
		order.setSecuritySymbol(sb);
		order.setSide("B");
		order.setVolume("1000    ");
		order.setPublishedVolume("1000    ");
		order.setPrice(TestCommon.getPrice(sb));
		order.setBoard("M");
		order.setFiller("");
		order.setPortClientFlag("C");
		order.setFiller2("");

		EPSServiceController svcController = EPSServiceController.getInstance();

		HosePacket packet = new HosePacket(svcController.getClientSeq(),
				svcController.getClientAckSeq(), svcController.getLinkID(),
				(ValueObject) order, "Length");

		// EPSServiceController.getInstance().sendMessageToQueue(packet);

		return packet;
	}

	// Broker send with content is NULL
	public static HosePacket case166() throws Exception {
		String orderNumber = TestCommon.createRandomOrderNumber();
		String acount = TestCommon.createRandomAcountBuy();
		String sb = TestCommon.createRandomSymbol();
		System.out.println(orderNumber + ";" + acount + ";" + sb);

		NewConditioned_1I order = new NewConditioned_1I();
		order.setFirm("057");
		order.setTraderID("2120");
		order.setOrderNumber(orderNumber);
		order.setClientID(acount);
		order.setSecuritySymbol(sb);
		order.setSide("B");
		order.setVolume("1000    ");
		order.setPublishedVolume("1000    ");
		order.setPrice(TestCommon.getPrice(sb));
		order.setBoard("M");
		order.setFiller("");
		order.setPortClientFlag("C");
		order.setFiller2("");

		EPSServiceController svcController = EPSServiceController.getInstance();

		HosePacket packet = new HosePacket(svcController.getClientSeq(),
				svcController.getClientAckSeq(), svcController.getLinkID(),
				(ValueObject) order, "ContentNULL");

		// EPSServiceController.getInstance().sendMessageToQueue(packet);
		return packet;
	}

	// Broker can't send RP to server
	public static ValueObject getInvalidRPMessage() throws Exception {
		String marketID = "A";
		long Firm = 057;
		RetransmissionReply_RP request = new RetransmissionReply_RP();

		request.setFirm(Firm);
		request.setMarketID(marketID);
		request.setMessageCount(1);
		request.setPreviousSequenceNumber(4);
		request.setSequenceNumber(20);
		request.setOriginalBroadcastMessage("invalid RP");
		return request;
	}

	// Broker send with invalid packet length
	public static HosePacket case164() throws Exception {
		String orderNumber = TestCommon.createRandomOrderNumber();
		String acount = TestCommon.createRandomAcountBuy();
		String sb = TestCommon.createRandomSymbol();
		System.out.println(orderNumber + ";" + acount + ";" + sb);
		NewConditioned_1I order = new NewConditioned_1I();
		order.setFirm("057");
		order.setTraderID("2120");
		order.setOrderNumber(orderNumber);
		order.setClientID(acount);
		order.setSecuritySymbol(sb);
		order.setSide("B");
		order.setVolume("1000    ");
		order.setPublishedVolume("1000    ");
		order.setPrice("ATO     ");
		order.setBoard("M");
		order.setFiller("");
		order.setPortClientFlag("C");
		order.setFiller2("");
		byte arg[] = MessageUtil.message2Bytes(order);
		byte content[] = new byte[490];
		System.arraycopy(arg, 0, content, 0, arg.length);
		for (int i = 70; i < 490; i++)
			content[i] = 1;

		EPSServiceController svcController = EPSServiceController.getInstance();

		HosePacket packet = new HosePacket(svcController.getClientSeq(),
				svcController.getClientAckSeq(), Opcode.DT, svcController
						.getLinkID(), content);

		// HosePacket packet = EPSServiceController.getInstance()
		// .createTestPacket(Opcode.DT, content);
		return packet;
	}
}
