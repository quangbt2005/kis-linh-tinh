package eps.com.client.proposal;

import eps.com.common.HosePacket;
import eps.com.common.HoseSystemPacket;
import eps.com.common.Opcode;

public class EchoPacketProducer extends Thread {
	private boolean isStop;
	private MessageQueue queue;
	HoseSystemPacket packet;

	public EchoPacketProducer(MessageQueue queue) {
		this.queue = queue;
	}

	public void setStop(boolean bool) {
		isStop = bool;
	}

	@Override
	public void run() {
		// System.out.println("Trong EchoPacketProducer");
		while (!isStop) {
			try {
				packet = new HoseSystemPacket();
				packet.setOpcode(Opcode.EC);
				queue.putMessage(packet);
				Thread.sleep(30000);
			} catch (InterruptedException ie) {
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

}
