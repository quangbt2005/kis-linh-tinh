package eps.com.client;

public interface EPSServiceInterface {
	/**
	 * Message này được gửi đến HOSE bởi công ty chứng khoán để nhập một lệnh.
	 */
	public void newConditionedOrder1I(String Firm, String TraderID,
			String OrderNumber, String ClientID, String SecuritySymbol,
			String Side, String Volume, String PublishedVolume, String Price,
			String Board, String Filler, String PortClientFlag, String Filler2);

	public void orderCancellation1C(String Firm, String OrderNumber,
			String OrderEntryDate);

	public void orderChange1D(String Firm, String OrderNumber,
			String OrderEntryDate, String ClientID, String Filler);

	public void advertisement1E(String Firm, String TraderID,
			String SecuritySymbol, String Side, String Volume, String Price,
			String Board, String Time, String AddCancelFlag, String Contact);

	public void oneFirmPutThroughDeal1F(String Firm, String TraderID,
			String ClientIDBuyer, String ClientIDSeller, String SecuritySymbol,
			String Price, String Board, String DealID, String Filler,
			String BrokerPortfolioVolumeBuyer, String BrokerClientVolumeBuyer,
			String MutualFundVolumeBuyer, String BrokerForeignVolumeBuyer,
			String Filler2, String BrokerPortfolioVolumeSeller,
			String BrokerClientVolumeSeller, String MutualFundVolumeSeller,
			String BrokerForeignVolumeSeller, String Filler3);

	public void twoFirmPutThroughDeal1G(String FirmSeller,
			String TraderIDSeller, String ClientIDSeller,
			String ContraFirmBuyer, String TraderIDBuyer,
			String SecuritySymbol, String Price, String Board, String DealID,
			String Filler, String BrokerPortfolioVolumeSeller,
			String BrokerClientVolumeSeller, String MutualFundVolumeSeller,
			String BrokerForeignVolumeSeller, String Filler2);

	public void admin3A(String Firm, String TraderIDSender,
			String TraderIDReciever, String ContraFirm, String AdminMessageText);

	public void putThroughDealReply3B(String Firm, String ConfirmNumber,
			String DealID, String ClientIDBuyer, String ReplyCode,
			String Filler, String BrokerPortfolioVolume,
			String BrokerClientVolume, String BrokerMutualFundVolume,
			String BrokerForeignVolume, String Filler2);

	public void dealPutThroughCancelRequest3C(String Firm, String ContraFirm,
			String TraderID, String ConfirmNumber, String SecuritySymbol,
			String Side);

	public void dealCancelReply3D(String Firm, String ConfirmNumber,
			String ReplyCode);
	
	public boolean connect();
	
	public boolean disconnect();
}
