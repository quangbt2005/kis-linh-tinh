package eps.com.message.sended;

import java.io.Serializable;

import eps.com.common.ValueObject;

public class PutThroughDealReply_3B extends ValueObject implements Serializable {

	private static final long serialVersionUID = 1L;

	public static final String MessageType = "3B";

	private String Firm;
	private String ConfirmNumber;
	private String DealID;
	private String ClientIDBuyer;
	private String ReplyCode;
	private String Filler;
	private String BrokerPortfolioVolume;
	private String BrokerClientVolume;
	private String BrokerMutualFundVolume;
	private String BrokerForeignVolume;
	private String Filler2;

	public PutThroughDealReply_3B() {
	}

	public String getFirm() {
		return Firm;
	}

	public void setFirm(String firm) {
		Firm = firm;
	}

	public String getConfirmNumber() {
		return ConfirmNumber;
	}

	public void setConfirmNumber(String confirmNumber) {
		ConfirmNumber = confirmNumber;
	}

	public String getDealID() {
		return DealID;
	}

	public void setDealID(String dealID) {
		DealID = dealID;
	}

	public String getClientIDBuyer() {
		return ClientIDBuyer;
	}

	public void setClientIDBuyer(String clientIDBuyer) {
		ClientIDBuyer = clientIDBuyer;
	}

	public String getReplyCode() {
		return ReplyCode;
	}

	public void setReplyCode(String replyCode) {
		ReplyCode = replyCode;
	}

	public String getFiller() {
		return Filler;
	}

	public void setFiller(String filler) {
		Filler = filler;
	}

	public String getBrokerPortfolioVolume() {
		return BrokerPortfolioVolume;
	}

	public void setBrokerPortfolioVolume(String brokerPortfolioVolume) {
		BrokerPortfolioVolume = brokerPortfolioVolume;
	}

	public String getBrokerClientVolume() {
		return BrokerClientVolume;
	}

	public void setBrokerClientVolume(String brokerClientVolume) {
		BrokerClientVolume = brokerClientVolume;
	}

	public String getBrokerMutualFundVolume() {
		return BrokerMutualFundVolume;
	}

	public void setBrokerMutualFundVolume(String brokerMutualFundVolume) {
		BrokerMutualFundVolume = brokerMutualFundVolume;
	}

	public String getBrokerForeignVolume() {
		return BrokerForeignVolume;
	}

	public void setBrokerForeignVolume(String brokerForeignVolume) {
		BrokerForeignVolume = brokerForeignVolume;
	}

	public String getFiller2() {
		return Filler2;
	}

	public void setFiller2(String filler2) {
		Filler2 = filler2;
	}

}
