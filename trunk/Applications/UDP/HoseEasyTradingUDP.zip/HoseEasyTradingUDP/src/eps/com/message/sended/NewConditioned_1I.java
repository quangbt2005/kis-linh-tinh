package eps.com.message.sended;

/**
 * Lớp này minh họa cho cấu trúc của message 1I-New Conditioned Order.
 * 
 */
import java.io.Serializable;
import java.sql.Date;
import java.sql.Timestamp;

import eps.com.common.ValueObject;

public class NewConditioned_1I extends ValueObject implements Serializable {

	private static final long serialVersionUID = 1L;

	/**
	 * Thuộc tính Message_Type có kích thước là 2 bytes, được sử dụng để xác
	 * định kiểu của message trong hệ thống. Hiện tại nó có giá trị mặc định là
	 * 1I (Lưu ý: Phải đọc từ tập tin messageconfg.xml).
	 */
	public static final String MessageType = "1I";
	/**
	 * Thuộc tính Firm có kích thước là 3 bytes, được sử dụng để nhận dạng việc
	 * gửi và nhận từ CTCK nào. Do TTGDCK cung cấp. Các giá thuộc phạm vi sau: +
	 * 1 <= n <= 9215 <nếu 2 bytes thì Mod96> + 1 <= n <= 999 <nếu 3 bytes thì
	 * numeric String>
	 */
	private String Firm;
	/**
	 * Thuộc tính Trader_ID có kích thước 4 bytes là một dãy bao gồm chữ và số.
	 * Được sử dụng để xác định một người dùng cụ thể.Những giá trị có thể :
	 * xxxx : x = 0-9
	 */
	private String TraderID;

	/**
	 * Những giá trị có thể có : 1 <= n <= 84,934,655
	 */
	private String OrderNumber;

	/**
	 * Một trường 10 ký tự kiểu chữ chứa đựng mã tài khoản khách hàng của cong
	 * ty chứng khoán. Thông tin này là bắt buộc và theo quy định của HOSE.
	 * 
	 * <pre>
	 * Những giá trị có thể : 
	 * - Ba ký tự đầu là mã công ty chứng khoán hoặc mã thành viên lưu ký
	 * - Ký tự thứ 4 thì tương ứng với pc flag
	 * - Những ký tự khác là giá trị
	 * - Không có khoảng trắng
	 * 
	 * PC Flag		Fourth Char             First three Char		
	 * P			P                       broker no			
	 * C			C                       broker no			
	 * M			A                       local custodian symbol		
	 * M			B                       custodian symbol		
	 * F			F                       custodian symbol or broker no	
	 * F			E                       foreign custodian symbol
	 * </pre>
	 */
	private String ClientID;

	/**
	 * Một trường 8 ký tự kiểu chữ chứa đựng mã chứng khoán được dùng ở HOSE.
	 */
	private String SecuritySymbol;

	/**
	 * Một trường 1 ký tự kiểu chữ xác định bên mua hoặc bên bán của 1 giao
	 * dịch. Trường này có thể để trống trong message xác nhận thỏa thuận (deal
	 * confirmation messages ) mà message này là kết quả của 1 giao dịch thỏa
	 * thuận cùng thành viên. Những giá trị có thể có :
	 * 
	 * <pre>
	 * X	Firm is both buyer and seller (for 2L)
	 * B	Buy
	 * S	Sell
	 * </pre>
	 */
	private String Side;

	/**
	 * The number of shares for equity securities and the number of bonds for
	 * debt securities that changed hands during the trading period. Possible
	 * values: 1 <= n <= 84,934,655 (encoded integer)
	 */
	private String Volume;

	/**
	 * Một trường 8 ký tự chỉa ra bao nhiêu khối lượng của lệnh đặt có trong thị
	 * trường. Những giá trị có thể có : 1 <= n <= 84,934,655 (encoded integer)
	 */
	private String PublishedVolume;

	/**
	 * Một trường chỉ ra giá của lệnh đặt hoặc lệnh khớp. Price có thể là số
	 * nguyên hoặc là số thập phân dựa vào loại giao dịch. Ví dụ : 54.25 hoặc
	 * 1250. Giá trị kiểu chữ chỉ được chấp nhận với trường hợp ATO, ATC hoặc
	 * lệnh MP. Những giá trị có thể có : *
	 * 
	 * <pre>
	 * ATO	At The Open    
	 * OR     ATC At The Close
	 * OR     MP Market Price   (orders only)
	 * OR 1 &lt;= n &lt;= 849,346 (for Broadcast)      
	 * OR 1 &lt;= n &lt;= 999,999.999999(for 1E, 1F, 1G, 2F, 2L,AA) 
	 * OR 1 &lt;= n &lt;= 99,999.99 (for 1I)    
	 * OR 1 &lt;= n &lt;;= 99,999.99  (for 2D, 2E, 2I)
	 * 
	 * Remark : Price trong giao dịch thỏa thuận như 1F,1G thì theo kiểu units of 1/1,000,000 point.
	 * 
	 * </pre>
	 */
	private String Price;

	/**
	 * Một trường một ký tự kiểu chử chỉ ra bảng giao dịch. Những giá trị có
	 * thể:
	 * 
	 * <pre>
	 * &quot;B&quot;  	Big-lot board 
	 * &quot;M&quot; 	Main board 
	 * &quot;O&quot; 	Off-hour board
	 * 
	 * </pre>
	 */
	private String Board;

	/**
	 * Một khối ký tự rỗng không chứa đựng thong tin
	 */
	private String Filler;

	/**
	 * Một trường 1 ký tự kiểu chữ chỉ ra lệnh đó được giao dịch với tư cách tự
	 * doanh cu3a công ty chứng khoán của nhà đầu tư v.v… Những giá trị có thể
	 * có :
	 * 
	 * <pre>
	 * &quot;C&quot;	Broker Client		
	 * &quot;F&quot;	Broker Foreign
	 * &quot;M&quot;	Mutual Fund
	 * &quot;P&quot;	Broker Portfolio
	 * 
	 * </pre>
	 */
	private String PortClientFlag;

	/**
	 * Một khối ký tự rỗng không chứa đựng thông tin
	 */
	private String Filler2;

	public NewConditioned_1I() {
	}

	public String getFirm() {
		return Firm;
	}

	public void setFirm(String firm) {
		Firm = firm;
	}

	public static String getMessageType() {
		return MessageType;
	}

	public String getBoard() {
		return Board;
	}

	public void setBoard(String board) {
		Board = board;
	}

	public String getClientID() {
		return ClientID;
	}

	public void setClientID(String client_ID) {
		ClientID = client_ID;
	}

	public String getOrderNumber() {
		return OrderNumber;
	}

	public void setOrderNumber(String order_Number) {
		OrderNumber = order_Number;
	}

	public String getPortClientFlag() {
		return PortClientFlag;
	}

	public void setPortClientFlag(String port_Client_Flag) {
		PortClientFlag = port_Client_Flag;
	}

	public String getPublishedVolume() {
		return PublishedVolume;
	}

	public void setPublishedVolume(String published_Volume) {
		PublishedVolume = published_Volume;
	}

	public String getPrice() {
		return Price;
	}

	public void setPrice(String price) {
		Price = price;
	}

	public String getSecuritySymbol() {
		return SecuritySymbol;
	}

	public void setSecuritySymbol(String security_Symbol) {
		SecuritySymbol = security_Symbol;
	}

	public String getSide() {
		return Side;
	}

	public void setSide(String side) {
		Side = side;
	}

	public String getTraderID() {
		return TraderID;
	}

	public void setTraderID(String traderID) {
		TraderID = traderID;
	}

	public String getVolume() {
		return Volume;
	}

	public void setVolume(String volume) {
		Volume = volume;
	}

	public String getFiller() {
		return Filler;
	}

	public void setFiller(String filler) {
		Filler = filler;
	}

	public String getFiller2() {
		return Filler2;
	}

	public void setFiller2(String filler2) {
		Filler2 = filler2;
	}

}
