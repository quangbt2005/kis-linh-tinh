package eps.com.test;

import java.util.ArrayList;
import java.util.List;

import eps.com.message.sended.DealCancelReply_3D;
import eps.com.message.sended.DealPutThroughCancelRequest_3C;
import eps.com.message.sended.NewConditioned_1I;
import eps.com.message.sended.PutThroughDealReply_3B;

public class C1ConformanceTest {

	public static NewConditioned_1I getOrder(String orderType) {
		List<NewConditioned_1I> listOrders;

		if (orderType.equals("ATC")) {
			listOrders = NormalTest.get1IMessages(1, "10", "B", "ATC");
		} else if (orderType.equals("ATO")) {
			listOrders = NormalTest.get1IMessages(1, "11", "B", "ATO");
		} else {
			listOrders = NormalTest.get1IMessages(1, "12", "S", "MP");
		}

		return listOrders.get(0);
	}

	public static List<NewConditioned_1I> get1IMessages(int numberOfMessages,
			String buyOrSell, String orderType, String securitySymbol) {
		List<NewConditioned_1I> ret = new ArrayList<NewConditioned_1I>();

		NewConditioned_1I order;
		for (int i = 0; i < numberOfMessages; i++) {
			String clientID = TestCommon.createRandomAcountBuy();

			order = new NewConditioned_1I();
			order.setFirm("057");
			order.setTraderID("2120");
			order.setOrderNumber(TestCommon.createRandomOrderNumber());
			order.setClientID(clientID);
			order.setSecuritySymbol(securitySymbol);
			order.setSide(buyOrSell);
			order.setVolume("1000    ");
			order.setPublishedVolume("1000    ");
			if (orderType.equals("")) {
				order.setPrice(TestCommon.getPrice(securitySymbol));
			} else {
				order.setPrice(orderType);
			}

			order.setBoard("M");
			order.setFiller("");
			order.setPortClientFlag("C");
			order.setFiller2("");

			ret.add(order);

			// System.out.println(order.getOrderNumber());
		}
		return ret;
	}

	public static List<NewConditioned_1I> get1IForeignerMessages(
			int numberOfMessages, String buyOrSell, String orderType,
			String securitySymbol) {
		List<NewConditioned_1I> ret = new ArrayList<NewConditioned_1I>();

		NewConditioned_1I order;
		for (int i = 0; i < numberOfMessages; i++) {
			// String orderNumber = TestCommon.createRandomOrderNumber();
			String clientID = TestCommon.createRandomForeignerAcountBuy();
			if (securitySymbol == null)
				securitySymbol = TestCommon.createRandomSymbol();

			order = new NewConditioned_1I();
			order.setFirm("057");
			order.setTraderID("2120");
			order.setOrderNumber(TestCommon.createRandomOrderNumber());
			order.setClientID(clientID);
			order.setSecuritySymbol(securitySymbol);
			order.setSide(buyOrSell);
			order.setVolume("10      ");
			order.setPublishedVolume("10      ");
			if (orderType.equals("")) {
				order.setPrice(TestCommon.getPrice(securitySymbol));
			} else {
				order.setPrice(orderType);
			}

			order.setBoard("M");
			order.setFiller("");
			order.setPortClientFlag("F");
			order.setFiller2("");

			ret.add(order);

			// System.out.println(order.getOrderNumber());
		}
		return ret;
	}

	// Pre-open session
	public static List<NewConditioned_1I> loadTest1() {
		List<NewConditioned_1I> ret = new ArrayList<NewConditioned_1I>();

		// 500 LO
		// 100 LO HAP Buy
		List<NewConditioned_1I> listOrders = get1IMessages(100, "B", "", "HAP");
		ret.addAll(listOrders);

		// 100 LO HAP Sell
		listOrders = get1IMessages(100, "S", "", "HAP");
		ret.addAll(listOrders);

		// 100 LO REE Buy
		listOrders = get1IMessages(100, "B", "", "REE");
		ret.addAll(listOrders);

		// 100 LO REE Sell
		listOrders = get1IMessages(100, "S", "", "REE");
		ret.addAll(listOrders);

		// 50 LO STB Buy
		listOrders = get1IMessages(50, "B", "", "STB");
		ret.addAll(listOrders);

		// 50 LO STB Sell
		listOrders = get1IMessages(50, "S", "", "STB");
		ret.addAll(listOrders);

		// 150 ATO
		// 75 ATO PJT
		listOrders = get1IMessages(75, "B", "ATO", "PJT");
		ret.addAll(listOrders);

		// 75 ATO VTO
		listOrders = get1IMessages(75, "B", "ATO", "VTO");
		ret.addAll(listOrders);

		// 100 MP/ATC
		// 50 MP
		listOrders = get1IMessages(50, "S", "MP", "PJT");
		ret.addAll(listOrders);

		// 50 ATC
		listOrders = get1IMessages(50, "B", "ATC", "VTO");
		ret.addAll(listOrders);

		return ret;
	}

	// Open session
	public static List<NewConditioned_1I> loadTest2() {
		List<NewConditioned_1I> ret = new ArrayList<NewConditioned_1I>();

		// 500 LO
		// 100 LO TDH Buy
		List<NewConditioned_1I> listOrders = get1IMessages(100, "B", "", "TDH");
		ret.addAll(listOrders);

		// 100 LO TDH Sell
		listOrders = get1IMessages(100, "S", "", "TDH");
		ret.addAll(listOrders);

		// 100 LO UNI Buy
		listOrders = get1IMessages(100, "B", "", "UNI");
		ret.addAll(listOrders);

		// 100 LO UNI Sell
		listOrders = get1IMessages(100, "S", "", "UNI");
		ret.addAll(listOrders);

		// 50 LO VIC Buy
		listOrders = get1IMessages(50, "B", "", "VPL");
		ret.addAll(listOrders);

		// 50 LO ABT Buy
		listOrders = get1IMessages(50, "B", "", "ABT");
		ret.addAll(listOrders);

		// 100 valid buying LO of foreigner DPM
		listOrders = get1IForeignerMessages(100, "B", "", "DPM");
		ret.addAll(listOrders);

		// 200 ATO/ATC/MP
		// 75 ATO UNI
		listOrders = get1IMessages(75, "B", "ATO", "UNI");
		ret.addAll(listOrders);

		// 75 ATC VPL
		listOrders = get1IMessages(75, "S", "ATC", "VPL");
		ret.addAll(listOrders);

		// 50 MP DPM
		listOrders = get1IMessages(50, "S", "MP", "DPM");
		ret.addAll(listOrders);

		return ret;
	}

	// Pre-close session
	public static List<NewConditioned_1I> loadTest3() {
		List<NewConditioned_1I> ret = new ArrayList<NewConditioned_1I>();

		// 500 LO
		// 200 LO DHG Buy
		List<NewConditioned_1I> listOrders = get1IMessages(200, "B", "", "DHG");
		ret.addAll(listOrders);

		// 200 LO SJS Sell
		listOrders = get1IMessages(200, "S", "", "SJS");
		ret.addAll(listOrders);

		// 100 LO HMC Buy
		listOrders = get1IMessages(100, "B", "", "HMC");
		ret.addAll(listOrders);

		// 50 ATC
		// 25 ATC IFS
		listOrders = get1IMessages(25, "B", "ATC", "IFS");
		ret.addAll(listOrders);

		// 25 ATC MCV
		listOrders = get1IMessages(25, "S", "ATC", "MCV");
		ret.addAll(listOrders);

		// 100 ATO/MP
		// 50 ATO
		listOrders = get1IMessages(50, "B", "ATO", "DHG");
		ret.addAll(listOrders);

		// 50 MP
		listOrders = get1IMessages(50, "B", "MP", "SJS");
		ret.addAll(listOrders);

		return ret;
	}

	public static PutThroughDealReply_3B get3BMessage(String confirmNumber,
			String replyCode, String pVolumne, String cVolumne,
			String mVolumne, String fVolumne) {
		PutThroughDealReply_3B send = new PutThroughDealReply_3B();
		send.setFirm("057");
		send.setConfirmNumber(confirmNumber);
		send.setDealID("12345");
		String ClientID = TestCommon.createRandomAcountBuy();
		send.setClientIDBuyer(ClientID);
		send.setReplyCode(replyCode); // A
		send.setFiller("    ");
		send.setBrokerPortfolioVolume(pVolumne);
		send.setBrokerClientVolume(cVolumne);
		send.setBrokerMutualFundVolume(mVolumne);
		send.setBrokerForeignVolume(fVolumne);

		String temp = "";
		for (int i = 0; i < 32; i++) {
			temp += " ";
		}
		send.setFiller2(temp);

		return send;

	}

	public static PutThroughDealReply_3B get3BMessage(String confirmNumber,
			String replyCode, String pVolumne, String cVolumne,
			String mVolumne, String fVolumne, String ClientType) {
		PutThroughDealReply_3B send = new PutThroughDealReply_3B();
		send.setFirm("057");
		send.setConfirmNumber(confirmNumber);
		send.setDealID("12345");
		String ClientID = "";
		if (ClientType.equals(""))
			ClientID = TestCommon.createRandomAcountBuy();
		else
			ClientID = TestCommon.createRandomForeignerAcountBuy();
		send.setClientIDBuyer(ClientID);
		send.setReplyCode(replyCode); // A
		send.setFiller("    ");
		send.setBrokerPortfolioVolume(pVolumne);
		send.setBrokerClientVolume(cVolumne);
		send.setBrokerMutualFundVolume(mVolumne);
		send.setBrokerForeignVolume(fVolumne);

		String temp = "";
		for (int i = 0; i < 32; i++) {
			temp += " ";
		}
		send.setFiller2(temp);

		return send;

	}

	public static DealPutThroughCancelRequest_3C getTwoFirm3CMessage(
			String Firm, String ContraFirm, String TraderID,
			String ConfirmNumber, String SecuritySymbol, String Side) {
		DealPutThroughCancelRequest_3C request = new DealPutThroughCancelRequest_3C();

		request.setFirm(Firm);
		request.setContraFirm(ContraFirm);
		request.setTraderID(TraderID);
		request.setConfirmNumber(ConfirmNumber);
		request.setSecuritySymbol(SecuritySymbol);
		request.setSide(Side);

		return request;
	}

	public static DealCancelReply_3D get3DMessage(String confirmNumber) {
		DealCancelReply_3D send = new DealCancelReply_3D();
		send.setFirm("057");
		send.setConfirmNumber(confirmNumber);
		send.setReplyCode("A");
		return send;

	}

}
