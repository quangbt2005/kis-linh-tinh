package eps.com.client.upd;

import java.util.Vector;

import eps.com.client.upd.Common;
import eps.com.common.HosePacket;
import eps.com.common.Opcode;
import eps.com.common.RecoveryObject;
import eps.com.common.ValueObject;
import eps.com.test.TestCommon;
import eps.com.util.MessageUtil;

public class ReceiveUDPMessageQueue {
	private Vector<byte[]> messages = new Vector();

	// Called by Main Thread
	public synchronized void putMessage(byte[] object) {
		messages.addElement(object);
		notify();
	}

	// Called by Main Thread
	public synchronized void putMessageinFirst(byte[] object) {
		messages.add(0,object);
		notify();
	}
	
	// Called by PacketSender
	public synchronized byte[] getMessage() throws InterruptedException {
		while (messages.size() == 0)
			wait();
		byte[] msgdata = (byte[])messages.remove(0);
		return msgdata;
	}

	public long getMessageSize() {
		return messages.size();
	}

}
