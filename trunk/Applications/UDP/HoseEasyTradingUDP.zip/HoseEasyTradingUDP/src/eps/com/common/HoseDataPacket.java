package eps.com.common;

public class HoseDataPacket extends HosePacket{
	public HoseDataPacket(byte[] arg) {
		super(arg);
	}

}
