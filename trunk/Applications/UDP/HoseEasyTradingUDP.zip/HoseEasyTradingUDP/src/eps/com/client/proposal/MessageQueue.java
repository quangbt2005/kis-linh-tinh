package eps.com.client.proposal;

import java.util.Vector;

import eps.com.client.upd.Common;
import eps.com.common.HosePacket;
import eps.com.common.Opcode;
import eps.com.common.RecoveryObject;
import eps.com.common.ValueObject;
import eps.com.test.TestCommon;

public class MessageQueue {
	private Vector<Object> messages = new Vector();

	// Called by Main Thread
	public synchronized void putMessage(Object object) {
		// boolean flag = false;
		// if (object != null && object instanceof HosePacket) {
		// HosePacket packet = (HosePacket) object;
		// flag = Common.compare2byteArray(packet.get_opcode(), Opcode.EC);
		// }
		boolean isObject = false;
		isObject = (object != null && object instanceof ValueObject);
		// khong can add echo message neu queue van con data
		while (messages.size() > 0 && !isObject) {
			// while (count > 0) {
			try {
				// System.out.println("co vo wait:" + messages.size());
				wait();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		messages.addElement(object);
		notify();
	}

	// Called by Main Thread or Receive Thread
	public synchronized void putMessageinFirst(Object object) {
		messages.add(0, object);
		notifyAll();
	}

	// Called by PacketSender
	public synchronized Object getMessage() throws InterruptedException {
		while (messages.size() == 0)
			wait();
		// Object message = (Object) messages.get(0);
		Object message = (Object) messages.remove(0);
		// notify create echo packet thread
		if (messages.size() == 0) {
			notifyAll();
		}
		return message;
	}

	public long getMessageSize() {
		return messages.size();
	}

	public synchronized void saveObjectsInQueue(Object obj) {
		if (obj != null)
			messages.add(0, obj);
		Object object;
		String name;
		for (int i = messages.size() -1 ; i >=0 ; i--) {
			object = messages.remove(i);
			if (object instanceof ValueObject) {
				name = RecoveryObject.getRecoveryName("QDT", i);
				RecoveryObject.writeObjectInQueue(name, object);
			}
		}
	}
}
