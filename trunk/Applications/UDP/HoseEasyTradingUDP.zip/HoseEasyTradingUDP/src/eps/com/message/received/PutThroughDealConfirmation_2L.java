package eps.com.message.received;

import java.io.Serializable;
import java.sql.Date;

import eps.com.common.ValueObject;

public class PutThroughDealConfirmation_2L extends ValueObject implements
		Serializable {

	private static final long serialVersionUID = 1L;

	public static final String MessageType = "2L";
	private String Firm;
	private String Side;
	private String DealID;
	private String ContraFirm;
	private String Volume;
	private String Price;
	private String ConfirmNumber;

	public PutThroughDealConfirmation_2L() {
	}

	public String getFirm() {
		return Firm;
	}

	public void setFirm(String firm) {
		Firm = firm;
	}

	public String getSide() {
		return Side;
	}

	public void setSide(String side) {
		Side = side;
	}

	public String getDealID() {
		return DealID;
	}

	public void setDealID(String dealID) {
		DealID = dealID;
	}

	public String getContraFirm() {
		return ContraFirm;
	}

	public void setContraFirm(String contraFirm) {
		ContraFirm = contraFirm;
	}

	public String getVolume() {
		return Volume;
	}

	public void setVolume(String volume) {
		Volume = volume;
	}

	public String getPrice() {
		return Price;
	}

	public void setPrice(String price) {
		Price = price;
	}

	public String getConfirmNumber() {
		return ConfirmNumber;
	}

	public void setConfirmNumber(String confirmNumber) {
		ConfirmNumber = confirmNumber;
	}

}
