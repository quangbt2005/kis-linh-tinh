package eps.com.common;

public interface MessageInterface {
	public byte[] getContent();
}
