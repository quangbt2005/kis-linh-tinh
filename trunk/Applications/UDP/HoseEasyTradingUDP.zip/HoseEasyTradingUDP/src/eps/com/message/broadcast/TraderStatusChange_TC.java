package eps.com.message.broadcast;

import java.io.Serializable;

import eps.com.common.ValueObject;

public class TraderStatusChange_TC extends ValueObject implements Serializable{
	
	public static final String MessageType="TC";
	
	private long Firm ;
	private long Trader_ID ;
	private String Trader_Status  ;
	
	public TraderStatusChange_TC()
	{
		
	}
	public long getFirm() {
		return Firm;
	}
	public void setFirm(long firm) {
		Firm = firm;
	}
	public static String getMessage_Type() {
		return MessageType ; 
	}
	
	public long getTrader_ID() {
		return Trader_ID;
	}
	public void setTrader_ID(long trader_ID) {
		Trader_ID = trader_ID;
	}
	public String getTrader_Status() {
		return Trader_Status;
	}
	public void setTrader_Status(String trader_Status) {
		Trader_Status = trader_Status;
	}
	
}
