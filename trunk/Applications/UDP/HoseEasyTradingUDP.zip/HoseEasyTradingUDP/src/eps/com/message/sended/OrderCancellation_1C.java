package eps.com.message.sended;

import java.io.Serializable;

import eps.com.common.ValueObject;

public class OrderCancellation_1C extends ValueObject implements Serializable {

	private static final long serialVersionUID = 1L;

	public static final String MessageType = "1C";

	private String Firm;
	private String OrderNumber;
	private String OrderEntryDate;

	public OrderCancellation_1C() {
	}

	public String getFirm() {
		return Firm;
	}

	public void setFirm(String firm) {
		Firm = firm;
	}

	public String getOrderNumber() {
		return OrderNumber;
	}

	public void setOrderNumber(String orderNumber) {
		OrderNumber = orderNumber;
	}

	public String getOrderEntryDate() {
		return OrderEntryDate;
	}

	public void setOrderEntryDate(String orderEntryDate) {
		OrderEntryDate = orderEntryDate;
	}
}
