package eps.com.message.broadcast;

import java.io.Serializable;

import eps.com.common.ValueObject;
import java.io.Serializable;
import java.sql.Date;
import java.sql.Timestamp;

import eps.com.common.ValueObject; 

public class BrokerReconcile_BR extends ValueObject implements Serializable{
public static final String MessageType="BR";
	
	long  Firm ;
	String  MarketID ;
	String VolumeSold ;
	String ValueSold ;
	String VolumeBought ;
	String ValueBought ;
	
	public BrokerReconcile_BR()
	{
		
	}
	
	
	public long getFirm() {
		return Firm;
	}

	public void setFirm(long firm) {
		Firm = firm;
	}

	public String getMarketID() {
		return MarketID;
	}

	public void setMarketID(String marketID) {
		MarketID = marketID;
	}

	public String getVolumeSold() {
		return VolumeSold;
	}

	public void setVolumeSold(String volumeSold) {
		VolumeSold = volumeSold;
	}

	public String getValueSold() {
		return ValueSold;
	}

	public void setValueSold(String valueSold) {
		ValueSold = valueSold;
	}

	public String getVolumeBought() {
		return VolumeBought ;
	}

	public void setVolumeBought(String volumeBought) {
		VolumeBought = volumeBought;
	}

	public String getValueBought() {
		return VolumeBought;
	}

	public void setValueBought(String valueBought) {
		ValueBought = valueBought;
	}

	
	
	public static String getMessageType() {
		return MessageType;
	}
}
