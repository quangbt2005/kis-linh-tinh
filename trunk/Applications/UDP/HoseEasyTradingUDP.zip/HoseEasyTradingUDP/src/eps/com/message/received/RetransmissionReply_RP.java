package eps.com.message.received;

import java.io.Serializable;

import eps.com.common.ValueObject;

public class RetransmissionReply_RP extends ValueObject implements Serializable {

	private static final long serialVersionUID = 1L;
	public static final String MessageType = "RP";
	private long Firm;
	private String MarketID;
	private long PreviousSequenceNumber;
	private long SequenceNumber;
	private long MessageCount;
	private String OriginalBroadcastMessage;

	public RetransmissionReply_RP() {
	}

	public long getFirm() {
		return Firm;
	}

	public void setFirm(long firm) {
		Firm = firm;
	}

	public String getMarketID() {
		return MarketID;
	}

	public void setMarketID(String marketID) {
		MarketID = marketID;
	}

	public long getPreviousSequenceNumber() {
		return PreviousSequenceNumber;
	}

	public void setPreviousSequenceNumber(long previousSequenceNumber) {
		PreviousSequenceNumber = previousSequenceNumber;
	}

	public long getSequenceNumber() {
		return SequenceNumber;
	}

	public void setSequenceNumber(long sequenceNumber) {
		SequenceNumber = sequenceNumber;
	}

	public long getMessageCount() {
		return MessageCount;
	}

	public void setMessageCount(long messageCount) {
		MessageCount = messageCount;
	}

	public String getOriginalBroadcastMessage() {
		return OriginalBroadcastMessage;
	}

	public void setOriginalBroadcastMessage(String originalBroadcastMessage) {
		OriginalBroadcastMessage = originalBroadcastMessage;
	}

}
