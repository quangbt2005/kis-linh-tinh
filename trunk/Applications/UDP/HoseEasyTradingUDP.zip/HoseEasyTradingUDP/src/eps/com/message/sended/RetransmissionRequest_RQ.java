package eps.com.message.sended;

import java.io.Serializable;

import eps.com.common.ValueObject;

public class RetransmissionRequest_RQ extends ValueObject implements Serializable {

	private static final long serialVersionUID = 1L;

	public static final String MessageType = "RQ";
	private long Firm;
	private String MarketID;
	private long RetransmissionStartSequence;
	private long RetransmissionEndSequence;

	public RetransmissionRequest_RQ() {
	}

	
	public String getMarketID() {
		return MarketID;
	}

	public void setMarketID(String marketID) {
		MarketID = marketID;
	}

	public long getRetransmissionStartSequence() {
		return RetransmissionStartSequence;
	}

	public void setRetransmissionStartSequence(long retransmissionStartSequence) {
		RetransmissionStartSequence = retransmissionStartSequence;
	}

	public long getRetransmissionEndSequence() {
		return RetransmissionEndSequence;
	}

	public void setRetransmissionEndSequence(long retransmissionEndSequence) {
		RetransmissionEndSequence = retransmissionEndSequence;
	}


	public long getFirm() {
		return Firm;
	}


	public void setFirm(long firm) {
		Firm = firm;
	}


	public static String getMessageType() {
		return MessageType;
	}

}
