package eps.com.message.received;

import java.io.Serializable;
import java.sql.Date;

import eps.com.common.ValueObject;

/**
 * Lớp minh họa cho lệnh xác nhận đặt 2B.
 * 
 * @author quocthai
 * 
 */
public class OrderConfirmation_2B extends ValueObject implements Serializable {

	private static final long serialVersionUID = 1L;

	public static final String MessageType = "2B";
	private String Firm;
	private String OrderNumber;
	private String OrderEntryDate;

	public OrderConfirmation_2B() {
	}

	public String getFirm() {
		return Firm;
	}

	public void setFirm(String firm) {
		Firm = firm;
	}

	public String getOrderNumber() {
		return OrderNumber;
	}

	public void setOrderNumber(String orderNumber) {
		OrderNumber = orderNumber;
	}

	public String getOrderEntryDate() {
		return OrderEntryDate;
	}

	public void setOrderEntryDate(String orderEntryDate) {
		OrderEntryDate = orderEntryDate;
	}

}
