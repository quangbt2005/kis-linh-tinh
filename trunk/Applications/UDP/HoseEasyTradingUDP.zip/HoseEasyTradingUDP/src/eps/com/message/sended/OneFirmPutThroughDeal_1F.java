package eps.com.message.sended;

import java.io.Serializable;
import java.sql.Date;

import eps.com.common.ValueObject;

public class OneFirmPutThroughDeal_1F extends ValueObject implements
		Serializable {

	private static final long serialVersionUID = 1L;

	public static final String MessageType = "1F";
	private String Firm;
	private String TraderID;
	private String ClientIDBuyer;
	private String ClientIDSeller;
	private String SecuritySymbol;
	private String Price;
	private String Board;
	private String DealID;
	private String Filler;
	private String BrokerPortfolioVolumeBuyer;
	private String BrokerClientVolumeBuyer;
	private String MutualFundVolumeBuyer;
	private String BrokerForeignVolumeBuyer;
	private String Filler2;
	private String BrokerPortfolioVolumeSeller;
	private String BrokerClientVolumeSeller;
	private String MutualFundVolumeSeller;
	private String BrokerForeignVolumeSeller;
	private String Filler3;

	public OneFirmPutThroughDeal_1F() {
	}

	public String getFirm() {
		return Firm;
	}

	public void setFirm(String firm) {
		Firm = firm;
	}

	public String getTraderID() {
		return TraderID;
	}

	public void setTraderID(String traderID) {
		TraderID = traderID;
	}

	public String getClientIDBuyer() {
		return ClientIDBuyer;
	}

	public void setClientIDBuyer(String clientIDBuyer) {
		ClientIDBuyer = clientIDBuyer;
	}

	public String getClientIDSeller() {
		return ClientIDSeller;
	}

	public void setClientIDSeller(String clientIDSeller) {
		ClientIDSeller = clientIDSeller;
	}

	public String getSecuritySymbol() {
		return SecuritySymbol;
	}

	public void setSecuritySymbol(String securitySymbol) {
		SecuritySymbol = securitySymbol;
	}

	public String getPrice() {
		return Price;
	}

	public void setPrice(String price) {
		Price = price;
	}

	public String getBoard() {
		return Board;
	}

	public void setBoard(String board) {
		Board = board;
	}

	public String getDealID() {
		return DealID;
	}

	public void setDealID(String dealID) {
		DealID = dealID;
	}

	public String getFiller() {
		return Filler;
	}

	public void setFiller(String filler) {
		Filler = filler;
	}

	public String getBrokerPortfolioVolumeBuyer() {
		return BrokerPortfolioVolumeBuyer;
	}

	public void setBrokerPortfolioVolumeBuyer(String brokerPortfolioVolumeBuyer) {
		BrokerPortfolioVolumeBuyer = brokerPortfolioVolumeBuyer;
	}

	public String getBrokerClientVolumeBuyer() {
		return BrokerClientVolumeBuyer;
	}

	public void setBrokerClientVolumeBuyer(String brokerClientVolumeBuyer) {
		BrokerClientVolumeBuyer = brokerClientVolumeBuyer;
	}

	public String getMutualFundVolumeBuyer() {
		return MutualFundVolumeBuyer;
	}

	public void setMutualFundVolumeBuyer(String mutualFundVolumeBuyer) {
		MutualFundVolumeBuyer = mutualFundVolumeBuyer;
	}

	public String getBrokerForeignVolumeBuyer() {
		return BrokerForeignVolumeBuyer;
	}

	public void setBrokerForeignVolumeBuyer(String brokerForeignVolumeBuyer) {
		BrokerForeignVolumeBuyer = brokerForeignVolumeBuyer;
	}

	public String getFiller2() {
		return Filler2;
	}

	public void setFiller2(String filler2) {
		Filler2 = filler2;
	}

	public String getBrokerPortfolioVolumeSeller() {
		return BrokerPortfolioVolumeSeller;
	}

	public void setBrokerPortfolioVolumeSeller(
			String brokerPortfolioVolumeSeller) {
		BrokerPortfolioVolumeSeller = brokerPortfolioVolumeSeller;
	}

	public String getBrokerClientVolumeSeller() {
		return BrokerClientVolumeSeller;
	}

	public void setBrokerClientVolumeSeller(String brokerClientVolumeSeller) {
		BrokerClientVolumeSeller = brokerClientVolumeSeller;
	}

	public String getMutualFundVolumeSeller() {
		return MutualFundVolumeSeller;
	}

	public void setMutualFundVolumeSeller(String mutualFundVolumeSeller) {
		MutualFundVolumeSeller = mutualFundVolumeSeller;
	}

	public String getBrokerForeignVolumeSeller() {
		return BrokerForeignVolumeSeller;
	}

	public void setBrokerForeignVolumeSeller(String brokerForeignVolumeSeller) {
		BrokerForeignVolumeSeller = brokerForeignVolumeSeller;
	}

	public String getFiller3() {
		return Filler3;
	}

	public void setFiller3(String filler3) {
		Filler3 = filler3;
	}

}
