package eps.com.message.broadcast;

import java.io.Serializable;

import eps.com.common.ValueObject;

public class ProjectedOpen_PO extends ValueObject implements Serializable{
	
	public static final String MessageType="PO";
	
	private  long Security_Number  ;
	private  long Projected_Open_Price  ;
	
	public ProjectedOpen_PO()
	{
		
	}
	public static String getMessage_Type() {
		return MessageType ;
	}
	
	public long getProjected_Open_Price() {
		return Projected_Open_Price;
	}
	public void setProjected_Open_Price(long projected_Open_Price) {
		Projected_Open_Price = projected_Open_Price;
	}
	public long getSecurity_Number() {
		return Security_Number;
	}
	public void setSecurity_Number(long security_Number) {
		Security_Number = security_Number;
	}
}
