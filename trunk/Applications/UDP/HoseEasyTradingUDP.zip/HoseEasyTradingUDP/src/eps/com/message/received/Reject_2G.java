package eps.com.message.received;

import java.io.Serializable;
import java.sql.Date;
import java.util.concurrent.RejectedExecutionException;

import eps.com.common.ValueObject;

public class Reject_2G extends ValueObject implements Serializable {

	private static final long serialVersionUID = 1L;

	public static final String MessageType = "2G";

	private String Firm;
	private String RejectReasonCode;
	private String OriginalMessageText;

	public Reject_2G() {
	}

	public String getFirm() {
		return Firm;
	}

	public void setFirm(String firm) {
		Firm = firm;
	}

	public String getRejectReasonCode() {
		return RejectReasonCode;
	}

	public void setRejectReasonCode(String rejectReasonCode) {
		RejectReasonCode = rejectReasonCode;
	}

	public String getOriginalMessageText() {
		return OriginalMessageText;
	}

	public void setOriginalMessageText(String originalMessageText) {
		OriginalMessageText = originalMessageText;
	}

	// public void setDesc(String rejectReasonCode) {
	// if (rejectReasonCode.equals("00"))
	// this.desc = "Lệnh MP không có bên đối tác.";
	// if (rejectReasonCode.equals("01"))
	// this.desc = "Giá không hợp lệ.";
	// if (rejectReasonCode.equals("02"))
	// this.desc = "Không đúng khối lượng qui định trên bảng giao dịch.";
	// if (rejectReasonCode.equals("03"))
	// this.desc = "Yêu cầu Không hợp lệ, Thị Trường đã đóng cửa.";
	// if (rejectReasonCode.equals("04"))
	// this.desc = "Không đúng mã chứng khoán.";
	// if (rejectReasonCode.equals("05"))
	// this.desc = "Không đúng mã số công ty.";
	// if (rejectReasonCode.equals("06"))
	// this.desc = "Không đúng mã số người nhập lệnh.";
	// if (rejectReasonCode.equals("07"))
	// this.desc = "Không đúng Confirm Number.";
	// if (rejectReasonCode.equals("08"))
	// this.desc = "Quá trễ để thực hiện yêu cầu.";
	// if (rejectReasonCode.equals("09"))
	// this.desc = "Không đúng Reference Number.";
	// if (rejectReasonCode.equals("10"))
	// this.desc = "Không đúng điều kiện.";
	// if (rejectReasonCode.equals("11"))
	// this.desc = "Chứng khoán bị ngừng giao dịch.";
	// if (rejectReasonCode.equals("12"))
	// this.desc = "Không đúng bảng giao dịch.";
	// if (rejectReasonCode.equals("13"))
	// this.desc = "Thiếu mã số tài khoản khách hàng.";
	// if (rejectReasonCode.equals("14"))
	// this.desc = "Không đúng loại lệnh.";
	// if (rejectReasonCode.equals("15"))
	// this.desc = "Không đúng loại nhà đầu tư.";
	// if (rejectReasonCode.equals("16"))
	// this.desc = "Không đúng Request Code hoặc Reply Code.";
	// if (rejectReasonCode.equals("17"))
	// this.desc = "Không đúng bên gia dịch: Phải là bên mua hoặc bên bán.";
	// if (rejectReasonCode.equals("18"))
	// this.desc = "không đúng Order Number.";
	// if (rejectReasonCode.equals("19"))
	// this.desc = "Không đúng thời gian.";
	// if (rejectReasonCode.equals("20"))
	// this.desc = "Không đúng ngày.";
	// if (rejectReasonCode.equals("24"))
	// this.desc = "Chứng khoán bị đình chỉ giao dịch.";
	// if (rejectReasonCode.equals("25"))
	// this.desc = "Thiếu lọai nhà đầu tư.";
	// if (rejectReasonCode.equals("28"))
	// this.desc = "Thị trường tạm nghỉ giao dịch.";
	// if (rejectReasonCode.equals("29"))
	// this.desc = "Thi trường ngưng giao dịch.";
	// if (rejectReasonCode.equals("31"))
	// this.desc = "Không được phép thay đổi thong tin khớp lệnh.";
	// if (rejectReasonCode.equals("33"))
	// this.desc = "Chứng khoán không được phép giao dịch.";
	// if (rejectReasonCode.equals("34"))
	// this.desc = "Không đúng giá – Trên giá trần.";
	// if (rejectReasonCode.equals("35"))
	// this.desc = "Không đúng giá – Dưới giá sàn.";
	// if (rejectReasonCode.equals("36"))
	// this.desc = "Giá của giao dịch thỏa thuận không đúng định dạng.";
	// if (rejectReasonCode.equals("37"))
	// this.desc = "Không được phép hủy lệnh khớp tự động.";
	// if (rejectReasonCode.equals("38"))
	// this.desc = "Không đúng khối lượng của giao dịch thỏa thuận.";
	// if (rejectReasonCode.equals("44"))
	// this.desc = "Không đúng mã tài khoản khách hàng.";
	// if (rejectReasonCode.equals("99"))
	// this.desc = "Lỗi không xác định.";
	// }

}
