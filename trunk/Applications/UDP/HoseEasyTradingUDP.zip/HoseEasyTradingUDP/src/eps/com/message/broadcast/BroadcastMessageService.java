package eps.com.message.broadcast;

import java.rmi.RemoteException;

import javax.xml.rpc.ServiceException;

import classDirectlyOrderTransfer.ClassDirectlyOrderTransferPort;
import classDirectlyOrderTransfer.ClassDirectlyOrderTransferService;
import classDirectlyOrderTransfer.ClassDirectlyOrderTransferServiceLocator;
import eps.com.client.proposal.EPSServiceController;
import eps.com.common.ValueObject;
import eps.com.message.received.TCPMessageService;

public class BroadcastMessageService {
	private ClassDirectlyOrderTransferService svc  = new ClassDirectlyOrderTransferServiceLocator();

	private ClassDirectlyOrderTransferPort getclassDirectlyOrderTransferPort;

	private static String authenUser = TCPMessageService.authenPass;
	private static String  authenPass= TCPMessageService.authenPass;
	
	public BroadcastMessageService(){
		try {
			getclassDirectlyOrderTransferPort = svc.getclassDirectlyOrderTransferPort();
		} catch (ServiceException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	
	public void processMessage(ValueObject object) {
			if (object instanceof AdvertisementAnnouncement_AA) { // 1
				AdvertisementAnnouncement_AA msgAA = (AdvertisementAnnouncement_AA) object;
				this.processAdvertisement(msgAA);
			} else if (object instanceof BrokerReconcile_BR) { // 2
				BrokerReconcile_BR msgBR = (BrokerReconcile_BR) object;
				this.processMessageBR(msgBR);
			} else if (object instanceof BrokerStatusChange_BS) { // 3
				BrokerStatusChange_BS msgBS = (BrokerStatusChange_BS) object;
				this.processMessage_BS(msgBS);
			} else if (object instanceof CancelOddLot_CO) { // 4
				CancelOddLot_CO msgCO = (CancelOddLot_CO) object;
				this.processMessage_CO(msgCO);
			} else if (object instanceof GeneralAdmin_GA) { // 5
				final GeneralAdmin_GA msgGA = (GeneralAdmin_GA) object;
				this.processMessage_GA(msgGA);
			} else if (object instanceof IndexUpdate_IU) { // 6
				IndexUpdate_IU msgIU = (IndexUpdate_IU) object;
				this.processMessage_IU(msgIU);
			} else if (object instanceof DealCancellationNotice_DC) { // 7
				DealCancellationNotice_DC msgDC = (DealCancellationNotice_DC) object;
				this.processMessage_DC(msgDC);
			} else if (object instanceof LastOddLot_LO) { // 8
				LastOddLot_LO msgLO = (LastOddLot_LO) object;
				this.processMessage_LO(msgLO);
			} else if (object instanceof ForeignRoom_TR) { // 9
				ForeignRoom_TR msgTR = (ForeignRoom_TR) object;
				this.processMessage_TR(msgTR);
			} else if (object instanceof LastSale_LS) { // 10
				LastSale_LS msgLS = (LastSale_LS) object;
				this.processMessage_LS(msgLS);
			} else if (object instanceof MarketOpenLastSale_OS) // 11
			{
				MarketOpenLastSale_OS msgOS = (MarketOpenLastSale_OS) object;
				this.processMessage_OS(msgOS);
			} else if (object instanceof NewOddLot_OL) // 12
			{
				NewOddLot_OL msgOL = (NewOddLot_OL) object;
				this.processMessage_OL(msgOL);
			} else if (object instanceof NewsHeadline_NH) // 13
			{
				NewsHeadline_NH msgNH = (NewsHeadline_NH) object;
				this.processMessage_NH(msgNH);
			} else if (object instanceof NewsStory_NS) // 14
			{
				NewsStory_NS msgNS = (NewsStory_NS) object;
				this.processMessage_NS(msgNS);
			} else if (object instanceof ProjectedOpen_PO) // 15
			{
				ProjectedOpen_PO msgPO = (ProjectedOpen_PO) object;
				this.processMessage_PO(msgPO);
			} else if (object instanceof PutThroughDealNotice_PD) // 16
			{
				PutThroughDealNotice_PD msgPD = (PutThroughDealNotice_PD) object;
				this.processMessage_PD(msgPD);
			} else if (object instanceof SectoralIndices_SI) // 17
			{
				SectoralIndices_SI msgSI = (SectoralIndices_SI) object;
				this.processMessage_SI(msgSI);
			} else if (object instanceof SecurityReconcile_SR) // 18
			{
				SecurityReconcile_SR msgSR = (SecurityReconcile_SR) object;
				this.processMessage_SR(msgSR);
			} else if (object instanceof SecurityStatusChange_SS) // 19
			{
				SecurityStatusChange_SS msgSS = (SecurityStatusChange_SS) object;
				this.processMessage_SS(msgSS);
			} else if (object instanceof SecurityUpdate_SU) // 20
			{
				SecurityUpdate_SU msgSU = (SecurityUpdate_SU) object;
				this.processMessage_SU(msgSU);

			} else if (object instanceof SystemControl_SC) // 21
			{
				SystemControl_SC msgSC = (SystemControl_SC) object;
				this.processMessage_SC(msgSC);
			} else if (object instanceof TimeStamp_TS) // 22
			{
			} else if (object instanceof TopPrices_TP) // 23
			{
				TopPrices_TP msgTP = (TopPrices_TP) object;
				this.processMessage_TS(msgTP);
			} else if (object instanceof TraderStatusChange_TC) // 24
			{
				TraderStatusChange_TC msgTC = (TraderStatusChange_TC) object;
				this.processMessage_TC(msgTC);
			}
	}
	
	public void processAdvertisement(AdvertisementAnnouncement_AA msgAA){ //1
		try {
			String messageType = "AA";
			String securityNumber =msgAA.getSecurityNumber() + "";
			String volume = msgAA.getVolume() + "";
			String price = msgAA.getPrice();
			String firm = msgAA.getFirm() + "";
			String trader = msgAA.getTrader() + "";
			String side= msgAA.getSide();
			String board= msgAA.getBoard();
			String time= msgAA.getTime() + "";
			String addCancelFlag= msgAA.getAddCancelFlag() + "";
			String contact= msgAA.getContact() + "";
			getclassDirectlyOrderTransferPort.insertAA(messageType, securityNumber, volume, price, firm, trader, side, board, time, addCancelFlag, contact, authenUser, authenPass);
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public void processMessageBR(BrokerReconcile_BR msgBR) //2
	{
		try {
			String messageType = "BR";
			String  firm = msgBR.getFirm() + "";
			String  marketID = msgBR.getMarketID();
			String  volumeSold=msgBR.getValueSold();
			String  valueSold=msgBR.getValueSold();
			String  volumeBought=msgBR.getVolumeBought();
			String  valueBought=msgBR.getValueBought();
			
			getclassDirectlyOrderTransferPort.insertBR(messageType, firm, marketID, volumeSold, valueSold, volumeBought, valueBought, authenUser, authenPass);
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public void processMessage_BS(BrokerStatusChange_BS msgBS){ //3
		try {
			String messageType = "BS";
			String firm =msgBS.getFirm() + "";
			String autoMatchHaltFlag=msgBS.getAutoMatchHaltFlag();
			String putthroughHaltFlag=msgBS.getPutthroughHaltFlag();
			getclassDirectlyOrderTransferPort.insertBS(messageType, firm, autoMatchHaltFlag, putthroughHaltFlag, authenUser, authenPass);
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public void processMessage_CO( CancelOddLot_CO msgCO) //4
	{
		try {
			String messageType = "CO";
			String referenceNumber= msgCO.getReferenceNumber() + "";
			getclassDirectlyOrderTransferPort.insertCO(messageType, referenceNumber, authenUser, authenPass);
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
	}
	
	public void processMessage_DC( DealCancellationNotice_DC msgDC) //5
	{
		try {
			String messageType = "DC";
			String confirmNumber = msgDC.getConfirmNumber() + "";
			String securityNumber = msgDC.getSecurityNumber() + "";
			String volume = msgDC.getVolume() + "";
			String price = msgDC.getPrice()  + "";
			String board = msgDC.getBoard();
			getclassDirectlyOrderTransferPort.insertDC(messageType, confirmNumber, securityNumber, volume, price, board, authenUser, authenPass);
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			
	}
	public void processMessage_TR(ForeignRoom_TR msgTR) // 6
	{
		try {
			String messageType = "TR";
			String securityNumber =msgTR.getSecurity_Number() + "";
			String totalRoom = msgTR.getTotal_Room() + "";
			String currentRoom= msgTR.getCurrent_Room() + "";
			getclassDirectlyOrderTransferPort.insertTR(messageType, securityNumber, totalRoom, currentRoom, authenUser, authenPass);
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
	}
	public void processMessage_GA(GeneralAdmin_GA msgGA ) //7
	{
		try {
			String messageType = "GA";
			String adminMessageLengh =msgGA.getAdminMessageLength() + "";
			String adminMessageText = msgGA.getAdminMessageText();
			getclassDirectlyOrderTransferPort.insertGA(messageType, adminMessageLengh, adminMessageText, authenUser, authenPass);
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
		
	}
	public void processMessage_IU( IndexUpdate_IU msgIU ) // 8
	{
		try {
			String messageType = "IU";
			String indexHoSE = msgIU.getIndexHoSE() + "";
			String totalTrades= msgIU.getTotalTrades() + "";
			String totalSharesTraded= msgIU.getTotalSharesTraded() + "";
			String totalValuesTraded= msgIU.getTotalValuesTraded() + "";
			String upVolume= msgIU.getUpVolume() + "";
			String downVolume= msgIU.getDownVolume() + "";
			String noChangeVolume= msgIU.getNoChangeVolume() + "";
			String advances= msgIU.getAdvances() + "";
			String declines= msgIU.getDeclines() + "";
			String noChange= msgIU.getNoChange() + "";
			String filler1= msgIU.getFiller1() + "";
			String marketID= msgIU.getMarketID() + "";
			String filler2= msgIU.getFiller2() + "";
			String indexTime= msgIU.getIndexTime() + "";
			getclassDirectlyOrderTransferPort.insertIU(messageType, indexHoSE, totalTrades, totalSharesTraded, totalValuesTraded, upVolume, downVolume, noChangeVolume, advances, declines, noChange, filler1, marketID, filler2, indexTime, authenUser, authenPass);
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public void processMessage_LO( LastOddLot_LO msgLO)  //9
	{
		try {
			String messageType = "LO";
			String confirmNumber = msgLO.getConfirm_Number() + "";
			String securityNumber = msgLO.getSecurity_Number() + "";
			String oddLotVolume = msgLO.getOdd_Lot_Volume() + "";
			String price = msgLO.getPrice() + "";
			String referenceNumber = msgLO.getReference_Number() + "";
			getclassDirectlyOrderTransferPort.insertLO(messageType, confirmNumber, securityNumber, oddLotVolume, price, referenceNumber, authenUser, authenPass);
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
	public void processMessage_LS(LastSale_LS msgLS) //10
	{
		try {
			String messageType = "LS";
			String confirmNumber = msgLS.getConfirmNumber() + "";
			String securityNumber = msgLS.getSecurityNumber() + "";
			String lotVolume = msgLS.getLotVolume() + "";
			String price = msgLS.getPrice() + "";
			String side = msgLS.getSide() + "";
			getclassDirectlyOrderTransferPort.insertLS(messageType, confirmNumber, securityNumber, lotVolume, price, side, authenUser, authenPass);
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public void processMessage_OS(MarketOpenLastSale_OS msgOS) //11
	{
		try {
			String messageType = "OS";
			String securityNumber = msgOS.getSecurity_Number() + "";
			String price = msgOS.getPrice() + "";
			getclassDirectlyOrderTransferPort.insertOS(messageType, securityNumber, price, authenUser, authenPass);
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void processMessage_OL(NewOddLot_OL msgOL ) //12
	{
		try {
			String messageType = "OL";
			String securityNumber = msgOL.getSecurity_Number() + "";
			String oddLotVolume= msgOL.getOdd_Lot_Volume() + "";
			String price= msgOL.getPrice() + "";
			String side= msgOL.getSide();
			String referenceNumber= msgOL.getReference_Number() + "";
			getclassDirectlyOrderTransferPort.insertOL(messageType, securityNumber, oddLotVolume, price, side, referenceNumber, authenUser, authenPass);
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	public void processMessage_NH(NewsHeadline_NH msgNH) //13
	{
		try {
			String messageType = "NH";
			String newsNumber = msgNH.getNews_number() + "";
			String securitySymbol= msgNH.getSecurity_Symbol() + "";
			String newsHeadlineLength= msgNH.getNews_headline_length() + "";
			String totalNewsStoryPages= msgNH.getTotal_News_Story_Pages() + "";
			String newsHeadlineText= msgNH.getNews_headline_text() + "";
			getclassDirectlyOrderTransferPort.insertNH(messageType, newsNumber, securitySymbol, newsHeadlineLength, totalNewsStoryPages, newsHeadlineText, authenUser, authenPass);
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public void processMessage_NS( NewsStory_NS msgNS) //14
	{
		try {
			String messageType = "NS";
			String newsNumber= msgNS.getNews_Number() +"";
			String newsPageNumber= msgNS.getNews_Page_Number() +"";
			String newsTextLength= msgNS.getNews_Text_Length() +"";
			String newsText= msgNS.getNews_Text() +"";
			getclassDirectlyOrderTransferPort.insertNS(messageType, newsNumber, newsPageNumber, newsTextLength, newsText, authenUser, authenPass);
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void processMessage_PO(ProjectedOpen_PO msgPO) //15
	{
		try {
			String messageType = "PO";
			String securityNumber =msgPO.getSecurity_Number() + "";
			String projectedOpenPrice = msgPO.getProjected_Open_Price() + "";
			getclassDirectlyOrderTransferPort.insertPO(messageType, securityNumber, projectedOpenPrice, authenUser, authenPass);
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public void processMessage_PD(PutThroughDealNotice_PD msgPD) //16
	{
		try {
			String messageType = "PD";
			String confirmNumber =msgPD.getConfirm_Number() + "";
			String securityNumber=msgPD.getSecurity_Number() + "";
			String volume=msgPD.getVolume()+ "";
			String price=msgPD.getPrice() + "";
			String board=msgPD.getBoard() + "";
			getclassDirectlyOrderTransferPort.insertPD(messageType, confirmNumber, securityNumber, volume, price, board, authenUser, authenPass);
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void processMessage_SI(SectoralIndices_SI msgSI) //17
	{
		try {
			String messageType = "SI";
			String indexSectoral = msgSI.getIndex_Sectoral_1()  + "";
			String filler = msgSI.getFiller();
			String indexTime= msgSI.getIndex_Time() + "";
			getclassDirectlyOrderTransferPort.insertSI(messageType, indexSectoral, filler, indexTime, authenUser, authenPass);
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
	}
	public void processMessage_SR( SecurityReconcile_SR msgSR) //18
	{
		try {
			String messageType = "SR";
			String mainOrForeignDeal =msgSR.getMain_or_Foreign_Deal() + "";
			String mainOrForeignAccVolume =msgSR.getMain_or_Foreign_Acc_Volume() + "";
			String mainOrForeignAccValue =msgSR.getMain_or_Foreign_Acc_Value() + "";
			String dealsInBigLotBoard =msgSR.getDeals_in_Big_Lot_Board() + "";
			String bigLotAccVolume =msgSR.getBig_Lot_Acc_Volume() + "";
			String bigLotAccValue =msgSR.getBig_Lot_Acc_Value() + "";
			String dealsInOddLotBoard =msgSR.getDeals_in_Odd_Lot_Board() + "";
			String oddLotAccVolume =msgSR.getOdd_Lot_Acc_Volume() + "";
			String oddLotAccValue =msgSR.getOdd_Lot_Acc_Value() + "";
			getclassDirectlyOrderTransferPort.insertSR(messageType, mainOrForeignDeal, mainOrForeignAccVolume, mainOrForeignAccValue, dealsInBigLotBoard, bigLotAccVolume, bigLotAccValue, dealsInOddLotBoard, oddLotAccVolume, oddLotAccValue, authenUser, authenPass);
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	public void processMessage_SS(SecurityStatusChange_SS  msgSS) //19
	{
		try {
			String messageType = "SS";
			String securityNumber = msgSS.getSecurity_Number() + "";
			String filler1= msgSS.getFiller1();
			String sectorNumber= msgSS.getSector_Number() + "";
			String filler2= msgSS.getFiller2();
			String haltorResumeFlag= msgSS.getHaltorResume_Flag();
			String systemControlCode= msgSS.getSystem_Control_Code();
			String filler3= msgSS.getFiller3()+ "";
			String suspension= msgSS.getSuspension();
			String delist= msgSS.getDelist();
			String filler4= msgSS.getFiller4();
			String ceiling= msgSS.getCeiling() + "";
			String floorPrice= msgSS.getFloor_Price()+ "";
			String securityType= msgSS.getSecurity_Type();
			String priorClosePrice= msgSS.getPrior_Close_Price() + "";
			String filler5= msgSS.getFiller5() + "";
			String split= msgSS.getSplit();
			String benefit= msgSS.getBenefit() + "";
			String meeting= msgSS.getMeeting() + "";
			String notice= msgSS.getNotice();
			String boardLot= msgSS.getBoard_Lot() + "";
			String filler6= msgSS.getFiller6();
			getclassDirectlyOrderTransferPort.insertSS(messageType, securityNumber, filler1, sectorNumber, filler2, haltorResumeFlag, systemControlCode, filler3, suspension, delist, filler4, ceiling, floorPrice, securityType, priorClosePrice, filler5, split, benefit, meeting, notice, boardLot, filler6, authenUser, authenPass);
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			
	}
	public void processMessage_SU(SecurityUpdate_SU msgSU ) //20
	{
		try {
			String messageType = "SU";
			String securityNumberOld = msgSU.getS_SecurityNumberOld() + "";
			String securityNumberNew= msgSU.getS_SecurityNumberNew() + "";
			String filler1= msgSU.getS_Filler1();
			String sectorNumber= msgSU.getS_SectorNumber() + "";
			String filler2= msgSU.getS_Filler2();
			String securitySymbol= msgSU.getS_SecuritySymbol();
			String securityType= msgSU.getS_SecurityType();
			String ceilingPrice= msgSU.getS_CeilingPrice() + "";
			String floorPrice = msgSU.getS_FloorPrice() + "";
			String lastSalePrice = msgSU.getS_LastSalePrice() + "";
			String marketID= msgSU.getS_MarketID();
			String filler3= msgSU.getS_Filler3();
			String securityName= msgSU.getS_SecurityName();
			String filler4= msgSU.getS_Filler4();
			String suspension= msgSU.getS_Suspension();
			String delist= msgSU.getS_Delist();
			String haltorResumeFlag= msgSU.getS_HaltResumeFlag();
			String split= msgSU.getS_Split();
			String benefit= msgSU.getS_Benefit();
			String meeting= msgSU.getS_Meeting();
			String notice= msgSU.getS_Notice();
			String clientIDRequired= msgSU.getS_ClientIDRequired();
			String parValue= msgSU.getS_ParValue() + "";
			String SDCFlag= msgSU.getS_SDCFlag();
			String priorClosePrice= msgSU.getS_PriorClosePrice() + "";
			String priorCloseDate= msgSU.getS_PriorClosedate();
			String openPrice= msgSU.getS_OpenPrice() + "";
			String highestPrice= msgSU.getS_HighestPrice() + "";
			String lowestPrice= msgSU.getS_LowestPrice() + "";
			String totalSharesTraded= msgSU.getS_TotalSharesTraded() + "";
			String totalValuesTraded= msgSU.getS_TotalValuesTraded() + "";
			String boardLot= msgSU.getS_BoardLot() + "";
			String filler5= msgSU.getS_Filler5();

			getclassDirectlyOrderTransferPort.insertSU(messageType, securityNumberOld, securityNumberNew, filler1, sectorNumber, filler2, securitySymbol, securityType, ceilingPrice, floorPrice, lastSalePrice, marketID, filler3, securityName, filler4, suspension, delist, haltorResumeFlag, split, benefit, meeting, notice, clientIDRequired, parValue, SDCFlag, priorClosePrice, priorCloseDate, openPrice, highestPrice, lowestPrice, totalSharesTraded, totalValuesTraded, boardLot, filler5, authenUser, authenPass);
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public void processMessage_SC(SystemControl_SC msgSC) //21
	{
		try {
			String messageType = "SC";
			String systemControlCode = msgSC.getSystem_Control_Code();
			String timestamp = msgSC.getTimestamp() + "";
			getclassDirectlyOrderTransferPort.insertSC(messageType, systemControlCode, timestamp, authenUser, authenPass);
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			
	}
	
	public void processMessage_TS(TimeStamp_TS  msgTS) //22
	{
	}
	public void processMessage_TS(TopPrices_TP  msgTP) //23
	{
		try {
			String messageType = "TP";
			String securityNumber = msgTP.getSecurity_Number() + "";
			String side= msgTP.getSide();
			String price1Best= msgTP.getPrice_1_best()+ "";
			String lotVolume1= msgTP.getLot_Volume_1() + "";
			String price2Best= msgTP.getPrice_2_2nd_best() + "";
			String lotVolume2= msgTP.getLot_Volume_2() + "";
			String price3Best= msgTP.getPrice_3_3rd_best() + "";
			String lotVolume3= msgTP.getLot_Volume_3() + "";
			getclassDirectlyOrderTransferPort.insertTP(messageType, securityNumber, side, price1Best, lotVolume1, price2Best, lotVolume2, price3Best, lotVolume3, authenUser, authenPass);
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public void processMessage_TC( TraderStatusChange_TC  msgTC) //24
	{
		try {
			String messageType = "TC";
			String firm = msgTC.getFirm() + "";
			String traderID= msgTC.getTrader_ID() + "";
			String traderStatus= msgTC.getTrader_Status() + "";
			getclassDirectlyOrderTransferPort.insertTC(messageType, firm, traderID, traderStatus, authenUser, authenPass);
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			
	}

	public void setGetclassDirectlyOrderTransferPort(
			ClassDirectlyOrderTransferPort getclassDirectlyOrderTransferPort) {
		this.getclassDirectlyOrderTransferPort = getclassDirectlyOrderTransferPort;
	}
	
	
	
	
	
	
	
	
}
