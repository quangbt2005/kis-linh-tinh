package eps.com.message.broadcast;

import java.io.Serializable;

import eps.com.common.ValueObject;

public class NewsStory_NS extends ValueObject implements Serializable{
	
	public static final String MessageType="NS";
	private long  News_Number ; 
	private long  News_Page_Number ; 
	private long  News_Text_Length ; 
	private String News_Text  ;
	
	public NewsStory_NS()
	{
		
	}
	
	public static String getMessage_Type() {
		return MessageType;
	}
	
	
	public long getNews_Number() {
		return News_Number;
	}
	public void setNews_Number(long news_Number) {
		News_Number = news_Number;
	}
	public long getNews_Page_Number() {
		return News_Page_Number;
	}
	public void setNews_Page_Number(long news_Page_Number) {
		News_Page_Number = news_Page_Number;
	}
	public String getNews_Text() {
		return News_Text;
	}
	public void setNews_Text(String news_Text) {
		News_Text = news_Text;
	}
	public long getNews_Text_Length() {
		return News_Text_Length;
	}
	public void setNews_Text_Length(long news_Text_Length) {
		News_Text_Length = news_Text_Length;
	}
	
	
}
