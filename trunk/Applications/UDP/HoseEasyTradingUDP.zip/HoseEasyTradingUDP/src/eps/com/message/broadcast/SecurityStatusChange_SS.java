package eps.com.message.broadcast;

import java.io.Serializable;

import eps.com.common.ValueObject;

public class SecurityStatusChange_SS extends ValueObject implements Serializable{
	
	public static final String MessageType="SS";
	
	private long Security_Number ;
	private String Filler1  ;
	private long Sector_Number ;
	private String  Filler2 ;
	private String HaltorResume_Flag  ;
	private String System_Control_Code  ;
	private String  Filler3 ; 
	private String Suspension ;
	private String  Delist ;
	private String Filler4 ;
	private long Ceiling ; 
	private long Floor_Price  ;
	private String Security_Type  ;
	private long  Prior_Close_Price  ;
	private long   Filler5 ; 
	private String Split ;
	private String Benefit ;
	private String Meeting ;
	private String  Notice  ;
	private long  Board_Lot ;
	private String Filler6 ;

	public SecurityStatusChange_SS()
	{
		
	}
	
	public String getBenefit() {
		return Benefit;
	}
	public void setBenefit(String benefit) {
		Benefit = benefit;
	}
	public long getBoard_Lot() {
		return Board_Lot;
	}
	public void setBoard_Lot(long board_Lot) {
		Board_Lot = board_Lot;
	}
	public long getCeiling() {
		return Ceiling;
	}
	public void setCeiling(long ceiling) {
		Ceiling = ceiling;
	}
	public String getDelist() {
		return Delist;
	}
	public void setDelist(String delist) {
		Delist = delist;
	}
	public String getFiller1() {
		return Filler1;
	}
	public void setFiller1(String filler1) {
		Filler1 = filler1;
	}
	public String getFiller2() {
		return Filler2;
	}
	public void setFiller2(String filler2) {
		Filler2 = filler2;
	}
	public String getFiller3() {
		return Filler3;
	}
	public void setFiller3(String filler3) {
		Filler3 = filler3;
	}
	public String getFiller4() {
		return Filler4;
	}
	public void setFiller4(String filler4) {
		Filler4 = filler4;
	}
	public long getFiller5() {
		return Filler5;
	}
	public void setFiller5(long filler5) {
		Filler5 = filler5;
	}
	public String getFiller6() {
		return Filler6;
	}
	public void setFiller6(String filler6) {
		Filler6 = filler6;
	}
	public long getFloor_Price() {
		return Floor_Price;
	}
	public void setFloor_Price(long floor_Price) {
		Floor_Price = floor_Price;
	}
	public String getHaltorResume_Flag() {
		return HaltorResume_Flag;
	}
	public void setHaltorResume_Flag(String haltorResume_Flag) {
		HaltorResume_Flag = haltorResume_Flag;
	}
	public String getMeeting() {
		return Meeting;
	}
	public void setMeeting(String meeting) {
		Meeting = meeting;
	}
	public static String getMessage_Type() {
		return MessageType;
	}
	
	public String getNotice() {
		return Notice;
	}
	public void setNotice(String notice) {
		Notice = notice;
	}
	public long getPrior_Close_Price() {
		return Prior_Close_Price;
	}
	public void setPrior_Close_Price(long prior_Close_Price) {
		Prior_Close_Price = prior_Close_Price;
	}
	public long getSector_Number() {
		return Sector_Number;
	}
	
	public void setSector_Number(long sector_Number) {
		Sector_Number = sector_Number;
	}
	
	public long getSecurity_Number() {
		return Security_Number;
	}
	
	public void setSecurity_Number(long security_Number) {
		Security_Number = security_Number;
	}
	public String getSecurity_Type() {
		return Security_Type;
	}
	public void setSecurity_Type(String security_Type) {
		Security_Type = security_Type;
	}
	public String getSplit() {
		return Split;
	}
	public void setSplit(String split) {
		Split = split;
	}
	public String getSuspension() {
		return Suspension;
	}
	public void setSuspension(String suspension) {
		Suspension = suspension;
	}
	public String getSystem_Control_Code() {
		return System_Control_Code;
	}
	public void setSystem_Control_Code(String system_Control_Code) {
		System_Control_Code = system_Control_Code;
	}
}
