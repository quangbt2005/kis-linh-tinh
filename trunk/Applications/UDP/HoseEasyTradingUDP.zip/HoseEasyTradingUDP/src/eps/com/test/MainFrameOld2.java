package eps.com.test;

import javax.swing.border.EtchedBorder;
import javax.swing.border.Border;
import javax.swing.JPanel;
import javax.swing.JFrame;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Rectangle;
import java.awt.SystemColor;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JComboBox;
import javax.swing.JRadioButton;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;
import javax.swing.SwingUtilities;

import java.awt.event.KeyEvent;
import eps.com.client.proposal.EPSServiceController;
import eps.com.client.upd.UDPClient;
import eps.com.client.upd.UDPContent;
import eps.com.common.HosePacket;
import eps.com.common.HoseSystemPacket;
import eps.com.common.Opcode;
import eps.com.common.ValueObject;
import eps.com.message.sended.Advertisement_1E;
import eps.com.message.sended.DealCancelReply_3D;
import eps.com.message.sended.DealPutThroughCancelRequest_3C;
import eps.com.message.sended.NewConditioned_1I;
import eps.com.message.sended.OrderCancellation_1C;
import eps.com.message.sended.OrderChange_1D;
import eps.com.message.sended.OneFirmPutThroughDeal_1F;
import eps.com.message.sended.PutThroughDealReply_3B;
import eps.com.message.sended.RetransmissionRequest_RQ;
import eps.com.message.sended.TwoFirmPutThroughDeal_1G;
import eps.com.util.MessageUtil;
import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;

import eps.com.message.received.PutThroughAcknowledgment_2F;
import eps.com.message.received.PutThroughDealConfirmation_2L;
import eps.com.message.received.RetransmissionReply_RP;
import java.awt.Font;
import java.awt.Insets;
import java.util.Iterator;
import java.util.List;

public class MainFrameOld2 extends JFrame {
	private JTextField tp4a4404TextField;
	private JTextField aa2TextField_1;
	private JTextField aa2TextField;
	private JTextField aa1TextField;
	private JTextField vfmvf1TextField;
	private JTextField cp1_0100TextField;
	private JTextField cp1c0101TextField;
	private JTextField sTextField_1;
	private JTextField textField_13;
	private JTextField textField_12;
	private JButton btnSend3C_1;
	private JTextField sTextField;
	private JTextField ttcTextField_12;
	private JTextField textField_11;
	private JTextField textField_10;
	private JTextField aTextField_1;
	private JTextField textField_9;
	private JTextField textField_8;
	private JTextField textField_7;
	private JTextField textField_6;
	private JTextField textField_5;
	private JTextField textField_4;
	private JTextField aTextField;
	private JTextField textField_3;
	private JTextField loTextField_6;
	private JTextField ttcTextField_11;
	private JTextField loTextField_5;
	private JTextField ttcTextField_10;
	private JTextField loTextField_4;
	private JTextField ttcTextField_9;
	private JTextField loTextField_3;
	private JTextField ttcTextField_8;
	private JTextField loTextField_2;
	private JTextField ttcTextField_7;
	private JTextField ttcTextField_6;
	private JTextField gmdTextField_1;
	private JTextField ttcTextField_5;
	private JTextField gmdTextField;
	private JTextField ttcTextField_4;
	private JTextField gmdTextField_4;
	private JTextField loTextField_1;
	private JTextField ttcTextField_3;
	private JTextField loTextField;
	private JTextField atoTextField;
	private JTextField ttcTextField_2;
	private JTextField ttcTextField_1;
	private JTextField textField_2;
	private JTextField textField;
	private JTextField stbTextField_1;
	private JTextField ttTextField_1;
	private JTextField stbTextField;
	private JTextField ttcTextField;
	private JTextField changeOrder36;
	private JTextField cancelRejectedOrder35;
	private JTextField cancelValidOrder34;
	private JTextField changeMatchedOrder22;
	private JTextField changeUnmatchedOrder21;
	private JTextField cancelMatchedOrder20;
	private JTextField cancelUnmatchedOrder19;
	private JTextField cancelRejectedOrder10;
	private JTextField cancelValidOrder9;
	private ButtonGroup buttonGroup = new ButtonGroup();
	private String opCode[] = { "HL", "HR", "CF", "DT", "LO", "LL", "RR", "RP",
			"AK", "NK", "FN", "AF", "EC", "ER" }; // @jve:decl-index=0:
	private static final long serialVersionUID = 1L;
	private EPSServiceController controller;
	private UDPClient udpClient;
	private JPanel jContentPane = null;

	private JPanel jPanel = null;

	private JLabel jLabel = null;

	private JLabel jLabel1 = null;

	private JLabel jLabel2 = null;

	private JLabel jLabel3 = null;

	private JLabel jLabel4 = null;
	Border border1 = BorderFactory.createEtchedBorder(EtchedBorder.RAISED,
			Color.white, new Color(165, 163, 151)); // @jve:decl-index=0:

	private JLabel jLabel5 = null;
	private JTextField txtFirmID = null;
	private JTextField txtServerPort = null;
	private JTextField txtServerIP = null;
	private JTextField txtSequence = null;
	private JTextField txtUDPPort = null;
	private JTextField noPacket = null;
	private JPasswordField txtPassword = null;
	private JTextField txtAck = null;
	private JLabel jLabel6 = null;
	private JLabel jLabel7 = null;
	private JTextField txtMarketID = null;
	private JLabel jLabel8 = null;
	private JLabel jLabel9 = null;
	private JComboBox cbPacketType = null;
	private JRadioButton modeA = null;
	private JRadioButton modeB = null;
	private JRadioButton modeC = null;
	private JButton btConnect = null;
	private JButton btDisconnect = null;
	private JButton startUdpListenButton = null;
	private JButton btStopUDP = null;
	private JTabbedPane jTabbedPane = null;
	public static ConformanceFrame conFrame ;
	
	
	public void update3BInfo(PutThroughAcknowledgment_2F message2F) {
		this.textField.setText(message2F.getConfirmNumber());
		// this.aTextField
		textField_3.setText(message2F.getConfirmNumber());
		this.textField_4.setText(message2F.getVolume());
		this.textField_5.setText(message2F.getVolume());
		this.textField_6.setText(message2F.getVolume());
		this.textField_7.setText(message2F.getVolume());
	}

	public void update3CInfo(PutThroughDealConfirmation_2L message2L) {
		textField_2.setText(message2L.getFirm());
		aTextField_1.setText(message2L.getContraFirm());
		// textField_8.setText(message2L.get Firm());
		textField_9.setText(message2L.getConfirmNumber());
		// ttcTextField_1.setText(message2L.get.getFirm());
		// sTextField.setText(message2L.getSide());

	}

	public void update3DInfo(DealPutThroughCancelRequest_3C message3C) {
		textField_10.setText(message3C.getConfirmNumber());
	}
	
	/**
	 * This is the default constructor
	 */
	public MainFrameOld2() {
		super();
		getContentPane().setName("contentPane");
		initialize();
	}

	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
		// jContentPane = (JPanel)this.getContentPane();
		this.getContentPane().setLayout(null);
		this.getContentPane().setBackground(SystemColor.control);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.setResizable(false);
		setSize(new Dimension(800, 600));
		this.getContentPane().add(getJPanel(), null);
		this.getContentPane().add(getJTabbedPane(), null);
		this.setTitle("Test Center");
	}

	/**
	 * This method initializes jContentPane
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getJContentPane() {
		if (jContentPane == null) {
			jContentPane = new JPanel();
			jContentPane.setMinimumSize(new Dimension(800, 600));
			jContentPane.setLayout(null);
			jContentPane.add(getJPanel());
			jContentPane.add(getJTabbedPane());
		}
		return jContentPane;
	}

	/**
	 * This method initializes jPanel
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getJPanel() {
		if (jPanel == null) {
			jLabel9 = new JLabel();
			jLabel9.setBounds(new Rectangle(470, 4, 93, 23));
			jLabel9.setFont(new Font("Dialog", Font.BOLD, 10));
			jLabel9.setText("Packet Type:");
			jLabel8 = new JLabel();
			jLabel8.setBounds(new Rectangle(470, 31, 96, 23));
			jLabel8.setFont(new Font("Dialog", Font.BOLD, 10));
			jLabel8.setText("Number Packets:");
			jLabel7 = new JLabel();
			jLabel7.setBounds(new Rectangle(470, 58, 70, 23));
			jLabel7.setFont(new Font("Dialog", Font.BOLD, 10));
			jLabel7.setText("Market ID:");
			jLabel6 = new JLabel();
			jLabel6.setBounds(new Rectangle(329, 4, 66, 23));
			jLabel6.setFont(new Font("Dialog", Font.BOLD, 10));
			jLabel6.setText("UPD Port:");
			jLabel5 = new JLabel();
			jLabel5.setBounds(new Rectangle(139, 88, 68, 19));
			jLabel5.setFont(new Font("Dialog", Font.BOLD, 10));
			jLabel5.setText("Ack Seq:");
			jLabel4 = new JLabel();
			jLabel4.setBounds(new Rectangle(138, 61, 70, 23));
			jLabel4.setFont(new Font("Dialog", Font.BOLD, 10));
			jLabel4.setText("Password:");
			jLabel3 = new JLabel();
			jLabel3.setBounds(new Rectangle(6, 88, 75, 23));
			jLabel3.setFont(new Font("Dialog", Font.BOLD, 10));
			jLabel3.setText("Sequence:");
			jLabel2 = new JLabel();
			jLabel2.setBounds(new Rectangle(6, 60, 74, 23));
			jLabel2.setFont(new Font("Dialog", Font.BOLD, 10));
			jLabel2.setText("Firm ID:");
			jLabel1 = new JLabel();
			jLabel1.setBounds(new Rectangle(6, 33, 76, 23));
			jLabel1.setFont(new Font("Dialog", Font.BOLD, 10));
			jLabel1.setText("Server Port:");
			jLabel = new JLabel();
			jLabel.setBounds(new Rectangle(6, 7, 74, 23));
			jLabel.setFont(new Font("Dialog", Font.BOLD, 10));
			jLabel.setText("Server IP:");
			jPanel = new JPanel();
			jPanel.setLayout(null);
			jPanel.setBounds(new Rectangle(2, 10, 799, 117));
			// jPanel.setBorder(BorderFactory.createLineBorder(Color.gray, 5));
			jPanel.setBorder(border1);
			jPanel.add(jLabel, null);
			jPanel.add(jLabel1, null);
			jPanel.add(jLabel2, null);
			jPanel.add(jLabel3, null);
			jPanel.add(jLabel4, null);
			jPanel.add(jLabel5, null);
			jPanel.add(getTxtFirmID(), null);
			jPanel.add(getTxtServerPort(), null);
			jPanel.add(getTxtServerIP(), null);
			jPanel.add(getTxtSequence(), null);
			jPanel.add(getTxtUDPPort(), null);
			jPanel.add(getNoPacket(), null);
			jPanel.add(getTxtPassword(), null);
			jPanel.add(getTxtAck(), null);
			jPanel.add(jLabel6, null);
			jPanel.add(jLabel7, null);
			jPanel.add(getTxtMarketID(), null);
			jPanel.add(jLabel8, null);
			jPanel.add(jLabel9, null);
			jPanel.add(getCbPacketType(), null);
			jPanel.add(getModeA(), null);
			jPanel.add(getModeB(), null);
			jPanel.add(getModeC(), null);
			jPanel.add(getBtConnect(), null);
			jPanel.add(getBtDisconnect(), null);
			jPanel.add(getStartUdpListenButton(), null);
			jPanel.add(getBtStopUDP(), null);

			final JButton retransmissionButton = new JButton();
			retransmissionButton.addActionListener(new ActionListener() {
				public void actionPerformed(final ActionEvent arg0) {
					//UDPContent.maxSequence = 0;
				}
			});
			retransmissionButton.setMargin(new Insets(0, 0, 0, 0));
			retransmissionButton.setText("Reset UDP Sequence");
			retransmissionButton.setBounds(329, 85, 122, 22);
			jPanel.add(retransmissionButton);

			final JButton conformanceDay1Button = new JButton();
			conformanceDay1Button.addActionListener(new ActionListener() {
				public void actionPerformed(final ActionEvent arg0) {
					conFrame = new  ConformanceFrame();
					conFrame.setModal(false);
					conFrame.setAlwaysOnTop(true);
					conFrame.setVisible(true);
				}
			});
			conformanceDay1Button.setText("Conformance Day1");
			conformanceDay1Button.setBounds(460, 85, 153, 22);
			jPanel.add(conformanceDay1Button);
		}
		return jPanel;
	}

	/**
	 * This method initializes txtFirmID
	 * 
	 * @return javax.swing.JTextField
	 */
	private JTextField getTxtFirmID() {
		if (txtFirmID == null) {
			txtFirmID = new JTextField();
			txtFirmID.setBounds(new Rectangle(92, 59, 41, 23));
			txtFirmID.setFont(new Font("Dialog", Font.PLAIN, 10));
			txtFirmID.setText("057");
		}
		return txtFirmID;
	}

	/**
	 * This method initializes txtServerPort
	 * 
	 * @return javax.swing.JTextField
	 */
	private JTextField getTxtServerPort() {
		if (txtServerPort == null) {
			txtServerPort = new JTextField();
			txtServerPort.setBounds(new Rectangle(90, 29, 110, 23));
			txtServerPort.setFont(new Font("Dialog", Font.PLAIN, 10));
			txtServerPort.setText("30057");
		}
		return txtServerPort;
	}

	/**
	 * This method initializes txtServerIP
	 * 
	 * @return javax.swing.JTextField
	 */
	private JTextField getTxtServerIP() {
		if (txtServerIP == null) {
			txtServerIP = new JTextField();
			txtServerIP.setBounds(new Rectangle(89, 4, 110, 23));
			txtServerIP.setFont(new Font("Dialog", Font.PLAIN, 10));
			txtServerIP.setText("172.16.255.30");
		}
		return txtServerIP;
	}

	/**
	 * This method initializes txtSequence
	 * 
	 * @return javax.swing.JTextField
	 */
	private JTextField getTxtSequence() {
		if (txtSequence == null) {
			txtSequence = new JTextField();
			txtSequence.setBounds(new Rectangle(92, 86, 42, 23));
			txtSequence.setFont(new Font("Dialog", Font.PLAIN, 10));
			txtSequence.setText("1");
		}
		return txtSequence;
	}

	/**
	 * This method initializes txtUDPPort
	 * 
	 * @return javax.swing.JTextField
	 */
	private JTextField getTxtUDPPort() {
		if (txtUDPPort == null) {
			txtUDPPort = new JTextField();
			txtUDPPort.setBounds(new Rectangle(384, 6, 66, 23));
			txtUDPPort.setFont(new Font("Dialog", Font.PLAIN, 10));
			txtUDPPort.setText("30000");
		}
		return txtUDPPort;
	}

	/**
	 * This method initializes noPacket
	 * 
	 * @return javax.swing.JTextField
	 */
	private JTextField getNoPacket() {
		if (noPacket == null) {
			noPacket = new JTextField();
			noPacket.setBounds(new Rectangle(562, 31, 63, 23));
			noPacket.setText("1");
		}
		return noPacket;
	}

	/**
	 * This method initializes txtPassword
	 * 
	 * @return javax.swing.JPasswordField
	 */
	private JPasswordField getTxtPassword() {
		if (txtPassword == null) {
			txtPassword = new JPasswordField();
			txtPassword.setBounds(new Rectangle(212, 60, 109, 20));
			txtPassword.setText("12345678");
		}
		return txtPassword;
	}

	/**
	 * This method initializes txtAck
	 * 
	 * @return javax.swing.JTextField
	 */
	private JTextField getTxtAck() {
		if (txtAck == null) {
			txtAck = new JTextField();
			txtAck.setBounds(new Rectangle(211, 85, 58, 23));
			txtAck.setText("1");
		}
		return txtAck;
	}

	/**
	 * This method initializes txtMarketID
	 * 
	 * @return javax.swing.JTextField
	 */
	private JTextField getTxtMarketID() {
		if (txtMarketID == null) {
			txtMarketID = new JTextField();
			txtMarketID.setBounds(new Rectangle(562, 58, 62, 23));
			txtMarketID.setText("A");
		}
		return txtMarketID;
	}

	/**
	 * This method initializes cbPacketType
	 * 
	 * @return javax.swing.JComboBox
	 */
	private JComboBox getCbPacketType() {
		if (cbPacketType == null) {
			cbPacketType = new JComboBox();
			cbPacketType.setBounds(new Rectangle(562, 4, 81, 23));
			cbPacketType.setFont(new Font("Dialog", Font.BOLD, 10));
			for (int i = 0; i < this.opCode.length; i++) {
				cbPacketType.insertItemAt(this.opCode[i], i);
			}
			cbPacketType.setSelectedIndex(3);
		}
		return cbPacketType;
	}

	/**
	 * This method initializes modeA
	 * 
	 * @return javax.swing.JRadioButton
	 */
	private JRadioButton getModeA() {
		if (modeA == null) {
			modeA = new JRadioButton();
			buttonGroup.add(modeA);
			modeA.setBounds(new Rectangle(666, 4, 82, 21));
			modeA.setText("Mode A");
			modeA.setFont(new Font("Dialog", Font.BOLD, 10));
			modeA.setSelected(true);
		}
		return modeA;
	}

	/**
	 * This method initializes modeB
	 * 
	 * @return javax.swing.JRadioButton
	 */
	private JRadioButton getModeB() {
		if (modeB == null) {
			modeB = new JRadioButton();
			buttonGroup.add(modeB);
			modeB.setBounds(new Rectangle(666, 31, 69, 21));
			modeB.setFont(new Font("Arian", Font.BOLD, 10));
			modeB.setText("Mode B");
		}
		return modeB;
	}

	/**
	 * This method initializes modeC
	 * 
	 * @return javax.swing.JRadioButton
	 */
	private JRadioButton getModeC() {
		if (modeC == null) {
			modeC = new JRadioButton();
			buttonGroup.add(modeC);
			modeC.setBounds(new Rectangle(666, 58, 89, 21));
			modeC.setFont(new Font("Arian", Font.BOLD, 10));
			modeC.setText("Mode C");
		}
		return modeC;
	}

	/**
	 * This method initializes btConnect
	 * 
	 * @return javax.swing.JButton
	 */
	private JButton getBtConnect() {
		if (btConnect == null) {
			btConnect = new JButton();
			btConnect.setBounds(new Rectangle(212, 4, 109, 23));
			btConnect.setActionCommand("btConnect");
			btConnect.setFont(new Font("Arian", Font.BOLD, 10));
			btConnect.setText("Connect");
			btConnect.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					btConnect_actionPerformed(e);
				}
			});

		}
		return btConnect;
	}

	// Connect to Server
	public void btConnect_actionPerformed(java.awt.event.ActionEvent e) {
		String message = "";
		char mode = 'A';
		if (modeA.isSelected())
			mode = 'A';
		if (modeB.isSelected())
			mode = 'B';
		if (modeC.isSelected())
			mode = 'C';
		int serverPort = Integer.parseInt(this.txtServerPort.getText());
		controller = null;
		try {
			this.controller = EPSServiceController.getInstance(this.txtServerIP
					.getText(), serverPort, this.txtPassword.getText(), mode);
			// boolean result =
			// controller.connectToServer(this.txtServerIP.getText(),
			// serverPort, this.txtPassword.getText(), mode);
			// if(!result){
			// message = "Can not connect to server.";
			// JOptionPane.showMessageDialog(this, message, "Information",
			// JOptionPane.OK_OPTION);
			// return;
			// }
			if (EPSServiceController.isConnectServerOK()) {
				btConnect.setEnabled(false);
				btDisconnect.setEnabled(true);
			} else {
				controller.releaseInstance();
			}
		} catch (Exception e1) {
			message = e1.getMessage();
			JOptionPane.showMessageDialog(this, message, "Information",
					JOptionPane.OK_OPTION);
			e1.printStackTrace();
		}
	}

	/**
	 * This method initializes btDisconnect
	 * 
	 * @return javax.swing.JButton
	 */
	private JButton getBtDisconnect() {
		if (btDisconnect == null) {
			btDisconnect = new JButton();
			btDisconnect.setBounds(new Rectangle(212, 33, 109, 23));
			btDisconnect.setActionCommand("btDisconnect_actionPerformed");
			btDisconnect.setFont(new Font("Arian", Font.BOLD, 10));
			btDisconnect.setText("Disconnect");
			btDisconnect.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					try {
						controller.disconnectFromClient();

						btConnect.setEnabled(true);
						btDisconnect.setEnabled(false);
					} catch (Exception e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
			});
			btDisconnect.setEnabled(false);
		}
		return btDisconnect;
	}

	/**
	 * This method initializes startUdpListenButton
	 * 
	 * @return javax.swing.JButton
	 */
	private JButton getStartUdpListenButton() {
		if (startUdpListenButton == null) {
			startUdpListenButton = new JButton();
			startUdpListenButton.setName("btStopUDP");
			// startUdpListenButton.setMargin(new Insets(0, 0, 0, 0));
			startUdpListenButton
					.addActionListener(new java.awt.event.ActionListener() {
						public void actionPerformed(
								final java.awt.event.ActionEvent e) {
							try {
								int udpPort = Integer.parseInt(txtUDPPort
										.getText());
								udpClient = new UDPClient(udpPort);

								System.out
										.println("Start UDPClient " + udpPort);
								udpClient.start();
								startUdpListenButton.setEnabled(false);
							} catch (Exception e1) {
								// TODO Auto-generated catch block
								e1.printStackTrace();
							}
						}
					});
			startUdpListenButton.setText("Start UDP Listen");
			startUdpListenButton.setBounds(327, 33, 122, 21);
		}
		return startUdpListenButton;
	}

	/**
	 * This method initializes btStopUDP
	 * 
	 * @return javax.swing.JButton
	 */
	private JButton getBtStopUDP() {
		if (btStopUDP == null) {
			btStopUDP = new JButton();
			btStopUDP.setName("btStopUDP");
			btStopUDP.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(final java.awt.event.ActionEvent e) {
					try {
						System.out.println("Stop UDPClient ");
						udpClient.setStop(true);
						udpClient.interrupt();
						udpClient.stop();
						startUdpListenButton.setEnabled(true);
						udpClient = null;
					} catch (Exception e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
			});

			btStopUDP.setText("Stop UDP Listen");
			btStopUDP.setBounds(328, 59, 122, 21);
		}
		return btStopUDP;
	}

	/**
	 * This method initializes jTabbedPane
	 * 
	 * @return javax.swing.JTabbedPane
	 */
	private JTabbedPane getJTabbedPane() {
		if (jTabbedPane == null) {
			jTabbedPane = new JTabbedPane();
			jTabbedPane.setBounds(new Rectangle(2, 121, 802, 501));

			final JPanel panel = new JPanel();
			panel.setLayout(null);
			jTabbedPane.addTab("Day 1 PreOpen", null, panel, null);

			final JButton button = new JButton();
			button.addActionListener(new ActionListener() {
				public void actionPerformed(final ActionEvent arg0) {
					//sendOrders(1);
				}
			});
			button.setBounds(26, 21, 130, 26);
			button.setText("7. Send order c.1");
			panel.add(button);

			final JButton button_1 = new JButton();
			button_1.addActionListener(new ActionListener() {
				public void actionPerformed(final ActionEvent e) {
					NewConditioned_1I conditioned_1I = Day1FunctionTest
							.getInvalidOrder("MP");
					controller.log("Chuong trinh chan khong goi : "
							+ conditioned_1I.toString());
					// sendOrder(conditioned_1I);
				}
			});
			button_1.setText("8. Send order c.2 MP");
			button_1.setBounds(26, 53, 165, 26);
			panel.add(button_1);

			final JButton button_1_1 = new JButton();
			button_1_1.addActionListener(new ActionListener() {
				public void actionPerformed(final ActionEvent arg0) {
					System.out.println(cancelValidOrder9.getText());
					OrderCancellation_1C get1CMessage = Day1FunctionTest
							.get1CMessage(cancelValidOrder9.getText());
					sendOrder(get1CMessage);
				}
			});
			button_1_1.setText("9. Cancel valid Order");
			button_1_1.setBounds(24, 203, 151, 26);
			panel.add(button_1_1);

			cancelValidOrder9 = new JTextField();
			cancelValidOrder9.setBounds(24, 177, 130, 20);
			panel.add(cancelValidOrder9);

			cancelRejectedOrder10 = new JTextField();
			cancelRejectedOrder10.setBounds(24, 235, 130, 20);
			panel.add(cancelRejectedOrder10);

			final JButton button_1_1_1 = new JButton();
			button_1_1_1.addActionListener(new ActionListener() {
				public void actionPerformed(final ActionEvent e) {
					String text = cancelRejectedOrder10.getText();
					System.out.println(text);
					if (text.equalsIgnoreCase("")) {
						controller
								.log("Chuong trinh chan. Can't send cancel request for rejected order");
					} else {
						OrderCancellation_1C get1CMessage = Day1FunctionTest
								.get1CMessage(text);
						controller
								.log("Chuong trinh chan. Can't send cancel request for rejected order: "
										+ get1CMessage.toString());
					}
				}
			});
			button_1_1_1.setText("10. Cancel rejected order");
			button_1_1_1.setBounds(24, 261, 167, 26);
			panel.add(button_1_1_1);

			final JButton button_1_1_1_1 = new JButton();
			button_1_1_1_1.addActionListener(new ActionListener() {
				public void actionPerformed(final ActionEvent e) {
					Advertisement_1E send = NormalTest.get1EMessageinPreOpen();
					sendOrder(send);
				}
			});
			button_1_1_1_1.setText("15. Send PT Advertisement sit.1");
			button_1_1_1_1.setBounds(528, 90, 194, 26);
			panel.add(button_1_1_1_1);

			final JButton button_1_1_1_1_1 = new JButton();
			button_1_1_1_1_1.addActionListener(new ActionListener() {
				public void actionPerformed(final ActionEvent e) {
					List<NewConditioned_1I> loadTest1 = Day1FunctionTest
							.loadTest1();
					sendOrders(loadTest1, "PreOpen");
				}
			});
			button_1_1_1_1_1.setText("16. Load Order#1");
			button_1_1_1_1_1.setBounds(528, 122, 194, 26);
			panel.add(button_1_1_1_1_1);

			final JButton button_3 = new JButton();
			button_3.addActionListener(new ActionListener() {
				public void actionPerformed(final ActionEvent arg0) {
					try {
						String sb = ttcTextField.getText().trim();
						NewConditioned_1I send = NormalTest
								.get1IForeignerMessage(sb);
						controller.sendMessageToQueue(send);
					} catch (Exception e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}

				}
			});
			button_3.setText("11 Send Buying order of Foreigner");
			button_3.setBounds(209, 53, 232, 26);
			panel.add(button_3);

			ttcTextField = new JTextField();
			ttcTextField.setText("TTC");
			ttcTextField.setBounds(334, 24, 87, 20);
			panel.add(ttcTextField);

			final JLabel maCkLabel = new JLabel();
			maCkLabel.setText("Security Symbol");
			maCkLabel.setBounds(220, 26, 108, 16);
			panel.add(maCkLabel);

			final JLabel maCkLabel_1 = new JLabel();
			maCkLabel_1.setText("Security Symbol");
			maCkLabel_1.setBounds(209, 90, 108, 16);
			panel.add(maCkLabel_1);

			stbTextField = new JTextField();
			stbTextField.setText("STB");
			stbTextField.setBounds(330, 88, 87, 20);
			panel.add(stbTextField);

			final JButton button_3_1 = new JButton();
			button_3_1.addActionListener(new ActionListener() {
				public void actionPerformed(final ActionEvent e) {
					try {
						String sb = stbTextField.getText().trim();
						NewConditioned_1I send = NormalTest
								.get1IForeignerMessage(sb);
						String message = "Chuong trinh chan.";
						controller.log(message);
						controller.log(send.toString());
						// controller.sendMessageToQueue(send);
					} catch (Exception e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
			});
			button_3_1.setText("12 Send Buying order of Foreigner (Room <10)");
			button_3_1.setBounds(198, 117, 284, 26);
			panel.add(button_3_1);

			final JButton button_4 = new JButton();
			button_4.addActionListener(new ActionListener() {
				public void actionPerformed(final ActionEvent e) {
					try {
						OneFirmPutThroughDeal_1F send = NormalTest
								.get1FMessage();
						controller.sendMessageToQueue(send);
					} catch (Exception e1) {
						e1.printStackTrace();
					}
				}
			});
			button_4.setText("13. Send PT Deal c.1");
			button_4.setBounds(528, 21, 194, 26);
			panel.add(button_4);

			final JButton button_1_2 = new JButton();
			button_1_2.addActionListener(new ActionListener() {
				public void actionPerformed(final ActionEvent e) {
					try {
						OneFirmPutThroughDeal_1F send = NormalTest
								.get1FBondMessage();
						controller.sendMessageToQueue(send);
					} catch (Exception e1) {
						e1.printStackTrace();
					}
				}
			});
			button_1_2.setText("14. Send PT Deal c.2 Bond");
			button_1_2.setBounds(528, 53, 194, 26);
			panel.add(button_1_2);

			final JButton button_1_3 = new JButton();
			button_1_3.addActionListener(new ActionListener() {
				public void actionPerformed(final ActionEvent e) {
					NewConditioned_1I conditioned_1I = Day1FunctionTest
							.getInvalidOrder("ATC");
					controller.log("Chuong trinh chan khong goi : "
							+ conditioned_1I.toString());
					// sendOrder(conditioned_1I);
				}
			});
			button_1_3.setText("8. Send order c.2 ATC");
			button_1_3.setBounds(26, 85, 165, 26);
			panel.add(button_1_3);

			final JButton insertSeparatorInButton = new JButton();
			insertSeparatorInButton.addActionListener(new ActionListener() {
				public void actionPerformed(final ActionEvent arg0) {
					controller
							.log("-------------- Bat dau PreOpen ----------------");
				}
			});
			insertSeparatorInButton
					.setText("Insert Separator in Log File PreOpen");
			insertSeparatorInButton.setBounds(411, 283, 317, 26);
			panel.add(insertSeparatorInButton);

			final JPanel panel_1 = new JPanel();
			panel_1.setLayout(null);
			jTabbedPane.addTab("Day 1 Open", null, panel_1, null);

			final JButton button_2 = new JButton();
			button_2.addActionListener(new ActionListener() {
				public void actionPerformed(final ActionEvent e) {
					//sendOrders(1);
				}
			});
			button_2.setText("18. Send order c.3");
			button_2.setBounds(10, 10, 130, 26);
			panel_1.add(button_2);

			cancelUnmatchedOrder19 = new JTextField();
			cancelUnmatchedOrder19.setBounds(10, 53, 130, 20);
			panel_1.add(cancelUnmatchedOrder19);

			final JButton button_2_1 = new JButton();
			button_2_1.addActionListener(new ActionListener() {
				public void actionPerformed(final ActionEvent e) {
					System.out.println(cancelUnmatchedOrder19.getText());
					OrderCancellation_1C get1CMessage = Day1FunctionTest
							.get1CMessage(cancelUnmatchedOrder19.getText());
					sendOrder(get1CMessage);
				}
			});
			button_2_1.setText("19. Cancel unmatched order");
			button_2_1.setBounds(10, 81, 194, 26);
			panel_1.add(button_2_1);

			cancelMatchedOrder20 = new JTextField();
			cancelMatchedOrder20.setBounds(10, 127, 130, 20);
			panel_1.add(cancelMatchedOrder20);

			final JButton button_2_1_1 = new JButton();
			button_2_1_1.addActionListener(new ActionListener() {
				public void actionPerformed(final ActionEvent e) {
					String text = cancelMatchedOrder20.getText();
					System.out.println(text);
					if (text.equalsIgnoreCase("")) {
						controller
								.log("Chuong trinh chan. Can't send cancel request for matched order");
					} else {
						OrderCancellation_1C get1CMessage = Day1FunctionTest
								.get1CMessage(text);
						controller
								.log("Chuong trinh chan. Can't send cancel request for matched order: "
										+ get1CMessage.toString());
					}
				}
			});
			button_2_1_1.setText("20. Cancel matched order");
			button_2_1_1.setBounds(10, 155, 194, 26);
			panel_1.add(button_2_1_1);

			changeUnmatchedOrder21 = new JTextField();
			changeUnmatchedOrder21.setBounds(10, 200, 130, 20);
			panel_1.add(changeUnmatchedOrder21);

			final JButton button_2_1_1_1 = new JButton();
			button_2_1_1_1.addActionListener(new ActionListener() {
				public void actionPerformed(final ActionEvent e) {
					System.out.println(changeUnmatchedOrder21.getText());
					OrderChange_1D get1DMessage = Day1FunctionTest
							.get1DMessage(changeUnmatchedOrder21.getText());
					sendOrder(get1DMessage);
				}
			});
			button_2_1_1_1.setText("21. Change unmatched order");
			button_2_1_1_1.setBounds(10, 228, 194, 26);
			panel_1.add(button_2_1_1_1);

			changeMatchedOrder22 = new JTextField();
			changeMatchedOrder22.setBounds(10, 274, 130, 20);
			panel_1.add(changeMatchedOrder22);

			final JButton button_2_1_1_1_1 = new JButton();
			button_2_1_1_1_1.addActionListener(new ActionListener() {
				public void actionPerformed(final ActionEvent e) {
					String text = changeMatchedOrder22.getText();
					System.out.println(text);
					if (text.equalsIgnoreCase("")) {
						controller
								.log("Chuong trinh chan. Can't send change order request for matched order");
					} else {
						OrderChange_1D get1DMessage = Day1FunctionTest
								.get1DMessage(text);
						controller
								.log("Chuong trinh chan. Can't send change order request for matched order: "
										+ get1DMessage.toString());
					}
				}
			});
			button_2_1_1_1_1.setText("22. Change matched order");
			button_2_1_1_1_1.setBounds(10, 302, 194, 26);
			panel_1.add(button_2_1_1_1_1);

			final JButton button_2_2 = new JButton();
			button_2_2.addActionListener(new ActionListener() {
				public void actionPerformed(final ActionEvent e) {
					NewConditioned_1I invalidOrder = Day1FunctionTest
							.getInvalidOrder("MP");
					controller.log("Chuong trinh chan khong goi : "
							+ invalidOrder);
					// sendOrder(invalidOrder);
				}
			});
			button_2_2.setText("23. Send order c.4");
			button_2_2.setBounds(229, 10, 130, 26);
			panel_1.add(button_2_2);

			final JButton button_2_2_1 = new JButton();
			button_2_2_1.addActionListener(new ActionListener() {
				public void actionPerformed(final ActionEvent e) {
					Advertisement_1E send = NormalTest.get1EMessage();
					sendOrder(send);
				}
			});
			button_2_2_1.setText("26. Send PT Advertisement c.1");
			button_2_2_1.setBounds(229, 130, 223, 26);
			panel_1.add(button_2_2_1);

			final JButton button_2_2_1_1 = new JButton();
			button_2_2_1_1.addActionListener(new ActionListener() {
				public void actionPerformed(final ActionEvent e) {
					Advertisement_1E send = NormalTest.get1EBondMessage();
					sendOrder(send);
				}
			});
			button_2_2_1_1.setText("27. Send PT Advertisement c.2 (Bond 1E)");
			button_2_2_1_1.setBounds(229, 170, 277, 26);
			panel_1.add(button_2_2_1_1);

			final JButton button_2_2_2 = new JButton();
			button_2_2_2.addActionListener(new ActionListener() {
				public void actionPerformed(final ActionEvent e) {
					List<NewConditioned_1I> loadTest2 = Day1FunctionTest
							.loadTest2();
					sendOrders(loadTest2, "Open");
				}
			});
			button_2_2_2.setText("30. Load Order#2");
			button_2_2_2.setBounds(458, 130, 176, 26);
			panel_1.add(button_2_2_2);

			final JButton button_2_2_1_2 = new JButton();
			button_2_2_1_2.addActionListener(new ActionListener() {
				public void actionPerformed(final ActionEvent e) {
					try {
						TwoFirmPutThroughDeal_1G send = NormalTest
								.get1GMessage();
						controller
								.log("Chuong trinh chan. Can't send two firm PT deal for Stock ");
						// controller.sendMessageToQueue(send);
					} catch (Exception e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
			});
			button_2_2_1_2.setText("24. Send PT Deal c3 (1G)");
			button_2_2_1_2.setBounds(225, 45, 194, 26);
			panel_1.add(button_2_2_1_2);

			final JButton button_2_2_1_1_1 = new JButton();
			button_2_2_1_1_1.addActionListener(new ActionListener() {
				public void actionPerformed(final ActionEvent e) {
					try {
						TwoFirmPutThroughDeal_1G send = NormalTest
								.get1GBondMessage();
						controller.sendMessageToQueue(send);
					} catch (Exception e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
			});
			button_2_2_1_1_1.setText("25. Send PT Deal c4 (1G Bond)");
			button_2_2_1_1_1.setBounds(229, 90, 190, 26);
			panel_1.add(button_2_2_1_1_1);

			final JLabel maCkLabel_2 = new JLabel();
			maCkLabel_2.setText("Security Symbol");
			maCkLabel_2.setBounds(469, 10, 108, 16);
			panel_1.add(maCkLabel_2);

			ttTextField_1 = new JTextField();
			ttTextField_1.setText("TTC");
			ttTextField_1.setBounds(583, 8, 87, 20);
			panel_1.add(ttTextField_1);

			final JButton button_3_2 = new JButton();
			button_3_2.addActionListener(new ActionListener() {
				public void actionPerformed(final ActionEvent e) {
					try {
						String sb = ttcTextField.getText().trim();
						NewConditioned_1I send = NormalTest
								.get1IForeignerMessage(sb);
						controller.sendMessageToQueue(send);
					} catch (Exception e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}

				}
			});
			button_3_2.setText("28. Send Buying order of Foreigner");
			button_3_2.setBounds(458, 37, 232, 26);
			panel_1.add(button_3_2);

			final JLabel maCkLabel_1_1 = new JLabel();
			maCkLabel_1_1.setText("Security Symbol");
			maCkLabel_1_1.setBounds(458, 74, 108, 16);
			panel_1.add(maCkLabel_1_1);

			stbTextField_1 = new JTextField();
			stbTextField_1.setText("STB");
			stbTextField_1.setBounds(579, 72, 87, 20);
			panel_1.add(stbTextField_1);

			final JButton button_3_1_1 = new JButton();
			button_3_1_1.addActionListener(new ActionListener() {
				public void actionPerformed(final ActionEvent e) {
					try {
						String sb = stbTextField.getText().trim();
						NewConditioned_1I send = NormalTest
								.get1IForeignerMessage(sb);

						String message = "Chuong trinh chan.";
						controller.log(message);
						controller.log(send.toString());
						// controller.sendMessageToQueue(send);
					} catch (Exception e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
			});
			button_3_1_1
					.setText("29. Send Buying order of Foreigner (Room <10)");
			button_3_1_1.setBounds(458, 96, 284, 26);
			panel_1.add(button_3_1_1);

			final JButton insertSeparatorInButton_1 = new JButton();
			insertSeparatorInButton_1.addActionListener(new ActionListener() {
				public void actionPerformed(final ActionEvent e) {
					controller
							.log("----------------- Bat dau Open ----------------");
				}
			});
			insertSeparatorInButton_1
					.setText("Insert Separator in Log file Open");
			insertSeparatorInButton_1.setBounds(398, 302, 317, 26);
			panel_1.add(insertSeparatorInButton_1);

			final JPanel panel_2 = new JPanel();
			panel_2.setLayout(null);
			jTabbedPane.addTab("Day 1 PreClose", null, panel_2, null);

			final JButton button_2_3 = new JButton();
			button_2_3.addActionListener(new ActionListener() {
				public void actionPerformed(final ActionEvent e) {
					//sendOrders(1);
				}
			});
			button_2_3.setText("32. Send order c.5");
			button_2_3.setBounds(10, 10, 148, 26);
			panel_2.add(button_2_3);

			final JButton button_2_3_1 = new JButton();
			button_2_3_1.addActionListener(new ActionListener() {
				public void actionPerformed(final ActionEvent e) {
					NewConditioned_1I invalidOrder = Day1FunctionTest
							.getInvalidOrder("MP");
					controller.log("Chuong trinh chan khong goi : "
							+ invalidOrder);
					// sendOrder(invalidOrder);
				}
			});
			button_2_3_1.setText("33. Send order c.6 MP");
			button_2_3_1.setBounds(10, 111, 170, 26);
			panel_2.add(button_2_3_1);

			final JButton button_2_3_1_1 = new JButton();
			button_2_3_1_1.addActionListener(new ActionListener() {
				public void actionPerformed(final ActionEvent e) {
					System.out.println(cancelValidOrder34.getText());
					OrderCancellation_1C get1CMessage = Day1FunctionTest
							.get1CMessage(cancelValidOrder34.getText());
					sendOrder(get1CMessage);
				}
			});
			button_2_3_1_1.setText("34. Cancel valid Order");
			button_2_3_1_1.setBounds(206, 36, 170, 26);
			panel_2.add(button_2_3_1_1);

			cancelValidOrder34 = new JTextField();
			cancelValidOrder34.setBounds(206, 10, 148, 20);
			panel_2.add(cancelValidOrder34);

			cancelRejectedOrder35 = new JTextField();
			cancelRejectedOrder35.setBounds(206, 85, 148, 20);
			panel_2.add(cancelRejectedOrder35);

			final JButton button_2_3_1_1_1 = new JButton();
			button_2_3_1_1_1.addActionListener(new ActionListener() {
				public void actionPerformed(final ActionEvent e) {
					String text = cancelRejectedOrder35.getText();
					System.out.println(text);
					if (text.equalsIgnoreCase("")) {
						controller
								.log("Chuong trinh chan. Can't send cancel request for rejected order");
					} else {
						OrderCancellation_1C get1CMessage = Day1FunctionTest
								.get1CMessage(text);
						controller
								.log("Chuong trinh chan. Can't send cancel request for rejected order: "
										+ get1CMessage.toString());
					}
				}
			});
			button_2_3_1_1_1.setText("35. Cancel rejected order");
			button_2_3_1_1_1.setBounds(206, 111, 170, 26);
			panel_2.add(button_2_3_1_1_1);

			final JButton button_2_3_1_1_1_1 = new JButton();
			button_2_3_1_1_1_1.addActionListener(new ActionListener() {
				public void actionPerformed(final ActionEvent e) {
					System.out.println(changeOrder36.getText());
					OrderChange_1D get1DMessage = Day1FunctionTest
							.get1DMessage(changeOrder36.getText());
					sendOrder(get1DMessage);
				}
			});
			button_2_3_1_1_1_1.setText("36. Change order");
			button_2_3_1_1_1_1.setBounds(206, 189, 170, 26);
			panel_2.add(button_2_3_1_1_1_1);

			changeOrder36 = new JTextField();
			changeOrder36.setBounds(206, 163, 148, 20);
			panel_2.add(changeOrder36);

			final JButton button_2_3_2 = new JButton();
			button_2_3_2.addActionListener(new ActionListener() {
				public void actionPerformed(final ActionEvent e) {
					List<NewConditioned_1I> loadTest3 = Day1FunctionTest
							.loadTest3();
					sendOrders(loadTest3, "PreClose");
				}
			});
			button_2_3_2.setText("37. Load Order#3");
			button_2_3_2.setBounds(455, 10, 148, 26);
			panel_2.add(button_2_3_2);

			final JButton button_2_3_1_2 = new JButton();
			button_2_3_1_2.addActionListener(new ActionListener() {
				public void actionPerformed(final ActionEvent e) {
					NewConditioned_1I invalidOrder = Day1FunctionTest
							.getInvalidOrder("ATO");
					controller.log("Chuong trinh chan khong goi : "
							+ invalidOrder);
					// sendOrder(invalidOrder);
				}
			});
			button_2_3_1_2.setText("33. Send order c.6 ATO");
			button_2_3_1_2.setBounds(10, 143, 170, 26);
			panel_2.add(button_2_3_1_2);

			final JButton insertSeparatorInButton_1_1 = new JButton();
			insertSeparatorInButton_1_1.addActionListener(new ActionListener() {
				public void actionPerformed(final ActionEvent e) {
					controller
							.log("------------- Bat dau PreClose ------------------");
				}
			});
			insertSeparatorInButton_1_1
					.setText("Insert Separator in Log file PreClose");
			insertSeparatorInButton_1_1.setBounds(418, 293, 317, 26);
			panel_2.add(insertSeparatorInButton_1_1);

			final JPanel panel_3 = new JPanel();
			panel_3.setLayout(null);
			jTabbedPane.addTab("Day 1 Close", null, panel_3, null);

			final JButton button_2_3_2_1 = new JButton();
			button_2_3_2_1.addActionListener(new ActionListener() {
				public void actionPerformed(final ActionEvent e) {
					Advertisement_1E send = NormalTest.get1EMessageRunOff();
					sendOrder(send);
				}
			});
			button_2_3_2_1.setText("39. Send PT Advertisement c.1");
			button_2_3_2_1.setBounds(10, 10, 207, 26);
			panel_3.add(button_2_3_2_1);

			final JButton button_2_3_2_1_1 = new JButton();
			button_2_3_2_1_1.addActionListener(new ActionListener() {
				public void actionPerformed(final ActionEvent e) {
					Advertisement_1E send = NormalTest.get1EBondMessageRunoff();
					sendOrder(send);
				}
			});
			button_2_3_2_1_1.setText("40. Send PT Advertisement c.2 (1E Bond)");
			button_2_3_2_1_1.setBounds(10, 53, 207, 26);
			panel_3.add(button_2_3_2_1_1);

			final JButton button_2_3_2_1_1_1 = new JButton();
			button_2_3_2_1_1_1.addActionListener(new ActionListener() {
				public void actionPerformed(final ActionEvent e) {
					List loadTest4 = Day1FunctionTest.loadTest4();
					sendOrders(loadTest4, "Close");
				}
			});
			button_2_3_2_1_1_1.setText("48. Load Order#4");
			button_2_3_2_1_1_1.setBounds(440, 10, 207, 26);
			panel_3.add(button_2_3_2_1_1_1);

			final JButton button_2_2_1_2_1 = new JButton();
			button_2_2_1_2_1.addActionListener(new ActionListener() {
				public void actionPerformed(final ActionEvent e) {
					TwoFirmPutThroughDeal_1G send = NormalTest
							.get1GForeignerMessage();

//					controller
//							.log("Chuong trinh chan. Can't send two firm PT deal for Stock  ");

					 sendOrder(send);
				}
			});
			button_2_2_1_2_1.setText("41. Send PT Deal c5");
			button_2_2_1_2_1.setBounds(10, 97, 194, 26);
			panel_3.add(button_2_2_1_2_1);

			final JButton button_2_2_1_1_1_1 = new JButton();
			button_2_2_1_1_1_1.addActionListener(new ActionListener() {
				public void actionPerformed(final ActionEvent e) {
					TwoFirmPutThroughDeal_1G send = NormalTest
							.get1GForeignerBondMessage();
					sendOrder(send);
				}
			});
			button_2_2_1_1_1_1.setText("42. Send PT Deal c6 (1G Bond)");
			button_2_2_1_1_1_1.setBounds(10, 140, 190, 26);
			panel_3.add(button_2_2_1_1_1_1);

			final JButton button_2_2_1_2_1_1 = new JButton();
			button_2_2_1_2_1_1.addActionListener(new ActionListener() {
				public void actionPerformed(final ActionEvent e) {
					OneFirmPutThroughDeal_1F send = NormalTest
							.get1FForeignerMessage();
					sendOrder(send);
				}
			});
			button_2_2_1_2_1_1.setText("43. Send PT Deal c7 (1F)");
			button_2_2_1_2_1_1.setBounds(227, 10, 201, 26);
			panel_3.add(button_2_2_1_2_1_1);

			final JButton button_2_2_1_1_1_1_1 = new JButton();
			button_2_2_1_1_1_1_1.addActionListener(new ActionListener() {
				public void actionPerformed(final ActionEvent e) {
					OneFirmPutThroughDeal_1F send = NormalTest
							.get1FForeignerBondMessage();
					sendOrder(send);
				}
			});
			button_2_2_1_1_1_1_1.setText("44. Send PT Deal c8 (1F Bond)");
			button_2_2_1_1_1_1_1.setBounds(223, 42, 215, 26);
			panel_3.add(button_2_2_1_1_1_1_1);

			final JButton button_2_2_1_2_1_2 = new JButton();
			button_2_2_1_2_1_2.addActionListener(new ActionListener() {
				public void actionPerformed(final ActionEvent e) {
					DealPutThroughCancelRequest_3C send = NormalTest
							.get3CMessage();
					sendOrder(send);
				}
			});
			button_2_2_1_2_1_2.setText("45. Cancel PT Deal c1 (1F)");
			button_2_2_1_2_1_2.setBounds(227, 109, 194, 26);
			panel_3.add(button_2_2_1_2_1_2);

			final JButton button_2_2_1_1_1_1_2 = new JButton();
			button_2_2_1_1_1_1_2.addActionListener(new ActionListener() {
				public void actionPerformed(final ActionEvent e) {
					DealPutThroughCancelRequest_3C send = NormalTest
							.getTwoFirm3CMessage();
					sendOrder(send);
				}
			});
			button_2_2_1_1_1_1_2.setText("46. Cancel PT Deal c2 (1G)");
			button_2_2_1_1_1_1_2.setBounds(227, 177, 190, 26);
			panel_3.add(button_2_2_1_1_1_1_2);

			final JButton insertSeparatorInButton_1_1_1 = new JButton();
			insertSeparatorInButton_1_1_1
					.addActionListener(new ActionListener() {
						public void actionPerformed(final ActionEvent e) {
							controller
									.log("----------- Bat dau Close --------------");
						}
					});
			insertSeparatorInButton_1_1_1
					.setText("Insert Separator in Log file Close");
			insertSeparatorInButton_1_1_1.setBounds(417, 292, 317, 26);
			panel_3.add(insertSeparatorInButton_1_1_1);

			final JButton button_2_2_1_2_1_2_1 = new JButton();
			button_2_2_1_2_1_2_1.addActionListener(new ActionListener() {
				public void actionPerformed(final ActionEvent e) {
					String confirmNumber = textField.getText().trim();
					PutThroughDealReply_3B send = NormalTest
							.get3BMessage(confirmNumber);
					sendOrder(send);
				}
			});
			button_2_2_1_2_1_2_1.setText("49. Send 3B reply for 1G");
			button_2_2_1_2_1_2_1.setBounds(440, 77, 194, 26);
			panel_3.add(button_2_2_1_2_1_2_1);

			textField = new JTextField();
			textField.setText("18");
			textField.setBounds(545, 55, 87, 20);
			panel_3.add(textField);

			final JLabel confirmNumberLabel = new JLabel();
			confirmNumberLabel.setText("Confirm Number");
			confirmNumberLabel.setBounds(444, 58, 96, 16);
			panel_3.add(confirmNumberLabel);

			final JButton button_2_2_1_2_1_2_1_1 = new JButton();
			button_2_2_1_2_1_2_1_1.addActionListener(new ActionListener() {
				public void actionPerformed(final ActionEvent e) {
					String confirmNumber = textField_2.getText().trim();
					DealCancelReply_3D send = NormalTest
							.get3DMessage(confirmNumber);
					sendOrder(send);
				}
			});
			button_2_2_1_2_1_2_1_1.setText("50. Send 3D reply for 3C");
			button_2_2_1_2_1_2_1_1.setBounds(440, 140, 194, 26);
			panel_3.add(button_2_2_1_2_1_2_1_1);

			final JLabel confirmNumberLabel_1 = new JLabel();
			confirmNumberLabel_1.setText("Confirm Number");
			confirmNumberLabel_1.setBounds(459, 114, 96, 16);
			panel_3.add(confirmNumberLabel_1);

			textField_2 = new JTextField();
			textField_2.setText("18");
			textField_2.setBounds(560, 111, 87, 20);
			panel_3.add(textField_2);

			final JButton button_2_2_1_2_1_3 = new JButton();
			button_2_2_1_2_1_3.addActionListener(new ActionListener() {
				public void actionPerformed(final ActionEvent e) {
					TwoFirmPutThroughDeal_1G send = NormalTest.get1GMessage();
					sendOrder(send);
				}
			});
			button_2_2_1_2_1_3.setText("41. Send PT Deal 1G to cancel");
			button_2_2_1_2_1_3.setBounds(227, 140, 194, 26);
			panel_3.add(button_2_2_1_2_1_3);

			final JButton button_2_2_1_2_1_1_1 = new JButton();
			button_2_2_1_2_1_1_1.addActionListener(new ActionListener() {
				public void actionPerformed(final ActionEvent e) {
					OneFirmPutThroughDeal_1F send = NormalTest.get1FMessage();
					sendOrder(send);
				}
			});
			button_2_2_1_2_1_1_1.setText("43. Send PT Deal 1F to cancel");
			button_2_2_1_2_1_1_1.setBounds(223, 74, 194, 26);
			panel_3.add(button_2_2_1_2_1_1_1);

			final JPanel panel_4 = new JPanel();
			panel_4.setLayout(null);
			jTabbedPane.addTab("C2 ReOpen", null, panel_4, null);

			final JLabel maCkLabel_3 = new JLabel();
			maCkLabel_3.setBounds(223, 10, 92, 16);
			maCkLabel_3.setText("Security Symbol");
			panel_4.add(maCkLabel_3);

			ttcTextField_1 = new JTextField();
			ttcTextField_1.setBounds(320, 8, 30, 20);
			ttcTextField_1.setText("STB");
			panel_4.add(ttcTextField_1);

			final JButton button_3_3 = new JButton();
			button_3_3.addActionListener(new ActionListener() {
				public void actionPerformed(final ActionEvent arg0) {
				}
			});
			button_3_3.setBounds(223, 32, 248, 26);
			button_3_3.setText("10 Send Buying order of Foreigner");
			panel_4.add(button_3_3);

			final JLabel maCkLabel_3_1 = new JLabel();
			maCkLabel_3_1.setText("Security Symbol");
			maCkLabel_3_1.setBounds(223, 64, 92, 16);
			panel_4.add(maCkLabel_3_1);

			ttcTextField_2 = new JTextField();
			ttcTextField_2.setText("TDH");
			ttcTextField_2.setBounds(320, 62, 30, 20);
			panel_4.add(ttcTextField_2);

			final JButton button_3_3_1 = new JButton();
			button_3_3_1.setText("11 Send Buying order of Foreigner");
			button_3_3_1.setBounds(223, 86, 248, 26);
			panel_4.add(button_3_3_1);

			atoTextField = new JTextField();
			atoTextField.setText("ATO");
			atoTextField.setBounds(356, 8, 87, 20);
			panel_4.add(atoTextField);

			loTextField = new JTextField();
			loTextField.setText("LO");
			loTextField.setBounds(356, 62, 87, 20);
			panel_4.add(loTextField);

			final JLabel maCkLabel_3_1_1 = new JLabel();
			maCkLabel_3_1_1.setText("Security Symbol");
			maCkLabel_3_1_1.setBounds(223, 118, 92, 16);
			panel_4.add(maCkLabel_3_1_1);

			ttcTextField_3 = new JTextField();
			ttcTextField_3.setText("TDH");
			ttcTextField_3.setBounds(320, 116, 30, 20);
			panel_4.add(ttcTextField_3);

			loTextField_1 = new JTextField();
			loTextField_1.setText("LO");
			loTextField_1.setBounds(356, 116, 87, 20);
			panel_4.add(loTextField_1);

			final JButton button_3_3_1_1 = new JButton();
			button_3_3_1_1.setText("12 Send Buying order of Foreigner");
			button_3_3_1_1.setBounds(223, 140, 248, 26);
			panel_4.add(button_3_3_1_1);

			final JButton button_2_2_1_1_1_2 = new JButton();
			button_2_2_1_1_1_2.setMargin(new Insets(0, 0, 0, 0));
			button_2_2_1_1_1_2.setText("13. Send PT Deal c1 (1F Investor)");
			button_2_2_1_1_1_2.setBounds(223, 176, 190, 26);
			panel_4.add(button_2_2_1_1_1_2);

			final JButton button_2_2_1_1_1_3 = new JButton();
			button_2_2_1_1_1_3.setMargin(new Insets(0, 0, 0, 0));
			button_2_2_1_1_1_3.setText("14. Send PT Deal c2 (1F Portfolio)");
			button_2_2_1_1_1_3.setBounds(223, 215, 190, 26);
			panel_4.add(button_2_2_1_1_1_3);

			final JButton button_2_2_1_3 = new JButton();
			button_2_2_1_3.setText("15. Send PT Advertisement c.1");
			button_2_2_1_3.setBounds(477, 32, 223, 26);
			panel_4.add(button_2_2_1_3);

			final JButton button_2_2_1_4 = new JButton();
			button_2_2_1_4.setText("16. Send PT Advertisement c.1");
			button_2_2_1_4.setBounds(477, 86, 223, 26);
			panel_4.add(button_2_2_1_4);

			final JLabel maCkLabel_3_2 = new JLabel();
			maCkLabel_3_2.setText("Security Symbol");
			maCkLabel_3_2.setBounds(477, 8, 92, 16);
			panel_4.add(maCkLabel_3_2);

			gmdTextField_4 = new JTextField();
			gmdTextField_4.setText("GMD");
			gmdTextField_4.setBounds(574, 6, 38, 20);
			panel_4.add(gmdTextField_4);

			final JLabel maCkLabel_3_1_2 = new JLabel();
			maCkLabel_3_1_2.setText("Bond Symbol");
			maCkLabel_3_1_2.setBounds(477, 62, 92, 16);
			panel_4.add(maCkLabel_3_1_2);

			ttcTextField_4 = new JTextField();
			ttcTextField_4.setText("HMCA1805");
			ttcTextField_4.setBounds(574, 60, 79, 20);
			panel_4.add(ttcTextField_4);

			final JLabel maCkLabel_3_2_1 = new JLabel();
			maCkLabel_3_2_1.setText("Security Symbol");
			maCkLabel_3_2_1.setBounds(487, 118, 92, 16);
			panel_4.add(maCkLabel_3_2_1);

			gmdTextField = new JTextField();
			gmdTextField.setText("GMD");
			gmdTextField.setBounds(584, 116, 38, 20);
			panel_4.add(gmdTextField);

			final JButton button_2_2_1_3_1 = new JButton();
			button_2_2_1_3_1.setText("17. Send PT Advertisement c.1");
			button_2_2_1_3_1.setBounds(487, 142, 223, 26);
			panel_4.add(button_2_2_1_3_1);

			final JLabel maCkLabel_3_1_2_1 = new JLabel();
			maCkLabel_3_1_2_1.setText("Bond Symbol");
			maCkLabel_3_1_2_1.setBounds(487, 172, 92, 16);
			panel_4.add(maCkLabel_3_1_2_1);

			ttcTextField_5 = new JTextField();
			ttcTextField_5.setText("HMCA1805");
			ttcTextField_5.setBounds(584, 170, 92, 20);
			panel_4.add(ttcTextField_5);

			final JButton button_2_2_1_4_1 = new JButton();
			button_2_2_1_4_1.setText("18. Send PT Advertisement c.1");
			button_2_2_1_4_1.setBounds(487, 196, 223, 26);
			panel_4.add(button_2_2_1_4_1);

			final JPanel panel_5 = new JPanel();
			panel_5.setLayout(null);
			jTabbedPane.addTab("C2 Open", null, panel_5, null);

			final JLabel maCkLabel_3_2_2 = new JLabel();
			maCkLabel_3_2_2.setBounds(344, 7, 92, 16);
			maCkLabel_3_2_2.setText("Security Symbol");
			panel_5.add(maCkLabel_3_2_2);

			gmdTextField_1 = new JTextField();
			gmdTextField_1.setBounds(441, 5, 31, 20);
			gmdTextField_1.setText("GMD");
			panel_5.add(gmdTextField_1);

			final JButton button_2_2_1_3_2 = new JButton();
			button_2_2_1_3_2.setBounds(344, 31, 207, 26);
			button_2_2_1_3_2.setText("36. Send PT Advertisement c.1");
			panel_5.add(button_2_2_1_3_2);

			final JLabel maCkLabel_3_1_2_2 = new JLabel();
			maCkLabel_3_1_2_2.setBounds(344, 68, 74, 16);
			maCkLabel_3_1_2_2.setText("Bond Symbol");
			panel_5.add(maCkLabel_3_1_2_2);

			ttcTextField_6 = new JTextField();
			ttcTextField_6.setBounds(423, 66, 66, 20);
			ttcTextField_6.setText("HMC_0204");
			panel_5.add(ttcTextField_6);

			final JButton button_2_2_1_4_2 = new JButton();
			button_2_2_1_4_2.setBounds(344, 90, 207, 26);
			button_2_2_1_4_2.setText("37. Send PT Advertisement c.1");
			panel_5.add(button_2_2_1_4_2);

			final JButton button_2_2_1_1_1_2_1 = new JButton();
			button_2_2_1_1_1_2_1.setMargin(new Insets(0, 0, 0, 0));
			button_2_2_1_1_1_2_1.setText("38. Send PT Deal c3");
			button_2_2_1_1_1_2_1.setBounds(344, 122, 190, 26);
			panel_5.add(button_2_2_1_1_1_2_1);

			final JButton button_2_2_1_1_1_3_1 = new JButton();
			button_2_2_1_1_1_3_1.setMargin(new Insets(0, 0, 0, 0));
			button_2_2_1_1_1_3_1.setText("39. Send PT Deal c4");
			button_2_2_1_1_1_3_1.setBounds(344, 154, 190, 26);
			panel_5.add(button_2_2_1_1_1_3_1);

			final JLabel maCkLabel_3_1_3 = new JLabel();
			maCkLabel_3_1_3.setText("Security Symbol");
			maCkLabel_3_1_3.setBounds(344, 193, 92, 16);
			panel_5.add(maCkLabel_3_1_3);

			ttcTextField_7 = new JTextField();
			ttcTextField_7.setText("VFMVF1");
			ttcTextField_7.setBounds(441, 191, 74, 20);
			panel_5.add(ttcTextField_7);

			loTextField_2 = new JTextField();
			loTextField_2.setText("LO");
			loTextField_2.setBounds(521, 191, 31, 20);
			panel_5.add(loTextField_2);

			final JButton button_3_3_1_2 = new JButton();
			button_3_3_1_2.setText("40 Send Order c23");
			button_3_3_1_2.setBounds(344, 215, 179, 26);
			panel_5.add(button_3_3_1_2);

			final JLabel maCkLabel_3_1_1_1 = new JLabel();
			maCkLabel_3_1_1_1.setText("Security Symbol");
			maCkLabel_3_1_1_1.setBounds(344, 247, 92, 16);
			panel_5.add(maCkLabel_3_1_1_1);

			ttcTextField_8 = new JTextField();
			ttcTextField_8.setText("ABT");
			ttcTextField_8.setBounds(441, 245, 30, 20);
			panel_5.add(ttcTextField_8);

			loTextField_3 = new JTextField();
			loTextField_3.setText("LO");
			loTextField_3.setBounds(477, 245, 41, 20);
			panel_5.add(loTextField_3);

			final JButton button_3_3_1_2_1 = new JButton();
			button_3_3_1_2_1.setText("41 Send Order c24");
			button_3_3_1_2_1.setBounds(344, 276, 179, 26);
			panel_5.add(button_3_3_1_2_1);

			final JLabel maCkLabel_3_1_3_1 = new JLabel();
			maCkLabel_3_1_3_1.setText("Security Symbol");
			maCkLabel_3_1_3_1.setBounds(567, 7, 92, 16);
			panel_5.add(maCkLabel_3_1_3_1);

			ttcTextField_9 = new JTextField();
			ttcTextField_9.setText("VFMVF1");
			ttcTextField_9.setBounds(664, 5, 74, 20);
			panel_5.add(ttcTextField_9);

			loTextField_4 = new JTextField();
			loTextField_4.setText("LO");
			loTextField_4.setBounds(744, 5, 31, 20);
			panel_5.add(loTextField_4);

			final JButton button_3_3_1_2_2 = new JButton();
			button_3_3_1_2_2.setText("42 Send Order c25");
			button_3_3_1_2_2.setBounds(567, 29, 179, 26);
			panel_5.add(button_3_3_1_2_2);

			final JLabel maCkLabel_3_1_1_1_1 = new JLabel();
			maCkLabel_3_1_1_1_1.setText("Security Symbol");
			maCkLabel_3_1_1_1_1.setBounds(567, 61, 92, 16);
			panel_5.add(maCkLabel_3_1_1_1_1);

			ttcTextField_10 = new JTextField();
			ttcTextField_10.setText("ABT");
			ttcTextField_10.setBounds(664, 59, 30, 20);
			panel_5.add(ttcTextField_10);

			loTextField_5 = new JTextField();
			loTextField_5.setText("LO");
			loTextField_5.setBounds(700, 59, 87, 20);
			panel_5.add(loTextField_5);

			final JButton button_3_3_1_2_1_1 = new JButton();
			button_3_3_1_2_1_1.setText("43 Send Order c26");
			button_3_3_1_2_1_1.setBounds(567, 90, 179, 26);
			panel_5.add(button_3_3_1_2_1_1);

			final JLabel maCkLabel_3_1_1_1_1_1 = new JLabel();
			maCkLabel_3_1_1_1_1_1.setText("Security Symbol");
			maCkLabel_3_1_1_1_1_1.setBounds(567, 122, 92, 16);
			panel_5.add(maCkLabel_3_1_1_1_1_1);

			ttcTextField_11 = new JTextField();
			ttcTextField_11.setText("ABT");
			ttcTextField_11.setBounds(664, 120, 30, 20);
			panel_5.add(ttcTextField_11);

			loTextField_6 = new JTextField();
			loTextField_6.setText("LO");
			loTextField_6.setBounds(700, 120, 87, 20);
			panel_5.add(loTextField_6);
 
			final JButton button_3_3_1_2_1_1_1 = new JButton();
			button_3_3_1_2_1_1_1.setText("44 Send Order c27");
			button_3_3_1_2_1_1_1.setBounds(567, 144, 179, 26);
			panel_5.add(button_3_3_1_2_1_1_1);

			final JButton button_2_2_1_3_2_1 = new JButton();
			button_2_2_1_3_2_1.setMargin(new Insets(0, 0, 0, 0));
			button_2_2_1_3_2_1.setText("45. Send Cancel PT Advertisement c.3");
			button_2_2_1_3_2_1.setBounds(558, 176, 229, 26);
			panel_5.add(button_2_2_1_3_2_1);

			final JButton button_2_2_1_3_2_1_1 = new JButton();
			button_2_2_1_3_2_1_1.setMargin(new Insets(0, 0, 0, 0));
			button_2_2_1_3_2_1_1.setText("46. Send Cancel PT Advertisement c.3");
			button_2_2_1_3_2_1_1.setBounds(558, 215, 229, 26);
			panel_5.add(button_2_2_1_3_2_1_1);

			final JButton button_2_2_1_3_2_1_2 = new JButton();
			button_2_2_1_3_2_1_2.setMargin(new Insets(0, 0, 0, 0));
			button_2_2_1_3_2_1_2.setText("47. Send Cancel PT Deal c1");
			button_2_2_1_3_2_1_2.setBounds(558, 247, 229, 26);
			panel_5.add(button_2_2_1_3_2_1_2);

			final JButton button_2_2_1_3_2_1_1_1 = new JButton();
			button_2_2_1_3_2_1_1_1.setMargin(new Insets(0, 0, 0, 0));
			button_2_2_1_3_2_1_1_1.setText("47. Send Cancel PT Deal c2");
			button_2_2_1_3_2_1_1_1.setBounds(558, 286, 229, 26);
			panel_5.add(button_2_2_1_3_2_1_1_1);

			final JPanel panel_6 = new JPanel();
			jTabbedPane.addTab("C2 PreClose", null, panel_6, null);

			final JPanel panel_7 = new JPanel();
			panel_7.setLayout(null);
			jTabbedPane.addTab("C2 Close", null, panel_7, null);

			final JButton button_2_3_2_1_2 = new JButton();
			button_2_3_2_1_2.addActionListener(new ActionListener() {
				public void actionPerformed(final ActionEvent e) {
					String sb =cp1c0101TextField.getText().trim();
					Advertisement_1E object = C21ConformationTest.get1EMessageRunOff(sb);
					sendOrder(object);
				}
			});
			button_2_3_2_1_2.setMargin(new Insets(0, 0, 0, 0));
			button_2_3_2_1_2.setText("59. Send PT Advertisement c.6 (1E)");
			button_2_3_2_1_2.setBounds(24, 10, 225, 26);
			panel_7.add(button_2_3_2_1_2);

			final JButton button_2_3_2_1_1_2 = new JButton();
			button_2_3_2_1_1_2.addActionListener(new ActionListener() {
				public void actionPerformed(final ActionEvent e) {
					String sb =cp1_0100TextField.getText().trim();
					Advertisement_1E object = C21ConformationTest.get1EMessageRunOff(sb);
					sendOrder(object);
				}
			});
			button_2_3_2_1_1_2.setMargin(new Insets(0, 0, 0, 0));
			button_2_3_2_1_1_2.setText("60. Send PT Advertisement c.7 (1E Bond)");
			button_2_3_2_1_1_2.setBounds(24, 53, 225, 26);
			panel_7.add(button_2_3_2_1_1_2);

			final JButton button_2_2_1_2_1_4 = new JButton();
			button_2_2_1_2_1_4.addActionListener(new ActionListener() {
				public void actionPerformed(final ActionEvent e) {
					String sb =vfmvf1TextField.getText().trim();
					TwoFirmPutThroughDeal_1G send = C21ConformationTest.get1GForeignerMessage(sb);
					sendOrder(send);
				}
			});
			button_2_2_1_2_1_4.setText("61. Send PT Deal c5 (1G)");
			button_2_2_1_2_1_4.setBounds(24, 97, 194, 26);
			panel_7.add(button_2_2_1_2_1_4);

			final JButton button_2_2_1_1_1_1_3 = new JButton();
			button_2_2_1_1_1_1_3.addActionListener(new ActionListener() {
				public void actionPerformed(final ActionEvent e) {
					String sb =aa1TextField.getText().trim();
					TwoFirmPutThroughDeal_1G send = C21ConformationTest.get1GForeignerMessage(sb);
					sendOrder(send);
				}
			});
			button_2_2_1_1_1_1_3.setText("62. Send PT Deal c6 (1G Bond)");
			button_2_2_1_1_1_1_3.setBounds(24, 140, 190, 26);
			panel_7.add(button_2_2_1_1_1_1_3);

			final JButton button_2_2_1_2_1_4_1 = new JButton();
			button_2_2_1_2_1_4_1.addActionListener(new ActionListener() {
				public void actionPerformed(final ActionEvent e) {
					String sb =aa2TextField.getText().trim();
					TwoFirmPutThroughDeal_1G send = C21ConformationTest.get1GForeignerMessage(sb);
					sendOrder(send);
				}
			});
			button_2_2_1_2_1_4_1.setText("63. Send PT Deal c7 (1G)");
			button_2_2_1_2_1_4_1.setBounds(436, 10, 194, 26);
			panel_7.add(button_2_2_1_2_1_4_1);

			final JButton button_2_2_1_1_1_1_3_1 = new JButton();
			button_2_2_1_1_1_1_3_1.addActionListener(new ActionListener() {
				public void actionPerformed(final ActionEvent e) {
					String sb =aa2TextField_1.getText().trim();
					TwoFirmPutThroughDeal_1G send = C21ConformationTest.get1GForeignerMessage(sb);
					sendOrder(send);
				}
			});
			button_2_2_1_1_1_1_3_1.setText("64. Send PT Deal c8 (1G Bond)");
			button_2_2_1_1_1_1_3_1.setBounds(436, 53, 190, 26);
			panel_7.add(button_2_2_1_1_1_1_3_1);

			final JButton button_2_2_1_1_1_1_3_1_1 = new JButton();
			button_2_2_1_1_1_1_3_1_1.addActionListener(new ActionListener() {
				public void actionPerformed(final ActionEvent e) {
					String sb =tp4a4404TextField.getText().trim();
					TwoFirmPutThroughDeal_1G send = C21ConformationTest.get1GForeignerMessage(sb);
					sendOrder(send);
				}
			});
			button_2_2_1_1_1_1_3_1_1.setText("65. Send PT Deal c9 (1G Bond)");
			button_2_2_1_1_1_1_3_1_1.setBounds(436, 85, 190, 26);
			panel_7.add(button_2_2_1_1_1_1_3_1_1);

			final JButton button_2_2_1_1_1_1_2_1 = new JButton();
			button_2_2_1_1_1_1_2_1.setText("66. Cancel PT Deal c2 (1G)");
			button_2_2_1_1_1_1_2_1.setBounds(436, 128, 190, 26);
			panel_7.add(button_2_2_1_1_1_1_2_1);

			final JLabel confirmNumberLabel_2 = new JLabel();
			confirmNumberLabel_2.setText("Confirm Number");
			confirmNumberLabel_2.setBounds(66, 218, 103, 16);
			panel_7.add(confirmNumberLabel_2);

			textField_3 = new JTextField();
			textField_3.setBounds(163, 218, 87, 20);
			panel_7.add(textField_3);

			final JLabel confirmNumberLabel_1_1 = new JLabel();
			confirmNumberLabel_1_1.setText("Reply Code");
			confirmNumberLabel_1_1.setBounds(93, 238, 63, 16);
			panel_7.add(confirmNumberLabel_1_1);

			aTextField = new JTextField();
			aTextField.setText("A");
			aTextField.setBounds(163, 242, 87, 20);
			panel_7.add(aTextField);

			final JLabel confirmNumberLabel_2_1 = new JLabel();
			confirmNumberLabel_2_1.setText("Portfolio Volume");
			confirmNumberLabel_2_1.setBounds(58, 263, 103, 16);
			panel_7.add(confirmNumberLabel_2_1);

			textField_4 = new JTextField();
			textField_4.setBounds(163, 264, 87, 20);
			panel_7.add(textField_4);

			final JLabel confirmNumberLabel_3 = new JLabel();
			confirmNumberLabel_3.setText("Client Volume");
			confirmNumberLabel_3.setBounds(66, 286, 103, 16);
			panel_7.add(confirmNumberLabel_3);

			textField_5 = new JTextField();
			textField_5.setBounds(163, 286, 87, 20);
			panel_7.add(textField_5);

			final JLabel confirmNumberLabel_1_1_1 = new JLabel();
			confirmNumberLabel_1_1_1.setText("Fund Volume");
			confirmNumberLabel_1_1_1.setBounds(66, 310, 103, 16);
			panel_7.add(confirmNumberLabel_1_1_1);

			textField_6 = new JTextField();
			textField_6.setBounds(163, 310, 87, 20);
			panel_7.add(textField_6);

			final JLabel confirmNumberLabel_2_1_1 = new JLabel();
			confirmNumberLabel_2_1_1.setText("Foreigner Volume");
			confirmNumberLabel_2_1_1.setBounds(48, 333, 111, 16);
			panel_7.add(confirmNumberLabel_2_1_1);

			textField_7 = new JTextField();
			textField_7.setText("30000");
			textField_7.setBounds(163, 332, 87, 20);
			panel_7.add(textField_7);

			final JLabel clientTypeLabel = new JLabel();
			clientTypeLabel.setText("Client Type");
			clientTypeLabel.setBounds(58, 360, 85, 16);
			panel_7.add(clientTypeLabel);

			textField_8 = new JTextField();
			textField_8.setText("F");
			textField_8.setBounds(162, 356, 87, 20);
			panel_7.add(textField_8);

			final JButton send3bReplyButton = new JButton();
			send3bReplyButton.addActionListener(new ActionListener() {
				public void actionPerformed(final ActionEvent arg0) {
					String confirmNumber = textField_3.getText().trim();
					String replyCode = aTextField.getText().trim();
					String pVolumne = textField_4.getText().trim();
					String cVolumne = textField_5.getText().trim();
					String mVolumne = textField_6.getText().trim();
					String fVolumne = textField_7.getText().trim();
					String clientType =textField_8.getText().trim();
					PutThroughDealReply_3B send = C1ConformanceTest.get3BMessage(
							confirmNumber, replyCode, pVolumne, cVolumne, mVolumne,
							fVolumne, clientType);
					sendOrder(send);
				}
			});
			send3bReplyButton.setText("50. Send 3B reply for 1G");
			send3bReplyButton.setBounds(84, 382, 194, 26);
			panel_7.add(send3bReplyButton);

			textField_9 = new JTextField();
			textField_9.setText("57");
			textField_9.setBounds(370, 230, 87, 20);
			panel_7.add(textField_9);

			final JLabel confirmNumberLabel_4 = new JLabel();
			confirmNumberLabel_4.setText("Firm");
			confirmNumberLabel_4.setBounds(330, 232, 25, 16);
			panel_7.add(confirmNumberLabel_4);

			final JLabel confirmNumberLabel_1_2 = new JLabel();
			confirmNumberLabel_1_2.setText("Contra Firm");
			confirmNumberLabel_1_2.setBounds(284, 255, 77, 16);
			panel_7.add(confirmNumberLabel_1_2);

			aTextField_1 = new JTextField();
			aTextField_1.setText("57");
			aTextField_1.setBounds(370, 254, 87, 20);
			panel_7.add(aTextField_1);

			final JLabel confirmNumberLabel_3_1 = new JLabel();
			confirmNumberLabel_3_1.setText("Trader ID");
			confirmNumberLabel_3_1.setBounds(293, 275, 63, 16);
			panel_7.add(confirmNumberLabel_3_1);

			textField_10 = new JTextField();
			textField_10.setText("571");
			textField_10.setBounds(371, 275, 87, 20);
			panel_7.add(textField_10);

			final JLabel confirmNumberLabel_1_1_1_1 = new JLabel();
			confirmNumberLabel_1_1_1_1.setText("Confirm Number");
			confirmNumberLabel_1_1_1_1.setBounds(274, 299, 103, 16);
			panel_7.add(confirmNumberLabel_1_1_1_1);

			textField_11 = new JTextField();
			textField_11.setBounds(371, 299, 87, 20);
			panel_7.add(textField_11);

			final JLabel confirmNumberLabel_2_2 = new JLabel();
			confirmNumberLabel_2_2.setText("Security Symbol");
			confirmNumberLabel_2_2.setBounds(264, 325, 103, 16);
			panel_7.add(confirmNumberLabel_2_2);

			ttcTextField_12 = new JTextField();
			ttcTextField_12.setText("DPM");
			ttcTextField_12.setBounds(374, 320, 87, 20);
			panel_7.add(ttcTextField_12);

			final JLabel confirmNumberLabel_2_1_1_1 = new JLabel();
			confirmNumberLabel_2_1_1_1.setText("Side");
			confirmNumberLabel_2_1_1_1.setBounds(330, 345, 25, 16);
			panel_7.add(confirmNumberLabel_2_1_1_1);

			sTextField = new JTextField();
			sTextField.setText("S");
			sTextField.setBounds(374, 344, 87, 20);
			panel_7.add(sTextField);

			btnSend3C_1 = new JButton();
			btnSend3C_1.addActionListener(new ActionListener() {
				public void actionPerformed(final ActionEvent e) {
					String Firm = textField_9.getText().trim();
					String ContraFirm = aTextField_1.getText().trim();
					String TraderID = textField_10.getText().trim();
					String ConfirmNumber = textField_11.getText().trim();
					String SecuritySymbol = ttcTextField_12.getText().trim();
					String Side = sTextField.getText().trim();
					DealPutThroughCancelRequest_3C send = C1ConformanceTest
							.getTwoFirm3CMessage(Firm, ContraFirm, TraderID,
									ConfirmNumber, SecuritySymbol, Side);
					sendOrder(send);
				}
			});
			btnSend3C_1.setToolTipText("send 2 firm put-through deal (1G)");
			btnSend3C_1.setFont(new Font("Dialog", Font.BOLD, 10));
			btnSend3C_1.setText("51. Send 3C");
			btnSend3C_1.setBounds(370, 383, 94, 27);
			panel_7.add(btnSend3C_1);

			final JLabel confirmNumberLabel_4_1 = new JLabel();
			confirmNumberLabel_4_1.setText("Firm");
			confirmNumberLabel_4_1.setBounds(541, 294, 25, 16);
			panel_7.add(confirmNumberLabel_4_1);

			textField_12 = new JTextField();
			textField_12.setText("57");
			textField_12.setBounds(581, 292, 87, 20);
			panel_7.add(textField_12);

			final JLabel confirmNumberLabel_1_1_1_1_1 = new JLabel();
			confirmNumberLabel_1_1_1_1_1.setText("Confirm Number");
			confirmNumberLabel_1_1_1_1_1.setBounds(485, 318, 103, 16);
			panel_7.add(confirmNumberLabel_1_1_1_1_1);

			textField_13 = new JTextField();
			textField_13.setBounds(582, 318, 87, 20);
			panel_7.add(textField_13);

			final JLabel confirmNumberLabel_2_1_1_1_1 = new JLabel();
			confirmNumberLabel_2_1_1_1_1.setText("Reply Code");
			confirmNumberLabel_2_1_1_1_1.setBounds(495, 345, 78, 16);
			panel_7.add(confirmNumberLabel_2_1_1_1_1);

			sTextField_1 = new JTextField();
			sTextField_1.setText("A");
			sTextField_1.setBounds(582, 342, 87, 20);
			panel_7.add(sTextField_1);

			final JButton button_2_2_1_2_1_2_1_1_1 = new JButton();
			button_2_2_1_2_1_2_1_1_1.addActionListener(new ActionListener() {
				public void actionPerformed(final ActionEvent arg0) {
					String confirmNumber = textField_13.getText().trim();
					DealCancelReply_3D send = C1ConformanceTest
							.get3DMessage(confirmNumber);
					sendOrder(send);
				}
			});
			button_2_2_1_2_1_2_1_1_1.setText("52. Send 3D reply for 3C");
			button_2_2_1_2_1_2_1_1_1.setBounds(501, 382, 194, 26);
			panel_7.add(button_2_2_1_2_1_2_1_1_1);

			cp1c0101TextField = new JTextField();
			cp1c0101TextField.setText("CP1C0101");
			cp1c0101TextField.setBounds(255, 13, 87, 20);
			panel_7.add(cp1c0101TextField);

			cp1_0100TextField = new JTextField();
			cp1_0100TextField.setText("CP1_0100");
			cp1_0100TextField.setBounds(255, 56, 87, 20);
			panel_7.add(cp1_0100TextField);

			vfmvf1TextField = new JTextField();
			vfmvf1TextField.setText("VFMVF1");
			vfmvf1TextField.setBounds(255, 100, 87, 20);
			panel_7.add(vfmvf1TextField);

			aa1TextField = new JTextField();
			aa1TextField.setText("AA1");
			aa1TextField.setBounds(255, 143, 87, 20);
			panel_7.add(aa1TextField);

			aa2TextField = new JTextField();
			aa2TextField.setText("AA2");
			aa2TextField.setBounds(636, 13, 87, 20);
			panel_7.add(aa2TextField);

			aa2TextField_1 = new JTextField();
			aa2TextField_1.setText("AA2");
			aa2TextField_1.setBounds(636, 56, 87, 20);
			panel_7.add(aa2TextField_1);

			tp4a4404TextField = new JTextField();
			tp4a4404TextField.setText("TP4A4404");
			tp4a4404TextField.setBounds(636, 88, 87, 20);
			panel_7.add(tp4a4404TextField);

			final JPanel panel_8 = new JPanel();
			jTabbedPane.addTab("C22 ReOpen", null, panel_8, null);

			final JPanel panel_9 = new JPanel();
			jTabbedPane.addTab("C22 Open", null, panel_9, null);

			final JPanel panel_10 = new JPanel();
			jTabbedPane.addTab("C22 ReClose", null, panel_10, null);

			final JPanel panel_11 = new JPanel();
			jTabbedPane.addTab("C22 Close", null, panel_11, null);
		}
		return jTabbedPane;
	}

































	public void sendOrder(ValueObject object) {
		try {
			controller.sendMessageToQueue(object);
		} catch (Exception e1) {
			e1.printStackTrace();
		}
	}

	public void sendOrders(List listOrders, String marketStatus) {
		try {
			Object object;
			NewConditioned_1I new1I;
			for (int i = 0; i < listOrders.size(); i++) {
				System.out.println("Load Test : number " + i);
				object = listOrders.get(i);
				if (object instanceof NewConditioned_1I) {
					new1I = (NewConditioned_1I) object;
					if (marketStatus.equalsIgnoreCase("PreOpen")) {
						if (new1I.getPrice().equalsIgnoreCase("ATC")
								|| new1I.getPrice().equalsIgnoreCase("MP")) {
							controller
									.log("Chuong trinh chan. Can't send order: "
											+ new1I.toString());
							continue;
						}
					} else if (marketStatus.equalsIgnoreCase("Open")) {
						if (new1I.getPrice().equalsIgnoreCase("ATC")
								|| new1I.getPrice().equalsIgnoreCase("MP")
								|| new1I.getPrice().equalsIgnoreCase("ATO")) {
							controller
									.log("Chuong trinh chan. Can't send order: "
											+ new1I.toString());
							continue;
						}
					} else if (marketStatus.equalsIgnoreCase("PreClose")) {
						if (new1I.getPrice().equalsIgnoreCase("MP")
								|| new1I.getPrice().equalsIgnoreCase("ATO")) {
							controller
									.log("Chuong trinh chan. Can't send order: "
											+ new1I.toString());
							continue;
						}
					} else if (marketStatus.equalsIgnoreCase("Close")) {
						// Can't send ATO,ATC,MP,LO trong Close
						controller.log("Chuong trinh chan. Can't send order: "
								+ new1I.toString());
						continue;
					}
				}
				controller.sendMessageToQueue(object);
			}
		} catch (Exception e1) {
			e1.printStackTrace();
		}
	}













	public static void showMessageAndExit(final String message) {
		Runnable doWorkRunnable = new Runnable() {
			public void run() {
				JOptionPane
						.showMessageDialog(MainFrameOld2.getFrames()[0], message);
				System.exit(0);
			}
		};
		SwingUtilities.invokeLater(doWorkRunnable);
	}

} // @jve:decl-index=0:visual-constraint="2,6"
