package eps.com.message.received;

import java.io.Serializable;
import java.sql.Date;

import eps.com.common.ValueObject;

public class PutThroughAcknowledgment_2F extends ValueObject implements
		Serializable {

	private static final long serialVersionUID = 1L;

	public static final String MessageType = "2F";

	private String FirmBuy;
	private String TraderIDBuy;
	private String SideB;
	private String ContraFirmSell;
	private String TraderIDContraSideSell;
	private String SecuritySymbol;
	private String Volume;
	private String Price;
	private String Board;
	private String ConfirmNumber;

	public PutThroughAcknowledgment_2F() {
	}

	public String getFirmBuy() {
		return FirmBuy;
	}

	public void setFirmBuy(String firmBuy) {
		FirmBuy = firmBuy;
	}

	public String getTraderIDBuy() {
		return TraderIDBuy;
	}

	public void setTraderIDBuy(String traderIDBuy) {
		TraderIDBuy = traderIDBuy;
	}

	public String getSideB() {
		return SideB;
	}

	public void setSideB(String sideB) {
		SideB = sideB;
	}

	public String getContraFirmSell() {
		return ContraFirmSell;
	}

	public void setContraFirmSell(String contraFirmSell) {
		ContraFirmSell = contraFirmSell;
	}

	public String getTraderIDContraSideSell() {
		return TraderIDContraSideSell;
	}

	public void setTraderIDContraSideSell(String traderIDContraSideSell) {
		TraderIDContraSideSell = traderIDContraSideSell;
	}

	public String getSecuritySymbol() {
		return SecuritySymbol;
	}

	public void setSecuritySymbol(String securitySymbol) {
		SecuritySymbol = securitySymbol;
	}

	public String getVolume() {
		return Volume;
	}

	public void setVolume(String volume) {
		Volume = volume;
	}

	public String getPrice() {
		return Price;
	}

	public void setPrice(String price) {
		Price = price;
	}

	public String getBoard() {
		return Board;
	}

	public void setBoard(String board) {
		Board = board;
	}

	public String getConfirmNumber() {
		return ConfirmNumber;
	}

	public void setConfirmNumber(String confirmNumber) {
		ConfirmNumber = confirmNumber;
	}

}
