package eps.com.client.proposal;

import java.util.Vector;

import eps.com.common.HosePacket;
import eps.com.common.ValueObject;

public class ReceiveMessageQueue {
	private Vector<HosePacket> messages = new Vector();

	// Called by Main Thread
	public synchronized void putMessage(HosePacket object) {
		messages.addElement(object);
		notifyAll();
	}

	// Called by Main Thread
	public synchronized void putMessageinFirst(HosePacket object) {
		messages.add(0,object);
		notifyAll();
	}
	
	// Called by ReceivePacketComsumer
	public synchronized ValueObject getMessage() throws InterruptedException {
		while (messages.size() == 0)
			wait();
		HosePacket packet = (HosePacket)messages.remove(0);
		ValueObject message = packet.getDataMessage();
		System.out.println("receive queue size:" + messages.size());
		return message;
	}

	public long getMessageSize() {
		return messages.size();
	}

}
