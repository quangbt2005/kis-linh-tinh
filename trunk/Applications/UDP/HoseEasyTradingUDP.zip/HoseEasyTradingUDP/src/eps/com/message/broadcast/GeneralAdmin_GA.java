package eps.com.message.broadcast;

import java.io.Serializable;

import eps.com.common.ValueObject;

public class GeneralAdmin_GA extends ValueObject implements Serializable{
	
	public static final String MessageType="GA";
	
	private long  adminMessageLength;
	private String adminMessageText;
	
	public GeneralAdmin_GA()
	{
		
	}
	public static String getMessageType() {
		return MessageType;
	}
	
	public String getAdminMessageText() {
		return adminMessageText;
	}
	public void setAdminMessageText(String AdminMessageText) {
		this.adminMessageText = AdminMessageText;
	}
	
	public long getAdminMessageLength() {
		return adminMessageLength;
	}
	public void setAdminMessageLength(long AdminMessageLength) {
		this.adminMessageLength = AdminMessageLength;		
	}
}
