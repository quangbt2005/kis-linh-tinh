package eps.com.message.sended;

/**
 * Lớp này minh h�?a cho cấu trúc của message 1D-Order Change.
 * 
 * @author lequocthai
 */
import java.io.Serializable;

import eps.com.common.ValueObject;

public class Advertisement_1E extends ValueObject implements Serializable {

	private static final long serialVersionUID = 1L;

	/**
	 * Thuộc tính Message_Type có kích thước là 2 bytes, được sử dụng để xác
	 * định kiểu của message trong hệ thống. Hiện tại nó có giá trị mặc định là
	 * 1E (Lưu ý: Phải đ�?c từ tập tin messageconfg.xml).
	 */
	public static final String MessageType = "1E";
	/**
	 * Thuộc tính Firm có kích thước là 3 bytes, được sử dụng để nhận dạng việc
	 * gửi và nhận từ CTCK nào. Do TTGDCK cung cấp. Các giá thuộc phạm vi sau: +
	 * 1 <= n <= 9215 <nếu 2 bytes thì Mod96> + 1 <= n <= 999 <nếu 3 bytes thì
	 * numeric String>
	 */
	private String Firm;
	/**
	 * Thuộc tính Trader_ID có kích thước 4 bytes là một dãy bao gồm chữ và số.
	 * �?ược sử dụng để xác định một ngư�?i dùng cụ thể.
	 */
	private String TraderID;

	/**
	 * Thuộc tính Security_Symbol có kích thước 84 byte, bao gồm chữ và số.
	 */
	private String SecuritySymbol;

	/**
	 * Thuộc tính Side có kích thước 1 byte, có kiểu là alpha. Bao gồm một trong
	 * ba giá trị sau: "X" : Firm is both buyer và seller (2L) "B" : Buy "S" :
	 * Sell
	 */
	private String Side;

	/**
	 * 
	 */
	private String Volume;
	private String Price;
	private String Board;
	private String Time;
	private String AddCancelFlag;
	private String Contact;

	public Advertisement_1E() {
	}

	public String getFirm() {
		return Firm;
	}

	public void setFirm(String firm) {
		Firm = firm;
	}

	public String getTraderID() {
		return TraderID;
	}

	public void setTraderID(String traderID) {
		TraderID = traderID;
	}

	public String getSecuritySymbol() {
		return SecuritySymbol;
	}

	public void setSecuritySymbol(String securitySymbol) {
		SecuritySymbol = securitySymbol;
	}

	public String getSide() {
		return Side;
	}

	public void setSide(String side) {
		Side = side;
	}

	public String getVolume() {
		return Volume;
	}

	public void setVolume(String volume) {
		Volume = volume;
	}

	public String getPrice() {
		return Price;
	}

	public void setPrice(String price) {
		Price = price;
	}

	public String getBoard() {
		return Board;
	}

	public void setBoard(String board) {
		Board = board;
	}

	public String getTime() {
		return Time;
	}

	public void setTime(String time) {
		Time = time;
	}

	public String getAddCancelFlag() {
		return AddCancelFlag;
	}

	public void setAddCancelFlag(String addCancelFlag) {
		AddCancelFlag = addCancelFlag;
	}

	public String getContact() {
		return Contact;
	}

	public void setContact(String contact) {
		Contact = contact;
	}

}
