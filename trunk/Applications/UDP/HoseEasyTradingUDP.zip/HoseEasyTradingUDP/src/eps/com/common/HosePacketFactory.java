package eps.com.common;

public class HosePacketFactory {
	private static HosePacketFactory instance = null;
	private HosePacketFactory(){
		
	}
	public static HosePacketFactory getInstance() {
		if (instance == null)
			instance = new HosePacketFactory();
		return instance;
	}
	public HosePacket createPacket(int seq,int ackseq,byte[] opcode,int linkID,byte[] content){
		return null;
	}

	
	public HosePacket createPacket(String opcode,byte[] content){
		return null;
	}

	public HosePacket createPacket(String opcode,ValueObject object){
		return null;
	}
	
	

}
