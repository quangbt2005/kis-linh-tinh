
package eps.com.test.xml;

import java.io.*;
import org.xml.sax.EntityResolver;
import org.xml.sax.InputSource;

/** 
 * Overrides DTD resolving since both Crimson and Xerces cannot seem to 
 * handle local systemId very well.
 * 
 * Perhaps this could even offer DTD caching???

 */
public class DTDResolver implements EntityResolver {
    protected String repositoryBase;
    
    public DTDResolver(String repositoryBase){
        this.repositoryBase = repositoryBase;
    }
    
    public InputSource resolveEntity(String publicId, String systemId) {
        
        if (systemId.toLowerCase().endsWith(".dtd")) {
            int idx = Math.max(0, systemId.lastIndexOf('/'));
            systemId = systemId.substring(idx+1);
            
            FileInputStream in = null;
            try {
                in = new FileInputStream(repositoryBase + systemId);
            } catch (IOException e) {
                System.err.println("Could not find " + repositoryBase + systemId);
                return null;
            }
            return new InputSource(in);
        } else {
            // use the default behaviour
            return null;
        }
    }
}
