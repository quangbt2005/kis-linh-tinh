package eps.com.client.upd;

import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;

import eps.com.client.proposal.ReceiveMessageQueue;
import eps.com.common.ValueObject;
import eps.com.message.broadcast.BroadcastMessageService;
import eps.com.message.broadcast.GeneralAdmin_GA;
import eps.com.message.broadcast.SystemControl_SC;
import eps.com.message.broadcast.TimeStamp_TS;
import eps.com.test.MainFrame;
import eps.com.util.MessageUtil;

public class UPDReceivePacketConsumer extends Thread {
	private boolean isStop = false;
	private ReceiveUDPMessageQueue receiveQueue;
	private BroadcastMessageService updService = new BroadcastMessageService();
	private static UdpLog log;

	public UPDReceivePacketConsumer(ReceiveUDPMessageQueue receiveQueue) {
		this.receiveQueue = receiveQueue;
	}

	public void setStop(boolean bool) {
		isStop = bool;
	}

	@Override
	public void run() {
		while (!isStop) {
			try {
				byte msgdata[] = this.receiveQueue.getMessage();
				ValueObject object = (ValueObject) MessageUtil
						.bytes2Message(msgdata);
				log = UDPContent.getLog();
				if (object != null) {
					// log.printAndSave(object.toString());
					log.saveLog(object.toString());
					if (object instanceof GeneralAdmin_GA) { // 5
						final GeneralAdmin_GA msgGA = (GeneralAdmin_GA) object;
						log.printAndSave("--------------");
						log.printAndSave(msgGA.getAdminMessageText());
						log.printAndSave("--------------");
						Runnable doWorkRunnable = new Runnable() {
							String message = msgGA.getAdminMessageText();

							public void run() {
								JOptionPane.showMessageDialog(MainFrame
										.getFrames()[0], message);
							}
						};
						SwingUtilities.invokeLater(doWorkRunnable);
					} else if (object instanceof SystemControl_SC) {
						final SystemControl_SC msgSC = (SystemControl_SC) object;
						// bat dau doc lenh
						String controlCode = msgSC.getSystem_Control_Code()
								.trim();
						if (controlCode.equalsIgnoreCase("P")) {
							try {
								log
										.printAndSave("--------------ReOpen Session");
								// EPSServiceController.getInstance().startReadingOrders();
							} catch (Exception e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
							// dong connect voi HOSE
						}
						if (controlCode.equalsIgnoreCase("O")) {
							try {
								log.printAndSave("--------------Open Session");
								// EPSServiceController.getInstance().startReadingOrders();
							} catch (Exception e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
							// dong connect voi HOSE
						} else if (controlCode.equalsIgnoreCase("A")) {
							try {
								log
										.printAndSave("--------------ReClose Session");
								// EPSServiceController.getInstance().startReadingOrders();
							} catch (Exception e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
							// dong connect voi HOSE
						} else if (controlCode.equalsIgnoreCase("Z")) {
							try {
								// EPSServiceController.getInstance().disconnectFromClient();
							} catch (Exception e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
						} else if (controlCode.equalsIgnoreCase("C")) {
							try {
								log
										.printAndSave("--------------Market Close Session");
								// EPSServiceController.getInstance().startReadingOrders();
							} catch (Exception e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
							// dong connect voi HOSE
						}
						Runnable doWorkRunnable = new Runnable() {
							final String message = "SC flag:"
									+ msgSC.getSystem_Control_Code();

							public void run() {
								JOptionPane.showMessageDialog(MainFrame
										.getFrames()[0], message);
							}
						};
						SwingUtilities.invokeLater(doWorkRunnable);
					} else if (object instanceof TimeStamp_TS) {
						//System.out.println("Queue size:" + this.receiveQueue.getMessageSize());
					}
					//long start = System.currentTimeMillis(); // start timing
					this.updService.processMessage(object);
					//long stop = System.currentTimeMillis(); // stop timing
					//log.printAndSave("Cap nhat xong. TimeMillis: " 	+ (stop - start));
				} else { // object is null
					log.printConsole("Object receive is null????");
				}
				Thread.sleep(50);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
}
