package eps.com.common;

import java.io.Serializable;

import eps.com.client.proposal.EPSServiceController;
import eps.com.client.upd.Common;
import eps.com.message.received.RetransmissionReply_RP;
import eps.com.message.sended.RetransmissionRequest_RQ;
import eps.com.test.TestCommon;
import eps.com.util.MessageUtil;

public class HosePacket implements Serializable {
	public static int TOTAL_HEADER_LENGH = 15;
	// total byte = 15 + n
	protected byte[] len; // 2 byte
	protected byte[] seq; // 4 byte
	protected byte[] ackseq; // 4 byte
	protected byte[] opcode; // 2 byte
	protected byte[] linkID; // 2 byte
	protected byte[] content; // n byte
	protected byte extendt = 3; // 1 byte
	protected byte[] auto_tPMessageFormat;

	public byte[] getAutotPMessage() throws Exception {
		// int length = TOTAL_HEADER_LENGH + content.length;
		if (auto_tPMessageFormat != null) {
			return this.auto_tPMessageFormat;
		}
		return null;
	}

	public HosePacket() {

	}

	// System message
	public HosePacket(byte[] arg) {
		int l = arg.length;
		len = new byte[2];
		seq = new byte[4];
		ackseq = new byte[4];
		opcode = new byte[2];
		linkID = new byte[2];
		// Tuan: them vao de test content is null
		if (l > TOTAL_HEADER_LENGH)
			content = new byte[l - TOTAL_HEADER_LENGH];
		else
			content = new byte[] {};

		System.arraycopy(arg, 0, len, 0, 2);
		System.arraycopy(arg, 2, seq, 0, 4);
		System.arraycopy(arg, 6, ackseq, 0, 4);
		System.arraycopy(arg, 10, opcode, 0, 2);
		System.arraycopy(arg, 12, linkID, 0, 2);
		if (l > TOTAL_HEADER_LENGH)
			System.arraycopy(arg, 14, content, 0, l - TOTAL_HEADER_LENGH);
		// this.auto_tPMessageFormat = new byte[l];
		// System.arraycopy(arg, 0, this.auto_tPMessageFormat, 0, l-
		// TOTAL_HEADER_LENGH);
		auto_tPMessageFormat = arg;
	}

	/**
	 * create general packet based on opcode
	 * 
	 * @param seq
	 * @param ackseq
	 * @param opcode
	 * @param linkID
	 * @param content
	 */
	// System message
	public HosePacket(long seq, long ackseq, byte[] opcode, long linkID,
			byte[] content) {
		this.opcode = new byte[2];

		int n = content.length;
		int packetLengh = TOTAL_HEADER_LENGH + n;
		auto_tPMessageFormat = new byte[packetLengh];
		this.len = Common.EnMod96(packetLengh - 2, 2);
		auto_tPMessageFormat[0] = this.len[0];
		auto_tPMessageFormat[1] = this.len[1];
		// seq 4 byte
		this.seq = Common.EnMod96(seq, 4);
		auto_tPMessageFormat[2] = this.seq[0];
		auto_tPMessageFormat[3] = this.seq[1];
		auto_tPMessageFormat[4] = this.seq[2];
		auto_tPMessageFormat[5] = this.seq[3];
		// ackseq 4
		this.ackseq = Common.EnMod96(ackseq, 4);
		auto_tPMessageFormat[6] = this.ackseq[0];
		auto_tPMessageFormat[7] = this.ackseq[1];
		auto_tPMessageFormat[8] = this.ackseq[2];
		auto_tPMessageFormat[9] = this.ackseq[3];
		// opcode
		this.opcode[0] = opcode[0];
		this.opcode[1] = opcode[1];
		auto_tPMessageFormat[10] = opcode[0];
		auto_tPMessageFormat[11] = opcode[1];
		// LinkID 57
		this.linkID = Common.EnMod96(linkID, 2);
		auto_tPMessageFormat[12] = this.linkID[0];
		auto_tPMessageFormat[13] = this.linkID[1];
		// CONTENT
		if (n > 0)
			System.arraycopy(content, 0, auto_tPMessageFormat, 14, n);
		// etx
		auto_tPMessageFormat[packetLengh - 1] = 3;
	}

	// get DataMessage co the la DT or RP
	public ValueObject getDataMessage() {
		ValueObject message = null;
		if (Common.compare2byteArray(this.opcode, Opcode.DT)
				|| Common.compare2byteArray(this.opcode, Opcode.LO)
				|| Common.compare2byteArray(this.opcode, Opcode.LL)) {
			String content = new String(this.content);
			// ARP OA }4!TP&ZB...
			if (content.indexOf("RP") == 1) {
				message = MessageUtil.bytesRRorRQ2Message(this.content);
			} else {
				message = MessageUtil.bytesDT2Message(this.content);
			}
		} else if (Common.compare2byteArray(this.opcode, Opcode.RP))
			message = MessageUtil.bytesRRorRQ2Message(this.content);
		return message;
	}

	/**
	 * create Data package with OpCode = DT & RP/ RR
	 * 
	 * @param seq
	 * @param ackseq
	 * @param linkID
	 * @param object
	 */
	public HosePacket(long seq, long ackseq, int linkID, ValueObject object)
			throws Exception {
		this.opcode = new byte[2];
		byte topCode[] = new byte[2];
		byte tContent[] = null;
		int n = 0;

		boolean isDT = false;
		// extra =1 danh cho RP
		// extra =2 danh cho DT
		int extraByte = 1;
		if (object instanceof RetransmissionRequest_RQ) {
			topCode[0] = 'R';
			topCode[1] = 'R';
			isDT = false;
			extraByte = 1;
			tContent = MessageUtil.message2Bytes(object);

		} else if (object instanceof RetransmissionReply_RP) {
			topCode[0] = 'R';
			topCode[1] = 'P';
			isDT = false;
			extraByte = 1;
			tContent = MessageUtil.message2Bytes(object);

		} else {
			// DATA packet
			topCode[0] = 'D';
			topCode[1] = 'T';
			tContent = MessageUtil.message2Bytes(object);
			isDT = true;
			extraByte = 2;

		}

		if (tContent != null) {
			// throw new Exception("Message is invalid");
			n = tContent.length + extraByte; // cong extra byte cho market_ID or
			// messageCount
		}

		content = tContent;

		int packetLengh = TOTAL_HEADER_LENGH + n;
		auto_tPMessageFormat = new byte[packetLengh];
		this.len = Common.EnMod96(packetLengh - 2, 2);
		auto_tPMessageFormat[0] = this.len[0];
		auto_tPMessageFormat[1] = this.len[1];
		// seq 4 byte
		this.seq = Common.EnMod96(seq, 4);
		auto_tPMessageFormat[2] = this.seq[0];
		auto_tPMessageFormat[3] = this.seq[1];
		auto_tPMessageFormat[4] = this.seq[2];
		auto_tPMessageFormat[5] = this.seq[3];
		// ackseq 4
		this.ackseq = Common.EnMod96(ackseq, 4);
		auto_tPMessageFormat[6] = this.ackseq[0];
		auto_tPMessageFormat[7] = this.ackseq[1];
		auto_tPMessageFormat[8] = this.ackseq[2];
		auto_tPMessageFormat[9] = this.ackseq[3];
		// opcode
		this.opcode[0] = topCode[0];
		this.opcode[1] = topCode[1];
		auto_tPMessageFormat[10] = opcode[0];
		auto_tPMessageFormat[11] = opcode[1];
		// LinkID 57
		this.linkID = Common.EnMod96(linkID, 2);
		auto_tPMessageFormat[12] = this.linkID[0];
		auto_tPMessageFormat[13] = this.linkID[1];

		auto_tPMessageFormat[14] = EPSServiceController._marketId[0];
		if (isDT) {
			auto_tPMessageFormat[15] = Common.EnMod96(1, 1)[0];
			if (n > 0)
				System.arraycopy(tContent, 0, auto_tPMessageFormat, 16, n
						- extraByte);
		} else {
			if (n > 0)
				System.arraycopy(tContent, 0, auto_tPMessageFormat, 15, n
						- extraByte);
		}
		auto_tPMessageFormat[packetLengh - 1] = 3;
	}

	/**
	 * create Data package with OpCode = DT or RR dung tong quat khi can phai
	 * truyen vo marketID
	 * 
	 * @param seq
	 * @param ackseq
	 * @param linkID
	 * @param object
	 */
	public HosePacket(long seq, long ackseq, byte[] opcode, int linkID,
			char marketID, ValueObject object) throws Exception {
		this.opcode = new byte[2];
		boolean isDT = false;
		// extra =1 danh cho RP
		// extra =2 danh cho DT
		int extraByte = 1;
		if (Common.compare2byteArray(opcode, Opcode.DT)) {
			isDT = true;
			extraByte = 2;
		} else if (Common.compare2byteArray(opcode, Opcode.RR)
				|| Common.compare2byteArray(opcode, Opcode.RP)) {
			isDT = false;
			extraByte = 1;
		} else {
			throw new Exception("Invalid Opcode with your contructor");
		}
		byte tContent[] = MessageUtil.message2Bytes(object);
		int n = 0;
		if (tContent != null) {
			n = tContent.length + extraByte;
		}

		content = tContent;

		int packetLengh = TOTAL_HEADER_LENGH + n;
		auto_tPMessageFormat = new byte[packetLengh];
		this.len = Common.EnMod96(packetLengh - 2, 2);
		auto_tPMessageFormat[0] = this.len[0];
		auto_tPMessageFormat[1] = this.len[1];
		// seq 4 byte
		this.seq = Common.EnMod96(seq, 4);
		auto_tPMessageFormat[2] = this.seq[0];
		auto_tPMessageFormat[3] = this.seq[1];
		auto_tPMessageFormat[4] = this.seq[2];
		auto_tPMessageFormat[5] = this.seq[3];
		// ackseq 4
		this.ackseq = Common.EnMod96(ackseq, 4);
		auto_tPMessageFormat[6] = this.ackseq[0];
		auto_tPMessageFormat[7] = this.ackseq[1];
		auto_tPMessageFormat[8] = this.ackseq[2];
		auto_tPMessageFormat[9] = this.ackseq[3];
		// opcode
		this.opcode[0] = opcode[0];
		this.opcode[1] = opcode[1];
		auto_tPMessageFormat[10] = opcode[0];
		auto_tPMessageFormat[11] = opcode[1];
		// LinkID 57
		this.linkID = Common.EnMod96(linkID, 2);
		auto_tPMessageFormat[12] = this.linkID[0];
		auto_tPMessageFormat[13] = this.linkID[1];

		auto_tPMessageFormat[14] = (byte) marketID;
		if (isDT) {
			auto_tPMessageFormat[15] = Common.EnMod96(1, 1)[0];
			if (n > 0)
				System.arraycopy(tContent, 0, auto_tPMessageFormat, 16, n
						- extraByte);
		} else {
			if (n > 0)
				System.arraycopy(tContent, 0, auto_tPMessageFormat, 15, n
						- extraByte);
		}
		auto_tPMessageFormat[packetLengh - 1] = 3;
	}

	// len
	public long get_lenVal() {
		return Common.DecodeMod96(len);
	}

	public byte[] get_len() {
		return len;
	}

	// seq
	public long get_seqVal() {
		return Common.DecodeMod96(seq);
	}

	public byte[] get_seq() {
		return seq;
	}

	// ackseq
	public long get_ackseqVal() {
		return Common.DecodeMod96(ackseq);
	}

	public byte[] get_ackseq() {
		return ackseq;
	}

	// opcode
	public byte[] get_opcode() {
		return opcode;
	}

	// link id
	public long get_linkidVal() {
		return Common.DecodeMod96(linkID);
	}

	// public byte[] get_linkid() {
	// return linkID;
	// }

	// end of package signal
	public byte getExtendt() {
		return extendt;
	}

	// content
	public byte[] getContent() {
		return content;
	}

	/**
	 * convert packet to bytes before sending make sure that seq/ackseq .. must
	 * have Mod96 format before
	 * 
	 * @param seq
	 * @param ackseq
	 * @param opcode
	 * @param linkID
	 * @param content
	 * @return
	 */
	public byte[] packetToBytes() {
		int len = TOTAL_HEADER_LENGH + content.length;
		byte[] bytes = new byte[len];
		System.arraycopy(len, 0, bytes, 0, 2);
		System.arraycopy(seq, 2, bytes, 0, 4);
		System.arraycopy(ackseq, 6, bytes, 0, 4);
		System.arraycopy(opcode, 10, bytes, 0, 2);
		System.arraycopy(linkID, 12, bytes, 0, 2);
		// CONTENT
		int n = content.length;
		if (n > 0)
			System.arraycopy(content, 0, bytes, 14, n);
		// etx
		bytes[len - 1] = 3;
		return bytes;
	}

	/**
	 * return packet content
	 */
	public String toString() {
		String s = TestCommon.getHosePacketFormatString("len="
				+ Common.DecodeMod96(len), "seq=" + Common.DecodeMod96(seq),
				"ackseq=" + Common.DecodeMod96(ackseq), "opcode="
						+ new String(opcode), "linkid="
						+ Common.DecodeMod96(linkID), "contentLen="
						+ content.length, "content=" + new String(content));

		// String s = "len= " + Common.DecodeMod96(len) + "  seq="
		// + Common.DecodeMod96(seq) + "  ackseq="
		// + Common.DecodeMod96(ackseq) + "  opcode=" + new String(opcode)
		// + "  linkid=" + Common.DecodeMod96(linkID) + "  contentLen="
		// + content.length + "  content=" + new String(content);
		return s;
	}

	// String
	public static String getString(byte[] arg) {
		if (arg == null)
			return "";
		String s = "";
		int l = arg.length;
		byte[] tlen = new byte[2];
		byte[] tseq = new byte[4];
		byte[] tackseq = new byte[4];
		byte[] topcode = new byte[2];
		byte[] tlinkID = new byte[2];
		byte[] tcontent = new byte[l - 15];
		System.arraycopy(arg, 0, tlen, 0, 2);
		System.arraycopy(arg, 2, tseq, 0, 4);
		System.arraycopy(arg, 6, tackseq, 0, 4);
		System.arraycopy(arg, 10, topcode, 0, 2);
		System.arraycopy(arg, 12, tlinkID, 0, 2);
		System.arraycopy(arg, 14, tcontent, 0, l - 15);

		s = TestCommon.getHosePacketFormatString("len="
				+ Common.DecodeMod96(tlen), "seq=" + Common.DecodeMod96(tseq),
				"ackseq=" + Common.DecodeMod96(tackseq), "opcode="
						+ new String(topcode), "linkid="
						+ Common.DecodeMod96(tlinkID), "contentLen="
						+ tcontent.length, "content=" + new String(tcontent));
		// s = "len=" + Common.DecodeMod96(tlen) + "  seq="
		// + Common.DecodeMod96(tseq) + "  ackseq="
		// + Common.DecodeMod96(tackseq) + "  opcode="
		// + new String(topcode) + "  linkid="
		// + Common.DecodeMod96(tlinkID) + "  contentLen="
		// + tcontent.length + "  content=" + new String(tcontent);
		return s;
	}

	// Only use to generate invalid packet, Communication Test
	public HosePacket(long seq, long ackseq, long linkID, ValueObject object,
			String wrongType) throws Exception {
		this.opcode = new byte[2];
		byte tContent[] = MessageUtil.message2Bytes(object);
		int n = 0;
		if (tContent != null) {
			// throw new Exception("Message is invalid");
			n = tContent.length + 2; // cong 2 byte cho market_ID & messageCount
		}

		int packetLengh = TOTAL_HEADER_LENGH + n;
		auto_tPMessageFormat = new byte[packetLengh];
		if (wrongType.equals("Length")) {
			this.len = Common.EnMod96(packetLengh - 5, 2);
		} else {
			this.len = Common.EnMod96(packetLengh - 2, 2);
		}
		auto_tPMessageFormat[0] = this.len[0];
		auto_tPMessageFormat[1] = this.len[1];
		// seq 4 byte
		this.seq = Common.EnMod96(seq, 4);
		auto_tPMessageFormat[2] = this.seq[0];
		auto_tPMessageFormat[3] = this.seq[1];
		auto_tPMessageFormat[4] = this.seq[2];
		auto_tPMessageFormat[5] = this.seq[3];
		// ackseq 4
		this.ackseq = Common.EnMod96(ackseq, 4);
		auto_tPMessageFormat[6] = this.ackseq[0];
		auto_tPMessageFormat[7] = this.ackseq[1];
		auto_tPMessageFormat[8] = this.ackseq[2];
		auto_tPMessageFormat[9] = this.ackseq[3];
		// opcode
		this.opcode[0] = Opcode.DT[0];
		this.opcode[1] = Opcode.DT[1];
		auto_tPMessageFormat[10] = opcode[0];
		auto_tPMessageFormat[11] = opcode[1];
		// LinkID 57
		this.linkID = Common.EnMod96(linkID, 2);
		auto_tPMessageFormat[12] = this.linkID[0];
		auto_tPMessageFormat[13] = this.linkID[1];

		if (wrongType.equals("ContentNULL")) {
			auto_tPMessageFormat[14] = 3;
		} else if (wrongType.equals("Length")) {
			auto_tPMessageFormat[14] = EPSServiceController._marketId[0];
			auto_tPMessageFormat[15] = Common.EnMod96(1, 1)[0];
			// CONTENT
			if (n > 0)
				System.arraycopy(tContent, 0, auto_tPMessageFormat, 16, n - 2);
			// etx
			auto_tPMessageFormat[packetLengh - 1] = 3;
		} else if (wrongType.equals("MarketIdB")) {
			auto_tPMessageFormat[14] = (byte) 'B';
			auto_tPMessageFormat[15] = Common.EnMod96(1, 1)[0];
			// CONTENT
			if (n > 0)
				System.arraycopy(tContent, 0, auto_tPMessageFormat, 16, n - 2);
			// etx
			auto_tPMessageFormat[packetLengh - 1] = 3;
		}
	}

	public byte[] getOpcode() {
		return opcode;
	}

	public void setOpcode(byte[] opcode) {
		this.opcode = opcode;
		if (auto_tPMessageFormat != null) {
			auto_tPMessageFormat[10] = opcode[0];
			auto_tPMessageFormat[11] = opcode[1];
		}
	}

	public byte[] getSeq() {
		return seq;
	}

	public void setSeq(byte[] seq) {
		this.seq = seq;
	}

	public byte[] getAckseq() {
		return ackseq;
	}

	public void setAckseq(byte[] ackseq) {
		this.ackseq = ackseq;
	}

	public byte[] getLinkID() {
		return linkID;
	}

	public void setLinkID(byte[] linkID) {
		this.linkID = linkID;
	}

	public void setContent(byte[] content) {
		this.content = content;
	}
}
