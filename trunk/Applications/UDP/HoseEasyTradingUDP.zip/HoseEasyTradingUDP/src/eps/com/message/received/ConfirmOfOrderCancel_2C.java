package eps.com.message.received;

import java.io.Serializable;
import java.sql.Date;

import eps.com.common.ValueObject;

public class ConfirmOfOrderCancel_2C extends ValueObject implements
		Serializable {

	private static final long serialVersionUID = 1L;

	public static final String MessageType = "2C";

	private String Firm;
	private String CancelShares;
	private String OrderNumber;
	private String OrderEntryDate;
	private String OrderCancelStatus;

	public ConfirmOfOrderCancel_2C() {
	}

	public String getFirm() {
		return Firm;
	}

	public void setFirm(String firm) {
		Firm = firm;
	}

	public String getCancelShares() {
		return CancelShares;
	}

	public void setCancelShares(String cancelShares) {
		CancelShares = cancelShares;
	}

	public String getOrderNumber() {
		return OrderNumber;
	}

	public void setOrderNumber(String orderNumber) {
		OrderNumber = orderNumber;
	}

	public String getOrderEntryDate() {
		return OrderEntryDate;
	}

	public void setOrderEntryDate(String orderEntryDate) {
		OrderEntryDate = orderEntryDate;
	}

	public String getOrderCancelStatus() {
		return OrderCancelStatus;
	}

	public void setOrderCancelStatus(String orderCancelStatus) {
		OrderCancelStatus = orderCancelStatus;
	}

}
