package eps.com.test;

import javax.swing.border.EtchedBorder;
import javax.swing.border.Border;
import javax.swing.JPanel;
import javax.swing.JFrame;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Rectangle;
import java.awt.SystemColor;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JComboBox;
import javax.swing.JRadioButton;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;
import javax.swing.SwingUtilities;

import java.awt.event.KeyEvent;
import eps.com.client.proposal.EPSServiceController;
import eps.com.client.proposal.SocketStatusDetector;
import eps.com.client.upd.UDPClient;
import eps.com.client.upd.UDPContent;
import eps.com.common.HosePacket;
import eps.com.common.HoseSystemPacket;
import eps.com.common.Opcode;
import eps.com.common.ValueObject;
import eps.com.message.sended.Advertisement_1E;
import eps.com.message.sended.DealCancelReply_3D;
import eps.com.message.sended.DealPutThroughCancelRequest_3C;
import eps.com.message.sended.NewConditioned_1I;
import eps.com.message.sended.OrderCancellation_1C;
import eps.com.message.sended.OrderChange_1D;
import eps.com.message.sended.OneFirmPutThroughDeal_1F;
import eps.com.message.sended.PutThroughDealReply_3B;
import eps.com.message.sended.RetransmissionRequest_RQ;
import eps.com.message.sended.TwoFirmPutThroughDeal_1G;
import eps.com.util.MessageUtil;
import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;

import eps.com.message.received.PutThroughAcknowledgment_2F;
import eps.com.message.received.PutThroughDealConfirmation_2L;
import eps.com.message.received.RetransmissionReply_RP;
import java.awt.Font;
import java.awt.Insets;
import java.util.Iterator;
import java.util.List;

public class MainFrame extends JFrame {
	private JLabel jLabel6_1;
	private JTextField txtNoThreads;
	private ButtonGroup buttonGroup = new ButtonGroup();
	private String opCode[] = { "HL", "HR", "CF", "DT", "LO", "LL", "RR", "RP",
			"AK", "NK", "FN", "AF", "EC", "ER" }; // @jve:decl-index=0:
	private static final long serialVersionUID = 1L;
	private EPSServiceController controller;
	private UDPClient udpClient;
	private JPanel jContentPane = null;

	private JPanel jPanel = null;

	private JLabel jLabel = null;

	private JLabel jLabel1 = null;

	private JLabel jLabel2 = null;

	private JLabel jLabel4 = null;
	Border border1 = BorderFactory.createEtchedBorder(EtchedBorder.RAISED,
			Color.white, new Color(165, 163, 151)); // @jve:decl-index=0:

	private JTextField txtFirmID = null;
	private JTextField txtServerPort = null;
	private JTextField txtServerIP = null;
	private JTextField txtUDPPort = null;
	private JPasswordField txtPassword = null;
	private JLabel jLabel6 = null;
	private JRadioButton modeA = null;
	private JRadioButton modeB = null;
	private JRadioButton modeC = null;
	private JButton btConnect = null;
	private JButton btDisconnect = null;
	private JButton startUdpListenButton = null;
	private JButton btStopUDP = null;
	public static ConformanceFrame conFrame;
	private static SocketStatusDetector detector;

	public static void startSocketDetector() {
		detector = new SocketStatusDetector();
		detector.setFlag(false);
		detector.setPriority(3);
		detector.start();
	}

	public static void stopSocketDetector() {
		detector.setFlag(true);
		detector.interrupt();
	}

	/**
	 * This is the default constructor
	 */
	public MainFrame() {
		super();
		getContentPane().setName("contentPane");
		initialize();
	}

	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
		// jContentPane = (JPanel)this.getContentPane();
		this.getContentPane().setLayout(null);
		this.getContentPane().setBackground(SystemColor.control);
		// this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.setResizable(false);
		setSize(new Dimension(640, 150));
		this.getContentPane().add(getJPanel(), null);
		this.setTitle("Test Center");

		this.setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
		this.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				// System.out.println("ExitExit");

				// Neu dang trong threadSendMessage thi ko dong
				if (controller != null)
					if (!controller.threadSendMessageFinished)
						return;

				System.exit(0);
			}
		});
	}

	/**
	 * This method initializes jContentPane
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getJContentPane() {
		if (jContentPane == null) {
			jContentPane = new JPanel();
			jContentPane.setActionMap(null);
			jContentPane.setMinimumSize(new Dimension(800, 600));
			jContentPane.setLayout(null);
			jContentPane.add(getJPanel());
		}
		return jContentPane;
	}

	/**
	 * This method initializes jPanel
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getJPanel() {
		if (jPanel == null) {
			jLabel6 = new JLabel();
			jLabel6.setBounds(new Rectangle(329, 4, 66, 23));
			jLabel6.setFont(new Font("Dialog", Font.BOLD, 10));
			jLabel6.setText("UPD Port:");
			jLabel4 = new JLabel();
			jLabel4.setBounds(new Rectangle(138, 61, 70, 23));
			jLabel4.setFont(new Font("Dialog", Font.BOLD, 10));
			jLabel4.setText("Password:");
			jLabel2 = new JLabel();
			jLabel2.setBounds(new Rectangle(6, 60, 74, 23));
			jLabel2.setFont(new Font("Dialog", Font.BOLD, 10));
			jLabel2.setText("Firm ID:");
			jLabel1 = new JLabel();
			jLabel1.setBounds(new Rectangle(6, 33, 76, 23));
			jLabel1.setFont(new Font("Dialog", Font.BOLD, 10));
			jLabel1.setText("Server Port:");
			jLabel = new JLabel();
			jLabel.setBounds(new Rectangle(6, 7, 74, 23));
			jLabel.setFont(new Font("Dialog", Font.BOLD, 10));
			jLabel.setText("Server IP:");
			jPanel = new JPanel();
			jPanel.setLayout(null);
			jPanel.setBounds(new Rectangle(2, 10, 619, 93));
			// jPanel.setBorder(BorderFactory.createLineBorder(Color.gray, 5));
			jPanel.setBorder(border1);
			jPanel.add(jLabel, null);
			jPanel.add(jLabel1, null);
			jPanel.add(jLabel2, null);
			jPanel.add(jLabel4, null);
			jPanel.add(getTxtFirmID(), null);
			jPanel.add(getTxtServerPort(), null);
			jPanel.add(getTxtServerIP(), null);
			jPanel.add(getTxtUDPPort(), null);
			jPanel.add(getTxtPassword(), null);
			jPanel.add(jLabel6, null);
			jPanel.add(getModeA(), null);
			jPanel.add(getModeB(), null);
			jPanel.add(getModeC(), null);
			jPanel.add(getBtConnect(), null);
			jPanel.add(getBtDisconnect(), null);
			jPanel.add(getStartUdpListenButton());
			jPanel.add(getBtStopUDP());

			txtNoThreads = new JTextField();
			txtNoThreads.setText("13");
			txtNoThreads.setEnabled(false);
			txtNoThreads.setFont(new Font("Dialog", Font.PLAIN, 10));
			txtNoThreads.setBounds(548, 7, 66, 23);
			jPanel.add(txtNoThreads);

			jLabel6_1 = new JLabel();
			jLabel6_1.setFont(new Font("Dialog", Font.BOLD, 10));
			jLabel6_1.setText("No of Threads:");
			jLabel6_1.setBounds(466, 6, 88, 23);
			jPanel.add(jLabel6_1);
		}
		return jPanel;
	}

	/**
	 * This method initializes txtFirmID
	 * 
	 * @return javax.swing.JTextField
	 */
	private JTextField getTxtFirmID() {
		if (txtFirmID == null) {
			txtFirmID = new JTextField();
			txtFirmID.setBounds(new Rectangle(92, 59, 41, 23));
			txtFirmID.setFont(new Font("Dialog", Font.PLAIN, 10));
			txtFirmID.setText("057");
		}
		return txtFirmID;
	}

	/**
	 * This method initializes txtServerPort
	 * 
	 * @return javax.swing.JTextField
	 */
	private JTextField getTxtServerPort() {
		if (txtServerPort == null) {
			txtServerPort = new JTextField();
			txtServerPort.setBounds(new Rectangle(90, 29, 110, 23));
			txtServerPort.setFont(new Font("Dialog", Font.PLAIN, 10));
			txtServerPort.setText(TestCommon.SERVER_PORT);
		}
		return txtServerPort;
	}

	/**
	 * This method initializes txtServerIP
	 * 
	 * @return javax.swing.JTextField
	 */
	private JTextField getTxtServerIP() {
		if (txtServerIP == null) {
			txtServerIP = new JTextField();
			txtServerIP.setBounds(new Rectangle(89, 4, 110, 23));
			txtServerIP.setFont(new Font("Dialog", Font.PLAIN, 10));
			txtServerIP.setText(TestCommon.SERVER_IP);
		}
		return txtServerIP;
	}

	/**
	 * This method initializes txtUDPPort
	 * 
	 * @return javax.swing.JTextField
	 */
	private JTextField getTxtUDPPort() {
		if (txtUDPPort == null) {
			txtUDPPort = new JTextField();
			txtUDPPort.setBounds(new Rectangle(384, 6, 66, 23));
			txtUDPPort.setFont(new Font("Dialog", Font.PLAIN, 10));
			txtUDPPort.setText(TestCommon.UDP_PORT);
		}
		return txtUDPPort;
	}

	/**
	 * This method initializes txtPassword
	 * 
	 * @return javax.swing.JPasswordField
	 */
	private JPasswordField getTxtPassword() {
		if (txtPassword == null) {
			txtPassword = new JPasswordField();
			txtPassword.setBounds(new Rectangle(212, 60, 109, 20));
			txtPassword.setText(TestCommon.SERVER_PASSWORD);
		}
		return txtPassword;
	}

	/**
	 * This method initializes modeA
	 * 
	 * @return javax.swing.JRadioButton
	 */
	private JRadioButton getModeA() {
		if (modeA == null) {
			modeA = new JRadioButton();
			buttonGroup.add(modeA);
			modeA.setBounds(new Rectangle(666, 4, 82, 21));
			modeA.setText("Mode A");
			modeA.setFont(new Font("Dialog", Font.BOLD, 10));
			modeA.setSelected(true);
		}
		return modeA;
	}

	/**
	 * This method initializes modeB
	 * 
	 * @return javax.swing.JRadioButton
	 */
	private JRadioButton getModeB() {
		if (modeB == null) {
			modeB = new JRadioButton();
			buttonGroup.add(modeB);
			modeB.setBounds(new Rectangle(666, 31, 69, 21));
			modeB.setFont(new Font("Arian", Font.BOLD, 10));
			modeB.setText("Mode B");
		}
		return modeB;
	}

	/**
	 * This method initializes modeC
	 * 
	 * @return javax.swing.JRadioButton
	 */
	private JRadioButton getModeC() {
		if (modeC == null) {
			modeC = new JRadioButton();
			buttonGroup.add(modeC);
			modeC.setBounds(new Rectangle(666, 58, 89, 21));
			modeC.setFont(new Font("Arian", Font.BOLD, 10));
			modeC.setText("Mode C");
		}
		return modeC;
	}

	/**
	 * This method initializes btConnect
	 * 
	 * @return javax.swing.JButton
	 */
	private JButton getBtConnect() {
		if (btConnect == null) {
			btConnect = new JButton();
			btConnect.setBounds(new Rectangle(212, 4, 109, 23));
			btConnect.setActionCommand("btConnect");
			btConnect.setFont(new Font("Arian", Font.BOLD, 10));
			btConnect.setText("Connect");
			btConnect.setEnabled(false);
			btConnect.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					btConnect_actionPerformed(e);
				}
			});

		}
		return btConnect;
	}

	// Connect to Server
	public void btConnect_actionPerformed(java.awt.event.ActionEvent e) {
		String message = "";
		char mode = 'A';
		if (modeA.isSelected())
			mode = 'A';
		if (modeB.isSelected())
			mode = 'B';
		if (modeC.isSelected())
			mode = 'C';
		int serverPort = Integer.parseInt(this.txtServerPort.getText());
		controller = null;
		try {
			this.controller = EPSServiceController.getInstance(this.txtServerIP
					.getText(), serverPort, this.txtPassword.getText(), mode);
			// boolean result =
			// controller.connectToServer(this.txtServerIP.getText(),
			// serverPort, this.txtPassword.getText(), mode);
			// if(!result){
			// message = "Can not connect to server.";
			// JOptionPane.showMessageDialog(this, message, "Information",
			// JOptionPane.OK_OPTION);
			// return;
			// }
			if (!EPSServiceController.isConnectServerOK())
				this.controller.connectServerAndStartThreads();
			if (EPSServiceController.isConnectServerOK()) {
				btConnect.setEnabled(false);
				btDisconnect.setEnabled(true);
				startSocketDetector();
			} else {
				// controller.releaseInstance();
			}
		} catch (Exception e1) {
			message = e1.getMessage();
			JOptionPane.showMessageDialog(this, message, "Information",
					JOptionPane.OK_OPTION);
			e1.printStackTrace();
		}
	}

	/**
	 * This method initializes btDisconnect
	 * 
	 * @return javax.swing.JButton
	 */
	private JButton getBtDisconnect() {
		if (btDisconnect == null) {
			btDisconnect = new JButton();
			btDisconnect.setBounds(new Rectangle(212, 33, 109, 23));
			btDisconnect.setActionCommand("btDisconnect_actionPerformed");
			btDisconnect.setFont(new Font("Arian", Font.BOLD, 10));
			btDisconnect.setText("Disconnect");
			btDisconnect.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					try {
						// stop detector thread
						detector.setFlag(true);
						detector.interrupt();
						controller.disconnectFromClient();
						btConnect.setEnabled(true);
						btDisconnect.setEnabled(false);
					} catch (Exception e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
			});
			btDisconnect.setEnabled(false);
		}
		return btDisconnect;
	}

	/**
	 * This method initializes startUdpListenButton
	 * 
	 * @return javax.swing.JButton
	 */
	private JButton getStartUdpListenButton() {
		if (startUdpListenButton == null) {
			startUdpListenButton = new JButton();
			startUdpListenButton.setName("btStopUDP");
			// startUdpListenButton.setMargin(new Insets(0, 0, 0, 0));
			startUdpListenButton
					.addActionListener(new java.awt.event.ActionListener() {
						public void actionPerformed(
								final java.awt.event.ActionEvent e) {
							try {
								int udpPort = Integer.parseInt(txtUDPPort
										.getText());
								udpClient = new UDPClient(udpPort);
								// UDPClient.numberThreads =
								// Integer.parseInt(txtNoThreads.getText());
								udpClient.setPriority(Thread.MAX_PRIORITY);
								System.out
										.println("Start UDPClient " + udpPort);
								udpClient.start();
								startUdpListenButton.setEnabled(false);
							} catch (Exception e1) {
								// TODO Auto-generated catch block
								e1.printStackTrace();
							}
						}
					});
			startUdpListenButton.setText("Start UDP Listen");
			startUdpListenButton.setBounds(327, 33, 153, 21);
		}
		return startUdpListenButton;
	}

	/**
	 * This method initializes btStopUDP
	 * 
	 * @return javax.swing.JButton
	 */
	private JButton getBtStopUDP() {
		if (btStopUDP == null) {
			btStopUDP = new JButton();
			btStopUDP.setName("btStopUDP");
			btStopUDP.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(final java.awt.event.ActionEvent e) {
					try {
						System.out.println("Stop UDPClient ");
						udpClient.setStop(true);
						startUdpListenButton.setEnabled(true);
						udpClient = null;
					} catch (Exception e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
			});

			btStopUDP.setText("Stop UDP Listen");
			btStopUDP.setBounds(328, 59, 152, 21);
		}
		return btStopUDP;
	}

	public void sendOrder(ValueObject object) {
		try {
			controller.sendMessageToQueue(object);
		} catch (Exception e1) {
			e1.printStackTrace();
		}
	}

	public void sendOrders(List listOrders, String marketStatus) {
		try {
			Object object;
			NewConditioned_1I new1I;
			for (int i = 0; i < listOrders.size(); i++) {
				System.out.println("Load Test : number " + i);
				object = listOrders.get(i);
				if (object instanceof NewConditioned_1I) {
					new1I = (NewConditioned_1I) object;
					if (marketStatus.equalsIgnoreCase("PreOpen")) {
						if (new1I.getPrice().equalsIgnoreCase("ATC")
								|| new1I.getPrice().equalsIgnoreCase("MP")) {
							controller
									.log("Chuong trinh chan. Can't send order: "
											+ new1I.toString());
							continue;
						}
					} else if (marketStatus.equalsIgnoreCase("Open")) {
						if (new1I.getPrice().equalsIgnoreCase("ATC")
								|| new1I.getPrice().equalsIgnoreCase("MP")
								|| new1I.getPrice().equalsIgnoreCase("ATO")) {
							controller
									.log("Chuong trinh chan. Can't send order: "
											+ new1I.toString());
							continue;
						}
					} else if (marketStatus.equalsIgnoreCase("PreClose")) {
						if (new1I.getPrice().equalsIgnoreCase("MP")
								|| new1I.getPrice().equalsIgnoreCase("ATO")) {
							controller
									.log("Chuong trinh chan. Can't send order: "
											+ new1I.toString());
							continue;
						}
					} else if (marketStatus.equalsIgnoreCase("Close")) {
						// Can't send ATO,ATC,MP,LO trong Close
						controller.log("Chuong trinh chan. Can't send order: "
								+ new1I.toString());
						continue;
					}
				}
				controller.sendMessageToQueue(object);
			}
		} catch (Exception e1) {
			e1.printStackTrace();
		}
	}

	public static void showMessageAndExit(final String message) {
		Runnable doWorkRunnable = new Runnable() {
			public void run() {
				JOptionPane
						.showMessageDialog(MainFrame.getFrames()[0], message);
				System.exit(0);
			}
		};
		SwingUtilities.invokeLater(doWorkRunnable);
	}

} // @jve:decl-index=0:visual-constraint="2,6"
