package eps.com.message.broadcast;

import java.io.Serializable;
import java.io.Serializable;

import eps.com.common.ValueObject;
import java.io.Serializable;
import java.sql.Date;
import java.sql.Timestamp;

import eps.com.common.ValueObject; 
public class BrokerStatusChange_BS  extends ValueObject implements Serializable {
	
	public static final String MessageType="BS";
	
	private long Firm ; 
	private String  AutoMatchHaltFlag ; // " " , "H" , "R"
	private String 	PutthroughHaltFlag ; // " " , "H" , "R"
	
	public long getFirm() {
		return Firm;
	}



	public void setFirm(long firm) {
		Firm = firm;
	}



	public String getAutoMatchHaltFlag() {
		return AutoMatchHaltFlag;
	}



	public void setAutoMatchHaltFlag(String autoMatchHaltFlag) {
		AutoMatchHaltFlag = autoMatchHaltFlag;
	}



	public String getPutthroughHaltFlag() {
		return PutthroughHaltFlag;
	}



	public void setPutthroughHaltFlag(String putthroughHaltFlag) {
		PutthroughHaltFlag = putthroughHaltFlag;
	}



	public BrokerStatusChange_BS()
	{
		
	}
	
	
	
	public static String getMessage_Type() {
		return MessageType ;
	}
	
	
	
	
}
