package eps.com.message.sended;

/**
 * Lớp này minh họa cho cấu trúc của message 1D-Order Change.
 * 
 * @author lequocthai
 */
import java.io.Serializable;

import eps.com.common.ValueObject;

public class OrderChange_1D extends ValueObject implements Serializable {

	private static final long serialVersionUID = 1L;

	/**
	 * Thuộc tính Message_Type có kích thước là 2 bytes, được sử dụng để xác
	 * định kiểu của message trong hệ thống. Hiện tại nó có giá trị mặc định là
	 * 1D (Lưu ý: Phải đọc từ tập tin messageconfg.xml).
	 */
	public static final String MessageType = "1D";
	/**
	 * Thuộc tính Firm có kích thước là 3 bytes, được sử dụng để nhận dạng việc
	 * gửi và nhận từ CTCK nào. Do TTGDCK cung cấp. Các giá thuộc phạm vi sau: +
	 * 1 <= n <= 9215 <nếu 2 bytes thì Mod96> + 1 <= n <= 999 <nếu 3 bytes thì
	 * numeric String>
	 */
	private String Firm;
	/**
	 * Thuộc tính Order_Number có kích thước 8 bytes là một dãy 8 kí tự số được
	 * gán bởi CTCK. Nó được sử dụng để CTCK nhận biết được đâu là lệnh của
	 * mình. Chú ý: Hệ thống SET không kiểm tra giá trị này. Khuôn dạng: 8+
	 * <broker_no> + <running_no>
	 */
	private String OrderNumber;

	/**
	 * Thuộc tính Order_Entry_Date có kích thước 4 byte, có khuôn dạng "DDMM".
	 * Ngày mà lệnh được đưa vào hệ thống SET.
	 */
	private String OrderEntryDate;

	/**
	 * 
	 */
	private String ClientID;

	/**
	 * Có kích thước 17 bytes, bao gồm các khoảng trắng. Không chứa thông tin.
	 */
	private String Filler;

	public OrderChange_1D() {
	}

	public String getFirm() {
		return Firm;
	}

	public void setFirm(String firm) {
		Firm = firm;
	}

	public String getOrderNumber() {
		return OrderNumber;
	}

	public void setOrderNumber(String orderNumber) {
		OrderNumber = orderNumber;
	}

	public String getOrderEntryDate() {
		return OrderEntryDate;
	}

	public void setOrderEntryDate(String orderEntryDate) {
		OrderEntryDate = orderEntryDate;
	}

	public String getClientID() {
		return ClientID;
	}

	public void setClientID(String clientID) {
		ClientID = clientID;
	}

	public String getFiller() {
		return Filler;
	}

	public void setFiller(String filler) {
		Filler = filler;
	}

}
