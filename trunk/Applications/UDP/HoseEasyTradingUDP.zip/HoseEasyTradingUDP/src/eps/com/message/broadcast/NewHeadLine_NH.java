package eps.com.message.broadcast;

import java.io.Serializable;

import eps.com.common.ValueObject;

public class NewHeadLine_NH  extends ValueObject implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	public static final String MessageType="NH";
	
	private long l_NewSNumber;
	private String s_SecuritySymbol;
	private long l_NewsHeadlineLength;
	private long l_TotalNewsStoryPages;
	private String s_NewsHeadlineText;
	
	public NewHeadLine_NH()
	{
		
	}
	
	
	

	public String getS_NewsHeadlineText() {
		return s_NewsHeadlineText;
	}

	public void setS_NewsHeadlineText(String newsHeadlineText) {
		s_NewsHeadlineText = newsHeadlineText;
	}

	public String getS_SecuritySymbol() {
		return s_SecuritySymbol;
	}

	public void setS_SecuritySymbol(String securitySymbol) {
		s_SecuritySymbol = securitySymbol;
	}

	public long getL_NewsHeadlineLength() {
		return l_NewsHeadlineLength;
	}

	public void setL_NewsHeadlineLength(long newsHeadlineLength) {
		l_NewsHeadlineLength = newsHeadlineLength;
	}

	public long getL_NewSNumber() {
		return l_NewSNumber;
	}

	public void setL_NewSNumber(long newSNumber) {
		l_NewSNumber = newSNumber;
	}

	public long getL_TotalNewsStoryPages() {
		return l_TotalNewsStoryPages;
	}

	public void setL_TotalNewsStoryPages(long totalNewsStoryPages) {
		l_TotalNewsStoryPages = totalNewsStoryPages;
	}
}
