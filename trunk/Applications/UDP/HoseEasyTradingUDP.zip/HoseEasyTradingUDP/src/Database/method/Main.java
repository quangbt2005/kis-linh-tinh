package Database.method;
import java.awt.BorderLayout;
import javax.swing.JPanel;
import javax.swing.JFrame;
import java.awt.Dimension;
import javax.swing.JTabbedPane;
import java.awt.Rectangle;
import java.awt.GridBagLayout;
import javax.swing.JButton;
import java.awt.GridBagConstraints;

public class Main extends JFrame {

	private static final long serialVersionUID = 1L;

	private JPanel jContentPane = null;

	private JTabbedPane jTabbedPane_Test = null;

	private JPanel jPTest_PreOpen_ModeB = null;

	private JButton b_PrO_7_sendOrdc1 = null;

	private JButton b_PrO8_sendOrdc2 = null;

	private JButton b_PrO9_CancelvalidOrder = null;

	private JButton b_PrO_10_Cancelrejectedorder = null;

	private JButton b_PrO_12SendbuyingorderofForeignerc2 = null;

	private JButton b_PrO_13SendPTdealc1 = null;

	private JButton b_PrO_14SendPTdealc2 = null;

	private JButton b_PrO15SendPTAdvertisementc1 = null;

	private JButton b_PrO16LoadOrder1 = null;

	private JButton b_PrO11SdborderofFc1 = null;

	private JPanel jPTest_OpenModeB_1 = null;

	private JButton b_O_18Sendorderc3  = null;
	private JButton b_O_19Cancelunmatchedorder  = null;
	private JButton b_O_20Cancelmatchedorder  = null;
	private JButton b_O_21Changeunmatchedorder  = null;
	private JButton b_O_22Changematchedorder  = null;
	private JButton b_O_23Sendorderc4  = null;
	private JButton b_O_24SendPTdealc3  = null; 
	private JButton b_O_25SendPTdealc4= null;
	private JButton b_O_26SendPTAdvertisementc1= null;
	private JButton b_O_27SendPTAdvertisementc2= null;
	private JButton b_O_28SendbuyingorderofForeignerc3= null;
	private JButton b_O_29SendbuyingorderofForeignerc4= null;
	private JButton b_O_30LoadOrder2= null;
	
	private JPanel jPTest_PreCloseModeB_1 = null;
	
	private JButton Pre_Close_32Sendorderc5 = null ;
	private JButton Pre_Close_33Sendorderc6 = null;
	private JButton Pre_Close_34CancelvalidOrder = null;
	private JButton Pre_Close_35Cancelrejectedorder = null ;
	private JButton Pre_Close_36Changeorder = null ;
	private JButton Pre_Close_37LoadOrder3 = null;
	
	/**
	 * This is the default constructor
	 */
	public Main() {
		super();
		initialize();
	}

	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
		this.setSize(968, 584);
		this.setContentPane(getJContentPane());
		this.setTitle("JFrame");
	}

	/**
	 * This method initializes jContentPane
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getJContentPane() {
		if (jContentPane == null) {
			jContentPane = new JPanel();
			jContentPane.setLayout(null);
			jContentPane.add(getJTabbedPane_Test(), null);
		}
		return jContentPane;
	}

	/**
	 * This method initializes jTabbedPane_Test	
	 * 	
	 * @return javax.swing.JTabbedPane	
	 */
	private JTabbedPane getJTabbedPane_Test() {
		if (jTabbedPane_Test == null) {
			jTabbedPane_Test = new JTabbedPane();
			jTabbedPane_Test.setBounds(new Rectangle(-2, 164, 964, 388));
			jTabbedPane_Test.addTab("Test Pre Open Mode B 1", null, getJPTest_PreOpenModeB1(), null);
			jTabbedPane_Test.addTab("Test Open Mode B 1", null, getJPTest_OpenModeB_1(), null);
			jTabbedPane_Test.addTab("Test Open Mode B 1", null, getJPTest_PreCloseModeB_1(), null);
			
		}
		return jTabbedPane_Test;
	}

	/**
	 * This method initializes jPTest_PreOpen1	
	 * 	
	 * @return javax.swing.JPanel	
	 */
	private JPanel getJPTest_PreOpenModeB1() {
		if (jPTest_PreOpen_ModeB == null) {
			jPTest_PreOpen_ModeB = new JPanel();
			jPTest_PreOpen_ModeB.setLayout(null);
			jPTest_PreOpen_ModeB.add(getB_PrO_7_sendOrdc1(), null);
			jPTest_PreOpen_ModeB.add(getB_PrO8_sendOrdc2(), null);
			jPTest_PreOpen_ModeB.add(getB_PrO9_CancelvalidOrder(), null);
			jPTest_PreOpen_ModeB.add(getB_PrO_10_Cancelrejectedorder(), null);
			jPTest_PreOpen_ModeB.add(getB_PrO_12SendbuyingorderofForeignerc2(), null);
			jPTest_PreOpen_ModeB.add(getB_PrO_13SendPTdealc1(), null);
			jPTest_PreOpen_ModeB.add(getB_PrO_14SendPTdealc2(), null);
			jPTest_PreOpen_ModeB.add(getB_PrO15SendPTAdvertisementc1(), null);
			jPTest_PreOpen_ModeB.add(getB_PrO16LoadOrder1(), null);
			jPTest_PreOpen_ModeB.add(getB_PrO11SdborderofFc1(), null);
		}
		return jPTest_PreOpen_ModeB;
	}

	/**
	 * This method initializes b_PrO_7_sendOrdc1	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getB_PrO_7_sendOrdc1() {
		if (b_PrO_7_sendOrdc1 == null) {
			b_PrO_7_sendOrdc1 = new JButton();
			b_PrO_7_sendOrdc1.setBounds(new Rectangle(6, 16, 183, 42));
			b_PrO_7_sendOrdc1.setText("b_PrO_7_sendOrdc1");
			
		}
		return b_PrO_7_sendOrdc1;
	}

	/**
	 * This method initializes b_PrO8_sendOrdc2	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getB_PrO8_sendOrdc2() {
		if (b_PrO8_sendOrdc2 == null) {
			b_PrO8_sendOrdc2 = new JButton();
			b_PrO8_sendOrdc2.setBounds(new Rectangle(195, 16, 183, 43));
			b_PrO8_sendOrdc2.setText("b_PrO8_sendOrdc2");
		}
		return b_PrO8_sendOrdc2;
	}

	/**
	 * This method initializes b_PrO9_CancelvalidOrder	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getB_PrO9_CancelvalidOrder() {
		if (b_PrO9_CancelvalidOrder == null) {
			b_PrO9_CancelvalidOrder = new JButton();
			b_PrO9_CancelvalidOrder.setBounds(new Rectangle(388, 16, 183, 43));
			b_PrO9_CancelvalidOrder.setText("b_PrO9_CancelvalidOrder");
		}
		return b_PrO9_CancelvalidOrder;
	}

	/**
	 * This method initializes b_PrO_10_Cancelrejectedorder	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getB_PrO_10_Cancelrejectedorder() {
		if (b_PrO_10_Cancelrejectedorder == null) {
			b_PrO_10_Cancelrejectedorder = new JButton();
			b_PrO_10_Cancelrejectedorder.setBounds(new Rectangle(582, 16, 183, 43));
			b_PrO_10_Cancelrejectedorder.setText("b_PrO_10_Cancelrejectedorder");
			
		}
		return b_PrO_10_Cancelrejectedorder;
	}

	/**
	 * This method initializes b_PrO_12SendbuyingorderofForeignerc2	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getB_PrO_12SendbuyingorderofForeignerc2() {
		if (b_PrO_12SendbuyingorderofForeignerc2 == null) {
			b_PrO_12SendbuyingorderofForeignerc2 = new JButton();
			b_PrO_12SendbuyingorderofForeignerc2.setBounds(new Rectangle(8, 80, 180, 48));
			b_PrO_12SendbuyingorderofForeignerc2.setText("b_PrO_12SendbuyingorderofForeignerc2");
		}
		return b_PrO_12SendbuyingorderofForeignerc2;
	}

	/**
	 * This method initializes b_PrO_13SendPTdealc1	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getB_PrO_13SendPTdealc1() {
		if (b_PrO_13SendPTdealc1 == null) {
			b_PrO_13SendPTdealc1 = new JButton();
			b_PrO_13SendPTdealc1.setBounds(new Rectangle(195, 80, 180, 48));
			b_PrO_13SendPTdealc1.setText("b_PrO_13SendPTdealc1");
		}
		return b_PrO_13SendPTdealc1;
	}

	/**
	 * This method initializes b_PrO_14SendPTdealc2	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getB_PrO_14SendPTdealc2() {
		if (b_PrO_14SendPTdealc2 == null) {
			b_PrO_14SendPTdealc2 = new JButton();
			b_PrO_14SendPTdealc2.setBounds(new Rectangle(388, 80, 180, 48));
			b_PrO_14SendPTdealc2.setText("b_PrO_14SendPTdealc2");
			
		}
		return b_PrO_14SendPTdealc2;
	}

	/**
	 * This method initializes b_PrO15SendPTAdvertisementc1	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getB_PrO15SendPTAdvertisementc1() {
		if (b_PrO15SendPTAdvertisementc1 == null) {
			b_PrO15SendPTAdvertisementc1 = new JButton();
			b_PrO15SendPTAdvertisementc1.setBounds(new Rectangle(582, 80, 180, 48));
			b_PrO15SendPTAdvertisementc1.setText("b_PrO15SendPTAdvertisementc1");
		}
		return b_PrO15SendPTAdvertisementc1;
	}

	/**
	 * This method initializes b_PrO16LoadOrder1	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getB_PrO16LoadOrder1() {
		if (b_PrO16LoadOrder1 == null) {
			b_PrO16LoadOrder1 = new JButton();
			b_PrO16LoadOrder1.setBounds(new Rectangle(773, 79, 180, 48));
			b_PrO16LoadOrder1.setText("b_PrO16LoadOrder1");
		}
		return b_PrO16LoadOrder1;
	}

	/**
	 * This method initializes b_PrO11SdborderofFc1	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getB_PrO11SdborderofFc1() {
		if (b_PrO11SdborderofFc1 == null) {
			b_PrO11SdborderofFc1 = new JButton();
			b_PrO11SdborderofFc1.setBounds(new Rectangle(773, 16, 178, 43));
			b_PrO11SdborderofFc1.setText("b_PrO11SdborderofFc1");
		}
		return b_PrO11SdborderofFc1;
	}

	public JButton getB_O_18Sendorderc3() {
		if ( b_O_18Sendorderc3 == null )
		{
			b_O_18Sendorderc3 = new JButton();
			b_O_18Sendorderc3.setBounds(new Rectangle(6, 16, 183, 42));
			b_O_18Sendorderc3.setText("b_O_18Sendorderc3");
			
		}

		return b_O_18Sendorderc3;
	}

	public JButton getB_O_19Cancelunmatchedorder() {
		if ( b_O_19Cancelunmatchedorder==null)
		{
			b_O_19Cancelunmatchedorder = new JButton();
			b_O_19Cancelunmatchedorder.setBounds(new Rectangle(195, 16, 183, 43));
			b_O_19Cancelunmatchedorder.setText("b_O_19Cancelunmatchedorder");
		}
		return b_O_19Cancelunmatchedorder;
	}

	public JButton getB_O_20Cancelmatchedorder() {
		if ( b_O_20Cancelmatchedorder == null )
		{
			b_O_20Cancelmatchedorder = new JButton();
			b_O_20Cancelmatchedorder.setBounds(new Rectangle(388, 16, 183, 43));
			b_O_20Cancelmatchedorder.setText("b_O_20Cancelmatchedorder");
		}

		return b_O_20Cancelmatchedorder;
	}

	public JButton getB_O_21Changeunmatchedorder() {
		if ( b_O_21Changeunmatchedorder == null )
		{
			b_O_21Changeunmatchedorder = new JButton();
			b_O_21Changeunmatchedorder.setBounds(new Rectangle(582, 16, 183, 43));
			b_O_21Changeunmatchedorder.setText("b_O_21Changeunmatchedorder");
			
		}
		return b_O_21Changeunmatchedorder;
	}

	public JButton getB_O_22Changematchedorder() {
		if ( b_O_22Changematchedorder == null )
		{
			b_O_22Changematchedorder = new JButton();
			b_O_22Changematchedorder.setBounds(new Rectangle(8, 80, 180, 48));
			b_O_22Changematchedorder.setText("b_O_22Changematchedorder");
		}
		return b_O_22Changematchedorder;
	}

	public JButton getB_O_23Sendorderc4() {
		if ( b_O_23Sendorderc4 == null )
		{
			b_O_23Sendorderc4 = new JButton();
			b_O_23Sendorderc4.setBounds(new Rectangle(195, 80, 180, 48));
			b_O_23Sendorderc4.setText("b_O_23Sendorderc4");
		}
		return b_O_23Sendorderc4;
	}

	public JButton getB_O_24SendPTdealc3() {
		if ( b_O_24SendPTdealc3 == null )
		{
			b_O_24SendPTdealc3 = new JButton();
			b_O_24SendPTdealc3.setBounds(new Rectangle(388, 80, 180, 48));
			b_O_24SendPTdealc3.setText("b_O_24SendPTdealc3");
		}

		return b_O_24SendPTdealc3;
	}

	public JButton getB_O_25SendPTdealc4() {
		if ( b_O_25SendPTdealc4 == null )
		{
			b_O_25SendPTdealc4 = new JButton();
			b_O_25SendPTdealc4.setBounds(new Rectangle(582, 80, 180, 48));
			b_O_25SendPTdealc4.setText("b_O_25SendPTdealc4");
		}
		return b_O_25SendPTdealc4;
	}

	public JButton getB_O_26SendPTAdvertisementc1() {
		if ( b_O_26SendPTAdvertisementc1 == null )
		{
			b_O_26SendPTAdvertisementc1 = new JButton();
			b_O_26SendPTAdvertisementc1.setBounds(new Rectangle(773, 79, 180, 48));
			b_O_26SendPTAdvertisementc1.setText("b_O_26SendPTAdvertisementc1");
		}
		return b_O_26SendPTAdvertisementc1;
	}

	

	public JButton getB_O_28SendbuyingorderofForeignerc3() {
		if ( b_O_28SendbuyingorderofForeignerc3 == null )
		{
			b_O_28SendbuyingorderofForeignerc3 = new JButton();
			b_O_28SendbuyingorderofForeignerc3.setBounds(new Rectangle(773, 16, 178, 43));
			b_O_28SendbuyingorderofForeignerc3.setText("b_O_28SendbuyingorderofForeignerc3");
		}
		return b_O_28SendbuyingorderofForeignerc3;
	}

	public JButton getB_O_27SendPTAdvertisementc2() {
		if (b_O_27SendPTAdvertisementc2 == null )
		{
		}
		return b_O_27SendPTAdvertisementc2;
	}

	public JButton getB_O_29SendbuyingorderofForeignerc4() {
		if ( b_O_29SendbuyingorderofForeignerc4 == null )
		{
		}
		return b_O_29SendbuyingorderofForeignerc4;
	}

	public JButton getB_O_30LoadOrder2() {
		if ( b_O_30LoadOrder2 == null )
		{
		
		}

		return b_O_30LoadOrder2;
	}

	public JPanel getJPTest_OpenModeB_1() {
	
			if (jPTest_OpenModeB_1 == null) {
				jPTest_OpenModeB_1 = new JPanel();
				jPTest_OpenModeB_1.setLayout(null);
				jPTest_OpenModeB_1.add(getB_O_18Sendorderc3(), null);
				jPTest_OpenModeB_1.add(getB_O_19Cancelunmatchedorder(), null);
				jPTest_OpenModeB_1.add(getB_O_20Cancelmatchedorder(), null);
				jPTest_OpenModeB_1.add(getB_O_21Changeunmatchedorder(), null);
				jPTest_OpenModeB_1.add(getB_O_22Changematchedorder(), null);
				jPTest_OpenModeB_1.add(getB_O_23Sendorderc4(), null);
				jPTest_OpenModeB_1.add(getB_O_24SendPTdealc3(), null);
				jPTest_OpenModeB_1.add(getB_O_25SendPTdealc4(), null);
				jPTest_OpenModeB_1.add(getB_O_26SendPTAdvertisementc1(), null);
				//jPTest_OpenModeB_1.add(b_O_27SendPTAdvertisementc2(), null);
				//jPTest_OpenModeB_1.add(b_O_28SendbuyingorderofForeignerc3(), null);
				//jPTest_OpenModeB_1.add(b_O_29SendbuyingorderofForeignerc4(), null);
				//jPTest_OpenModeB_1.add(b_O_30LoadOrder2(), null);
		}
			return jPTest_OpenModeB_1;
		
	}

	public JButton getPre_Close_32Sendorderc5() {
		if ( Pre_Close_32Sendorderc5 == null )
		{	
			Pre_Close_32Sendorderc5 = new JButton();
			Pre_Close_32Sendorderc5.setBounds(new Rectangle(6, 16, 183, 42));
			Pre_Close_32Sendorderc5.setText("Pre_Close_32Sendorderc5");
			
		}
		return Pre_Close_32Sendorderc5;
	}

	public JButton getPre_Close_33Sendorderc6() {
		if ( Pre_Close_33Sendorderc6 == null )
		{
			Pre_Close_33Sendorderc6 = new JButton();
			Pre_Close_33Sendorderc6.setBounds(new Rectangle(195, 16, 183, 43));
			Pre_Close_33Sendorderc6.setText("Pre_Close_33Sendorderc6");
		}
		return Pre_Close_33Sendorderc6;
	}

	public JPanel getJPTest_PreCloseModeB_1() {
		if ( jPTest_PreCloseModeB_1 == null )
		{
			
			jPTest_PreCloseModeB_1 = new JPanel();
			jPTest_PreCloseModeB_1.setLayout(null);
			jPTest_PreCloseModeB_1.add(getPre_Close_32Sendorderc5(), null);
			jPTest_PreCloseModeB_1.add(getPre_Close_33Sendorderc6(), null);
			jPTest_PreCloseModeB_1.add(getPre_Close_34CancelvalidOrder(), null);
			jPTest_PreCloseModeB_1.add(getPre_Close_35Cancelrejectedorder(), null);
			jPTest_PreCloseModeB_1.add(getPre_Close_36Changeorder(), null);
			jPTest_PreCloseModeB_1.add(getPre_Close_37LoadOrder3(), null);		}
		
		return jPTest_PreCloseModeB_1;
	}

	public JButton getPre_Close_35Cancelrejectedorder() {
		if ( Pre_Close_35Cancelrejectedorder == null )
		{
			Pre_Close_35Cancelrejectedorder = new JButton();
			Pre_Close_35Cancelrejectedorder.setBounds(new Rectangle(582, 16, 183, 43));
			Pre_Close_35Cancelrejectedorder.setText("Pre_Close_35Cancelrejectedorder");
		}

		return Pre_Close_35Cancelrejectedorder;
	}

	public JButton getPre_Close_34CancelvalidOrder() {
		if ( Pre_Close_34CancelvalidOrder == null )
		{
			Pre_Close_34CancelvalidOrder = new JButton();
			Pre_Close_34CancelvalidOrder.setBounds(new Rectangle(8, 80, 180, 48));
			Pre_Close_34CancelvalidOrder.setText("Pre_Close_34CancelvalidOrder");
		}
		return Pre_Close_34CancelvalidOrder;
	}

	public JButton getPre_Close_36Changeorder() {
		if (Pre_Close_36Changeorder == null )
		{
			Pre_Close_36Changeorder = new JButton();
			Pre_Close_36Changeorder.setBounds(new Rectangle(195, 80, 180, 48));
			Pre_Close_36Changeorder.setText("Pre_Close_36Changeorder");
		}
		return Pre_Close_36Changeorder;
	}

	public JButton getPre_Close_37LoadOrder3() {
		if ( Pre_Close_37LoadOrder3 == null )
		{
			Pre_Close_37LoadOrder3 = new JButton();
			Pre_Close_37LoadOrder3.setBounds(new Rectangle(388, 80, 180, 48));
			Pre_Close_37LoadOrder3.setText("Pre_Close_37LoadOrder3");
		}
		return Pre_Close_37LoadOrder3;
	}

	

	
	
	

	

	

	
	

	

}  //  @jve:decl-index=0:visual-constraint="10,10"
