package Database.method;

import java.sql.*;

public class DbMrg {
	
	public DbMrg()
	{
		
	}
	
	public Connection makeConnection() throws SQLException
	{
	
		Connection connectionMySQL = null ;
		try { 
			
			Class.forName("com.mysql.jdbc.Driver");
			connectionMySQL = DriverManager.getConnection("jdbc:mysql://172.25.2.112/esms?noAccessToProcedureBodies=true", 
			    		"hottohot", "hot2hot@2008");
		}
		catch (Exception e) 
		{
			 	System.err.println ("Cannot connect to database server");
	            e.printStackTrace();	  
	        	 throw new RuntimeException(e.getMessage());
	                 
	     }
		return connectionMySQL ;
		
	}
	
	
	public void releaseConnection(Connection Conn) throws SQLException {
		
		Conn.close() ;
		
	}
	
	
}
